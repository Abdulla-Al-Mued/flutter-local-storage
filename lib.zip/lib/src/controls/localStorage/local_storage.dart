import 'dart:convert';

import 'package:care4u/src/models/Dpd_Cms_User_Login_Model.dart';
import 'package:get_storage/get_storage.dart';

class LocalStorage {
  final getStorage = GetStorage('dStorage');
  final userLoginDetails = 'userLoginDetails';
  final passcode = 'passcode';
  final userId = 'userId';

  String get getPasscode => getStorage.read(passcode) ?? '';

  String get getUserId => getStorage.read(userId) ?? '0';

  void setPasscode({required String value}) =>
      getStorage.write(passcode, value);

  DpdCmsUserLoginModel get userLoginDetail {
    final userData = getStorage.read(userLoginDetails);
    if (userData != null) {
      final data = json.decode(userData);
      final returnData = DpdCmsUserLoginModel.fromJson(data);
      return returnData;
    } else {
      return DpdCmsUserLoginModel();
    }
  }

  void setUserLoginDetails({required DpdCmsUserLoginModel model}) {
    getStorage.write(userLoginDetails, json.encode(model));
  }
}
