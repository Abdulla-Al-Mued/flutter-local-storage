import 'dart:convert';
import 'package:care4u/src/controls/localDatabaseHandler/data_download_into_sql.dart';
import 'package:care4u/src/controls/localStorage/local_storage.dart';
import 'package:care4u/src/models/Response/response.dart';
import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:http/http.dart' as http;

import '../../models/Dpd_Cms_User_Login_Model.dart';
import '../localDatabaseHandler/local_database_handler.dart';

class ApiHandler {
  LocalStorage localStorage = LocalStorage();

  final _baseUrl = 'http://homecare.alphabytetech.com/CMS_UK/';
  //final _baseUrl = 'http://118.67.223.117/CMS_UK/';


  /*=========================>
  Get Authority Permission From Api
  <==========================*/
  Future<int> loginUser({required Map<String, dynamic> data}) async {
    try {
      final data2 = {
     // "P_USER_CODE":"mamun@alphabytetech.com","P_USER_PASSWORD":"Mamun@321"
      "P_USER_CODE":data["P_USER_CODE"],"P_USER_PASSWORD":data["P_USER_PASSWORD"]
      };
      final jsonData = json.encode(data);
      final response = await http.post(
        Uri.parse('${_baseUrl}AUTH/DPD_CMS_USER_LOGIN.php'),
        headers: {
          "Access-Control-Allow-Origin": "*",
          "Content-Type": "application/json; charset=UTF-8",
          "Accept": "*/*",
        },
        body: jsonData,
      );
      print('res code'+response.statusCode.toString());
      if (response.statusCode == 504) {
        return 2;
      }
      if (response.statusCode == 200) {
        final resValue = response.body.toString();
        final resData = DpdCmsUserLoginModel.fromJson(json.decode(resValue));
        if (resData.code=="400"||resData.value!.isEmpty) {
          return 0;
        } else {
          //await tableGenerator();
          LocalStorage().setUserLoginDetails(model: resData);
          final data2 = resData.toJson();
          DataDownloadIntoSql().downloadData(
            data: data2['Value'][0],
            tableName: "DPD_CMS_USER_LOGIN",
          );
          return 1;
        }
      } else {
        return 2;
      }
    } catch (e) {
      return 2;
      rethrow;
    }
  }


  Future<bool> checkOut(Map<String, dynamic> data) async {
    try {

      final jsonData = json.encode(data);
      final response = await http.post(
        Uri.parse('${_baseUrl}UPLOAD/DPD_CMS_CARER_APP_UPLOAD.php'),
        headers: {
          "Access-Control-Allow-Origin": "*",
          "Content-Type": "application/json; charset=UTF-8",
          "Accept": "*/*",
        },
        body: jsonData,
      );
      print("ERROR"+response.statusCode.toString());
      if (response.statusCode == 200) {
        final resValue = response.body.toString();
        print("ERROR"+resValue);
        final resData = Response.fromJson(json.decode(resValue));
        if (resData.statusCode == "204" || resData.data != 1) {
          Fluttertoast.showToast(
              msg: resData.toString(),
              toastLength: Toast.LENGTH_LONG, // Duration for which the toast will be visible
              gravity: ToastGravity.BOTTOM, // Position of the toast on the screen
              backgroundColor: Colors.black, // Background color of the toast
              textColor: Colors.white, // Text color of the toast message
              fontSize: 16.0 // Font size of the toast message
          );
          return true;
        } else {
          print(resData.toString());
          return true;
        }

      } else {
        Fluttertoast.showToast(
            msg: "res not 200",
            toastLength: Toast.LENGTH_LONG, // Duration for which the toast will be visible
            gravity: ToastGravity.BOTTOM, // Position of the toast on the screen
            backgroundColor: Colors.black, // Background color of the toast
            textColor: Colors.white, // Text color of the toast message
            fontSize: 16.0 // Font size of the toast message
        );
        return true;
      }
    } catch (e) {
      Fluttertoast.showToast(
          msg: "upload problem",
          toastLength: Toast.LENGTH_LONG, // Duration for which the toast will be visible
          gravity: ToastGravity.BOTTOM, // Position of the toast on the screen
          backgroundColor: Colors.black, // Background color of the toast
          textColor: Colors.white, // Text color of the toast message
          fontSize: 16.0 // Font size of the toast message
      );
      return true;
      rethrow;
    }
  }

  Future<bool> checkInOut(Map<String, dynamic> data) async {
    try {

      final jsonData = json.encode(data);
      final response = await http.post(
        Uri.parse('${_baseUrl}UPLOAD/DPD_CMS_CARER_VISIT_CHK_INOUT.php'),
        headers: {
          "Access-Control-Allow-Origin": "*",
          "Content-Type": "application/json; charset=UTF-8",
          "Accept": "*/*",
        },
        body: jsonData,
      );
      if (response.statusCode == 200) {
        final resValue = response.body.toString();
        print("EEEE"+resValue);
        final resData = Response.fromJson(json.decode(resValue));
        if (resData.statusCode == "200" && resData.values == "1") {
          print("EEEE"+resData.toString());
          return true;
        } else {

          Fluttertoast.showToast(
              msg: resData.toString(),
              toastLength: Toast.LENGTH_LONG, // Duration for which the toast will be visible
              gravity: ToastGravity.BOTTOM, // Position of the toast on the screen
              backgroundColor: Colors.black, // Background color of the toast
              textColor: Colors.white, // Text color of the toast message
              fontSize: 16.0 // Font size of the toast message
          );

          return true;
        }

      } else {
        Fluttertoast.showToast(
            msg: "NOT 200",
            toastLength: Toast.LENGTH_LONG, // Duration for which the toast will be visible
            gravity: ToastGravity.BOTTOM, // Position of the toast on the screen
            backgroundColor: Colors.black, // Background color of the toast
            textColor: Colors.white, // Text color of the toast message
            fontSize: 16.0 // Font size of the toast message
        );
        return true;
      }
    } catch (e) {
      Fluttertoast.showToast(
          msg: "check in out problem",
          toastLength: Toast.LENGTH_LONG,
          gravity: ToastGravity.BOTTOM,
          backgroundColor: Colors.black,
          textColor: Colors.white,
          fontSize: 16.0
      );
      return true;
      rethrow;
    }
  }


  Future<bool?> storeApiDataIntoDb(
      String? userId, String tableName) async {


    final _database = await LocalDatabaseHandler().getDatabase;

    final data = {"P_USER_ID":userId};
    final jsonData = json.encode(data);
    try {
      final response = await http.post(
        Uri.parse('${_baseUrl}DOWNLOAD/$tableName.php'),
        headers: {
          "Access-Control-Allow-Origin": "*",
          "Content-Type": "application/json; charset=UTF-8",
          "Accept": "*/*"

        },
        body: jsonData,
      );


      if (response.statusCode == 200) {

        final resData = json.decode(response.body.toString());

        //print("table name: $tableName");


        /*  final DpdTaskListModel dpdTaskListModel =
            DpdTaskListModel.fromJson(resData);*/
        int dataLength = resData['Value'].length;

        final countResult = await _database?.rawQuery('SELECT COUNT(*) FROM $tableName');
        //print(countResult.toString());
        final count = countResult?.first.values.first as int? ?? 0;
        print(count.toString());
        print(tableName);

        if(tableName=="DPD_CMS_CARER_LIST"){
          print("DPD_CMS_CARER_LIST DDDD"+resData['Value'].toString());
          //print("DPD_CARER_VISIT_SUMM_RPT $count");
          //await _database?.rawQuery('DELETE FROM DPD_CMS_CARER_LIST');
        }

        if (count > 0) {
          print("DELETE $tableName");
          await _database?.rawQuery('DELETE FROM $tableName');
        }

        // if(resData['Value']==""){
        //   print("empty");
        //   return true;
        // }



        if (dataLength > 0) {

          int count = 0;

          for(int i=0;i<dataLength;i++)
            {
              if(tableName == "DPD_CLIENT_VISIT_TYPE_DTL") {
                count++;
              }
              DataDownloadIntoSql().downloadData(
                data: resData['Value'][i],
                tableName: tableName,
              );
            }

          return true;
        } else {
          return false;
        }
      }
    } catch (e) {
      Fluttertoast.showToast(
          msg: "Something went wrong",
          toastLength: Toast.LENGTH_SHORT,
          gravity: ToastGravity.BOTTOM,
          backgroundColor: Colors.black,
          textColor: Colors.white,
          fontSize: 16.0
      );
      rethrow;
    }
    return null;
  } //task list end

  Future<bool> downloadData() async {
    try {
      String? userId = "${localStorage.userLoginDetail.value![0].userId}";


      await storeApiDataIntoDb(userId, "DPD_CARER_VISIT_CMPNNSHP_DTL");
      await storeApiDataIntoDb(userId, "DPD_CARER_VISIT_HOUSWRK_DTL");
      await storeApiDataIntoDb(userId, "DPD_CMS_CARER_CLN_DTWS_SCH_LST");

      apiCall1(userId);

      await storeApiDataIntoDb(userId, "DPD_CARER_VISIT_PERCARE_DTL");
      await storeApiDataIntoDb(userId, "DPD_CARER_VISIT_MEDICATION_DTL");
      await storeApiDataIntoDb(userId, "DPD_TASK_LIST_SUMM_RPT");

      apiCall2(userId);

      await storeApiDataIntoDb(userId, "DPD_CARER_VISIT_UNBLEDLVR_DTL");
      await storeApiDataIntoDb(userId, "DPD_CARER_VISIT_REPOSNG_DTL");
      await storeApiDataIntoDb(userId, "DPD_CARER_VISIT_BODY_MAP_DTL");

      apiCall3(userId);

      await storeApiDataIntoDb(userId, "DPD_CARER_VISIT_GROCERI_DTL");
      await storeApiDataIntoDb(userId, "DPD_CARER_VISIT_HOUSHLDCRS_DTL");
      await storeApiDataIntoDb(userId, "DPD_CARER_VISIT_SUMM_RPT");

      await storeApiDataIntoDb(userId, "DPD_CLIENT_VISIT_TYPE_DTL_LST");
      await storeApiDataIntoDb(userId, "DPD_CLIENT_VISIT_TYPE_MST_LST");


      //new

      return true;
    } catch (e) {
      print('Error downloading data: $e');
      // Handle or log the error appropriately

      return false;

    }
  }

  Future<void> apiCall1(String userId) async {


    await storeApiDataIntoDb(userId, "DPD_CLIENT_BIOGRAPHY");
    await storeApiDataIntoDb(userId, "DPD_CLIENT_KEY_CONTACT_DTL");
    await storeApiDataIntoDb(userId, "DPD_CLIENT_VISIT_TYPE_DTL");
    await storeApiDataIntoDb(userId, "DPD_CLIENT_MEDICATION_DTL");
    await storeApiDataIntoDb(userId, "DPD_EMOJI_LIST");
    await storeApiDataIntoDb(userId, "DPD_CMS_CARER_LIST");
    await storeApiDataIntoDb(userId, "DPD_ORG_ALL_CLIENT_LIST");

  }


  Future<void> apiCall2(String userId) async {

    await storeApiDataIntoDb(userId, "DPD_CMS_ORG_PARAMETER");
    await storeApiDataIntoDb(userId, "DPD_DOC_DTL_LIST");
    await storeApiDataIntoDb(userId, "DPD_FRND_FMLY_LIST");
    await storeApiDataIntoDb(userId, "DPD_PERSONAL_DTL_LIST");
    await storeApiDataIntoDb(userId, "DPD_CARER_CHK_INOUT_STATUS");
    await storeApiDataIntoDb(userId, "DPD_TASK_LIST");

  }

  Future<void> apiCall3(String userId) async {

    await storeApiDataIntoDb(userId, "DPD_CARER_VISIT_TOIAST_DTL");
    await storeApiDataIntoDb(userId, "DPD_CARER_VISIT_LAUNDRY_DTL");
    await storeApiDataIntoDb(userId, "DPD_CLIENT_VISIT_AGNCY_NOTE");
    await storeApiDataIntoDb(userId, "DPD_CARER_VISIT_DRINKS_DTL");
    await storeApiDataIntoDb(userId, "DPD_CARER_VISIT_DTL_RPT");
    await storeApiDataIntoDb(userId, "DPD_CARER_VISIT_FOOD_DTL");

  }


}
