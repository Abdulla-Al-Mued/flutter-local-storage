
import 'package:flutter/material.dart';
import 'package:permission_handler/permission_handler.dart';

Future<void> checkPermission0(Permission permission, BuildContext context) async {

  final status = await permission.request();

  if(status.isGranted){

  }
  else{
    final status = await permission.request();

    if(status.isGranted){


    }
    else{
      const snackBar = SnackBar(
        content: Text('permission not given'),
        duration: Duration(seconds: 3), // Adjust the duration as needed
      );
      ScaffoldMessenger.of(context as BuildContext).showSnackBar(snackBar);
    }
  }

}