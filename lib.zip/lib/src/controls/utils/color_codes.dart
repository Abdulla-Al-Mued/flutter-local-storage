
import 'dart:ui';

const grayColor = Color(0xFF4E4E4E);
const grayColor2 = Color(0xFF4a4e69);
const grayColor3 = Color(0x804a4e69);
const grayBgColor = Color(0xffeaeaea);
const text = Color(0xFF6d6875);
const heading = Color(0xFF264653);
const lightPrimaryColor = Color(0xFF7B65F5);
const primaryColor = Color(0xFF2D889B);
const primaryColor2 = Color(0xFF135860);
const color1 = Color(0xFF2660A4);
const color2 = Color(0xFFC47335);