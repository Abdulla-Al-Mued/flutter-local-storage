import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import 'color_codes.dart';

class CustomAppBar extends StatelessWidget implements PreferredSizeWidget {
  final String title;
  final Color backgroundColor;

  const CustomAppBar({Key? key, required this.title, required this.backgroundColor}) : super(key: key);

  @override
  Size get preferredSize => const Size.fromHeight(kToolbarHeight * 2); //1.5

  @override
  Widget build(BuildContext context) {
    return AppBar(
      systemOverlayStyle: const SystemUiOverlayStyle(
          statusBarColor: primaryColor,
          statusBarIconBrightness: Brightness.light,
          systemNavigationBarColor: Colors.white),
      backgroundColor: backgroundColor,
      elevation: 0,
      centerTitle: true,
      title: Padding(
        padding: const EdgeInsets.only(bottom:5.0),
        child: Text(title),
      ),
      titleTextStyle: TextStyle(
        fontSize: MediaQuery.of(context).size.height*0.025,
        color: Colors.white,
        fontFamily: 'Montserrat',
        fontWeight: FontWeight.w800,
      ),
      flexibleSpace: FlexibleSpaceBar(
        background: CustomPaint(
          painter: RPSCustomPainter(),
        ),
      ),
      iconTheme: const IconThemeData(color: Colors.white),
    );
  }
}


class RPSCustomPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    Paint paint_fill_0 = Paint()
      ..color = const Color(0xFF2D889B)
      ..style = PaintingStyle.fill
      ..strokeWidth = size.width * 0.00
      ..strokeCap = StrokeCap.butt
      ..strokeJoin = StrokeJoin.miter;

    Path path_0 = Path();
    path_0.moveTo(size.width * 0.0005463, size.height * 0.6306500);
    path_0.quadraticBezierTo(size.width * 0.5988333, size.height * 0.6230250,
        size.width * 0.7847593, size.height * 0.6223500);
    path_0.quadraticBezierTo(size.width * 0.9808519, size.height * 0.6295250,
        size.width * 1.0005463, size.height * 1.0032750);
    path_0.lineTo(size.width * 0.9999352, size.height * 0.0006750);
    path_0.lineTo(size.width * 0.0000741, size.height * 0.0007250);
    path_0.lineTo(size.width * 0.0005463, size.height * 0.6306500);
    path_0.close();

    canvas.drawPath(path_0, paint_fill_0);

    // Layer 1

    Paint paint_stroke_0 = Paint()
      ..color = const Color.fromARGB(0, 255, 255, 255)
      ..style = PaintingStyle.stroke
      ..strokeWidth = size.width * 0.00
      ..strokeCap = StrokeCap.butt
      ..strokeJoin = StrokeJoin.miter;

    canvas.drawPath(path_0, paint_stroke_0);
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) {
    return true;
  }
}

