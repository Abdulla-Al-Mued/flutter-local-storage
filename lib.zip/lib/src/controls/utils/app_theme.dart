import 'package:flutter/material.dart';

import 'color_codes.dart';

ThemeData themeData = ThemeData(
  useMaterial3: true,
  visualDensity: VisualDensity.adaptivePlatformDensity,
  colorScheme: const ColorScheme.light(
    // primary: Color(0xFF0966A4),
    primary: primaryColor,
    secondary: Colors.grey,
    background: Colors.white,
  ),
);
