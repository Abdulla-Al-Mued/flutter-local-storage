import 'package:connectivity_plus/connectivity_plus.dart';
import 'package:flutter/cupertino.dart';

class InternetConnectionCheck extends ChangeNotifier{

  Connectivity connectivity = Connectivity();
  bool isConnected = true;

  Future<void> checkConnection() async{
    connectivity.onConnectivityChanged.listen((event) {
      if (event.contains(ConnectivityResult.mobile)) {
        isConnected = true;
      } else if (event.contains(ConnectivityResult.wifi)) {
        isConnected = true;
      } else if (event.contains(ConnectivityResult.ethernet)) {
        isConnected = true;
      } else if (event.contains(ConnectivityResult.vpn)) {
        isConnected = true;
      } else if (event.contains(ConnectivityResult.bluetooth)) {
        isConnected = true;
      } else if (event.contains(ConnectivityResult.other)) {
        isConnected = true;
      } else if (event.contains(ConnectivityResult.none)) {
        isConnected = false;
      }
      notifyListeners();
    });

  }

}