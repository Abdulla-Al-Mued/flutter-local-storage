
import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:geolocator/geolocator.dart';
import 'package:get_ip_address/get_ip_address.dart';
import 'package:intl/intl.dart';
import 'package:location/location.dart';

String dateToDays(String dateString){
  List<String> dateParts = dateString.split('/');
  int day = int.parse(dateParts[0]);
  int month = int.parse(dateParts[1]);
  int year = int.parse(dateParts[2]);

  // Create a DateTime object from the parsed components
  DateTime date = DateTime(year, month, day);

  // Calculate the difference between the parsed date and today's date
  Duration difference = DateTime.now().difference(date);

  // Convert the difference to years
  double yearsDifference = difference.inDays / 365;

  // Format the result as a string and return
  return yearsDifference.toStringAsFixed(2);

}


Future<String> getIp() async {
  try {
    var ipAddress = IpAddress(type: RequestType.json);
    dynamic data = await ipAddress.getIpAddress();


    return data['ip'];

  } on IpAddressException catch (exception) {
    /// Handle the exception.
    print(exception.message);

    return "";
  }
}

String getCurrentDate() {
  DateTime now = DateTime.now();
  String formattedDate = DateFormat('dd/MM/yyyy').format(now);
  return formattedDate;
}

Future<bool> checkPermission() async {
  bool serviceEnabled;
  LocationPermission permission;

  serviceEnabled = await Geolocator.isLocationServiceEnabled();
  if (!serviceEnabled) {
    return Future.error('Location services are disabled.');
  }

  permission = await Geolocator.checkPermission();
  if (permission == LocationPermission.denied) {
    permission = await Geolocator.requestPermission();
    if (permission == LocationPermission.denied) {
      return false;
    }
  }

  if (permission == LocationPermission.deniedForever) {
    // Permissions are denied forever, handle appropriately.
    return false;
  }

  // When we reach here, permissions are granted and we can
  // continue accessing the position of the device.
  return true;
}

void showSnackBar(BuildContext context, String text){
  var snackBar = SnackBar(
    backgroundColor: Theme.of(context).colorScheme.primary,
    content: Text(text),
    duration: const Duration(seconds: 2),
  );
  ScaffoldMessenger.of(context).showSnackBar(snackBar);
}

void showToastInfo(String message){
  Fluttertoast.showToast(
      msg: message,
      toastLength: Toast.LENGTH_LONG, // Duration for which the toast will be visible
      gravity: ToastGravity.BOTTOM, // Position of the toast on the screen
      backgroundColor: Colors.black, // Background color of the toast
      textColor: Colors.white, // Text color of the toast message
      fontSize: 16.0 // Font size of the toast message
  );
}

int getDurationFromDate(String startDate1, String startTime){

  DateTime parsedTime = DateFormat("HH:mm").parse(startTime.trim());

  int hours1 = parsedTime.hour;
  int minutes1 = parsedTime.minute;

  DateTime parsedDate = DateFormat("dd/MM/yyyy").parse(startDate1.trim());


  int day = parsedDate.day;
  int month = parsedDate.month;
  int year = parsedDate.year;



  DateTime startDate = DateTime(year, month, day, hours1, minutes1);
  DateTime endDate = DateTime(DateTime.now().year, DateTime.now().month, DateTime.now().day, DateTime.now().hour, DateTime.now().minute); // 5:10 PM on February 19, 2024


  Duration duration = endDate.difference(startDate);

  int totalMinutes = duration.inMinutes;



  return totalMinutes;
}



int parseTo24HourFormate(String timeString){


  DateTime parsedTime = DateFormat("h:mm a").parse(timeString);


  int hours = parsedTime.hour;
  int minutes = parsedTime.minute;


  
  return hours;
}

String convertTo12HourFormat(String time24 , BuildContext context) {
  final time = TimeOfDay.fromDateTime(DateFormat('HH:mm').parse(time24));
  return time.format(context); // context should be available in the widget's build method
}

Future<bool> checkLocationStatus() async {
  Location location = Location();

  if (!await location.serviceEnabled()) {
    bool serviceStatus = await location.requestService();
    if (!serviceStatus) {
      // Handle if the user refuses to enable location services
      print('User denied to enable location services.');

      return true;
    }
    else {
      return true;
    }

  }else{
    return true;
  }
}


Future<Position> determinePosition() async {
  bool serviceEnabled;
  LocationPermission permission;

  checkLocationStatus();

  // Test if location services are enabled.
  serviceEnabled = await Geolocator.isLocationServiceEnabled();
  if (!serviceEnabled) {
    // Location services are not enabled don't continue
    // accessing the position and request users of the
    // App to enable the location services.
    return Future.error('Location services are disabled.');
  }

  permission = await Geolocator.checkPermission();
  if (permission == LocationPermission.denied) {
    permission = await Geolocator.requestPermission();
    if (permission == LocationPermission.denied) {
      // Permissions are denied, next time you could try
      // requesting permissions again (this is also where
      // Android's shouldShowRequestPermissionRationale
      // returned true. According to Android guidelines
      // your App should show an explanatory UI now.
      return Future.error('Location permissions are denied');
    }
  }

  if (permission == LocationPermission.deniedForever) {
    // Permissions are denied forever, handle appropriately.
    return Future.error(
        'Location permissions are permanently denied, we cannot request permissions.');
  }

  // When we reach here, permissions are granted and we can
  // continue accessing the position of the device.
  return await Geolocator.getCurrentPosition();
}


