String CLIENT_IMAGE_URL = 'http://homecare.caresoft4u.com/Home/DisplayClientImage?fileName=';
String CARER_IMAGE_URL = 'http://homecare.caresoft4u.com/Home/DisplayCareWorkerImage?fileName=';