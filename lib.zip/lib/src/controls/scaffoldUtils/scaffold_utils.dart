import 'package:flutter/material.dart';

Future<void> toggleMsg({
  required String text,
  required Color color,
  required IconData iconData,
  required BuildContext context,
}) async {
  Future.delayed(
    Duration.zero,
    () {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          backgroundColor: Colors.transparent,
          elevation: 0,
          content: Container(
            width: double.infinity,
            padding: const EdgeInsets.all(20),
            decoration: BoxDecoration(
              color: color,
              borderRadius: const BorderRadius.all(Radius.circular(10)),
            ),
            child: Row(
              children: [
                Icon(iconData, color: Colors.white),
                Expanded(child: Text(text)),
              ],
            ),
          ),
        ),
      );
    },
  );
}
