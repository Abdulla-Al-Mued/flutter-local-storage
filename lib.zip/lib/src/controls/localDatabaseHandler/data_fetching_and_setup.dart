import 'package:care4u/src/controls/localDatabaseHandler/local_database_handler.dart';

import '../../models/Dpd_Cms_Carer_Cln_Dtws_Sch_Lst_Model.dart';
import 'constants.dart';

Future<void> tableGenerator() async {
  final LocalDatabaseHandler localDatabaseHandler = LocalDatabaseHandler();
  await localDatabaseHandler.initDatabase();

  for (var key in databaseTables.keys) {
    try {
      await localDatabaseHandler
          .doesTableExist(tableName: key)
          .then((value) async {
        if (!value) {
          await localDatabaseHandler.createTable(
              sqlInject: databaseTables[key]!);
        }
      });
    } catch (e) {
      rethrow;
    }
  }
}


