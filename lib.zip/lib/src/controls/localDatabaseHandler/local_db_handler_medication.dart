
import 'package:care4u/src/models/insertion/Medication.dart';
import 'package:intl/intl.dart';
import 'package:sqflite/sqflite.dart';
import 'local_database_handler.dart';

class MedicationHandler {

  final LocalDatabaseHandler dbHandler = LocalDatabaseHandler();

  Future<List<Map<String, dynamic>>> getMedicationSchedules(int clientId, String masterId) async {
    Database? db = await dbHandler.getDatabase;

    List<Map<String, dynamic>>? result = await db?.rawQuery('''
SELECT * FROM (SELECT  A.CLIENT_MEDICATION_DTL_ID,A.CLIENT_ID, DOSAGE,
    A.MONDAY_SCHEDULE,
    A.TUESDAY_SCHEDULE,
    A.WEDNESDAY_SCHEDULE,
    A.THURSDAY_SCHEDULE,
    A.FRIDAY_SCHEDULE,
    A.SATURDAY_SCHEDULE,
    A.MORNING_SCHEDULE,
    A.LUNCHTIME_SCHEDULE,
    A.SUNDAY_SCHEDULE, MEDICATION_NAME,NULL CARER_VISIT_MST_ID, NULL TAKEN_REMARKS, NULL TAKEN_STATUS, NULL NOT_TAKEN_REMARKS, NULL NOT_TAKEN_STATUS FROM DPD_CLIENT_MEDICATION_DTL A 
WHERE A.CLIENT_MEDICATION_DTL_ID NOT IN (SELECT CLIENT_MEDICATION_DTL_ID 
                                         FROM CMS_CARER_VISIT_MEDICATION WHERE CLIENT_MEDICATION_DTL_ID IS NOT NULL
										 AND MORNING_SCHEDULE = 'Y' AND ${getDay()} = 'Y'
										 AND CARER_VISIT_MST_ID=?
										 AND CLIENT_ID = ?
										 )
AND MORNING_SCHEDULE = 'Y' AND ${getDay()} = 'Y'
AND CLIENT_ID = ?										 
UNION
SELECT CLIENT_MEDICATION_DTL_ID,CLIENT_ID, DOSAGE,
    MONDAY_SCHEDULE,
    TUESDAY_SCHEDULE,
    WEDNESDAY_SCHEDULE,
    THURSDAY_SCHEDULE,
    FRIDAY_SCHEDULE,
    SATURDAY_SCHEDULE,
    MORNING_SCHEDULE,
    LUNCHTIME_SCHEDULE,
    SUNDAY_SCHEDULE, MEDICATION_NAME,CARER_VISIT_MST_ID, TAKEN_REMARKS, TAKEN_STATUS, NOT_TAKEN_REMARKS, NOT_TAKEN_STATUS
                                         FROM CMS_CARER_VISIT_MEDICATION WHERE CLIENT_MEDICATION_DTL_ID IS NOT NULL
										 AND CLIENT_ID = ?	AND MORNING_SCHEDULE = 'Y' AND ${getDay()} = 'Y'
										 AND CARER_VISIT_MST_ID=?)
  ''', [masterId,clientId,clientId,clientId, masterId]);



    if(result!.isNotEmpty){

      print(result);
      return result;
    }
    else{
      return[];
    }

  }

  Future<List<Map<String, dynamic>>> getMedicationLunchSchedules(int clientId, String masterId) async {
    Database? db = await dbHandler.getDatabase;

    List<Map<String, dynamic>>? result = await db?.rawQuery('''
SELECT * FROM (SELECT  A.CLIENT_MEDICATION_DTL_ID,A.CLIENT_ID, DOSAGE,
    A.MONDAY_SCHEDULE,
    A.TUESDAY_SCHEDULE,
    A.WEDNESDAY_SCHEDULE,
    A.THURSDAY_SCHEDULE,
    A.FRIDAY_SCHEDULE,
    A.SATURDAY_SCHEDULE,
    A.MORNING_SCHEDULE,
    A.LUNCHTIME_SCHEDULE,
    A.SUNDAY_SCHEDULE, MEDICATION_NAME,NULL CARER_VISIT_MST_ID, NULL TAKEN_REMARKS, NULL TAKEN_STATUS, NULL NOT_TAKEN_REMARKS, NULL NOT_TAKEN_STATUS FROM DPD_CLIENT_MEDICATION_DTL A 
WHERE A.CLIENT_MEDICATION_DTL_ID NOT IN (SELECT CLIENT_MEDICATION_DTL_ID 
                                         FROM CMS_CARER_VISIT_MEDICATION WHERE CLIENT_MEDICATION_DTL_ID IS NOT NULL
										 AND LUNCHTIME_SCHEDULE = 'Y' AND ${getDay()} = 'Y'
										 AND CARER_VISIT_MST_ID=?
										 AND CLIENT_ID = ?
										 )
AND LUNCHTIME_SCHEDULE = 'Y' AND ${getDay()} = 'Y'
AND CLIENT_ID = ?										 
UNION
SELECT CLIENT_MEDICATION_DTL_ID,CLIENT_ID, DOSAGE,
    MONDAY_SCHEDULE,
    TUESDAY_SCHEDULE,
    WEDNESDAY_SCHEDULE,
    THURSDAY_SCHEDULE,
    FRIDAY_SCHEDULE,
    SATURDAY_SCHEDULE,
    MORNING_SCHEDULE,
    LUNCHTIME_SCHEDULE,
    SUNDAY_SCHEDULE, MEDICATION_NAME,CARER_VISIT_MST_ID, TAKEN_REMARKS, TAKEN_STATUS, NOT_TAKEN_REMARKS, NOT_TAKEN_STATUS
                                         FROM CMS_CARER_VISIT_MEDICATION WHERE CLIENT_MEDICATION_DTL_ID IS NOT NULL
										 AND CLIENT_ID = ?	AND LUNCHTIME_SCHEDULE = 'Y' AND ${getDay()} = 'Y'
										 AND CARER_VISIT_MST_ID=?)
  ''', [masterId,clientId,clientId,clientId, masterId]);



    if(result!.isNotEmpty){


      print(result);
      return result;
    }
    else{
      return[];
    }

  }

  Future<List<Map<String, dynamic>>> getMedicationEveningSchedules(int clientId, String masterId) async {
    Database? db = await dbHandler.getDatabase;

    List<Map<String, dynamic>>? result = await db?.rawQuery('''
SELECT * FROM (SELECT  A.CLIENT_MEDICATION_DTL_ID,A.CLIENT_ID, DOSAGE,
    A.MONDAY_SCHEDULE,
    A.TUESDAY_SCHEDULE,
    A.WEDNESDAY_SCHEDULE,
    A.THURSDAY_SCHEDULE,
    A.FRIDAY_SCHEDULE,
    A.SATURDAY_SCHEDULE,
    A.MORNING_SCHEDULE,
    A.EVENING_SCHEDULE,
    A.SUNDAY_SCHEDULE, MEDICATION_NAME,NULL CARER_VISIT_MST_ID, NULL TAKEN_REMARKS, NULL TAKEN_STATUS, NULL NOT_TAKEN_REMARKS, NULL NOT_TAKEN_STATUS FROM DPD_CLIENT_MEDICATION_DTL A 
WHERE A.CLIENT_MEDICATION_DTL_ID NOT IN (SELECT CLIENT_MEDICATION_DTL_ID 
                                         FROM CMS_CARER_VISIT_MEDICATION WHERE CLIENT_MEDICATION_DTL_ID IS NOT NULL
										 AND EVENING_SCHEDULE = 'Y' AND ${getDay()} = 'Y'
										 AND CARER_VISIT_MST_ID=?
										 AND CLIENT_ID = ?
										 )
AND EVENING_SCHEDULE = 'Y' AND ${getDay()} = 'Y'
AND CLIENT_ID = ?										 
UNION
SELECT CLIENT_MEDICATION_DTL_ID,CLIENT_ID, DOSAGE,
    MONDAY_SCHEDULE,
    TUESDAY_SCHEDULE,
    WEDNESDAY_SCHEDULE,
    THURSDAY_SCHEDULE,
    FRIDAY_SCHEDULE,
    SATURDAY_SCHEDULE,
    MORNING_SCHEDULE,
    EVENING_SCHEDULE,
    SUNDAY_SCHEDULE, MEDICATION_NAME,CARER_VISIT_MST_ID, TAKEN_REMARKS, TAKEN_STATUS, NOT_TAKEN_REMARKS, NOT_TAKEN_STATUS
                                         FROM CMS_CARER_VISIT_MEDICATION WHERE CLIENT_MEDICATION_DTL_ID IS NOT NULL
										 AND CLIENT_ID = ?	AND EVENING_SCHEDULE = 'Y' AND ${getDay()} = 'Y'
										 AND CARER_VISIT_MST_ID=?)
  ''', [masterId,clientId,clientId,clientId, masterId]);



    if(result!.isNotEmpty){


      print(result);
      return result;
    }
    else{
      return[];
    }

  }

  Future<List<Map<String, dynamic>>> getMedicationBedTimeSchedules(int clientId, String masterId) async {
    Database? db = await dbHandler.getDatabase;

    List<Map<String, dynamic>>? result = await db?.rawQuery('''
SELECT * FROM (SELECT  A.CLIENT_MEDICATION_DTL_ID,A.CLIENT_ID, DOSAGE,
    A.MONDAY_SCHEDULE,
    A.TUESDAY_SCHEDULE,
    A.WEDNESDAY_SCHEDULE,
    A.THURSDAY_SCHEDULE,
    A.FRIDAY_SCHEDULE,
    A.SATURDAY_SCHEDULE,
    A.MORNING_SCHEDULE,
    A.BEDTIME_SCHEDULE,
    A.SUNDAY_SCHEDULE, MEDICATION_NAME,NULL CARER_VISIT_MST_ID, NULL TAKEN_REMARKS, NULL TAKEN_STATUS, NULL NOT_TAKEN_REMARKS, NULL NOT_TAKEN_STATUS FROM DPD_CLIENT_MEDICATION_DTL A 
WHERE A.CLIENT_MEDICATION_DTL_ID NOT IN (SELECT CLIENT_MEDICATION_DTL_ID 
                                         FROM CMS_CARER_VISIT_MEDICATION WHERE CLIENT_MEDICATION_DTL_ID IS NOT NULL
										 AND BEDTIME_SCHEDULE = 'Y' AND ${getDay()} = 'Y'
										 AND CARER_VISIT_MST_ID=?
										 AND CLIENT_ID = ?
										 )
AND BEDTIME_SCHEDULE = 'Y' AND ${getDay()} = 'Y'
AND CLIENT_ID = ?										 
UNION
SELECT CLIENT_MEDICATION_DTL_ID,CLIENT_ID, DOSAGE,
    MONDAY_SCHEDULE,
    TUESDAY_SCHEDULE,
    WEDNESDAY_SCHEDULE,
    THURSDAY_SCHEDULE,
    FRIDAY_SCHEDULE,
    SATURDAY_SCHEDULE,
    MORNING_SCHEDULE,
    BEDTIME_SCHEDULE,
    SUNDAY_SCHEDULE, MEDICATION_NAME,CARER_VISIT_MST_ID, TAKEN_REMARKS, TAKEN_STATUS, NOT_TAKEN_REMARKS, NOT_TAKEN_STATUS
                                         FROM CMS_CARER_VISIT_MEDICATION WHERE CLIENT_MEDICATION_DTL_ID IS NOT NULL
										 AND CLIENT_ID = ?	AND BEDTIME_SCHEDULE = 'Y' AND ${getDay()} = 'Y'
										 AND CARER_VISIT_MST_ID=?)
  ''', [masterId,clientId,clientId,clientId, masterId]);



    if(result!.isNotEmpty){

      print("BED TIME");
      print(result);

      return result;
    }
    else{
      return[];
    }

  }

  Future<List<Map<String, dynamic>>> getMedicationAsNeededSchedules(int clientId, String masterId) async {
    Database? db = await dbHandler.getDatabase;

    List<Map<String, dynamic>>? result = await db?.rawQuery('''
SELECT * FROM (SELECT  A.CLIENT_MEDICATION_DTL_ID,A.CLIENT_ID, DOSAGE,
    A.MONDAY_SCHEDULE,
    A.TUESDAY_SCHEDULE,
    A.WEDNESDAY_SCHEDULE,
    A.THURSDAY_SCHEDULE,
    A.FRIDAY_SCHEDULE,
    A.SATURDAY_SCHEDULE,
    A.MORNING_SCHEDULE,
    A.AS_NEEDED_SCHEDULE,
    A.SUNDAY_SCHEDULE, MEDICATION_NAME,NULL CARER_VISIT_MST_ID, NULL TAKEN_REMARKS, NULL TAKEN_STATUS, NULL NOT_TAKEN_REMARKS, NULL NOT_TAKEN_STATUS FROM DPD_CLIENT_MEDICATION_DTL A 
WHERE A.CLIENT_MEDICATION_DTL_ID NOT IN (SELECT CLIENT_MEDICATION_DTL_ID 
                                         FROM CMS_CARER_VISIT_MEDICATION WHERE CLIENT_MEDICATION_DTL_ID IS NOT NULL
										 AND AS_NEEDED_SCHEDULE = 'Y' AND ${getDay()} = 'Y'
										 AND CARER_VISIT_MST_ID=?
										 AND CLIENT_ID = ?
										 )
AND AS_NEEDED_SCHEDULE = 'Y' AND ${getDay()} = 'Y'
AND CLIENT_ID = ?										 
UNION
SELECT CLIENT_MEDICATION_DTL_ID,CLIENT_ID, DOSAGE,
    MONDAY_SCHEDULE,
    TUESDAY_SCHEDULE,
    WEDNESDAY_SCHEDULE,
    THURSDAY_SCHEDULE,
    FRIDAY_SCHEDULE,
    SATURDAY_SCHEDULE,
    MORNING_SCHEDULE,
    BEDTIME_SCHEDULE,
    SUNDAY_SCHEDULE, MEDICATION_NAME,CARER_VISIT_MST_ID, TAKEN_REMARKS, TAKEN_STATUS, NOT_TAKEN_REMARKS, NOT_TAKEN_STATUS
                                         FROM CMS_CARER_VISIT_MEDICATION WHERE CLIENT_MEDICATION_DTL_ID IS NOT NULL
										 AND CLIENT_ID = ?	AND AS_NEEDED_SCHEDULE = 'Y' AND ${getDay()} = 'Y'
										 AND CARER_VISIT_MST_ID=?)
  ''', [masterId,clientId,clientId,clientId, masterId]);



    if(result!.isNotEmpty){


      print(result);
      return result;
    }
    else{
      return[];
    }

  }

  Future<int?> insertOrUpdateMedication(CarerVisitMedication medication, String visitTime) async {
    Database? db = await dbHandler.getDatabase;

    // Check if the record already exists
    List<Map<String, dynamic>>? existingRecords = await db?.query(
      'CMS_CARER_VISIT_MEDICATION',
      where: "CLIENT_MEDICATION_DTL_ID = ? AND CARER_VISIT_MST_ID = ? AND CLIENT_ID = ? AND $visitTime = 'Y'",
      whereArgs: [medication.medicationDetailId, medication.carerVisitMstId, medication.clientId],
    );

    if (existingRecords != null && existingRecords.isNotEmpty) {
      // Record exists, perform update
      return await db?.update(
        'CMS_CARER_VISIT_MEDICATION',
        medication.toMap(),
        where: "CLIENT_MEDICATION_DTL_ID = ? AND CARER_VISIT_MST_ID = ? AND CLIENT_ID = ? AND $visitTime = 'Y'",
        whereArgs: [medication.medicationDetailId, medication.carerVisitMstId, medication.clientId],
      );
    } else {
      // Record does not exist, perform insert
      return await db?.insert('CMS_CARER_VISIT_MEDICATION', medication.toMap());
    }
  }

  Future<void> deleteAllMedications() async {
    Database? db = await dbHandler.getDatabase;
    await db?.delete('CMS_CARER_VISIT_MEDICATION');
  }

  String getDay() {
    String visitDay = "";

    if (getCurrentDay() == 'Monday') {
      visitDay = "MONDAY_SCHEDULE";
    }
    if (getCurrentDay() == 'Tuesday') {
      visitDay = "TUESDAY_SCHEDULE";
    }
    if (getCurrentDay() == 'Wednesday') {
      visitDay = "WEDNESDAY_SCHEDULE";
    }
    if (getCurrentDay() == 'Thursday') {
      visitDay = "THURSDAY_SCHEDULE";
    }
    if (getCurrentDay() == 'Friday') {
      visitDay = "FRIDAY_SCHEDULE";
    }
    if (getCurrentDay() == 'Saturday') {
      visitDay = "SATURDAY_SCHEDULE";
    }
    if (getCurrentDay() == 'Sunday') {
      visitDay = "SUNDAY_SCHEDULE";
    }

    return visitDay;
  }

  String getCurrentDay() {
    DateTime now = DateTime.now();

    String formattedDate = DateFormat('EEEE').format(now);

    return formattedDate;
  }



}