import 'package:care4u/src/controls/localStorage/local_storage.dart';
import 'package:care4u/src/controls/utils/Tools.dart';
import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:sqflite/sqflite.dart';

import '../apiHandler/api_handler.dart';
import 'local_database_handler.dart';

class VisitHandler {
  final LocalDatabaseHandler dbHandler = LocalDatabaseHandler();
  late Map<String, dynamic> data;
  ApiHandler _apiHandler = ApiHandler();
  LocalStorage localStorage = LocalStorage();

  Future<List<Map<String, dynamic>>> getVisitData(
      String carerVisitMstId) async {
    Database? db = await dbHandler.getDatabase;
    List<Map<String, dynamic>> result = await db!.rawQuery('''
    SELECT 
        cms.CHECK_IN_TIME,
        cms.CHECK_IN_DATE,
        cms.CARER_ID2,
        cms.CLIENT_VISIT_TYPE_MST_ID,
        cms.IS_SCHEDULED,
        visitType.VISIT_TYPE_NAME
    FROM CMS_CARER_VISIT_MST AS cms
    JOIN DPD_CLIENT_VISIT_TYPE_MST_LST AS visitType
    ON cms.CLIENT_VISIT_TYPE_MST_ID = visitType.CLIENT_VISIT_TYPE_MST_ID
    WHERE cms.CARER_VISIT_MST_ID = ?
  ''', [carerVisitMstId]);

    if (result.isNotEmpty) {
      //print(result);
      return result;
    } else {
      print("AAAAAAAAAAAAAAA no data found");
      return [];
    }
  }

  Future<List<Map<String, dynamic>>> getUnUploadedData() async {
    Database? db = await dbHandler.getDatabase;
    List<Map<String, dynamic>> result = await db!.rawQuery('''
    SELECT CARER_VISIT_MST_ID 
FROM CMS_CARER_VISIT_MST 
WHERE CHECK_IN_TIME IS NOT NULL AND CHECK_OUT_TIME IS NOT NULL;
  ''');

    if (result.isNotEmpty) {
      //print(result);
      return result;
    } else {
      print("AAAAAAAAAAAAAAA no data found");
      return [];
    }
  }

  Future<String> isTimeEditAble(String orgCode) async {
    Database? db = await dbHandler.getDatabase;
    List<Map<String, dynamic>> result = await db!.rawQuery('''
    SELECT ALLW_CARER_EDIT_CHECKIN_TIME
  FROM DPD_CMS_ORG_PARAMETER
  WHERE ORG_CODE = ?
  ''', [orgCode]);

    if (result.isNotEmpty) {
      return result.first['ALLW_CARER_EDIT_CHECKIN_TIME'];
    } else {
      print("no data found");
      return 'Y';
    }
  }

  Future<Map<String, dynamic>> getCheckInDetails(String carerVisitMstId) async {
    Database? db = await dbHandler.getDatabase;
    List<Map<String, dynamic>> result = await db!.rawQuery('''
    SELECT CHECK_IN_DATE, CHECK_IN_TIME
    FROM CMS_CARER_VISIT_MST
    WHERE CARER_VISIT_MST_ID = ?
  ''', [carerVisitMstId]);

    if (result.isNotEmpty) {
      return result.first;
    } else {
      return {}; // Return an empty map if no data is found
    }
  }

  Future<void> updateCheckOut(String checkOutDate, String checkOutTime,
      String checkOutLat, String checkOutLong, String mstId, String alert, String alertText, String durationFromDate, String summary) async {
    final Database? db = await dbHandler.getDatabase;

    print("master id " + mstId);

    await db?.update(
      'CMS_CARER_VISIT_MST',
      {
        'CHECK_OUT_DATE ': checkOutDate,
        'CHECK_OUT_TIME': checkOutTime,
        'CHECK_OUT_LATTITUDE': checkOutLat,
        'CHECK_OUT_LONGITUDE': checkOutLong,
        'RAISE_ALERT': alert,
        'ALERT_DTL': alertText,
        'WORKING_TIME': durationFromDate,
      },
      where: 'CARER_VISIT_MST_ID = ?',
      whereArgs: [mstId],
    );
  }

  Future<bool> getAllVisitData(String carerVisitMstId) async {

    final Database? db = await dbHandler.getDatabase;

    List<Map<String, dynamic>>? result = await db?.rawQuery('''
      SELECT 
          cvm.CARER_VISIT_MST_ID,
          cvm.ORG_CODE,
          cvm.CLIENT_DATEWISE_SCH_ID,
          cvm.CLIENT_ID,
          cvm.CLIENT_CODE,
          cvm.CLIENT_VISIT_TYPE_MST_ID,
          cvm.VISIT_DATE,
          cvm.CHECK_IN_DATE,
          cvm.CHECK_IN_TIME,
          cvm.CHECK_IN_LATTITUDE,
          cvm.CHECK_IN_LONGITUDE,
          cvm.CARER_ID,
          cvm.CARER_CODE,
          cvm.ANOTHER_CARER_STATUS,
          cvm.CARER_ID2,
          cvm.CARER_CODE2,
          cvm.HOW_DID_CLIENT_EMOJI_CODE,
          cvm.VISIT_SUMMARY,
          cvm.RAISE_ALERT,
          cvm.ALERT_DTL,
          cvm.CHECK_OUT_DATE,
          cvm.CHECK_OUT_TIME,
          cvm.WORKING_TIME,
          cvm.CHECK_OUT_LATTITUDE,
          cvm.CHECK_OUT_LONGITUDE,
          ccgf.TASK_CODE AS GROCERIES_TASK_CODE,
          ccgf.GROCERIES,
          ccd.TASK_CODE AS DRINKS_TASK_CODE,
          ccd.DRINKS,
          cch.TASK_CODE AS HOUSEWORK_TASK_CODE,
          cch.HOUSEWORK,
          ccta.TASK_CODE AS TOILET_ASSISTANT_TASK_CODE,
          ccta.TOILET_ASSISTANT,
          ccr.TASK_CODE AS REPOSITIONING_TASK_CODE,
          ccr.REPOSITIONING,
          ccrp.TASK_CODE AS COMPANIONSHIP_RESPITE_TASK_CODE,
          ccrp.COMPANIONSHIP_RESPITE,
          ccl.TASK_CODE AS LAUNDRY_TASK_CODE,
          ccl.LAUNDRY,
          cchc.TASK_CODE AS HOUSEHOLD_CHORES_TASK_CODE,
          cchc.HOUSEHOLD_CHORES,
          ccudd.TASK_CODE AS UNABLE_DELIVER_DTL_TASK_CODE,
          ccudd.UNABLE_DELIVER_DTL,
          ccpc.TASK_CODE AS PERSONAL_CARE_TASK_CODE,
          ccpc.PERSONAL_CARE,
          food.TASK_CODE AS FOOD_TASK_CODE,
          food.FOOD,
          body.TASK_CODE AS BODY_TASK_CODE,
          medic.TASK_CODE AS MEDIC_TASK_CODE
          FROM
          CMS_CARER_VISIT_MST AS cvm
          LEFT JOIN
          CMS_CARER_VISIT_GROCERIES AS ccgf
          ON
          cvm.CARER_VISIT_MST_ID = ccgf.CARER_VISIT_MST_ID
          LEFT JOIN
          CMS_CARER_VISIT_DRINKS AS ccd
          ON
          cvm.CARER_VISIT_MST_ID = ccd.CARER_VISIT_MST_ID
          LEFT JOIN
          CMS_CARER_VISIT_HOUSEWORK AS cch
          ON
          cvm.CARER_VISIT_MST_ID = cch.CARER_VISIT_MST_ID
          LEFT JOIN
          CMS_CARER_VISIT_TOILET_ASSIST AS ccta
          ON
          cvm.CARER_VISIT_MST_ID = ccta.CARER_VISIT_MST_ID
          LEFT JOIN
          CMS_CARER_VISIT_REPOSITIONING AS ccr
          ON
          cvm.CARER_VISIT_MST_ID = ccr.CARER_VISIT_MST_ID
          LEFT JOIN
          CMS_CARER_VISIT_CMPNNSHP_RESPT AS ccrp
          ON
          cvm.CARER_VISIT_MST_ID = ccrp.CARER_VISIT_MST_ID
          LEFT JOIN
          CMS_CARER_VISIT_LAUNDRY AS ccl
          ON
          cvm.CARER_VISIT_MST_ID = ccl.CARER_VISIT_MST_ID
          LEFT JOIN
          CMS_CARER_VISIT_HOUSHLD_CHORES AS cchc
          ON
          cvm.CARER_VISIT_MST_ID = cchc.CARER_VISIT_MST_ID
          LEFT JOIN
          CMS_CARER_VISIT_UNBLE_DLVR_DTL AS ccudd
          ON
          cvm.CARER_VISIT_MST_ID = ccudd.CARER_VISIT_MST_ID
          LEFT JOIN
          CMS_CARER_VISIT_PERSONAL_CARE AS ccpc
          ON
          cvm.CARER_VISIT_MST_ID = ccpc.CARER_VISIT_MST_ID
          LEFT JOIN
          CMS_CARER_VISIT_FOOD AS food
          ON
          cvm.CARER_VISIT_MST_ID = food.CARER_VISIT_MST_ID
          LEFT JOIN
          CMS_CARER_VISIT_BODY_MAP AS body
          ON
          cvm.CARER_VISIT_MST_ID = body.CARER_VISIT_MST_ID
          LEFT JOIN
          CMS_CARER_VISIT_MEDICATION AS medic
          ON
          cvm.CARER_VISIT_MST_ID = medic.CARER_VISIT_MST_ID
          WHERE
          cvm.CARER_VISIT_MST_ID = ?
      ''', [carerVisitMstId]);


    Map<String, List<String>> medicationData = await getMedicationData(carerVisitMstId);
    print("MEDIC: "+medicationData.toString());
    //return true;
    List<Map<String, dynamic>> bodyMapData = await getBodyMapData(carerVisitMstId);

    print(bodyMapData);

    // 1 means ok
    // 2 means not ok
    // 3 means not done any assign task

    if (result!.isNotEmpty) {
      print("PRINT ALL DATA");
      print(result.first['BODY_TASK_CODE']);
      print(result.first['MEDIC_TASK_CODE']);


      data = {
        "P_CARER_VISIT_MST_ID": result.first['CARER_VISIT_MST_ID'],
        "P_ORG_CODE": result.first['ORG_CODE'],
        "P_CLIENT_DATEWISE_SCH_ID": result.first['CLIENT_DATEWISE_SCH_ID'],
        "P_CLIENT_ID": result.first['CLIENT_ID'],
        "P_CLIENT_CODE": result.first['CLIENT_CODE'],
        "P_CLIENT_VISIT_TYPE_MST_ID":
        result.first['CLIENT_VISIT_TYPE_MST_ID'],
        "P_VISIT_DATE": result.first['VISIT_DATE'],
        "P_CHECK_IN_DATE": result.first['CHECK_IN_DATE'],
        "P_CHECK_IN_TIME": result.first['CHECK_IN_TIME'],
        "P_CHECK_IN_LATTITUDE": result.first['CHECK_IN_LATTITUDE'],
        "P_CHECK_IN_LONGITUDE": result.first['CHECK_IN_LONGITUDE'],
        "P_CARER_ID": result.first['CARER_ID'],
        "P_CARER_CODE": result.first['CARER_CODE'],
        "P_ANOTHER_CARER_STATUS": result.first['ANOTHER_CARER_STATUS'],
        "P_CARER_ID2": result.first['CARER_ID2'],
        "P_CARER_CODE2": result.first['CARER_CODE2'],
        "P_HOW_DID_CLIENT_EMOJI_CODE":
        result.first['HOW_DID_CLIENT_EMOJI_CODE'],
        "P_VISIT_SUMMARY": result.first['VISIT_SUMMARY'],
        "P_RAISE_ALERT": result.first['RAISE_ALERT'],
        "P_ALERT_DTL": result.first['ALERT_DTL'],
        "P_CHECK_OUT_DATE": result.first['CHECK_OUT_DATE'],
        "P_CHECK_OUT_TIME": result.first['CHECK_OUT_TIME'],
        "P_WORKING_TIME": result.first['WORKING_TIME'],
        "P_CHECK_OUT_LATTITUDE": result.first['CHECK_OUT_LATTITUDE'],
        "P_CHECK_OUT_LONGITUDE": result.first['CHECK_OUT_LONGITUDE'],
        "P_GROCERIES_TASK_CODE": result.first['GROCERIES_TASK_CODE'],
        "P_GROCERIES": result.first['GROCERIES'],
        "P_DRINKS_TASK_CODE": result.first['DRINKS_TASK_CODE'],
        "P_DRINKS": result.first['DRINKS'],
        "P_FOOD_TASK_CODE": result.first['FOOD_TASK_CODE'],
        "P_FOOD": result.first['FOOD'],
        "P_HOUSEWORK_TASK_CODE": result.first['HOUSEWORK_TASK_CODE'],
        "P_HOUSEWORK": result.first['HOUSEWORK'],
        "P_TOILET_ASST_TASK_CODE": result.first['TOILET_ASSISTANT_TASK_CODE'],
        "P_TOILET_ASSISTANT": result.first['TOILET_ASSISTANT'],
        "P_REPOSITIONING_TASK_CODE": result.first['REPOSITIONING_TASK_CODE'],
        "P_REPOSITIONING": result.first['REPOSITIONING'],
        "P_COMPANNSHP_RESPITE_TASK_CODE":
        result.first['COMPANIONSHIP_RESPITE_TASK_CODE'],
        "P_COMPANIONSHIP_RESPITE": result.first['COMPANIONSHIP_RESPITE'],
        "P_LAUNDRY_TASK_CODE": result.first['LAUNDRY_TASK_CODE'],
        "P_LAUNDRY": result.first['LAUNDRY'],
        "P_HOUSEHOLD_CHORES_TASK_CODE":
        result.first['HOUSEHOLD_CHORES_TASK_CODE'],
        "P_HOUSEHOLD_CHORES": result.first['HOUSEHOLD_CHORES'],
        "P_UNABLE_DELIVER_TASK_CODE":
        result.first['UNABLE_DELIVER_TASK_CODE'],
        "P_UNABLE_DELIVER_DTL": result.first['UNABLE_DELIVER_DTL'],
        "P_PERSONAL_CARE_TASK_CODE": result.first['PERSONAL_CARE_TASK_CODE'],
        "P_PERSONAL_CARE": result.first['PERSONAL_CARE'],
        "P_User": localStorage.userLoginDetail.value?[0].userCode,
        "P_USER_IP": await getIp(),
        "P_MEDICATION_TASK_CODE": result.first['MEDIC_TASK_CODE'],
        "P_CLIENT_MEDICATION_DTL_ID":medicationData['CLIENT_MEDICATION_DTL_ID']!=null?
        medicationData['CLIENT_MEDICATION_DTL_ID'].toString():"",
        "P_MEDICATION_NAME": medicationData['MEDICATION_NAME']!=null?medicationData['MEDICATION_NAME'].toString():"",
        "P_DOSAGE": medicationData['DOSAGE']!=null?medicationData['DOSAGE'].toString():"",
        "P_ADMINISTRATION_NOTES":medicationData['ADMINISTRATION_NOTES']!=null?
        medicationData['ADMINISTRATION_NOTES'].toString():"",
        "P_MORNING_SCHEDULE": medicationData['MORNING_SCHEDULE']!=null?medicationData['MORNING_SCHEDULE'].toString():"",
        "P_LUNCHTIME_SCHEDULE": medicationData['LUNCHTIME_SCHEDULE']!=null?
        medicationData['LUNCHTIME_SCHEDULE'].toString():"",
        "P_EVENING_SCHEDULE": medicationData['EVENING_SCHEDULE']!=null?medicationData['EVENING_SCHEDULE'].toString():"",
        "P_BEDTIME_SCHEDULE": medicationData['BEDTIME_SCHEDULE']!=null?medicationData['BEDTIME_SCHEDULE'].toString():"",
        "P_SATURDAY_SCHEDULE": medicationData['SATURDAY_SCHEDULE']!=null?medicationData['SATURDAY_SCHEDULE'].toString():"",
        "P_AS_NEEDED_SCHEDULE":medicationData['AS_NEEDED_SCHEDULE']!=null?
        medicationData['AS_NEEDED_SCHEDULE'].toString():"",
        "P_TUESDAY_SCHEDULE": medicationData['TUESDAY_SCHEDULE']!=null? medicationData['TUESDAY_SCHEDULE'].toString():"",
        "P_WEDNESDAY_SCHEDULE": medicationData['WEDNESDAY_SCHEDULE']!=null?
        medicationData['WEDNESDAY_SCHEDULE'].toString():"",
        "P_THURSDAY_SCHEDULE": medicationData['THURSDAY_SCHEDULE']!=null?medicationData['THURSDAY_SCHEDULE'].toString():"",
        "P_FRIDAY_SCHEDULE": medicationData['FRIDAY_SCHEDULE']!=null?medicationData['FRIDAY_SCHEDULE'].toString():"",
        "P_MONDAY_SCHEDULE": medicationData['MONDAY_SCHEDULE']!=null?medicationData['MONDAY_SCHEDULE'].toString():"",
        "P_SUNDAY_SCHEDULE": medicationData['SUNDAY_SCHEDULE']!=null?medicationData['SUNDAY_SCHEDULE'].toString():"",
        "P_TAKEN_STATUS": medicationData['TAKEN_STATUS']!=null?medicationData['TAKEN_STATUS'].toString():"",
        "P_TAKEN_REMARKS": medicationData['TAKEN_REMARKS']!=null?medicationData['TAKEN_REMARKS'].toString():"",
        "P_NOT_TAKEN_STATUS": medicationData['NOT_TAKEN_STATUS']!=null?medicationData['NOT_TAKEN_STATUS'].toString():"",
        "P_NOT_TAKEN_REMARKS": medicationData['NOT_TAKEN_REMARKS']!=null?medicationData['NOT_TAKEN_REMARKS'].toString():"",
        "P_DATA_CAPTURED_DATE":medicationData['DATA_CAPTURED_DATE']!=null?
        medicationData['DATA_CAPTURED_DATE'].toString():"",
        "P_DATA_CAPTURED_TIME":medicationData['DATA_CAPTURED_TIME']!=null?
        medicationData['DATA_CAPTURED_TIME'].toString():"",
        "P_BODY_MAP_TASK_CODE": result.first['BODY_TASK_CODE'],
        "P_FRONT_HEAD_NECK": bodyMapData.isNotEmpty ? bodyMapData.first['FRONT_HEAD_NECK'] : null,
        "P_FRONT_RIGHT_SHOULDER": bodyMapData.isNotEmpty ? bodyMapData.first['FRONT_RIGHT_SHOULDER'] : null,
        "P_FRONT_LEFT_SHOULDER": bodyMapData.isNotEmpty ? bodyMapData.first['FRONT_LEFT_SHOULDER'] : null,
        "P_FRONT_RIGHT_UPPER_ARM_ELBOW": bodyMapData.isNotEmpty ? bodyMapData.first['FRONT_RIGHT_UPPER_ARM_ELBOW'] : null,
        "P_FRONT_RIGHT_FOREARM": bodyMapData.isNotEmpty ? bodyMapData.first['FRONT_RIGHT_FOREARM'] : null,
        "P_FRONT_RIGHT_HAND_WRIST": bodyMapData.isNotEmpty ? bodyMapData.first['FRONT_RIGHT_HAND_WRIST'] : null,
        "P_FRONT_LEFT_UPPER_ARM_ELBOW": bodyMapData.isNotEmpty ? bodyMapData.first['FRONT_LEFT_UPPER_ARM_ELBOW'] : null,
        "P_FRONT_LEFT_FOREARM": bodyMapData.isNotEmpty ? bodyMapData.first['FRONT_LEFT_FOREARM'] : null,
        "P_FRONT_LEFT_HAND_WRIST": bodyMapData.isNotEmpty ? bodyMapData.first['FRONT_LEFT_HAND_WRIST'] : null,
        "P_FRONT_RIGHT_CHEST": bodyMapData.isNotEmpty ? bodyMapData.first['FRONT_RIGHT_CHEST'] : null,
        "P_FRONT_LEFT_CHEST": bodyMapData.isNotEmpty ? bodyMapData.first['FRONT_LEFT_CHEST'] : null,
        "P_FRONT_ABDOMEN": bodyMapData.isNotEmpty ? bodyMapData.first['FRONT_ABDOMEN'] : null,
        "P_FRONT_GROIN": bodyMapData.isNotEmpty ? bodyMapData.first['FRONT_GROIN'] : null,
        "P_FRONT_RIGHT_UPPER_LEG": bodyMapData.isNotEmpty ? bodyMapData.first['FRONT_RIGHT_UPPER_LEG'] : null,
        "P_FRONT_RIGHT_KNEE": bodyMapData.isNotEmpty ? bodyMapData.first['FRONT_RIGHT_KNEE'] : null,
        "P_FRONT_RIGHT_LOWER_LEG": bodyMapData.isNotEmpty ? bodyMapData.first['FRONT_RIGHT_LOWER_LEG'] : null,
        "P_FRONT_RIGHT_FOOT_ANKLE": bodyMapData.isNotEmpty ? bodyMapData.first['FRONT_RIGHT_FOOT_ANKLE'] : null,
        "P_FRONT_LEFT_UPPER_LEG": bodyMapData.isNotEmpty ? bodyMapData.first['FRONT_LEFT_UPPER_LEG'] : null,
        "P_FRONT_LEFT_KNEE": bodyMapData.isNotEmpty ? bodyMapData.first['FRONT_LEFT_KNEE'] : null,
        "P_FRONT_LEFT_LOWER_LEG": bodyMapData.isNotEmpty ? bodyMapData.first['FRONT_LEFT_LOWER_LEG'] : null,
        "P_FRONT_LEFT_FOOT_ANKLE": bodyMapData.isNotEmpty ? bodyMapData.first['FRONT_LEFT_FOOT_ANKLE'] : null,
        "P_BACK_HEAD_NECK": bodyMapData.isNotEmpty ? bodyMapData.first['BACK_HEAD_NECK'] : null,
        "P_BACK_RIGHT_SHOULDER": bodyMapData.isNotEmpty ? bodyMapData.first['BACK_RIGHT_SHOULDER'] : null,
        "P_BACK_LEFT_SHOULDER": bodyMapData.isNotEmpty ? bodyMapData.first['BACK_LEFT_SHOULDER'] : null,
        "P_BACK_RIGHT_UPPER_ARM_ELBOW": bodyMapData.isNotEmpty ? bodyMapData.first['BACK_RIGHT_UPPER_ARM_ELBOW'] : null,
        "P_BACK_RIGHT_FOREARM": bodyMapData.isNotEmpty ? bodyMapData.first['BACK_RIGHT_FOREARM'] : null,
        "P_BACK_RIGHT_HAND_WRIST": bodyMapData.isNotEmpty ? bodyMapData.first['BACK_RIGHT_HAND_WRIST'] : null,
        "P_BACK_LEFT_UPPER_ARM_ELBOW": bodyMapData.isNotEmpty ? bodyMapData.first['BACK_LEFT_UPPER_ARM_ELBOW'] : null,
        "P_BACK_LEFT_FOREARM": bodyMapData.isNotEmpty ? bodyMapData.first['BACK_LEFT_FOREARM'] : null,
        "P_BACK_LEFT_HAND_WRIST": bodyMapData.isNotEmpty ? bodyMapData.first['BACK_LEFT_HAND_WRIST'] : null,
        "P_BACK_UPPER_BACK": bodyMapData.isNotEmpty ? bodyMapData.first['BACK_UPPER_BACK'] : null,
        "P_BACK_LOWER_BACK": bodyMapData.isNotEmpty ? bodyMapData.first['BACK_LOWER_BACK'] : null,
        "P_BACK_BOTTOM_SACRUM": bodyMapData.isNotEmpty ? bodyMapData.first['BACK_BOTTOM_SACRUM'] : null,
        "P_BACK_RIGHT_UPPER_LEG": bodyMapData.isNotEmpty ? bodyMapData.first['BACK_RIGHT_UPPER_LEG'] : null,
        "P_BACK_RIGHT_KNEE": bodyMapData.isNotEmpty ? bodyMapData.first['BACK_RIGHT_KNEE'] : null,
        "P_BACK_RIGHT_LOWER_LEG": bodyMapData.isNotEmpty ? bodyMapData.first['BACK_RIGHT_LOWER_LEG'] : null,
        "P_BACK_RIGHT_FOOT_ANKLE": bodyMapData.isNotEmpty ? bodyMapData.first['BACK_RIGHT_FOOT_ANKLE'] : null,
        "P_BACK_LEFT_UPPER_LEG": bodyMapData.isNotEmpty ? bodyMapData.first['BACK_LEFT_UPPER_LEG'] : null,
        "P_BACK_LEFT_KNEE": bodyMapData.isNotEmpty ? bodyMapData.first['BACK_LEFT_KNEE'] : null,
        "P_BACK_LEFT_LOWER_LEG": bodyMapData.isNotEmpty ? bodyMapData.first['BACK_LEFT_LOWER_LEG'] : null,
        "P_BACK_LEFT_FOOT_ANKLE": bodyMapData.isNotEmpty ? bodyMapData.first['BACK_LEFT_FOOT_ANKLE'] : null,
        "P_GENERAL_NOTES": bodyMapData.isNotEmpty ? bodyMapData.first['GENERAL_NOTES'] : null,
      };

      Map<String, dynamic> apiData = {
        "P_CARER_VISIT_CHK_INOUT_ID": "",
        "P_ORG_CODE": result.first['ORG_CODE'],
        "P_CLIENT_DATEWISE_SCH_ID": result.first['CLIENT_DATEWISE_SCH_ID'],
        "P_CLIENT_ID": result.first['CLIENT_ID'],
        "P_CLIENT_CODE": result.first['CLIENT_CODE'],
        "P_CLIENT_VISIT_TYPE_MST_ID": result.first['CLIENT_VISIT_TYPE_MST_ID'],
        "P_VISIT_DATE": "",
        "P_CHECK_IN_DATE": result.first['CHECK_IN_DATE'],
        "P_CHECK_IN_TIME": result.first['CHECK_IN_TIME'],
        "P_CHECK_IN_LATTITUDE": result.first['CHECK_IN_LATTITUDE'],
        "P_CHECK_IN_LONGLITUDE": result.first['CHECK_IN_LONGITUDE'],
        "P_CARER_ID": result.first['CARER_ID'],
        "P_CARER_CODE": result.first['CARER_CODE'],
        "P_CARER_ID2": result.first['CARER_ID2'],
        "P_CARER_CODE2": result.first['CARER_CODE2'],
        "P_CHECK_OUT_DATE": result.first['CHECK_OUT_DATE'],
        "P_CHECK_OUT_TIME": result.first['CHECK_OUT_TIME'],
        "P_WORKING_TIME": getDurationFromDate(
            result.first['CHECK_IN_DATE'], result.first['CHECK_IN_TIME']),
        "P_CHECK_OUT_LATTITUDE": result.first['CHECK_OUT_LATTITUDE'],
        "P_CHECK_OUT_LONGLITUDE": result.first['CHECK_OUT_LONGITUDE'],
        "P_RowStatus": "2",
        "P_User": localStorage.userLoginDetail.value?[0].userCode,
        "P_USER_IP": await getIp()
      };


      //print("BLFA"+data['P_BACK_LEFT_FOOT_ANKLE']);

      try{
        if (await uploadData(data) && await checkOutAPI(apiData)) {

          check1(carerVisitMstId);
          check2(carerVisitMstId);
          check3(carerVisitMstId);
          check4(carerVisitMstId);
          check5(carerVisitMstId);


          return true;
        }
        else{
          return false;
        }
      }catch(e){
        return false;
        print(e.toString());
        rethrow;
      }

    } else {
      print("AAAAAAAAAAAAAAA no data found");
      return false;
    }
  }


  Future<void> checkBeforeCheckOutAndDelete(String carerVisitMstId, String tableName) async {

    // 1 means ok
    // 2 means not ok
    // 3 means not done any assign task

    final Database? db = await dbHandler.getDatabase;

    try {
      // Execute SQL query to count rows with the given visit master ID
      List<Map<String, dynamic>> result = await db!.rawQuery('''
      SELECT COUNT(*) AS count FROM $tableName WHERE CARER_VISIT_MST_ID = ?;
    ''', [carerVisitMstId]);

      // Extract count from the result
      final count = result.first.values.first as int? ?? 0;

      if(count != 0){

        await db.rawQuery('DELETE FROM $tableName WHERE CARER_VISIT_MST_ID = ?',[carerVisitMstId]);

      }



    } catch (e) {
      print('Error while checking if table is empty: $e');
      // Assume table is empty in case of error
    }


  }

  Future<bool> checkBeforeCheckOut(String carerVisitMstId, String tableName) async {

    // 1 means ok
    // 2 means not ok
    // 3 means not done any assign task

    final Database? db = await dbHandler.getDatabase;

    if(tableName == 'CMS_CARER_VISIT_BODY_MAP'){
      await db?.rawQuery('DELETE FROM $tableName WHERE CARER_VISIT_MST_ID = ? AND TASK_CODE IS NULL',[carerVisitMstId]);
    }

    try {
      // Execute SQL query to count rows with the given visit master ID
      List<Map<String, dynamic>> result = await db!.rawQuery('''
      SELECT COUNT(*) AS count FROM $tableName WHERE CARER_VISIT_MST_ID = ?;
    ''', [carerVisitMstId]);

      // Extract count from the result
      final count = result.first.values.first as int? ?? 0;


      return count == 0;
    } catch (e) {
      print('Error while checking if table is empty: $e');
      return true; // Assume table is empty in case of error
    }


  }

  Future<Map<String, List<String>>> getMedicationData(String carerVisitMstId) async {

    Database? db = await dbHandler.getDatabase;

    List<Map<String, dynamic>>? result = await db?.rawQuery('''
      SELECT
        CARER_VISIT_MEDICATION_ID,
        MEDICATION_NAME,
        CLIENT_MEDICATION_DTL_ID,
        DOSAGE,
        ADMINISTRATION_NOTES,
        MORNING_SCHEDULE,
        LUNCHTIME_SCHEDULE,
        EVENING_SCHEDULE,
        BEDTIME_SCHEDULE,
        SATURDAY_SCHEDULE,
        AS_NEEDED_SCHEDULE,
        TUESDAY_SCHEDULE,
        WEDNESDAY_SCHEDULE,
        THURSDAY_SCHEDULE,
        FRIDAY_SCHEDULE,
        MONDAY_SCHEDULE,
        SUNDAY_SCHEDULE,
        TAKEN_STATUS,
        TAKEN_REMARKS,
        NOT_TAKEN_STATUS,
        NOT_TAKEN_REMARKS,
        DATA_CAPTURED_DATE,
        DATA_CAPTURED_TIME
      FROM
        CMS_CARER_VISIT_MEDICATION
      WHERE
        CARER_VISIT_MST_ID = ? AND (TAKEN_STATUS IS NOT NULL OR NOT_TAKEN_STATUS IS NOT NULL)
    ''', [carerVisitMstId]);

    /*Map<String,List<String>> medicationData = {};
    result?.forEach((row) {
      row.forEach((key,value) {
        if (!medicationData.containsKey(key)) {
          medicationData[key] = [];
        }
        medicationData[key]?.add(value.toString().trim());

      });
    });

    print(medicationData);*/

    Map<String, List<String>> medicationData = {};
    result?.forEach((row) {
      row.forEach((key,value) {
        if (!medicationData.containsKey(key)) {
          medicationData[key] = [];
        }
        medicationData[key]?.add(value != null?value.toString().trim():"");
        //print(medicationData.toString());
      });
    });

    //print(medicationData);

    return medicationData;
  }

  Future<List<Map<String, dynamic>>> getBodyMapData(String carerVisitMstId) async {

    Database? db = await dbHandler.getDatabase;

    List<Map<String, dynamic>>? result = await db?.rawQuery('''
      SELECT
    CARER_VISIT_BODYMAP_ID,
    CARER_VISIT_MST_ID,
    ORG_CODE,
    CLIENT_ID,
    CLIENT_CODE,
    CARER_ID,
    CARER_CODE,
    ANOTHER_CARER_STATUS,
    CARER_ID2,
    CARER_CODE2,
    TASK_CODE,
    FRONT_HEAD_NECK,
    FRONT_RIGHT_SHOULDER,
    FRONT_LEFT_SHOULDER,
    FRONT_RIGHT_UPPER_ARM_ELBOW,
    FRONT_RIGHT_FOREARM,
    FRONT_RIGHT_HAND_WRIST,
    FRONT_LEFT_UPPER_ARM_ELBOW,
    FRONT_LEFT_FOREARM,
    FRONT_LEFT_HAND_WRIST,
    FRONT_RIGHT_CHEST,
    FRONT_LEFT_CHEST,
    FRONT_ABDOMEN,
    FRONT_GROIN,
    FRONT_RIGHT_UPPER_LEG,
    FRONT_RIGHT_KNEE,
    FRONT_RIGHT_LOWER_LEG,
    FRONT_RIGHT_FOOT_ANKLE,
    FRONT_LEFT_UPPER_LEG,
    FRONT_LEFT_KNEE,
    FRONT_LEFT_LOWER_LEG,
    FRONT_LEFT_FOOT_ANKLE,
    BACK_HEAD_NECK,
    BACK_RIGHT_SHOULDER,
    BACK_LEFT_SHOULDER,
    BACK_RIGHT_UPPER_ARM_ELBOW,
    BACK_RIGHT_FOREARM,
    BACK_RIGHT_HAND_WRIST,
    BACK_LEFT_UPPER_ARM_ELBOW,
    BACK_LEFT_FOREARM,
    BACK_LEFT_HAND_WRIST,
    BACK_UPPER_BACK,
    BACK_LOWER_BACK,
    BACK_BOTTOM_SACRUM,
    BACK_RIGHT_UPPER_LEG,
    BACK_RIGHT_KNEE,
    BACK_RIGHT_LOWER_LEG,
    BACK_RIGHT_FOOT_ANKLE,
    BACK_LEFT_UPPER_LEG,
    BACK_LEFT_KNEE,
    BACK_LEFT_LOWER_LEG,
    BACK_LEFT_FOOT_ANKLE,
    GENERAL_NOTES,
    CL_STATUS
FROM 
    CMS_CARER_VISIT_BODY_MAP
      WHERE
        CARER_VISIT_MST_ID = ?
    ''', [carerVisitMstId]);

    //print(medicationData);
    if(result!.isNotEmpty){
      return result;
    }
    else{
      return[];
    }


  }



  Future<void> updateVisitType(
      String carerVisitMstId, String newClientVisitTypeId) async {
    String? nullableString = newClientVisitTypeId;

    if (newClientVisitTypeId == 'G') {
      nullableString = "0";
    }

    Database? db = await dbHandler.getDatabase;
    await db!.update(
      'CMS_CARER_VISIT_MST',
      {'CLIENT_VISIT_TYPE_MST_ID': nullableString},
      where: 'CARER_VISIT_MST_ID = ?',
      whereArgs: [carerVisitMstId],
    );
  }

  Future<void> updateCheckInTime(
      String carerVisitMstId, String newClientVisitCheckInTime) async {
    Database? db = await dbHandler.getDatabase;
    await db!.update(
      'CMS_CARER_VISIT_MST',
      {'CHECK_IN_TIME': newClientVisitCheckInTime},
      where: 'CARER_VISIT_MST_ID = ?',
      whereArgs: [carerVisitMstId],
    );
  }

  Future<void> updateCoCareWorker(
      String carerVisitMstId, String coCareWorker, carerCode) async {
    Database? db = await dbHandler.getDatabase;
    await db!.update(
      'CMS_CARER_VISIT_MST',
      {
        'CARER_ID2': coCareWorker,
        "CARER_CODE2": carerCode,
        'ANOTHER_CARER_STATUS': 'Y'
      },
      where: 'CARER_VISIT_MST_ID = ?',
      whereArgs: [carerVisitMstId],
    );
  }

  Future<void> updateRating(String carerVisitMstId, String rate) async {
    Database? db = await dbHandler.getDatabase;
    await db!.update(
      'CMS_CARER_VISIT_MST',
      {'HOW_DID_CLIENT_EMOJI_CODE': rate},
      where: 'CARER_VISIT_MST_ID = ?',
      whereArgs: [carerVisitMstId],
    );
  }

  Future<void> removeCarerId2(String carerVisitMstId) async {
    Database? db = await dbHandler.getDatabase;

    await db!.update(
      'CMS_CARER_VISIT_MST',
      {'CARER_ID2': '', 'ANOTHER_CARER_STATUS': "N", 'CARER_CODE2': ''},
      where: 'CARER_VISIT_MST_ID = ?',
      whereArgs: [carerVisitMstId],
    );
  }

  Future<String?> getCarerName(String carerId) async {
    Database? db = await dbHandler.getDatabase;
    List<Map<String, dynamic>> result = await db!.query(
      'DPD_CMS_CARER_LIST', // Table name
      columns: ['CARER_NAME'], // Columns to select
      where: 'CARER_ID = ?', // WHERE clause
      whereArgs: [carerId], // Arguments for WHERE clause
    );
    if (result.isNotEmpty) {
      return result.first['CARER_NAME'] as String?;
    } else {
      return null; // Return null if no matching row found
    }
  }

  Future<void> check1(String carerVisitMstId) async {
    await checkBeforeCheckOutAndDelete(
    carerVisitMstId, "CMS_CARER_VISIT_FOOD");
    await checkBeforeCheckOutAndDelete(
    carerVisitMstId, "CMS_CARER_VISIT_BODY_MAP");
    await checkBeforeCheckOutAndDelete(
    carerVisitMstId, "CMS_CARER_VISIT_PERSONAL_CARE");
  }

  Future<void> check2(String carerVisitMstId) async {
    await checkBeforeCheckOutAndDelete(
    carerVisitMstId, "CMS_CARER_VISIT_UNBLE_DLVR_DTL");
    await checkBeforeCheckOutAndDelete(
    carerVisitMstId, "CMS_CARER_VISIT_HOUSHLD_CHORES");
    await checkBeforeCheckOutAndDelete(
    carerVisitMstId, "CMS_CARER_VISIT_LAUNDRY");
  }

  Future<void> check3(String carerVisitMstId) async {
    await checkBeforeCheckOutAndDelete(
    carerVisitMstId, "CMS_CARER_VISIT_CMPNNSHP_RESPT");
    await checkBeforeCheckOutAndDelete(
    carerVisitMstId, "CMS_CARER_VISIT_REPOSITIONING");
    await checkBeforeCheckOutAndDelete(
    carerVisitMstId, "CMS_CARER_VISIT_TOILET_ASSIST");
  }

  Future<void> check4(String carerVisitMstId) async {
    await checkBeforeCheckOutAndDelete(
    carerVisitMstId, "CMS_CARER_VISIT_HOUSEWORK");
    await checkBeforeCheckOutAndDelete(
    carerVisitMstId, "CMS_CARER_VISIT_DRINKS");
    await checkBeforeCheckOutAndDelete(
    carerVisitMstId, "CMS_CARER_VISIT_GROCERIES");
  }

  Future<void> check5(String carerVisitMstId) async {
    await checkBeforeCheckOutAndDelete(
    carerVisitMstId, "CMS_CARER_VISIT_MEDICATION");
    await checkBeforeCheckOutAndDelete(
    carerVisitMstId, "CMS_CARER_VISIT_MST");
  }

  Future<bool> uploadData(Map<String, dynamic> data) async {
    return await _apiHandler.checkOut(data);
  }

  checkOutAPI(Map<String, dynamic> apiData) async {
    return await _apiHandler.checkInOut(apiData);
  }
}
