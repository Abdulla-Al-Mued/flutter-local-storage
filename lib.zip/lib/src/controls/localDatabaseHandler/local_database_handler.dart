import 'dart:io';
import 'package:care4u/src/models/insertion/CMS_CARER_VISIT_CMPNNSHP_RESPT.dart';
import 'package:care4u/src/models/insertion/CMS_CARER_VISIT_GROCERIES.dart';
import 'package:care4u/src/models/insertion/CMS_CARER_VISIT_HOUSEWORK.dart';
import 'package:care4u/src/models/insertion/CMS_CARER_VISIT_HOUSHLD_CHORES.dart';
import 'package:care4u/src/models/insertion/CMS_CARER_VISIT_LAUNDRY.dart';
import 'package:care4u/src/models/insertion/CMS_CARER_VISIT_PERSONAL_CARE.dart';
import 'package:care4u/src/models/insertion/CMS_CARER_VISIT_REPOSITIONING.dart';
import 'package:care4u/src/models/insertion/CMS_CARER_VISIT_TOILET_ASSIST.dart';
import 'package:care4u/src/models/insertion/CMS_CARER_VISIT_UNBLE_DLVR_DTL.dart';
import 'package:flutter/material.dart';
import 'package:sqflite/sqflite.dart';
import 'package:path/path.dart';
import 'package:path_provider/path_provider.dart';
import '../../models/LocalModel/LocalDpd_Cms_Carer_Cln_Dtws_Sch_Lst_Model.dart';
import '../../models/insertion/CMS_CARER_VISIT_FOOD.dart';
import '../../models/insertion/CMS_CARER_VISIT_DRINKS.dart';
import '../../models/insertion/CMS_CARER_VISIT_MST.dart';

class LocalDatabaseHandler {
  /*===================>
  Variables Declaring
  <===================*/
  final String dbName = 'CMS_UK.db';
  final int dbVersion = 1;
  Database? _database;
  String dbPath = '';

  /*===================>
  Checking Database Available or Not
  <===================*/
  Future<Database?> get getDatabase async {
    if (_database != null) return _database;
    _database = await initDatabase();
    return _database;
  }

  /*===================>
  Initializing Database and Opening Database
  <===================*/
  Future<Database> initDatabase() async {
    //Directory? documentsDirectory = await getExternalStorageDirectory();
    try {
    //  dbPath = join(documentsDirectory!.path, dbName);
      var database = await openDatabase(dbName, version: dbVersion);
      // print("check path");
      // print(database.path);
      return database;
    } catch (e) {
      rethrow;
    }
  }

  /*===================>
  Checking Database is Exist or Not
  <===================*/
  Future<bool> doesTableExist({required String tableName}) async {
    try {
      Database? db = await getDatabase;
      List<Map<String, Object?>> tables =
          await db!.query('sqlite_master', columns: ['name']);
      final data = tables
          .any((Map<String, dynamic> table) => table['name'] == tableName);
      return data;
    } catch (e) {
      rethrow;
    }
  }

  /*===================>
    Creating Database Table
    <===================*/
  Future<void> createTable({required String sqlInject}) async {
    Database? db = await getDatabase;
    try {
      await db!.execute(sqlInject);
    } catch (e) {
      rethrow;
    }
  }

  //for display
  Future<List<Map<String, dynamic>>> getDPDAllClientList() async {
    Database? db = await getDatabase;
    final List<Map<String, dynamic>> maps = await db!.query('DPD_ORG_ALL_CLIENT_LIST');

    return maps;
  }
  Future<List<Map<String, dynamic>>> getDpdCmsCarerClnDtwsSchLst() async {
    Database? db = await getDatabase;
    final List<Map<String, dynamic>> maps = await db!.rawQuery('''
    SELECT *
    FROM DPD_CMS_CARER_CLN_DTWS_SCH_LST
	  WHERE SUBSTR(SCHEDULE_DATE,7,4)||SUBSTR(SCHEDULE_DATE,4,2)||SUBSTR(SCHEDULE_DATE,1,2) >=SUBSTR(strftime('%d/%m/%Y', datetime('now')),7,4)||SUBSTR(strftime('%d/%m/%Y', datetime('now')),4,2)||SUBSTR(strftime('%d/%m/%Y', datetime('now')),1,2)
    ORDER BY SUBSTR(SCHEDULE_DATE,7,4)||SUBSTR(SCHEDULE_DATE,4,2)||SUBSTR(SCHEDULE_DATE,1,2) ASC
  ''');

    return maps;
  }

  Future<int?> insertItemCareMaster(CarerVisitMst data, String clientDateWiseSchId) async {

    final Database? db = await getDatabase;

    try {
      return await db!.transaction<int>((txn) async {

        List<Map<String, dynamic>> result = await txn.query(
          'CMS_CARER_VISIT_MST',
          where: 'CLIENT_DATEWISE_SCH_ID = ?',
          whereArgs: [clientDateWiseSchId],
        );

        if (result.isNotEmpty) {

          return result.first['CARER_VISIT_MST_ID'] as int;
        } else {

          return await txn.insert('CMS_CARER_VISIT_MST', data.toMap());
        }
      });
    } catch (e) {
      print('Error inserting item: $e');
      return null;
    }
  }

  Future<String?> getCarerVisitMstIdBYScheduleID() async {

    // open the database
    Database? database = await getDatabase;

    // await database?.delete(
    //   'CMS_CARER_VISIT_MST', // Replace 'YourTableName' with the actual table name
    //   where: 'CARER_VISIT_MST_ID = 6',
    //
    // );
    //
    // return 0;

    // Query the database
    List<Map<String, dynamic>>? result = await database?.rawQuery(
      'select CARER_VISIT_MST_ID,CLIENT_ID from CMS_CARER_VISIT_MST WHERE CHECK_IN_DATE IS NOT NULL AND CHECK_OUT_DATE IS NULL',
    );


    // Return the result
    if (result!.isNotEmpty) {

      print("client ID "+result.first['CLIENT_ID']);
      return result.first['CLIENT_ID'];

    } else {

      print("client ID null");
      return '';
    }
  }

  Future<int?> insertOrGetMstId(String clientId, CarerVisitMst data) async {

    // open the database
    Database? database = await getDatabase;


    // Query the database
    List<Map<String, dynamic>>? result = await database?.rawQuery(
        'select CARER_VISIT_MST_ID,CLIENT_ID from CMS_CARER_VISIT_MST WHERE CHECK_IN_DATE IS NOT NULL AND CHECK_OUT_DATE IS NULL',
    );


    // Return the result
    if (result!.isEmpty) {
       // insert no one checked in
      try {
        return await database!.transaction<int>((txn) async {

          return await txn.insert('CMS_CARER_VISIT_MST', data.toMap());

        });
      } catch (e) {
        print('Error inserting item: $e');
        return null;
      }
    }
    else {
       return result.first['CARER_VISIT_MST_ID'];
    }
    // else{
    //    // already checked in
    // }
  }

  Future<Map<String, dynamic>?> getMstIdIfExist() async {

    // open the database
    Database? database = await getDatabase;


    // Query the database
    List<Map<String, dynamic>>? result = await database?.rawQuery(
      'select A.CARER_VISIT_MST_ID, B.NAME, A.ORG_CODE, A.CLIENT_DATEWISE_SCH_ID, A.CLIENT_ID, A.CLIENT_CODE, A.CLIENT_VISIT_TYPE_MST_ID from CMS_CARER_VISIT_MST AS A, DPD_PERSONAL_DTL_LIST AS B WHERE CHECK_IN_DATE IS NOT NULL AND CHECK_OUT_DATE IS NULL AND A.CLIENT_ID=B.CLIENT_ID',
    );


    // Return the result
    if (result!.isEmpty) {

      return null;
    }
    else {

      // Value val = Value(
      //   clientName: result.first['NAME'],
      //   clientCode: result.first['CLIENT_CODE'],
      //   clientId: result.first['CLIENT_ID'],
      //   orgCode: result.first['ORG_CODE'],
      //   clientDatewiseSchId: result.first[''],
      //   clientVisitTypeMstId: result.first[''],
      // );

      return result.first;
    }

  }

  Future<List<Map<String, dynamic>>> getClientAddress(String id) async {
    Database? db = await getDatabase;
    final List<Map<String, dynamic>> maps = await db!.query(
      'DPD_ORG_ALL_CLIENT_LIST',
      columns: ['ADDRESS'],
      where: 'CLIENT_ID = ?',
      whereArgs: [id],
    );

    if (maps.isNotEmpty) {
      //print(maps.first['ADDRESS']);
      return maps;
    } else {
      //print("no element found");
      return [];
    }
  }


  Future<List<Map<String, dynamic>>> getClientMedication(String id) async {
    Database? db = await getDatabase;
    List<Map<String, dynamic>> result = await db!.query(
      'DPD_CLIENT_MEDICATION_DTL',
      where: 'CLIENT_ID = ?',
      whereArgs: [id],
    );

    if (result.isNotEmpty) {
      //print(result);
      return result;
    } else {
      print("no medication found");
      return [];
    }


  }


  Future<List<Map<String, dynamic>>> getClientVisitTypeName(String id) async {
    Database? db = await getDatabase;

    final List<Map<String, dynamic>> result = await db!.query(
      'DPD_CLIENT_VISIT_TYPE_DTL',
      distinct: true,
      columns: ['VISIT_TYPE_NAME','CLIENT_VISIT_TYPE_MST_ID'],
      where: 'CLIENT_ID = ?',
      whereArgs: [id],
    );

    if (result.isNotEmpty) {
      return result;
    } else {
      print("no medication found");
      return [];
    }


  }

  Future<List<Map<String, dynamic>>> getClientVisitTypeIconByName(String visitTypeName) async {
    Database? db = await getDatabase;
    final List<Map<String, dynamic>> result = await db!.query(
      'DPD_CLIENT_VISIT_TYPE_DTL',
      columns: ['TASK_CODE'],
      where: 'VISIT_TYPE_NAME = ?',
      whereArgs: [visitTypeName],
    );

    if (result.isNotEmpty) {
      //print(result);
      return result;
    } else {
      print("no medication found");
      return [];
    }


  }

  // Future<List<Map<String, dynamic>>> getClientVisitTypeIcon(String clientId, String visitType) async {
  //
  //   Database? db = await getDatabase;
  //   List<Map<String, dynamic>>? result = await db?.rawQuery(
  //       'SELECT ICON_IMAGE_PATH FROM DPD_CLIENT_VISIT_TYPE_DTL_LST WHERE CLIENT_VISIT_TYPE_DTL_ID = ? AND CLIENT_ID = ?',
  //       [visitType, clientId]);
  //
  //   if (result!.isNotEmpty) {
  //     //print(result);
  //     return result;
  //   } else {
  //     print("no medication found");
  //     return [];
  //   }
  //
  //
  // }

  Future<bool?> isMedicationExist(String carerVisitMstId) async {
    Database? db = await getDatabase;
    List<Map<String, dynamic>>? result = await db?.query(
      'CMS_CARER_VISIT_MEDICATION',
      where: 'CARER_VISIT_MST_ID = ?',
      whereArgs: [carerVisitMstId],
    );
    return result?.isNotEmpty;
  }

  Future<List<Map<String, dynamic>>> getClientDOB(String clientId) async {
    Database? db = await getDatabase;
    final List<Map<String, dynamic>> result = await db!.rawQuery(
          'SELECT DOB FROM DPD_PERSONAL_DTL_LIST WHERE CLIENT_ID = ?',
        [clientId]
    );

    if (result.isNotEmpty) {

      return result;
    } else {
      print("no medication found");
      return [];
    }


  }

  Future<List<Map<String, dynamic>>> getAdditionalCareWorker(String carerId, String orgCode) async {
    Database? db = await getDatabase;
    final List<Map<String, dynamic>> result = await db!.rawQuery(
        "SELECT CARER_NAME, CARER_ID, CARER_CODE FROM DPD_CMS_CARER_LIST WHERE ORG_CODE = ? AND CARER_ID != ?",
        [orgCode, carerId]
    );

    if (result.isNotEmpty) {
      return result;
    } else {
      print("no medication found");
      return [];
    }


  }

  /// visit data








  /// foodTaskDataInsertion

  Future<void> insertFoodData(CarerVisitFood data) async {

    final Database? db = await getDatabase;

    try {
      await db?.insert(
        'CMS_CARER_VISIT_FOOD',
        data.toMap(),
        conflictAlgorithm: ConflictAlgorithm.replace,
      );


      final snackBar = SnackBar(
        content: Text('Data inserted successfully!'),
        duration: Duration(seconds: 3), // Adjust the duration as needed
      );
      ScaffoldMessenger.of(context as BuildContext).showSnackBar(snackBar);
    } catch (e) {

      print('Error inserting data: $e');
    }
  }


  Future<void> updateFood(String newFoodValue, String mstId) async {
    final Database? db = await getDatabase; // Assume getDatabase returns the SQLite database instance

    await db?.update(
      'CMS_CARER_VISIT_FOOD',
      {'FOOD': newFoodValue},
      where: 'CARER_VISIT_MST_ID = ?',
      whereArgs: [mstId],
    );
  }


  Future<void> deleteFoodByMstId(String mstId) async {
    final Database? db = await getDatabase; // Assume getDatabase returns the SQLite database instance

    await db?.delete(
      'CMS_CARER_VISIT_FOOD',
      where: 'CARER_VISIT_MST_ID = ?',
      whereArgs: [mstId],
    );
  }


  Future<List<dynamic>> isFoodExistsByMstId(String mstId) async {
    final Database? db = await getDatabase; // Assume getDatabase returns the SQLite database instance

    List<Map<String, dynamic>>? result = await db?.query(
      'CMS_CARER_VISIT_FOOD',
      where: 'CARER_VISIT_MST_ID = ?',
      whereArgs: [mstId],
    );

    if (result!.isNotEmpty) {

      return [true, result.first['FOOD']];
    } else {

      return [false, null];
    }
  }


  Future<String?> getStatusByMstId(String mstId) async {
    final Database? db = await getDatabase; // Assume getDatabase returns the SQLite database instance

    List<Map<String, dynamic>>? result = await db?.query(
      'CMS_CARER_VISIT_FOOD',
      columns: ['STATUS'], // Select only the STATUS column
      where: 'CARER_VISIT_MST_ID = ?',
      whereArgs: [mstId],
    );

    // Check if any row is returned by the query
    if (result!.isNotEmpty) {
      // Return the status from the first row
      return result[0]['STATUS'];
    } else {
      // No matching row found, return null
      return "N";
    }
  }

  Future<String> isBodyMapExistsByMstId(String carerVisitMstId) async {
    final Database? db = await getDatabase; // Assume getDatabase returns the SQLite database instance

    List<Map<String, dynamic>>? result = await db?.query(
      'CMS_CARER_VISIT_BODY_MAP',
      columns: ['TASK_CODE'], // Select only the STATUS column
      where: 'CARER_VISIT_MST_ID = ?',
      whereArgs: [carerVisitMstId],
    );

    if (result!.isNotEmpty && result[0]['TASK_CODE'] != null) {
      // Return the status from the first row
      return result[0]['TASK_CODE'];
    } else {
      // No matching row found, return null
      return "N";
    }
  }



   /// ---------------------> Drinks <-------------------------------///

  Future<void> insertDrinksData(CarerVisitDrinks data) async {

    final Database? db = await getDatabase;

    try {
      await db?.insert(
        'CMS_CARER_VISIT_DRINKS',
        data.toMap(),
        conflictAlgorithm: ConflictAlgorithm.replace,
      );


      final snackBar = SnackBar(
        content: Text('Data inserted successfully!'),
        duration: Duration(seconds: 3), // Adjust the duration as needed
      );
      ScaffoldMessenger.of(context as BuildContext).showSnackBar(snackBar);
    } catch (e) {

      print('Error inserting data: $e');
    }
  }


  Future<void> updateDrinks(String newDrinksValue, String carerVisitMstId) async {
    final Database? db = await getDatabase; // Assume getDatabase returns the SQLite database instance

    await db?.update(
      'CMS_CARER_VISIT_DRINKS',
      {'DRINKS': newDrinksValue},
      where: 'CARER_VISIT_MST_ID = ?',
      whereArgs: [carerVisitMstId],
    );
  }


  Future<void> deleteDrinksByMstId(String carerVisitMstId) async {
    final Database? db = await getDatabase; // Assume getDatabase returns the SQLite database instance

    await db?.delete(
      'CMS_CARER_VISIT_DRINKS',
      where: 'CARER_VISIT_MST_ID = ?',
      whereArgs: [carerVisitMstId],
    );
  }


  Future<List<dynamic>> isDrinksExistsByMstId(String carerVisitMstId) async {
    final Database? db = await getDatabase; // Assume getDatabase returns the SQLite database instance

    List<Map<String, dynamic>>? result = await db?.query(
      'CMS_CARER_VISIT_DRINKS',
      where: 'CARER_VISIT_MST_ID = ?',
      whereArgs: [carerVisitMstId],
    );

    if (result!.isNotEmpty) {
      // If data exists, return a list with true and the Drinks data
      return [true, result.first['DRINKS']];
    } else {
      print('NULL');
      // If data doesn't exist, return a list with false and null for Drinks data
      return [false, null];
    }
  }

  Future<String?> getDrinksStatusByMstId(String mstId) async {
    final Database? db = await getDatabase; // Assume getDatabase returns the SQLite database instance

    List<Map<String, dynamic>>? result = await db?.query(
      'CMS_CARER_VISIT_DRINKS',
      columns: ['STATUS'], // Select only the STATUS column
      where: 'CARER_VISIT_MST_ID = ?',
      whereArgs: [mstId],
    );

    // Check if any row is returned by the query
    if (result!.isNotEmpty) {
      // Return the status from the first row
      return result[0]['STATUS'];
    } else {
      // No matching row found, return null
      return "N";
    }
  }

  Future<String> getEmojiStatusByMstId(String mstId) async {
    final Database? db = await getDatabase; // Assume getDatabase returns the SQLite database instance

    List<Map<String, dynamic>>? result = await db?.query(
      'CMS_CARER_VISIT_MST',
      columns: ['HOW_DID_CLIENT_EMOJI_CODE'], // Select only the STATUS column
      where: 'CARER_VISIT_MST_ID = ?',
      whereArgs: [mstId],
    );

    // Check if any row is returned by the query
    if (result!.isNotEmpty) {
      // Return the status from the first row
      return result.first['HOW_DID_CLIENT_EMOJI_CODE']??'-1';
    } else {
      // No matching row found, return null
      return '-1';
    }
  }


  /// ---------------------> Personal Care <-------------------------------///

  Future<void> insertPersonalCareData(CarerVisitCare data) async {

    final Database? db = await getDatabase;

    try {
      await db?.insert(
        'CMS_CARER_VISIT_PERSONAL_CARE',
        data.toMap(),
        conflictAlgorithm: ConflictAlgorithm.replace,
      );


      final snackBar = const SnackBar(
        content:  Text('Data inserted successfully!'),
        duration: Duration(seconds: 3), // Adjust the duration as needed
      );
      ScaffoldMessenger.of(context as BuildContext).showSnackBar(snackBar);
    } catch (e) {

      print('Error inserting data: $e');
    }
  }


  Future<void> updateCare(String newCareValue, String carerVisitMstId) async {
    final Database? db = await getDatabase; // Assume getDatabase returns the SQLite database instance

    await db?.update(
      'CMS_CARER_VISIT_PERSONAL_CARE',
      {'PERSONAL_CARE': newCareValue},
      where: 'CARER_VISIT_MST_ID = ?',
      whereArgs: [carerVisitMstId],
    );
  }


  Future<void> deleteCareByMstId(String carerVisitMstId) async {
    final Database? db = await getDatabase; // Assume getDatabase returns the SQLite database instance

    await db?.delete(
      'CMS_CARER_VISIT_PERSONAL_CARE',
      where: 'CARER_VISIT_MST_ID = ?',
      whereArgs: [carerVisitMstId],
    );
  }


  Future<List<dynamic>> isCareExistsByMstId(String carerVisitMstId) async {
    final Database? db = await getDatabase; // Assume getDatabase returns the SQLite database instance

    List<Map<String, dynamic>>? result = await db?.query(
      'CMS_CARER_VISIT_PERSONAL_CARE',
      where: 'CARER_VISIT_MST_ID = ?',
      whereArgs: [carerVisitMstId],
    );

    if (result!.isNotEmpty) {
      // If data exists, return a list with true and the Drinks data
      return [true, result.first['PERSONAL_CARE']];
    } else {
      print('NULL');
      // If data doesn't exist, return a list with false and null for Drinks data
      return [false, null];
    }
  }

  Future<String?> getCareStatusByMstId(String mstId) async {
    final Database? db = await getDatabase; // Assume getDatabase returns the SQLite database instance

    List<Map<String, dynamic>>? result = await db?.query(
      'CMS_CARER_VISIT_PERSONAL_CARE',
      columns: ['STATUS'], // Select only the STATUS column
      where: 'CARER_VISIT_MST_ID = ?',
      whereArgs: [mstId],
    );

    // Check if any row is returned by the query
    if (result!.isNotEmpty) {
      // Return the status from the first row
      return result[0]['STATUS'];
    } else {
      // No matching row found, return null
      return "N";
    }
  }


  /// ---------------------> Toilet Assistance <-------------------------------///

  Future<void> insertToiletData(CarerVisitToilet data) async {

    final Database? db = await getDatabase;

    try {
      await db?.insert(
        'CMS_CARER_VISIT_TOILET_ASSIST',
        data.toMap(),
        conflictAlgorithm: ConflictAlgorithm.replace,
      );


      final snackBar = const SnackBar(
        content:  Text('Data inserted successfully!'),
        duration: Duration(seconds: 3), // Adjust the duration as needed
      );
      ScaffoldMessenger.of(context as BuildContext).showSnackBar(snackBar);
    } catch (e) {

      print('Error inserting data: $e');
    }
  }


  Future<void> updateToilet(String newToiletValue, String carerVisitMstId) async {
    final Database? db = await getDatabase; // Assume getDatabase returns the SQLite database instance

    await db?.update(
      'CMS_CARER_VISIT_TOILET_ASSIST',
      {'TOILET_ASSISTANT': newToiletValue},
      where: 'CARER_VISIT_MST_ID = ?',
      whereArgs: [carerVisitMstId],
    );
  }


  Future<void> deleteToiletByMstId(String carerVisitMstId) async {
    final Database? db = await getDatabase; // Assume getDatabase returns the SQLite database instance

    await db?.delete(
      'CMS_CARER_VISIT_TOILET_ASSIST',
      where: 'CARER_VISIT_MST_ID = ?',
      whereArgs: [carerVisitMstId],
    );
  }


  Future<List<dynamic>> isToiletExistsByMstId(String carerVisitMstId) async {
    final Database? db = await getDatabase; // Assume getDatabase returns the SQLite database instance

    List<Map<String, dynamic>>? result = await db?.query(
      'CMS_CARER_VISIT_TOILET_ASSIST',
      where: 'CARER_VISIT_MST_ID = ?',
      whereArgs: [carerVisitMstId],
    );

    if (result!.isNotEmpty) {
      // If data exists, return a list with true and the Drinks data

      return [true, result.first['TOILET_ASSISTANT']];
    } else {
      print('NULL');
      // If data doesn't exist, return a list with false and null for Drinks data
      return [false, null];
    }
  }

  Future<String?> getToiletStatusByMstId(String mstId) async {
    final Database? db = await getDatabase; // Assume getDatabase returns the SQLite database instance

    List<Map<String, dynamic>>? result = await db?.query(
      'CMS_CARER_VISIT_TOILET_ASSIST',
      columns: ['STATUS'], // Select only the STATUS column
      where: 'CARER_VISIT_MST_ID = ?',
      whereArgs: [mstId],
    );

    // Check if any row is returned by the query
    if (result!.isNotEmpty) {
      // Return the status from the first row
      return result[0]['STATUS'];
    } else {
      // No matching row found, return null
      return "N";
    }
  }
  /// ---------------------> REPOSITIONING   <-------------------------------///

  Future<void> insertRepositioningData(CarerVisitRepositioning data) async {

    final Database? db = await getDatabase;

    try {
      await db?.insert(
        'CMS_CARER_VISIT_REPOSITIONING',
        data.toMap(),
        conflictAlgorithm: ConflictAlgorithm.replace,
      );


      final snackBar = SnackBar(
        content: Text('Data inserted successfully!'),
        duration: Duration(seconds: 3), // Adjust the duration as needed
      );
      ScaffoldMessenger.of(context as BuildContext).showSnackBar(snackBar);
    } catch (e) {

      print('Error inserting data: $e');
    }
  }


  Future<void> updateRepositioning(String newRepositioningValue, String carerVisitMstId) async {
    final Database? db = await getDatabase; // Assume getDatabase returns the SQLite database instance

    await db?.update(
      'CMS_CARER_VISIT_REPOSITIONING',
      {'REPOSITIONING': newRepositioningValue},
      where: 'CARER_VISIT_MST_ID = ?',
      whereArgs: [carerVisitMstId],
    );
  }


  Future<void> deleteRepositioningByMstId(String carerVisitMstId) async {
    final Database? db = await getDatabase; // Assume getDatabase returns the SQLite database instance

    await db?.delete(
      'CMS_CARER_VISIT_REPOSITIONING',
      where: 'CARER_VISIT_MST_ID = ?',
      whereArgs: [carerVisitMstId],
    );
  }


  Future<List<dynamic>> isRepositioningExistsByMstId(String carerVisitMstId) async {
    final Database? db = await getDatabase; // Assume getDatabase returns the SQLite database instance

    List<Map<String, dynamic>>? result = await db?.query(
      'CMS_CARER_VISIT_REPOSITIONING',
      where: 'CARER_VISIT_MST_ID = ?',
      whereArgs: [carerVisitMstId],
    );

    if (result!.isNotEmpty) {
      // If data exists, return a list with true and the Repositioning data

      return [true, result.first['REPOSITIONING']];
    } else {
      print('NULL');
      // If data doesn't exist, return a list with false and null for Repositioning data
      return [false, null];
    }
  }

  Future<String?> getRepositioningStatusByMstId(String mstId) async {
    final Database? db = await getDatabase; // Assume getDatabase returns the SQLite database instance

    List<Map<String, dynamic>>? result = await db?.query(
      'CMS_CARER_VISIT_REPOSITIONING',
      columns: ['STATUS'], // Select only the STATUS column
      where: 'CARER_VISIT_MST_ID = ?',
      whereArgs: [mstId],
    );

    // Check if any row is returned by the query
    if (result!.isNotEmpty) {
      // Return the status from the first row
      return result[0]['STATUS'];
    } else {
      // No matching row found, return null
      return "N";
    }
  }




  /// ---------------------> Companionship   <-------------------------------///

  Future<void> insertCompanionshipData(CarerVisitCompanionship data) async {

    final Database? db = await getDatabase;

    try {
      await db?.insert(
        'CMS_CARER_VISIT_CMPNNSHP_RESPT',
        data.toMap(),
        conflictAlgorithm: ConflictAlgorithm.replace,
      );


      final snackBar = SnackBar(
        content: Text('Data inserted successfully!'),
        duration: Duration(seconds: 3), // Adjust the duration as needed
      );
      ScaffoldMessenger.of(context as BuildContext).showSnackBar(snackBar);
    } catch (e) {

      print('Error inserting data: $e');
    }
  }


  Future<void> updateCompanionship(String newCompanionshipValue, String carerVisitMstId) async {
    final Database? db = await getDatabase; // Assume getDatabase returns the SQLite database instance

    await db?.update(
      'CMS_CARER_VISIT_CMPNNSHP_RESPT',
      {'COMPANIONSHIP_RESPITE': newCompanionshipValue},
      where: 'CARER_VISIT_MST_ID = ?',
      whereArgs: [carerVisitMstId],
    );
  }


  Future<void> deleteCompanionshipByMstId(String carerVisitMstId) async {
    final Database? db = await getDatabase; // Assume getDatabase returns the SQLite database instance

    await db?.delete(
      'CMS_CARER_VISIT_CMPNNSHP_RESPT',
      where: 'CARER_VISIT_MST_ID = ?',
      whereArgs: [carerVisitMstId],
    );
  }


  Future<List<dynamic>> isCompanionshipExistsByMstId(String carerVisitMstId) async {
    final Database? db = await getDatabase; // Assume getDatabase returns the SQLite database instance

    List<Map<String, dynamic>>? result = await db?.query(
      'CMS_CARER_VISIT_CMPNNSHP_RESPT',
      where: 'CARER_VISIT_MST_ID = ?',
      whereArgs: [carerVisitMstId],
    );

    if (result!.isNotEmpty) {
      // If data exists, return a list with true and the Companionship data

      return [true, result.first['COMPANIONSHIP_RESPITE']];
    } else {
      print('NULL');
      // If data doesn't exist, return a list with false and null for Companionship data
      return [false, null];
    }
  }

  Future<String?> getCompanionshipStatusByMstId(String mstId) async {
    final Database? db = await getDatabase; // Assume getDatabase returns the SQLite database instance

    List<Map<String, dynamic>>? result = await db?.query(
      'CMS_CARER_VISIT_CMPNNSHP_RESPT',
      columns: ['STATUS'], // Select only the STATUS column
      where: 'CARER_VISIT_MST_ID = ?',
      whereArgs: [mstId],
    );

    // Check if any row is returned by the query
    if (result!.isNotEmpty) {
      // Return the status from the first row
      return result[0]['STATUS'];
    } else {
      // No matching row found, return null
      return "N";
    }
  }


  /// ---------------------> Laundry   <-------------------------------///

  Future<void> insertLaundryData(CarerVisitLaundry data) async {
    final Database? db = await getDatabase;
    try {
      await db?.insert(
        'CMS_CARER_VISIT_LAUNDRY',
        data.toMap(),
        conflictAlgorithm: ConflictAlgorithm.replace,
      );

      final snackBar = SnackBar(
        content: Text('Data inserted successfully!'),
        duration: Duration(seconds: 3), // Adjust the duration as needed
      );
      ScaffoldMessenger.of(context as BuildContext).showSnackBar(snackBar);
    } catch (e) {

      print('Error inserting data: $e');
    }
  }


  Future<void> updateLaundry(String newLaundryValue, String carerVisitMstId) async {
    final Database? db = await getDatabase; // Assume getDatabase returns the SQLite database instance

    await db?.update(
      'CMS_CARER_VISIT_LAUNDRY',
      {'LAUNDRY': newLaundryValue},
      where: 'CARER_VISIT_MST_ID = ?',
      whereArgs: [carerVisitMstId],
    );
  }


  Future<void> deleteLaundryByMstId(String carerVisitMstId) async {
    final Database? db = await getDatabase; // Assume getDatabase returns the SQLite database instance

    await db?.delete(
      'CMS_CARER_VISIT_LAUNDRY',
      where: 'CARER_VISIT_MST_ID = ?',
      whereArgs: [carerVisitMstId],
    );
  }


  Future<List<dynamic>> isLaundryExistsByMstId(String carerVisitMstId) async {
    final Database? db = await getDatabase; // Assume getDatabase returns the SQLite database instance

    List<Map<String, dynamic>>? result = await db?.query(
      'CMS_CARER_VISIT_LAUNDRY',
      where: 'CARER_VISIT_MST_ID = ?',
      whereArgs: [carerVisitMstId],
    );

    if (result!.isNotEmpty) {
      // If data exists, return a list with true and the Laundry data

      return [true, result.first['LAUNDRY']];
    } else {
      print('NULL');
      // If data doesn't exist, return a list with false and null for Laundry data
      return [false, null];
    }
  }

  Future<String?> getLaundryStatusByMstId(String mstId) async {
    final Database? db = await getDatabase; // Assume getDatabase returns the SQLite database instance

    List<Map<String, dynamic>>? result = await db?.query(
      'CMS_CARER_VISIT_LAUNDRY',
      columns: ['STATUS'], // Select only the STATUS column
      where: 'CARER_VISIT_MST_ID = ?',
      whereArgs: [mstId],
    );

    // Check if any row is returned by the query
    if (result!.isNotEmpty) {
      // Return the status from the first row
      return result[0]['STATUS'];
    } else {
      // No matching row found, return null
      return "N";
    }
  }

  /// ---------------------> Groceries   <-------------------------------///

  Future<void> insertGroceriesData(CarerVisitGroceries data) async {
    final Database? db = await getDatabase;
    try {
      await db?.insert(
        'CMS_CARER_VISIT_GROCERIES',
        data.toMap(),
        conflictAlgorithm: ConflictAlgorithm.replace,
      );

      final snackBar = SnackBar(
        content: Text('Data inserted successfully!'),
        duration: Duration(seconds: 3), // Adjust the duration as needed
      );
      ScaffoldMessenger.of(context as BuildContext).showSnackBar(snackBar);
    } catch (e) {

      print('Error inserting data: $e');
    }
  }


  Future<void> updateGroceries(String newGroceriesValue, String carerVisitMstId) async {
    final Database? db = await getDatabase; // Assume getDatabase returns the SQLite database instance

    await db?.update(
      'CMS_CARER_VISIT_GROCERIES',
      {'GROCERIES': newGroceriesValue},
      where: 'CARER_VISIT_MST_ID = ?',
      whereArgs: [carerVisitMstId],
    );
  }


  Future<void> deleteGroceriesByMstId(String carerVisitMstId) async {
    final Database? db = await getDatabase; // Assume getDatabase returns the SQLite database instance

    await db?.delete(
      'CMS_CARER_VISIT_GROCERIES',
      where: 'CARER_VISIT_MST_ID = ?',
      whereArgs: [carerVisitMstId],
    );
  }


  Future<List<dynamic>> isGroceriesExistsByMstId(String carerVisitMstId) async {
    final Database? db = await getDatabase; // Assume getDatabase returns the SQLite database instance

    List<Map<String, dynamic>>? result = await db?.query(
      'CMS_CARER_VISIT_GROCERIES',
      where: 'CARER_VISIT_MST_ID = ?',
      whereArgs: [carerVisitMstId],
    );

    if (result!.isNotEmpty) {
      // If data exists, return a list with true and the Groceries data

      return [true, result.first['GROCERIES']];
    } else {
      print('NULL');
      // If data doesn't exist, return a list with false and null for Groceries data
      return [false, null];
    }
  }

  Future<String?> getGroceriesStatusByMstId(String mstId) async {
    final Database? db = await getDatabase; // Assume getDatabase returns the SQLite database instance

    List<Map<String, dynamic>>? result = await db?.query(
      'CMS_CARER_VISIT_GROCERIES',
      columns: ['STATUS'], // Select only the STATUS column
      where: 'CARER_VISIT_MST_ID = ?',
      whereArgs: [mstId],
    );

    // Check if any row is returned by the query
    if (result!.isNotEmpty) {
      // Return the status from the first row
      return result[0]['STATUS'];
    } else {
      // No matching row found, return null
      return "N";
    }
  }



  /// ---------------------> Housework   <-------------------------------///

  Future<void> insertHouseworkData(CarerVisitHousework data) async {
    final Database? db = await getDatabase;
    try {
      await db?.insert(
        'CMS_CARER_VISIT_HOUSEWORK',
        data.toMap(),
        conflictAlgorithm: ConflictAlgorithm.replace,
      );

      final snackBar = SnackBar(
        content: Text('Data inserted successfully!'),
        duration: Duration(seconds: 3), // Adjust the duration as needed
      );
      ScaffoldMessenger.of(context as BuildContext).showSnackBar(snackBar);
    } catch (e) {

      print('Error inserting data: $e');
    }
  }


  Future<void> updateHousework(String newHouseworkValue, String carerVisitMstId) async {
    final Database? db = await getDatabase; // Assume getDatabase returns the SQLite database instance

    await db?.update(
      'CMS_CARER_VISIT_HOUSEWORK',
      {'HOUSEWORK': newHouseworkValue},
      where: 'CARER_VISIT_MST_ID = ?',
      whereArgs: [carerVisitMstId],
    );
  }


  Future<void> deleteHouseworkByMstId(String carerVisitMstId) async {
    final Database? db = await getDatabase; // Assume getDatabase returns the SQLite database instance

    await db?.delete(
      'CMS_CARER_VISIT_HOUSEWORK',
      where: 'CARER_VISIT_MST_ID = ?',
      whereArgs: [carerVisitMstId],
    );
  }


  Future<List<dynamic>> isHouseworkExistsByMstId(String carerVisitMstId) async {
    final Database? db = await getDatabase; // Assume getDatabase returns the SQLite database instance

    List<Map<String, dynamic>>? result = await db?.query(
      'CMS_CARER_VISIT_HOUSEWORK',
      where: 'CARER_VISIT_MST_ID = ?',
      whereArgs: [carerVisitMstId],
    );

    if (result!.isNotEmpty) {
      // If data exists, return a list with true and the Housework data

      return [true, result.first['HOUSEWORK']];
    } else {
      print('NULL');
      // If data doesn't exist, return a list with false and null for Housework data
      return [false, null];
    }
  }

  Future<String?> getHouseworkStatusByMstId(String mstId) async {
    final Database? db = await getDatabase; // Assume getDatabase returns the SQLite database instance

    List<Map<String, dynamic>>? result = await db?.query(
      'CMS_CARER_VISIT_HOUSEWORK',
      columns: ['STATUS'], // Select only the STATUS column
      where: 'CARER_VISIT_MST_ID = ?',
      whereArgs: [mstId],
    );

    // Check if any row is returned by the query
    if (result!.isNotEmpty) {
      // Return the status from the first row
      return result[0]['STATUS'];
    } else {
      // No matching row found, return null
      return "N";
    }
  }


  /// ---------------------> Household   <-------------------------------///

  Future<void> insertHouseholdData(CarerVisitHousehold data) async {
    final Database? db = await getDatabase;
    try {
      await db?.insert(
        'CMS_CARER_VISIT_HOUSHLD_CHORES',
        data.toMap(),
        conflictAlgorithm: ConflictAlgorithm.replace,
      );

      final snackBar = SnackBar(
        content: Text('Data inserted successfully!'),
        duration: Duration(seconds: 3), // Adjust the duration as needed
      );
      ScaffoldMessenger.of(context as BuildContext).showSnackBar(snackBar);
    } catch (e) {

      print('Error inserting data: $e');
    }
  }


  Future<void> updateHousehold(String newHouseholdValue, String carerVisitMstId) async {
    final Database? db = await getDatabase; // Assume getDatabase returns the SQLite database instance

    await db?.update(
      'CMS_CARER_VISIT_HOUSHLD_CHORES',
      {'HOUSEHOLD_CHORES': newHouseholdValue},
      where: 'CARER_VISIT_MST_ID = ?',
      whereArgs: [carerVisitMstId],
    );
  }


  Future<void> deleteHouseholdByMstId(String carerVisitMstId) async {
    final Database? db = await getDatabase; // Assume getDatabase returns the SQLite database instance

    await db?.delete(
      'CMS_CARER_VISIT_HOUSHLD_CHORES',
      where: 'CARER_VISIT_MST_ID = ?',
      whereArgs: [carerVisitMstId],
    );
  }


  Future<List<dynamic>> isHouseholdExistsByMstId(String carerVisitMstId) async {
    final Database? db = await getDatabase; // Assume getDatabase returns the SQLite database instance

    List<Map<String, dynamic>>? result = await db?.query(
      'CMS_CARER_VISIT_HOUSHLD_CHORES',
      where: 'CARER_VISIT_MST_ID = ?',
      whereArgs: [carerVisitMstId],
    );

    if (result!.isNotEmpty) {
      // If data exists, return a list with true and the Household data

      return [true, result.first['HOUSEHOLD_CHORES']];
    } else {
      print('NULL');
      // If data doesn't exist, return a list with false and null for Household data
      return [false, null];
    }
  }

  Future<String?> getHouseholdStatusByMstId(String mstId) async {
    final Database? db = await getDatabase; // Assume getDatabase returns the SQLite database instance

    List<Map<String, dynamic>>? result = await db?.query(
      'CMS_CARER_VISIT_HOUSHLD_CHORES',
      columns: ['STATUS'], // Select only the STATUS column
      where: 'CARER_VISIT_MST_ID = ?',
      whereArgs: [mstId],
    );

    // Check if any row is returned by the query
    if (result!.isNotEmpty) {
      // Return the status from the first row
      return result[0]['STATUS'];
    } else {
      // No matching row found, return null
      return "N";
    }
  }

  /// ---------------------> Unable   <-------------------------------///

  Future<void> insertUnableData(CarerVisitUnable data) async {
    final Database? db = await getDatabase;
    try {
      await db?.insert(
        'CMS_CARER_VISIT_UNBLE_DLVR_DTL',
        data.toMap(),
        conflictAlgorithm: ConflictAlgorithm.replace,
      );

      final snackBar = SnackBar(
        content: Text('Data inserted successfully!'),
        duration: Duration(seconds: 3), // Adjust the duration as needed
      );
      ScaffoldMessenger.of(context as BuildContext).showSnackBar(snackBar);
    } catch (e) {

      print('Error inserting data: $e');
    }
  }


  Future<void> updateUnable(String newUnableValue, String carerVisitMstId) async {
    final Database? db = await getDatabase; // Assume getDatabase returns the SQLite database instance

    await db?.update(
      'CMS_CARER_VISIT_UNBLE_DLVR_DTL',
      {'UNABLE_DELIVER_DTL': newUnableValue},
      where: 'CARER_VISIT_MST_ID = ?',
      whereArgs: [carerVisitMstId],
    );
  }


  Future<void> deleteUnableByMstId(String carerVisitMstId) async {
    final Database? db = await getDatabase; // Assume getDatabase returns the SQLite database instance

    await db?.delete(
      'CMS_CARER_VISIT_UNBLE_DLVR_DTL',
      where: 'CARER_VISIT_MST_ID = ?',
      whereArgs: [carerVisitMstId],
    );
  }


  Future<List<dynamic>> isUnableExistsByMstId(String carerVisitMstId) async {
    final Database? db = await getDatabase; // Assume getDatabase returns the SQLite database instance

    List<Map<String, dynamic>>? result = await db?.query(
      'CMS_CARER_VISIT_UNBLE_DLVR_DTL',
      where: 'CARER_VISIT_MST_ID = ?',
      whereArgs: [carerVisitMstId],
    );

    if (result!.isNotEmpty) {
      // If data exists, return a list with true and the Unable data

      return [true, result.first['UNABLE_DELIVER_DTL']];
    } else {
      print('NULL');
      // If data doesn't exist, return a list with false and null for Unable data
      return [false, null];
    }
  }

  Future<String?> getUnableStatusByMstId(String mstId) async {
    final Database? db = await getDatabase; // Assume getDatabase returns the SQLite database instance

    List<Map<String, dynamic>>? result = await db?.query(
      'CMS_CARER_VISIT_UNBLE_DLVR_DTL',
      columns: ['STATUS'], // Select only the STATUS column
      where: 'CARER_VISIT_MST_ID = ?',
      whereArgs: [mstId],
    );

    // Check if any row is returned by the query
    if (result!.isNotEmpty) {
      // Return the status from the first row
      return result[0]['STATUS'];
    } else {
      // No matching row found, return null
      return "N";
    }
  }

  Future<List<Map<String, dynamic>>?> getTaskCode(String clntVisitTypeMstID, String clientId) async {

    print("Task");
    print(clntVisitTypeMstID);
    print(clientId);

    try {
      final Database? db = await getDatabase;

      List<Map<String, dynamic>> result = await db!.rawQuery(
          'SELECT TASK_CODE, VISIT_TYPE_NAME, NOTES_FOR_CARER FROM DPD_CLIENT_VISIT_TYPE_DTL WHERE CLIENT_VISIT_TYPE_MST_ID = ? AND CLIENT_ID = ?',
          [clntVisitTypeMstID, clientId]);

      if (result.isNotEmpty) {
        //print(result);
        return result;
      } else {
        print("EMPTY");
        return [];
      }
    } catch (e) {
      print('Error fetching task code: $e');
      return null;
    }
  }



}
