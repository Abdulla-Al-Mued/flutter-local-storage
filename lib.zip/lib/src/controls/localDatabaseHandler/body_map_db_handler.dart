import 'package:sqflite/sqflite.dart';

import '../../models/insertion/BodyMap.dart';
import 'local_database_handler.dart';

class BodyMapHandler{

  final LocalDatabaseHandler dbHandler = LocalDatabaseHandler();

  Future<int?> insertBodyMap(CarerVisitBodyMap data, String visitMasterId) async {

    final Database? db = await dbHandler.getDatabase;

    try {
      return await db!.transaction<int>((txn) async {

        List<Map<String, dynamic>> result = await txn.query(
          'CMS_CARER_VISIT_BODY_MAP',
          where: 'CARER_VISIT_MST_ID = ?',
          whereArgs: [visitMasterId],
        );

        if (result.isNotEmpty) {

          return result.first['CARER_VISIT_MST_ID'] as int;
        } else {

          return await txn.insert('CMS_CARER_VISIT_BODY_MAP', data.toMap());
        }
      });
    } catch (e) {
      print('Error inserting item: $e');
      return null;
    }
  }

  Future<void> updateBodyMapTaskCode(String taskCode, String mstId, String notes) async {
    final Database? db = await dbHandler.getDatabase;

    if(taskCode == "D"){
      await db?.rawUpdate(
        '''UPDATE CMS_CARER_VISIT_BODY_MAP
          SET TASK_CODE = NULL
          WHERE CARER_VISIT_MST_ID = ?;'''
          ,
          [mstId]);
    }
    else{
      await db?.rawUpdate(
        'UPDATE CMS_CARER_VISIT_BODY_MAP SET TASK_CODE = ?, GENERAL_NOTES = ? WHERE CARER_VISIT_MST_ID = ?',
        [taskCode,notes, mstId],
      );
    }



  }


  Future<Map<String, dynamic>?> getBodyMapDataByMstId(String carerVisitMstId) async {
    // Open the database

    final Database? db = await dbHandler.getDatabase;

    // Query the database to fetch all the column values based on the CARER_VISIT_MST_ID
    List<Map<String, dynamic>>? results = await db?.rawQuery(
      'SELECT * FROM CMS_CARER_VISIT_BODY_MAP WHERE CARER_VISIT_MST_ID = ?',
      [carerVisitMstId],
    );


    if (results!.isEmpty) {
      return null;
    }


    return results.first;
  }

  Future<bool> getBodyMapDataByMstId2(String carerVisitMstId) async {

    List<String> bodyParts = [
      'FRONT_HEAD_NECK',
      'FRONT_RIGHT_SHOULDER',
      'FRONT_LEFT_SHOULDER',
      'FRONT_RIGHT_UPPER_ARM_ELBOW',
      'FRONT_RIGHT_FOREARM',
      'FRONT_RIGHT_HAND_WRIST',
      'FRONT_LEFT_UPPER_ARM_ELBOW',
      'FRONT_LEFT_FOREARM',
      'FRONT_LEFT_HAND_WRIST',
      'FRONT_RIGHT_CHEST',
      'FRONT_LEFT_CHEST',
      'FRONT_ABDOMEN',
      'FRONT_GROIN',
      'FRONT_RIGHT_UPPER_LEG',
      'FRONT_RIGHT_KNEE',
      'FRONT_RIGHT_LOWER_LEG',
      'FRONT_RIGHT_FOOT_ANKLE',
      'FRONT_LEFT_UPPER_LEG',
      'FRONT_LEFT_KNEE',
      'FRONT_LEFT_LOWER_LEG',
      'FRONT_LEFT_FOOT_ANKLE',
      'BACK_HEAD_NECK',
      'BACK_RIGHT_SHOULDER',
      'BACK_LEFT_SHOULDER',
      'BACK_RIGHT_UPPER_ARM_ELBOW',
      'BACK_RIGHT_FOREARM',
      'BACK_RIGHT_HAND_WRIST',
      'BACK_LEFT_UPPER_ARM_ELBOW',
      'BACK_LEFT_FOREARM',
      'BACK_LEFT_HAND_WRIST',
      'BACK_UPPER_BACK',
      'BACK_LOWER_BACK',
      'BACK_BOTTOM_SACRUM',
      'BACK_RIGHT_UPPER_LEG',
      'BACK_RIGHT_KNEE',
      'BACK_RIGHT_LOWER_LEG',
      'BACK_RIGHT_FOOT_ANKLE',
      'BACK_LEFT_UPPER_LEG',
      'BACK_LEFT_KNEE',
      'BACK_LEFT_LOWER_LEG',
      'BACK_LEFT_FOOT_ANKLE'
    ];



    final Database? db = await dbHandler.getDatabase;

    List<Map<String, dynamic>>? results = await db?.rawQuery('''
      SELECT
      FRONT_HEAD_NECK,
      FRONT_RIGHT_SHOULDER,
      FRONT_LEFT_SHOULDER,
      FRONT_RIGHT_UPPER_ARM_ELBOW,
      FRONT_RIGHT_FOREARM,
      FRONT_RIGHT_HAND_WRIST,
      FRONT_LEFT_UPPER_ARM_ELBOW,
      FRONT_LEFT_FOREARM,
      FRONT_LEFT_HAND_WRIST,
      FRONT_RIGHT_CHEST,
      FRONT_LEFT_CHEST,
      FRONT_ABDOMEN,
      FRONT_GROIN,
      FRONT_RIGHT_UPPER_LEG,
      FRONT_RIGHT_KNEE,
      FRONT_RIGHT_LOWER_LEG,
      FRONT_RIGHT_FOOT_ANKLE,
      FRONT_LEFT_UPPER_LEG,
      FRONT_LEFT_KNEE,
      FRONT_LEFT_LOWER_LEG,
      FRONT_LEFT_FOOT_ANKLE,
      BACK_HEAD_NECK,
      BACK_RIGHT_SHOULDER,
      BACK_LEFT_SHOULDER,
      BACK_RIGHT_UPPER_ARM_ELBOW,
      BACK_RIGHT_FOREARM,
      BACK_RIGHT_HAND_WRIST,
      BACK_LEFT_UPPER_ARM_ELBOW,
      BACK_LEFT_FOREARM,
      BACK_LEFT_HAND_WRIST,
      BACK_UPPER_BACK,  
      BACK_LOWER_BACK,
      BACK_BOTTOM_SACRUM,
      BACK_RIGHT_UPPER_LEG,
      BACK_RIGHT_KNEE,
      BACK_RIGHT_LOWER_LEG,
      BACK_RIGHT_FOOT_ANKLE,
      BACK_LEFT_UPPER_LEG,
      BACK_LEFT_KNEE,
      BACK_LEFT_LOWER_LEG,
      BACK_LEFT_FOOT_ANKLE
      FROM
      CMS_CARER_VISIT_BODY_MAP
      WHERE
      CARER_VISIT_MST_ID = ?;''',
      [carerVisitMstId],
    );


    if(results!.isNotEmpty){
      for (var element in bodyParts) {
        if(results.first[element]!=null){
          return false;
        }
      }
    }

    return true;

  }

  Future<void> updateHead(String newHeadValue, String mstId) async {
    final Database? db = await dbHandler.getDatabase;

    await db?.rawUpdate(
      'UPDATE CMS_CARER_VISIT_BODY_MAP SET FRONT_HEAD_NECK = ? WHERE CARER_VISIT_MST_ID = ?',
      [newHeadValue, mstId],
    );

  }


  Future<void> deleteHeadByMstId(String mstId) async {
    final Database? db = await dbHandler.getDatabase;

    await db?.rawDelete(
      'UPDATE CMS_CARER_VISIT_BODY_MAP SET FRONT_HEAD_NECK = NULL WHERE CARER_VISIT_MST_ID = ?',
      [mstId],
    );
  }

  // Head End....

  Future<void> updateRightShoulder(String newRightShoulderValue, String mstId) async {
    final Database? db = await dbHandler.getDatabase;

    await db?.rawUpdate(
      'UPDATE CMS_CARER_VISIT_BODY_MAP SET FRONT_RIGHT_SHOULDER = ? WHERE CARER_VISIT_MST_ID = ?',
      [newRightShoulderValue, mstId],
    );

  }

  Future<void> deleteRightShoulderByMstId(String mstId) async {
    final Database? db = await dbHandler.getDatabase;

    await db?.rawDelete(
      'UPDATE CMS_CARER_VISIT_BODY_MAP SET FRONT_RIGHT_SHOULDER = NULL WHERE CARER_VISIT_MST_ID = ?',
      [mstId],
    );
  }
   // --------------------> end Right Shoulder
  Future<void> updateLeftShoulder(String newLeftShoulderValue, String mstId) async {
    final Database? db = await dbHandler.getDatabase;

    await db?.rawUpdate(
      'UPDATE CMS_CARER_VISIT_BODY_MAP SET FRONT_LEFT_SHOULDER = ? WHERE CARER_VISIT_MST_ID = ?',
      [newLeftShoulderValue, mstId],
    );

  }

  Future<void> deleteLeftShoulderByMstId(String mstId) async {
    final Database? db = await dbHandler.getDatabase;

    await db?.rawDelete(
      'UPDATE CMS_CARER_VISIT_BODY_MAP SET FRONT_LEFT_SHOULDER = NULL WHERE CARER_VISIT_MST_ID = ?',
      [mstId],
    );
  }
  // --------------------> end Left Shoulder


  // -------------------->  F RightElbow
  Future<void> updateRightElbow(String newRightElbowValue, String mstId) async {
    final Database? db = await dbHandler.getDatabase;

    await db?.rawUpdate(
      'UPDATE CMS_CARER_VISIT_BODY_MAP SET FRONT_RIGHT_UPPER_ARM_ELBOW = ? WHERE CARER_VISIT_MST_ID = ?',
      [newRightElbowValue, mstId],
    );

  }

  Future<void> deleteRightElbowByMstId(String mstId) async {
    final Database? db = await dbHandler.getDatabase;

    await db?.rawDelete(
      'UPDATE CMS_CARER_VISIT_BODY_MAP SET FRONT_RIGHT_UPPER_ARM_ELBOW = NULL WHERE CARER_VISIT_MST_ID = ?',
      [mstId],
    );
  }


  // -------------------->  F LeftElbow
  Future<void> updateFLeftElbow(String newLeftElbowValue, String mstId) async {
    final Database? db = await dbHandler.getDatabase;

    await db?.rawUpdate(
      'UPDATE CMS_CARER_VISIT_BODY_MAP SET FRONT_LEFT_UPPER_ARM_ELBOW = ? WHERE CARER_VISIT_MST_ID = ?',
      [newLeftElbowValue, mstId],
    );

  }

  Future<void> deleteFLeftElbowByMstId(String mstId) async {
    final Database? db = await dbHandler.getDatabase;

    await db?.rawDelete(
      'UPDATE CMS_CARER_VISIT_BODY_MAP SET FRONT_LEFT_UPPER_ARM_ELBOW = NULL WHERE CARER_VISIT_MST_ID = ?',
      [mstId],
    );
  }




  // -------------------->  Abdomen
  Future<void> updateAbdomen(String newAbdomenValue, String mstId) async {
    final Database? db = await dbHandler.getDatabase;

    await db?.rawUpdate(
      'UPDATE CMS_CARER_VISIT_BODY_MAP SET FRONT_ABDOMEN = ? WHERE CARER_VISIT_MST_ID = ?',
      [newAbdomenValue, mstId],
    );

  }

  Future<void> deleteAbdomenByMstId(String mstId) async {
    final Database? db = await dbHandler.getDatabase;

    await db?.rawDelete(
      'UPDATE CMS_CARER_VISIT_BODY_MAP SET FRONT_ABDOMEN = NULL WHERE CARER_VISIT_MST_ID = ?',
      [mstId],
    );
  }


  // -------------------->  Left Hand
  Future<void> updateFLhand(String newAbdomenValue, String mstId) async {
    final Database? db = await dbHandler.getDatabase;

    await db?.rawUpdate(
      'UPDATE CMS_CARER_VISIT_BODY_MAP SET FRONT_LEFT_HAND_WRIST = ? WHERE CARER_VISIT_MST_ID = ?',
      [newAbdomenValue, mstId],
    );

  }

  Future<void> deleteFLhandByMstId(String mstId) async {
    final Database? db = await dbHandler.getDatabase;

    await db?.rawDelete(
      'UPDATE CMS_CARER_VISIT_BODY_MAP SET FRONT_LEFT_HAND_WRIST = NULL WHERE CARER_VISIT_MST_ID = ?',
      [mstId],
    );
  }

  // -------------------->  Right Hand
  Future<void> updateFRhand(String newAbdomenValue, String mstId) async {
    final Database? db = await dbHandler.getDatabase;

    await db?.rawUpdate(
      'UPDATE CMS_CARER_VISIT_BODY_MAP SET FRONT_RIGHT_HAND_WRIST = ? WHERE CARER_VISIT_MST_ID = ?',
      [newAbdomenValue, mstId],
    );

  }

  Future<void> deleteFRhandByMstId(String mstId) async {
    final Database? db = await dbHandler.getDatabase;

    await db?.rawDelete(
      'UPDATE CMS_CARER_VISIT_BODY_MAP SET FRONT_RIGHT_HAND_WRIST = NULL WHERE CARER_VISIT_MST_ID = ?',
      [mstId],
    );
  }

  // -------------------->  Right Elbow
  Future<void> updateFRFoream(String newAbdomenValue, String mstId) async {
    final Database? db = await dbHandler.getDatabase;

    await db?.rawUpdate(
      'UPDATE CMS_CARER_VISIT_BODY_MAP SET FRONT_RIGHT_FOREARM = ? WHERE CARER_VISIT_MST_ID = ?',
      [newAbdomenValue, mstId],
    );

  }

  Future<void> deleteFRForeamByMstId(String mstId) async {
    final Database? db = await dbHandler.getDatabase;

    await db?.rawDelete(
      'UPDATE CMS_CARER_VISIT_BODY_MAP SET FRONT_RIGHT_FOREARM = NULL WHERE CARER_VISIT_MST_ID = ?',
      [mstId],
    );
  }

  // -------------------->  Left Elbow
  Future<void> updateLeftElbow(String newLeftElbowValue, String mstId) async {
    final Database? db = await dbHandler.getDatabase;

    await db?.rawUpdate(
      'UPDATE CMS_CARER_VISIT_BODY_MAP SET FRONT_LEFT_UPPER_ARM_ELBOW = ? WHERE CARER_VISIT_MST_ID = ?',
      [newLeftElbowValue, mstId],
    );

  }

  Future<void> deleteLeftElbowByMstId(String mstId) async {
    final Database? db = await dbHandler.getDatabase;

    await db?.rawDelete(
      'UPDATE CMS_CARER_VISIT_BODY_MAP SET FRONT_LEFT_UPPER_ARM_ELBOW = NULL WHERE CARER_VISIT_MST_ID = ?',
      [mstId],
    );
  }


  // -------------------->  Left Chest
  Future<void> updateLeftChest(String newLeftElbowValue, String mstId) async {
    final Database? db = await dbHandler.getDatabase;

    await db?.rawUpdate(
      'UPDATE CMS_CARER_VISIT_BODY_MAP SET FRONT_LEFT_CHEST = ? WHERE CARER_VISIT_MST_ID = ?',
      [newLeftElbowValue, mstId],
    );

  }

  Future<void> deleteLeftChestByMstId(String mstId) async {
    final Database? db = await dbHandler.getDatabase;

    await db?.rawDelete(
      'UPDATE CMS_CARER_VISIT_BODY_MAP SET FRONT_LEFT_CHEST = NULL WHERE CARER_VISIT_MST_ID = ?',
      [mstId],
    );
  }


  // -------------------->  Right  Chest
  Future<void> updateRightChest(String newLeftElbowValue, String mstId) async {
    final Database? db = await dbHandler.getDatabase;

    await db?.rawUpdate(
      'UPDATE CMS_CARER_VISIT_BODY_MAP SET FRONT_RIGHT_CHEST = ? WHERE CARER_VISIT_MST_ID = ?',
      [newLeftElbowValue, mstId],
    );

  }

  Future<void> deleteRightChestByMstId(String mstId) async {
    final Database? db = await dbHandler.getDatabase;

    await db?.rawDelete(
      'UPDATE CMS_CARER_VISIT_BODY_MAP SET FRONT_RIGHT_CHEST = NULL WHERE CARER_VISIT_MST_ID = ?',
      [mstId],
    );
  }


  // -------------------->  Right  Forearm
  Future<void> updateFRForearm(String newLeftElbowValue, String mstId) async {
    final Database? db = await dbHandler.getDatabase;

    await db?.rawUpdate(
      'UPDATE CMS_CARER_VISIT_BODY_MAP SET FRONT_RIGHT_FOREARM = ? WHERE CARER_VISIT_MST_ID = ?',
      [newLeftElbowValue, mstId],
    );

  }

  Future<void> deleteFRForearmByMstId(String mstId) async {
    final Database? db = await dbHandler.getDatabase;

    await db?.rawDelete(
      'UPDATE CMS_CARER_VISIT_BODY_MAP SET FRONT_RIGHT_FOREARM = NULL WHERE CARER_VISIT_MST_ID = ?',
      [mstId],
    );
  }

  // -------------------->  Left  Forearm
  Future<void> updateFLForearm(String newLeftElbowValue, String mstId) async {
    final Database? db = await dbHandler.getDatabase;

    await db?.rawUpdate(
      'UPDATE CMS_CARER_VISIT_BODY_MAP SET FRONT_LEFT_FOREARM = ? WHERE CARER_VISIT_MST_ID = ?',
      [newLeftElbowValue, mstId],
    );

  }

  Future<void> deleteFLForearmByMstId(String mstId) async {
    final Database? db = await dbHandler.getDatabase;

    await db?.rawDelete(
      'UPDATE CMS_CARER_VISIT_BODY_MAP SET FRONT_LEFT_FOREARM = NULL WHERE CARER_VISIT_MST_ID = ?',
      [mstId],
    );
  }

  // -------------------->  Left  Groin
  Future<void> updateFGroin(String newLeftElbowValue, String mstId) async {
    final Database? db = await dbHandler.getDatabase;

    await db?.rawUpdate(
      'UPDATE CMS_CARER_VISIT_BODY_MAP SET FRONT_GROIN = ? WHERE CARER_VISIT_MST_ID = ?',
      [newLeftElbowValue, mstId],
    );

  }

  Future<void> deleteFGroinByMstId(String mstId) async {
    final Database? db = await dbHandler.getDatabase;

    await db?.rawDelete(
      'UPDATE CMS_CARER_VISIT_BODY_MAP SET FRONT_GROIN = NULL WHERE CARER_VISIT_MST_ID = ?',
      [mstId],
    );
  }

  // -------------------->  Right Upper Leg
  Future<void> updateFRUpperLeg(String newFRUpperLegValue, String mstId) async {
    final Database? db = await dbHandler.getDatabase;

    await db?.rawUpdate(
      'UPDATE CMS_CARER_VISIT_BODY_MAP SET FRONT_RIGHT_UPPER_LEG = ? WHERE CARER_VISIT_MST_ID = ?',
      [newFRUpperLegValue, mstId],
    );

  }

  Future<void> deleteFRUpperLegByMstId(String mstId) async {
    final Database? db = await dbHandler.getDatabase;

    await db?.rawDelete(
      'UPDATE CMS_CARER_VISIT_BODY_MAP SET FRONT_RIGHT_UPPER_LEG = NULL WHERE CARER_VISIT_MST_ID = ?',
      [mstId],
    );
  }

  // -------------------->  Left Upper Leg
  Future<void> updateFLUpperLeg(String newFLUpperLegValue, String mstId) async {
    final Database? db = await dbHandler.getDatabase;

    await db?.rawUpdate(
      'UPDATE CMS_CARER_VISIT_BODY_MAP SET FRONT_LEFT_UPPER_LEG = ? WHERE CARER_VISIT_MST_ID = ?',
      [newFLUpperLegValue, mstId],
    );

  }

  Future<void> deleteFLUpperLegByMstId(String mstId) async {
    final Database? db = await dbHandler.getDatabase;

    await db?.rawDelete(
      'UPDATE CMS_CARER_VISIT_BODY_MAP SET FRONT_LEFT_UPPER_LEG = NULL WHERE CARER_VISIT_MST_ID = ?',
      [mstId],
    );
  }

  // -------------------->  Right Knee
  Future<void> updateFRKnee(String newFLUpperLegValue, String mstId) async {
    final Database? db = await dbHandler.getDatabase;

    await db?.rawUpdate(
      'UPDATE CMS_CARER_VISIT_BODY_MAP SET FRONT_RIGHT_KNEE = ? WHERE CARER_VISIT_MST_ID = ?',
      [newFLUpperLegValue, mstId],
    );

  }

  Future<void> deleteFRKneeByMstId(String mstId) async {
    final Database? db = await dbHandler.getDatabase;

    await db?.rawDelete(
      'UPDATE CMS_CARER_VISIT_BODY_MAP SET FRONT_RIGHT_KNEE = NULL WHERE CARER_VISIT_MST_ID = ?',
      [mstId],
    );
  }

  // -------------------->  Left Knee
  Future<void> updateFLKnee(String newFLUpperLegValue, String mstId) async {
    final Database? db = await dbHandler.getDatabase;

    await db?.rawUpdate(
      'UPDATE CMS_CARER_VISIT_BODY_MAP SET FRONT_LEFT_KNEE = ? WHERE CARER_VISIT_MST_ID = ?',
      [newFLUpperLegValue, mstId],
    );

  }

  Future<void> deleteFLKneeByMstId(String mstId) async {
    final Database? db = await dbHandler.getDatabase;

    await db?.rawDelete(
      'UPDATE CMS_CARER_VISIT_BODY_MAP SET FRONT_LEFT_KNEE = NULL WHERE CARER_VISIT_MST_ID = ?',
      [mstId],
    );
  }

  // -------------------->  Right Lower Leg
  Future<void> updateFRLowerLeg(String newFLUpperLegValue, String mstId) async {
    final Database? db = await dbHandler.getDatabase;

    await db?.rawUpdate(
      'UPDATE CMS_CARER_VISIT_BODY_MAP SET FRONT_RIGHT_LOWER_LEG = ? WHERE CARER_VISIT_MST_ID = ?',
      [newFLUpperLegValue, mstId],
    );

  }

  Future<void> deleteFRLowerLegByMstId(String mstId) async {
    final Database? db = await dbHandler.getDatabase;

    await db?.rawDelete(
      'UPDATE CMS_CARER_VISIT_BODY_MAP SET FRONT_RIGHT_LOWER_LEG = NULL WHERE CARER_VISIT_MST_ID = ?',
      [mstId],
    );
  }

  // -------------------->  Left Lower Leg
  Future<void> updateFlLowerLeg(String newFLLowerLegValue, String mstId) async {
    final Database? db = await dbHandler.getDatabase;

    await db?.rawUpdate(
      'UPDATE CMS_CARER_VISIT_BODY_MAP SET FRONT_LEFT_LOWER_LEG = ? WHERE CARER_VISIT_MST_ID = ?',
      [newFLLowerLegValue, mstId],
    );

  }

  Future<void> deleteFlLowerLegByMstId(String mstId) async {
    final Database? db = await dbHandler.getDatabase;

    await db?.rawDelete(
      'UPDATE CMS_CARER_VISIT_BODY_MAP SET FRONT_LEFT_LOWER_LEG = NULL WHERE CARER_VISIT_MST_ID = ?',
      [mstId],
    );
  }


  // -------------------->  Right Lower Foot
  Future<void> updateFRfoot(String newFLUpperLegValue, String mstId) async {
    final Database? db = await dbHandler.getDatabase;

    await db?.rawUpdate(
      'UPDATE CMS_CARER_VISIT_BODY_MAP SET FRONT_RIGHT_FOOT_ANKLE = ? WHERE CARER_VISIT_MST_ID = ?',
      [newFLUpperLegValue, mstId],
    );

  }

  Future<void> deleteFRfootByMstId(String mstId) async {
    final Database? db = await dbHandler.getDatabase;

    await db?.rawDelete(
      'UPDATE CMS_CARER_VISIT_BODY_MAP SET FRONT_RIGHT_FOOT_ANKLE = NULL WHERE CARER_VISIT_MST_ID = ?',
      [mstId],
    );
  }




  // -------------------->  Left Lower Foot
  Future<void> updateFLfoot(String newFLUpperLegValue, String mstId) async {
    final Database? db = await dbHandler.getDatabase;

    await db?.rawUpdate(
      'UPDATE CMS_CARER_VISIT_BODY_MAP SET FRONT_LEFT_FOOT_ANKLE = ? WHERE CARER_VISIT_MST_ID = ?',
      [newFLUpperLegValue, mstId],
    );

  }

  Future<void> deleteFLfootByMstId(String mstId) async {
    final Database? db = await dbHandler.getDatabase;

    await db?.rawDelete(
      'UPDATE CMS_CARER_VISIT_BODY_MAP SET FRONT_LEFT_FOOT_ANKLE = NULL WHERE CARER_VISIT_MST_ID = ?',
      [mstId],
    );
  }

  // --------------------> Back head
  Future<void> updateBhead(String newbackHead, String mstId) async {
    final Database? db = await dbHandler.getDatabase;

    await db?.rawUpdate(
      'UPDATE CMS_CARER_VISIT_BODY_MAP SET BACK_HEAD_NECK = ? WHERE CARER_VISIT_MST_ID = ?',
      [newbackHead, mstId],
    );

  }

  Future<void> deleteBheadByMstId(String mstId) async {
    final Database? db = await dbHandler.getDatabase;

    await db?.rawDelete(
      'UPDATE CMS_CARER_VISIT_BODY_MAP SET BACK_HEAD_NECK = NULL WHERE CARER_VISIT_MST_ID = ?',
      [mstId],
    );
  }

  // -------------------->  Back Right Shoulder
  Future<void> updateBRshoulder(String newFLUpperLegValue, String mstId) async {
    final Database? db = await dbHandler.getDatabase;

    await db?.rawUpdate(
      'UPDATE CMS_CARER_VISIT_BODY_MAP SET BACK_RIGHT_SHOULDER = ? WHERE CARER_VISIT_MST_ID = ?',
      [newFLUpperLegValue, mstId],
    );

  }

  Future<void> deleteBRshoulderByMstId(String mstId) async {
    final Database? db = await dbHandler.getDatabase;

    await db?.rawDelete(
      'UPDATE CMS_CARER_VISIT_BODY_MAP SET BACK_RIGHT_SHOULDER = NULL WHERE CARER_VISIT_MST_ID = ?',
      [mstId],
    );
  }

  // --------------------> Back Left Shoulder
  Future<void> updateBLshoulder(String newFLUpperLegValue, String mstId) async {
    final Database? db = await dbHandler.getDatabase;

    await db?.rawUpdate(
      'UPDATE CMS_CARER_VISIT_BODY_MAP SET BACK_LEFT_SHOULDER = ? WHERE CARER_VISIT_MST_ID = ?',
      [newFLUpperLegValue, mstId],
    );

  }

  Future<void> deleteBLshoulderByMstId(String mstId) async {
    final Database? db = await dbHandler.getDatabase;

    await db?.rawDelete(
      'UPDATE CMS_CARER_VISIT_BODY_MAP SET BACK_LEFT_SHOULDER = NULL WHERE CARER_VISIT_MST_ID = ?',
      [mstId],
    );
  }

  // -------------------->  Back Right Elbow
  Future<void> updateBRelbow(String newFLUpperLegValue, String mstId) async {
    final Database? db = await dbHandler.getDatabase;

    await db?.rawUpdate(
      'UPDATE CMS_CARER_VISIT_BODY_MAP SET BACK_RIGHT_UPPER_ARM_ELBOW = ? WHERE CARER_VISIT_MST_ID = ?',
      [newFLUpperLegValue, mstId],
    );

  }

  Future<void> deleteBRelbowByMstId(String mstId) async {
    final Database? db = await dbHandler.getDatabase;

    await db?.rawDelete(
      'UPDATE CMS_CARER_VISIT_BODY_MAP SET BACK_RIGHT_UPPER_ARM_ELBOW = NULL WHERE CARER_VISIT_MST_ID = ?',
      [mstId],
    );
  }

  // -------------------->  Back Left Elbow
  Future<void> updateBLelbow(String newFLUpperLegValue, String mstId) async {
    final Database? db = await dbHandler.getDatabase;

    await db?.rawUpdate(
      'UPDATE CMS_CARER_VISIT_BODY_MAP SET BACK_LEFT_UPPER_ARM_ELBOW = ? WHERE CARER_VISIT_MST_ID = ?',
      [newFLUpperLegValue, mstId],
    );

  }

  Future<void> deleteBLelbowByMstId(String mstId) async {
    final Database? db = await dbHandler.getDatabase;

    await db?.rawDelete(
      'UPDATE CMS_CARER_VISIT_BODY_MAP SET BACK_LEFT_UPPER_ARM_ELBOW = NULL WHERE CARER_VISIT_MST_ID = ?',
      [mstId],
    );
  }

  // -------------------->  Back Back Right Forearm
  Future<void> updateBRforearm(String newBRforearmValue, String mstId) async {
    final Database? db = await dbHandler.getDatabase;

    await db?.rawUpdate(
      'UPDATE CMS_CARER_VISIT_BODY_MAP SET BACK_RIGHT_FOREARM = ? WHERE CARER_VISIT_MST_ID = ?',
      [newBRforearmValue, mstId],
    );

  }

  Future<void> deleteBRforearmByMstId(String mstId) async {
    final Database? db = await dbHandler.getDatabase;

    await db?.rawDelete(
      'UPDATE CMS_CARER_VISIT_BODY_MAP SET BACK_RIGHT_FOREARM = NULL WHERE CARER_VISIT_MST_ID = ?',
      [mstId],
    );
  }

  // -------------------->  Back Left Forearm
  Future<void> updateBLforearm(String newBLforearmValue, String mstId) async {
    final Database? db = await dbHandler.getDatabase;

    await db?.rawUpdate(
      'UPDATE CMS_CARER_VISIT_BODY_MAP SET BACK_LEFT_FOREARM = ? WHERE CARER_VISIT_MST_ID = ?',
      [newBLforearmValue, mstId],
    );

  }

  Future<void> deleteBLforearmByMstId(String mstId) async {
    final Database? db = await dbHandler.getDatabase;

    await db?.rawDelete(
      'UPDATE CMS_CARER_VISIT_BODY_MAP SET BACK_LEFT_FOREARM = NULL WHERE CARER_VISIT_MST_ID = ?',
      [mstId],
    );
  }


  // -------------------->  Back  Right Hand
  Future<void> updateBRhand(String newBRforearmValue, String mstId) async {
    final Database? db = await dbHandler.getDatabase;

    await db?.rawUpdate(
      'UPDATE CMS_CARER_VISIT_BODY_MAP SET BACK_RIGHT_HAND_WRIST = ? WHERE CARER_VISIT_MST_ID = ?',
      [newBRforearmValue, mstId],
    );

  }

  Future<void> deleteBRhandByMstId(String mstId) async {
    final Database? db = await dbHandler.getDatabase;

    await db?.rawDelete(
      'UPDATE CMS_CARER_VISIT_BODY_MAP SET BACK_RIGHT_HAND_WRIST = NULL WHERE CARER_VISIT_MST_ID = ?',
      [mstId],
    );
  }

  // -------------------->  Back Left hand
  Future<void> updateBLhand(String newBRforearmValue, String mstId) async {
    final Database? db = await dbHandler.getDatabase;

    await db?.rawUpdate(
      'UPDATE CMS_CARER_VISIT_BODY_MAP SET BACK_LEFT_HAND_WRIST = ? WHERE CARER_VISIT_MST_ID = ?',
      [newBRforearmValue, mstId],
    );

  }

  Future<void> deleteBLhandByMstId(String mstId) async {
    final Database? db = await dbHandler.getDatabase;

    await db?.rawDelete(
      'UPDATE CMS_CARER_VISIT_BODY_MAP SET BACK_LEFT_HAND_WRIST = NULL WHERE CARER_VISIT_MST_ID = ?',
      [mstId],
    );
  }

  // -------------------->  Back Lower Back
  Future<void> updateBlowerBack(String newLowerBackValue, String mstId) async {
    final Database? db = await dbHandler.getDatabase;

    await db?.rawUpdate(
      'UPDATE CMS_CARER_VISIT_BODY_MAP SET BACK_LOWER_BACK = ? WHERE CARER_VISIT_MST_ID = ?',
      [newLowerBackValue, mstId],
    );

  }

  Future<void> deleteBlowerBackByMstId(String mstId) async {
    final Database? db = await dbHandler.getDatabase;

    await db?.rawDelete(
      'UPDATE CMS_CARER_VISIT_BODY_MAP SET BACK_LOWER_BACK = NULL WHERE CARER_VISIT_MST_ID = ?',
      [mstId],
    );
  }

  // -------------------->  Bottom
  Future<void> updateBottom(String newBRforearmValue, String mstId) async {
    final Database? db = await dbHandler.getDatabase;

    await db?.rawUpdate(
      'UPDATE CMS_CARER_VISIT_BODY_MAP SET BACK_BOTTOM_SACRUM = ? WHERE CARER_VISIT_MST_ID = ?',
      [newBRforearmValue, mstId],
    );

  }

  Future<void> deleteBottomByMstId(String mstId) async {
    final Database? db = await dbHandler.getDatabase;

    await db?.rawDelete(
      'UPDATE CMS_CARER_VISIT_BODY_MAP SET BACK_BOTTOM_SACRUM = NULL WHERE CARER_VISIT_MST_ID = ?',
      [mstId],
    );
  }

  // -------------------->  UpperBack
  Future<void> updateUpperBack(String newBRforearmValue, String mstId) async {
    final Database? db = await dbHandler.getDatabase;

    await db?.rawUpdate(
      'UPDATE CMS_CARER_VISIT_BODY_MAP SET BACK_UPPER_BACK = ? WHERE CARER_VISIT_MST_ID = ?',
      [newBRforearmValue, mstId],
    );

  }

  Future<void> deleteUpperBackByMstId(String mstId) async {
    final Database? db = await dbHandler.getDatabase;

    await db?.rawDelete(
      'UPDATE CMS_CARER_VISIT_BODY_MAP SET BACK_UPPER_BACK = NULL WHERE CARER_VISIT_MST_ID = ?',
      [mstId],
    );
  }

  // -------------------->  LowerBack
  Future<void> updateLowerBack(String newLowerBackValue, String mstId) async {
    final Database? db = await dbHandler.getDatabase;

    await db?.rawUpdate(
      'UPDATE CMS_CARER_VISIT_BODY_MAP SET BACK_LOWER_BACK = ? WHERE CARER_VISIT_MST_ID = ?',
      [newLowerBackValue, mstId],
    );

  }

  Future<void> deleteLowerBackByMstId(String mstId) async {
    final Database? db = await dbHandler.getDatabase;

    await db?.rawDelete(
      'UPDATE CMS_CARER_VISIT_BODY_MAP SET BACK_LOWER_BACK = NULL WHERE CARER_VISIT_MST_ID = ?',
      [mstId],
    );
  }

  // -------------------->  Back Right Foot
  Future<void> updateBRfoot(String newRightfootValue, String mstId) async {
    final Database? db = await dbHandler.getDatabase;

    await db?.rawUpdate(
      'UPDATE CMS_CARER_VISIT_BODY_MAP SET BACK_RIGHT_FOOT_ANKLE = ? WHERE CARER_VISIT_MST_ID = ?',
      [newRightfootValue, mstId],
    );

  }

  Future<void> deleteBRfootByMstId(String mstId) async {
    final Database? db = await dbHandler.getDatabase;

    await db?.rawDelete(
      'UPDATE CMS_CARER_VISIT_BODY_MAP SET BACK_RIGHT_FOOT_ANKLE = NULL WHERE CARER_VISIT_MST_ID = ?',
      [mstId],
    );
  }

  // -------------------->  Back Left Foot
  Future<void> updateBLfoot(String newrRIGHTfootValue, String mstId) async {
    final Database? db = await dbHandler.getDatabase;

    await db?.rawUpdate(
      'UPDATE CMS_CARER_VISIT_BODY_MAP SET BACK_LEFT_FOOT_ANKLE = ? WHERE CARER_VISIT_MST_ID = ?',
      [newrRIGHTfootValue, mstId],
    );

  }

  Future<void> deleteBLfootByMstId(String mstId) async {
    final Database? db = await dbHandler.getDatabase;

    await db?.rawDelete(
      'UPDATE CMS_CARER_VISIT_BODY_MAP SET BACK_LEFT_FOOT_ANKLE = NULL WHERE CARER_VISIT_MST_ID = ?',
      [mstId],
    );
  }

  // -------------------->  Back Right Kneee
  Future<void> updateBRknee(String newrRIGHTfootValue, String mstId) async {
    final Database? db = await dbHandler.getDatabase;

    await db?.rawUpdate(
      'UPDATE CMS_CARER_VISIT_BODY_MAP SET BACK_RIGHT_KNEE = ? WHERE CARER_VISIT_MST_ID = ?',
      [newrRIGHTfootValue, mstId],
    );

  }

  Future<void> deleteBRkneeByMstId(String mstId) async {
    final Database? db = await dbHandler.getDatabase;

    await db?.rawDelete(
      'UPDATE CMS_CARER_VISIT_BODY_MAP SET BACK_RIGHT_KNEE = NULL WHERE CARER_VISIT_MST_ID = ?',
      [mstId],
    );
  }
  // -------------------->  Back left Kneee
  Future<void> updateBLknee(String newrLEFTfootValue, String mstId) async {
    final Database? db = await dbHandler.getDatabase;

    await db?.rawUpdate(
      'UPDATE CMS_CARER_VISIT_BODY_MAP SET BACK_LEFT_KNEE = ? WHERE CARER_VISIT_MST_ID = ?',
      [newrLEFTfootValue, mstId],
    );

  }

  Future<void> deleteBLkneeByMstId(String mstId) async {
    final Database? db = await dbHandler.getDatabase;

    await db?.rawDelete(
      'UPDATE CMS_CARER_VISIT_BODY_MAP SET BACK_LEFT_KNEE = NULL WHERE CARER_VISIT_MST_ID = ?',
      [mstId],
    );
  }

  // -------------------->  Back Right Upper leg
  Future<void> updateBRupperLeg(String newrRIGHTfootValue, String mstId) async {
    final Database? db = await dbHandler.getDatabase;

    await db?.rawUpdate(
      'UPDATE CMS_CARER_VISIT_BODY_MAP SET BACK_RIGHT_UPPER_LEG = ? WHERE CARER_VISIT_MST_ID = ?',
      [newrRIGHTfootValue, mstId],
    );

  }

  Future<void> deleteBRupperLegByMstId(String mstId) async {
    final Database? db = await dbHandler.getDatabase;

    await db?.rawDelete(
      'UPDATE CMS_CARER_VISIT_BODY_MAP SET BACK_RIGHT_UPPER_LEG = NULL WHERE CARER_VISIT_MST_ID = ?',
      [mstId],
    );
  }
  // -------------------->  Back Left Upper leg
  Future<void> updateBLupperLeg(String newrRIGHTfootValue, String mstId) async {
    final Database? db = await dbHandler.getDatabase;

    await db?.rawUpdate(
      'UPDATE CMS_CARER_VISIT_BODY_MAP SET BACK_LEFT_UPPER_LEG = ? WHERE CARER_VISIT_MST_ID = ?',
      [newrRIGHTfootValue, mstId],
    );

  }

  Future<void> deleteBLupperLegByMstId(String mstId) async {
    final Database? db = await dbHandler.getDatabase;

    await db?.rawDelete(
      'UPDATE CMS_CARER_VISIT_BODY_MAP SET BACK_LEFT_UPPER_LEG = NULL WHERE CARER_VISIT_MST_ID = ?',
      [mstId],
    );
  }


  // -------------------->  Back Left Lower leg
  Future<void> updateBLlowerLeg(String newrleftLowerlerValue, String mstId) async {
    final Database? db = await dbHandler.getDatabase;

    await db?.rawUpdate(
      'UPDATE CMS_CARER_VISIT_BODY_MAP SET BACK_LEFT_LOWER_LEG = ? WHERE CARER_VISIT_MST_ID = ?',
      [newrleftLowerlerValue, mstId],
    );

  }

  Future<void> deleteBLlowerLegByMstId(String mstId) async {
    final Database? db = await dbHandler.getDatabase;

    await db?.rawDelete(
      'UPDATE CMS_CARER_VISIT_BODY_MAP SET BACK_LEFT_LOWER_LEG = NULL WHERE CARER_VISIT_MST_ID = ?',
      [mstId],
    );
  }
  // -------------------->  Back Right Lower leg
  Future<void> updateBRlowerLeg(String newrrightlowerlegValue, String mstId) async {
    final Database? db = await dbHandler.getDatabase;

    await db?.rawUpdate(
      'UPDATE CMS_CARER_VISIT_BODY_MAP SET BACK_RIGHT_LOWER_LEG = ? WHERE CARER_VISIT_MST_ID = ?',
      [newrrightlowerlegValue, mstId],
    );

  }

  Future<void> deleteBRlowerLegByMstId(String mstId) async {
    final Database? db = await dbHandler.getDatabase;

    await db?.rawDelete(
      'UPDATE CMS_CARER_VISIT_BODY_MAP SET BACK_RIGHT_LOWER_LEG = NULL WHERE CARER_VISIT_MST_ID = ?',
      [mstId],
    );
  }
}