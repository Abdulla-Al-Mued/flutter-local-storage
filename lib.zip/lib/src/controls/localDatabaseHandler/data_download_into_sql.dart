import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:sqflite/sqflite.dart';

import 'local_database_handler.dart';

class DataDownloadIntoSql {
  Future<void> downloadData({
    required Map<String, dynamic> data,
    required String tableName,
  }) async {
    try {
      final _database = await LocalDatabaseHandler().getDatabase;


      await _database?.insert(
        tableName,
        data,
        conflictAlgorithm: ConflictAlgorithm.replace,
      );

    } catch (e) {
      Fluttertoast.showToast(
          msg: "error in $tableName",
          toastLength: Toast.LENGTH_LONG, // Duration for which the toast will be visible
          gravity: ToastGravity.BOTTOM, // Position of the toast on the screen
          backgroundColor: Colors.black, // Background color of the toast
          textColor: Colors.white, // Text color of the toast message
          fontSize: 16.0 // Font size of the toast message
      );
      rethrow;
    }
  }
}
