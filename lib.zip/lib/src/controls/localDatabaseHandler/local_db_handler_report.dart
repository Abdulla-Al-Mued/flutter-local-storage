
import 'package:sqflite/sqflite.dart';

import 'local_database_handler.dart';

class ReportHandler{
  late final LocalDatabaseHandler dbHandler = LocalDatabaseHandler();

  Future<List<Map<String, dynamic>>> getReportSummary() async {

    Database? db = await dbHandler.getDatabase;

    List<Map<String, dynamic>>? result = await db?.rawQuery('''
    
select A.CARER_VISIT_MST_ID,A.CHECK_IN_DATE,A.CHECK_IN_TIME,A.CHECK_OUT_TIME, A.CHECK_OUT_DATE,A.CARER_NAME,A.WORKING_TIME, B.TASK_CODE,B.TASK_DESC 
from DPD_CARER_VISIT_SUMM_RPT A, DPD_TASK_LIST_SUMM_RPT B
where A.CARER_VISIT_MST_ID = B.CARER_VISIT_MST_ID
and A.CLIENT_ID = B.CLIENT_ID
GROUP BY A.CARER_VISIT_MST_ID,A.CHECK_IN_DATE,A.CHECK_IN_TIME,A.CHECK_OUT_TIME,B.TASK_CODE,B.TASK_DESC,A.CHECK_OUT_DATE, A.CARER_NAME, A.WORKING_TIME
ORDER BY A.CHECK_OUT_DATE DESC, A.CHECK_OUT_TIME DESC

        ''');

    if(result!.isNotEmpty){

      Map<String, Map<String, dynamic>> transformedData = {};

      // Iterate over the fetched result
      result.forEach((element) {
        String carerVisitMstId = element['CARER_VISIT_MST_ID'];
        // If the transformedData doesn't have the current CARER_VISIT_MST_ID, add it with the required fields
        if (!transformedData.containsKey(carerVisitMstId)) {
          transformedData[carerVisitMstId] = {
            'CARER_VISIT_MST_ID': carerVisitMstId,
            'CHECK_IN_DATE': element['CHECK_IN_DATE'],
            'CHECK_IN_TIME': element['CHECK_IN_TIME'],
            'CHECK_OUT_TIME': element['CHECK_OUT_TIME'],
            'CARER_NAME': element['CARER_NAME'],
            'WORKING_TIME': element['WORKING_TIME'],
            'TASK_DATA': [],
          };
        }
        // Add TASK_DATA to the existing entry in transformedData
        transformedData[carerVisitMstId]?['TASK_DATA'].add({
          'TASK_CODE': element['TASK_CODE'],
          'TASK_DESC': element['TASK_DESC'],
        });
      });



      // Return the transformed data as a list
      return transformedData.values.toList();
    }
    else{
      return[];
    }

  }

  Future<List<Map<String, dynamic>>> getRecentVisit(String clientId) async {

    Database? db = await dbHandler.getDatabase;

    List<Map<String, dynamic>>? result = await db?.rawQuery('''
    
SELECT * FROM (
select A.CARER_VISIT_MST_ID,A.CHECK_IN_DATE,A.CHECK_IN_TIME,A.CHECK_OUT_TIME, A.CHECK_OUT_DATE,A.CARER_NAME,A.WORKING_TIME,A.CLIENT_ID, B.TASK_CODE,B.TASK_DESC 
from DPD_CARER_VISIT_SUMM_RPT A, DPD_TASK_LIST_SUMM_RPT B
where A.CARER_VISIT_MST_ID = B.CARER_VISIT_MST_ID
and A.CLIENT_ID = B.CLIENT_ID
GROUP BY A.CARER_VISIT_MST_ID,A.CHECK_IN_DATE,A.CHECK_IN_TIME,A.CHECK_OUT_TIME,B.TASK_CODE,B.TASK_DESC,A.CHECK_OUT_DATE, A.CARER_NAME, A.WORKING_TIME
ORDER BY A.CHECK_OUT_DATE DESC , A.CHECK_OUT_TIME DESC
) WHERE CLIENT_ID = ?
        ''', [clientId]);

    if(result!.isNotEmpty){

      Map<String, Map<String, dynamic>> transformedData = {};

      // Iterate over the fetched result
      result.forEach((element) {
        String carerVisitMstId = element['CARER_VISIT_MST_ID'];
        // If the transformedData doesn't have the current CARER_VISIT_MST_ID, add it with the required fields
        if (!transformedData.containsKey(carerVisitMstId)) {
          transformedData[carerVisitMstId] = {
            'CARER_VISIT_MST_ID': carerVisitMstId,
            'CHECK_IN_DATE': element['CHECK_IN_DATE'],
            'CHECK_IN_TIME': element['CHECK_IN_TIME'],
            'CHECK_OUT_TIME': element['CHECK_OUT_TIME'],
            'CARER_NAME': element['CARER_NAME'],
            'WORKING_TIME': element['WORKING_TIME'],
            'TASK_DATA': [],
          };
        }
        // Add TASK_DATA to the existing entry in transformedData
        transformedData[carerVisitMstId]?['TASK_DATA'].add({
          'TASK_CODE': element['TASK_CODE'],
          'TASK_DESC': element['TASK_DESC'],
        });
      });



      // Return the transformed data as a list
      return transformedData.values.toList();
    }
    else{
      return[];
    }

  }

  Future<Map<String, dynamic>> getReportDetails(String carerVisitMstId) async {

    Database? db = await dbHandler.getDatabase;

    List<Map<String, dynamic>>? result = await db?.rawQuery('''
    
SELECT
    A.VISIT_DAY,
    A.CHECK_IN_DATE,
    A.CHECK_IN_TIME,
    A.CHECK_OUT_DATE,
    A.CHECK_OUT_TIME,
    A.WORKING_TIME,
    A.CARER_NAME,
    A.CARER_VISIT_MST_ID,
    A.VISIT_TYPE_NAME,
    A.HOW_DID_CLIENT_EMOJI_CODE,
    A.EMOJI_DESC,
    A.IMOJI_PATH,
    A.AGENCY_NOTE,
    B.NAME
FROM
    DPD_CARER_VISIT_DTL_RPT A, DPD_PERSONAL_DTL_LIST B
WHERE
    CARER_VISIT_MST_ID = ? AND A.CLIENT_ID = B.CLIENT_ID
    
        ''', [carerVisitMstId]);

    if(result!.isNotEmpty){

      return result.first;
    }
    else{
      return{};
    }

  }

  Future<List<Map<String, dynamic>>> getAgencyReport(String carerVisitMstId) async {
    Database? db = await dbHandler.getDatabase;

    List<Map<String, dynamic>>? result = await db?.rawQuery('''
SELECT * FROM DPD_CLIENT_VISIT_AGNCY_NOTE WHERE CARER_VISIT_MST_ID = ?
        ''', [carerVisitMstId]);

    if(result!.isNotEmpty){
      return result;
    }
    else{
      return [];
    }

  }

  Future<List<Map<String, dynamic>>> getFoodForCarerVisitMstId(String carerVisitMstId, String tableName, String columnName) async {
    final Database? db = await dbHandler.getDatabase;

    final List<Map<String, dynamic>>? result;

    if(tableName == 'DPD_CARER_VISIT_MEDICATION_DTL'){
      result = await db?.rawQuery(
        'SELECT $columnName, TAKEN_STATUS, NOT_TAKEN_STATUS, TAKEN_REMARKS, NOT_TAKEN_REMARKS FROM $tableName WHERE "CARER_VISIT_MST_ID" = ?',
        [carerVisitMstId],
      );
    }
    else if(tableName == 'DPD_CARER_VISIT_BODY_MAP_DTL'){
      result = await db?.rawQuery(
        'SELECT * FROM $tableName WHERE "CARER_VISIT_MST_ID" = ?',
        [carerVisitMstId],
      );
    }
    else{
      result = await db?.rawQuery(
        'SELECT $columnName FROM $tableName WHERE "CARER_VISIT_MST_ID" = ?',
        [carerVisitMstId],
      );
    }


    if(result != null && result.isNotEmpty){
      return result;
    }
    else
      {
        return [];
      }

  }

}