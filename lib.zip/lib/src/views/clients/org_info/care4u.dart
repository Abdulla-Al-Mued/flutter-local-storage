import 'package:care4u/src/controls/utils/appbar.dart';
import 'package:flutter/material.dart';

class CareForYou extends StatelessWidget {
  const CareForYou({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: const CustomAppBar(
        backgroundColor: Colors.white,
        title: 'Organizations',
      ),
      body: Column(
        mainAxisAlignment: MainAxisAlignment.start,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
           Padding(
            padding: const EdgeInsets.symmetric(horizontal: 20.0),
            child: Row(
              children: [
                const Icon(Icons.home_work_outlined, size: 30,),
                SizedBox(width: MediaQuery.of(context).size.width * 0.02),
                const Text(
                  'Care 4 U',
                  style: TextStyle(fontSize: 26, fontFamily: 'PoppinsSemiBold'),
                ),
              ],
            ),
          ),
          Padding(
            padding: const EdgeInsets.symmetric(vertical: 30.0),
            child: Divider(
              thickness: 10,
              color: Colors.grey.shade200,
              height: 5,
            ),
          ),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 20.0),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.start,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text(
                  "Agency details",
                  textAlign: TextAlign.start,
                  style: TextStyle(fontSize: 18, fontFamily: 'PoppinsSemiBold'),
                ),
                SizedBox(height: MediaQuery.of(context).size.width * 0.03),
                Row(
                  children: [
                    const Icon(Icons.home, color: Colors.grey),
                    SizedBox(width: MediaQuery.of(context).size.width * 0.02),
                    GestureDetector(
                      onTap: () {},
                      child: const Text(
                        'Free Trial',
                        style: TextStyle(fontSize: 16),
                      ),
                    ),
                  ],
                ),
                SizedBox(height: MediaQuery.of(context).size.width * 0.03),
                Row(
                  children: [
                    const Icon(Icons.email_rounded, color: Colors.grey),
                    SizedBox(width: MediaQuery.of(context).size.width * 0.02),
                    GestureDetector(
                      onTap: () {},
                      child: const Text(
                        'abusufian@alphabytetech.com',
                        style: TextStyle(fontSize: 16),
                      ),
                    ),
                  ],
                )
              ],
            ),
          ),
          Padding(
            padding: const EdgeInsets.symmetric(vertical: 30.0),
            child: Divider(
              thickness: 10,
              color: Colors.grey.shade200,
              height: 5,
            ),
          ),
          const Padding(
            padding: EdgeInsets.symmetric(horizontal: 20.0),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.start,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  "Documents",
                  style: TextStyle(fontSize: 18, fontFamily: 'PoppinsSemiBold'),
                ),
                Text(
                  "No documents added",
                  style: TextStyle(fontSize: 16, color: Colors.grey, fontFamily: 'PoppinsRegular'),
                ),
              ],
            ),
          ),
          Padding(
            padding: const EdgeInsets.symmetric(vertical: 30.0),
            child: Divider(
              thickness: 10,
              color: Colors.grey.shade200,
              height: 5,
            ),
          ),
        ],
      ),
    );
  }
}
