import 'dart:async';

import 'package:care4u/src/controls/utils/Tools.dart';
import 'package:care4u/src/controls/utils/appbar.dart';
import 'package:care4u/src/controls/utils/color_codes.dart';
import 'package:care4u/src/views/clients/org_info/care4u.dart';
import 'package:care4u/src/views/schedulelist/ClientProvider/ClientProvider.dart';
import 'package:connectivity_plus/connectivity_plus.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/svg.dart';
import 'package:provider/provider.dart';
import 'package:swipe_refresh/swipe_refresh.dart';
import '../../controls/apiHandler/api_handler.dart';
import '../../controls/localDatabaseHandler/local_database_handler.dart';
import '../../controls/localDatabaseHandler/local_db_handler_visit.dart';
import '../../controls/utils/image_url.dart';
import '../../controls/utils/oneTimeNetCheck.dart';
import '../../models/LocalModel/LocalDpd_Cms_Carer_Cln_Dtws_Sch_Lst_Model.dart';
import '../schedulelist/client_profile/client_profile.dart';

class Clients extends StatefulWidget {
  const Clients({Key? key}) : super(key: key);

  @override
  State<Clients> createState() => _ClientsState();
}

class _ClientsState extends State<Clients> {
  final LocalDatabaseHandler _databaseHandler = LocalDatabaseHandler();

  late Future<List<Map<String, dynamic>>> _clientListFuture;
  String _appVersion = 'Unknown';
  // bool _isOrange = true;

  final _controller = StreamController<SwipeRefreshState>.broadcast();
  final ScrollController _scrollController = ScrollController();
  final VisitHandler visitHandler = VisitHandler();


  Stream<SwipeRefreshState> get _stream => _controller.stream;


  bool isConnected = true;
  late Connectivity connectivity;
  late StreamSubscription<List<ConnectivityResult>> connectivitySubscription;

  Future<void> checkConnection() async{

    connectivitySubscription = connectivity.onConnectivityChanged.listen((event) {
      if (event.contains(ConnectivityResult.mobile)) {
        isConnected = true;
      } else if (event.contains(ConnectivityResult.wifi)) {
        isConnected = true;
      } else if (event.contains(ConnectivityResult.ethernet)) {
        isConnected = true;
      } else if (event.contains(ConnectivityResult.vpn)) {
        isConnected = true;
      } else if (event.contains(ConnectivityResult.bluetooth)) {
        isConnected = true;
      } else if (event.contains(ConnectivityResult.other)) {
        isConnected = true;
      } else if (event.contains(ConnectivityResult.none)) {
        isConnected = false;
      }
      setState(() {

      });
    });



  }


  Future<void> refresh() async {

    if(await uploadData()??false){
      await ApiHandler().downloadData();
      setState(() {

      });
      _controller.sink.add(SwipeRefreshState.hidden);
    }else{
      await ApiHandler().downloadData();
      setState(() {

      });
      _controller.sink.add(SwipeRefreshState.hidden);
    }
  }

  Future<bool?> uploadData() async {

    List<Map<String, dynamic>> result = await visitHandler.getUnUploadedData();

    if (await getConnection()) {
      bool temp = false;

      await Future.forEach(result ?? [], (element) async {

        temp = await visitHandler.getAllVisitData(element['CARER_VISIT_MST_ID'].toString());

      });

      if (temp) {
        return true;
      } else {
        return false;

      }

    }

    return false;
  }

  @override
  void initState() {
    super.initState();
    _getAppVersion();
    connectivity = Connectivity();
    checkConnection();
    _clientListFuture = _databaseHandler.getDPDAllClientList(); // Fetch data from DPD_ORG_ALL_CLIENT_LIST table
  }

  @override
  void dispose() {
    super.dispose();
    // Dispose of the subscription
    connectivitySubscription.cancel();
  }


  Future<void> _getAppVersion() async {
    //PackageInfo packageInfo = await PackageInfo.fromPlatform();
    setState(() {
      _appVersion = "";
    });
  }

  @override
  Widget build(BuildContext context) {

    final clientProvider = Provider.of<ClientProvider>(context, listen: false);

    return Scaffold(
      appBar:  const CustomAppBar(
          backgroundColor: Colors.white,
          title: 'Clients List'),
      body: SwipeRefresh.material(
          scrollController: _scrollController,
          stateStream: _stream,
          onRefresh: refresh,
          children: [
            SingleChildScrollView(
              child: SizedBox(
                height: MediaQuery.of(context).size.height*.9,
                child: Container(
                  color: Colors.white,
                  child: FutureBuilder<List<Map<String, dynamic>>>(
                    future: _clientListFuture,
                    builder: (context, snapshot) {
                      if (snapshot.connectionState == ConnectionState.waiting) {
                        return Center(child: SizedBox(
                          height: MediaQuery.of(context).size.height*.7,
                          child: Container(
                              height: 50,
                              width: 50,
                              child: Image.asset('assets/images/loading.gif')
                          ),
                        ));
                      } else if (snapshot.hasError) {
                        return Center(
                          child: Text('Error: ${snapshot.error}'),
                        );
                      } else {

                        List<Map<String, dynamic>> clientList = snapshot.data!;
                        Map<String, List<Map<String, dynamic>>> groupedClients = {};
                        for (var client in clientList) {
                          clientProvider.mstIsExist(client['CLIENT_ID']);
                          String orgName = client['ORG_NAME'];
                          if (!groupedClients.containsKey(orgName)) {
                            groupedClients[orgName] = [];
                          }
                          groupedClients[orgName]!.add(client);
                        }
                        if(clientList.isEmpty) {
                          return Container(
                            alignment: Alignment.center,
                            child: const Text(
                              'No data found',
                              textAlign: TextAlign.center,
                            ),
                          );
                        }

                        return Column(
                          children: [
                            //searchBar(),
                            Expanded(
                              child: ListView.builder(
                                scrollDirection: Axis.vertical,
                                shrinkWrap: true,
                                primary: false,
                                itemCount: groupedClients.length * 2,
                                itemBuilder: (context, index) {
                                  if (index.isOdd) {
                                    return  Divider(
                                      color: Colors.grey.shade200,
                                      thickness: 8,
                                    ); // Divider between groups
                                  }
                                  final int groupIndex = index ~/ 2;
                                  String orgName = groupedClients.keys.elementAt(groupIndex);
                                  List<Map<String, dynamic>> clients = groupedClients[orgName]!;
                                  // final Color orgColor = _isOrange ? Colors.orange : Colors.purple;
                                  // _isOrange = !_isOrange; // Toggle color for the next group

                                  return Column(
                                    children: [
                                      ListTile(
                                        title: Text(
                                          orgName,
                                          textAlign: TextAlign.start,
                                          style:  const TextStyle(
                                            color: Color(0xFF03245B),
                                            fontSize: 22,
                                            fontWeight: FontWeight.bold,
                                          ),
                                        ),
                                        onTap: () {
                                          //Navigator.push(context, MaterialPageRoute(builder: (context) => const CareForYou(),));
                                        },
                                      ),
                                      ...clients.map((client) => Container(
                                        margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                                        decoration: BoxDecoration(
                                          color: Colors.white,
                                          borderRadius: BorderRadius.circular(8),
                                          boxShadow: [
                                            BoxShadow(
                                              color: Colors.grey.withOpacity(0.5),
                                              spreadRadius: 2,
                                              blurRadius: 5,
                                              offset: const Offset(0, 3),
                                            ),
                                          ],
                                        ),
                                        child: ListTile(
                                          leading: isConnected && client['CLIENT_IMAGE_PATH'] != null
                                              ? ClipRRect(
                                            borderRadius: BorderRadius.circular(25),
                                            child: Image.network(
                                              CLIENT_IMAGE_URL+client['CLIENT_IMAGE_PATH'],
                                              width: 50,
                                              height: 50,
                                              fit: BoxFit.cover,
                                              errorBuilder: (context, error, stackTrace) {
                                                // Error occurred while loading image
                                                return const CircleAvatar(
                                                  backgroundColor: Colors.purple,
                                                  radius: 40,
                                                  child: Icon(Icons.person),
                                                );
                                              },
                                            ),
                                          )
                                              : const CircleAvatar(
                                            backgroundColor: Colors.blue,
                                            radius: 25,
                                            child: Icon(Icons.person),
                                          ),
                                          title: Text(
                                            client['NAME'] ?? '',
                                            style: const TextStyle(
                                              overflow: TextOverflow.ellipsis,
                                              fontSize: 18,
                                              fontWeight: FontWeight.w600,
                                            ),
                                          ),
                                          subtitle: Text(client['ADDRESS'] ?? '', maxLines: 2),
                                          trailing: Consumer<ClientProvider>(builder: (BuildContext context, ClientProvider value, Widget? child) {

                                            //value.mstIsExist(client['CLIENT_ID']);

                                            return value.checkedInClientId == client['CLIENT_ID']?ClipRRect(
                                              borderRadius: BorderRadius.circular(10),
                                              child: SvgPicture.asset(
                                                'assets/images/ic_checked_in.svg',
                                                height: 40,
                                                width: 40,
                                                color: color2,
                                                //color: lightPrimaryColor,
                                              ),
                                            ):
                                            ClipRRect(
                                              borderRadius: BorderRadius.circular(10),
                                              child: Container(
                                                height: 40,
                                                width: 40,
                                                decoration: const BoxDecoration(
                                                    color: primaryColor
                                                ),
                                                child: const Icon(
                                                  Icons.arrow_forward_ios,
                                                  color: Colors.white,
                                                ),
                                              ),
                                            );
                                          },),
                                          onTap: () {
                                            Value val = Value(
                                              clientName: client['NAME'],
                                              clientCode: client['CLIENT_CODE'],
                                              clientId: client['CLIENT_ID'],
                                              orgCode: client['ORG_CODE'],
                                              clientDatewiseSchId: '0',
                                              clientVisitTypeMstId: '0',
                                              startTime: 'Not Scheduled',
                                              endTime: '',
                                            );

                                            Navigator.push(
                                              context,
                                              MaterialPageRoute(
                                                builder: (context) => ClientProfile(userId: val, isScheduled: 'N'),
                                              ),
                                            );
                                          },
                                        ),
                                      ),
                                      ),
                                    ],
                                  );
                                },
                              ),
                            ),
                          ],
                        );
                      }
                    },
                  ),
                ),
              ),
            ),
          ]
      ),
    );
  }

  Padding searchBar() {
    return Padding(
      padding: const EdgeInsets.all(16.0),
      child: TextField(
        decoration: InputDecoration(
          hintText: 'Search clients',
          suffixIcon:  Icon(Icons.search, size :MediaQuery.of(context).size.height*0.04, color:const Color(0xFF2D889B)),
          border: OutlineInputBorder(
            borderRadius: const BorderRadius.all(Radius.circular(8.0)),
            borderSide:  BorderSide(
              color: Colors.red.shade50,
              width: 1.0,
            ),
          ),
          contentPadding: const EdgeInsets.symmetric(
            vertical: 10.0,
            horizontal: 10.0,
          ),
        ),
      ),
    );
  }
}


