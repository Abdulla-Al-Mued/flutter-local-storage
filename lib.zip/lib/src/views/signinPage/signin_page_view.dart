import 'package:care4u/src/views/signinPage/providers/sign_page_provider.dart';
import 'package:care4u/src/views/signinPage/widgets/colored_area.dart';
import 'package:care4u/src/views/signinPage/widgets/forget_password_button.dart';
import 'package:care4u/src/views/signinPage/widgets/image_area.dart';
import 'package:care4u/src/views/signinPage/widgets/inputFIeldArea.dart';
import 'package:care4u/src/views/signinPage/widgets/login_button.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:provider/provider.dart';

import '../../controls/localDatabaseHandler/data_fetching_and_setup.dart';

class SignInPage extends StatefulWidget {
  const SignInPage({super.key});

  @override
  State<SignInPage> createState() => _SignInPageState();
}

class _SignInPageState extends State<SignInPage> {
  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();
  final TextEditingController _emailController = TextEditingController();
  final TextEditingController _passwordController = TextEditingController();

  void checkLogin() async {
    final permission = await Permission.storage.status;
    if (permission.isDenied) {
      await Permission.storage.request();
    }
  }

  @override
  void initState() {
    WidgetsBinding.instance.addPostFrameCallback((timeStamp) {
      checkLogin();
    });
    generateTable();
    super.initState();
  }

  @override
  void dispose() {
    _emailController.dispose();
    _passwordController.dispose();
    //generateTable();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final signInPageProvider = Provider.of<SignInPageProvider>(context);
    // SystemChrome.setPreferredOrientations([
    //   DeviceOrientation.portraitUp,
    //   DeviceOrientation.portraitDown,
    // ]);
    return Scaffold(
      body: SingleChildScrollView(
        child: SizedBox(
          width: MediaQuery.of(context).size.width,
          height: MediaQuery.of(context).size.height,
          child: Stack(
            children: [
              imageArea(context),
              coloredArea(context),
              Align(
                alignment: Alignment.bottomCenter,
                child: Container(
                  width: MediaQuery.of(context).size.width,
                  height: MediaQuery.of(context).size.height /
                      1.7991, //second upper
                  decoration: const BoxDecoration(
                      color: Colors.white,
                      borderRadius:
                          BorderRadius.only(topLeft: Radius.circular(70))),
                  child: Padding(
                    padding: const EdgeInsets.all(30.0),
                    child: Column(
                      children: [
                        Form(
                          key: _formKey,
                          child: Column(
                            children: <Widget>[
                              SizedBox(
                                height:
                                    MediaQuery.of(context).size.height * .04,
                              ),
                              inputFieldArea(

                                  context: context,
                                  emailController: _emailController,
                                  passwordController: _passwordController),
                              SizedBox(
                                height:
                                    MediaQuery.of(context).size.height * .05,
                              ),
                              loginButton(
                                context: context,
                                isLoading: signInPageProvider.isLoading,
                                email: _emailController.text.trim(),
                                password: _passwordController.text.trim(),
                              ),
                              SizedBox(
                                height:
                                    MediaQuery.of(context).size.height * .04,
                              ),
                              forgetPasswordButton(context),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Future<void> generateTable() async {
    await tableGenerator();
  }
}
