import 'package:flutter/material.dart';
import 'package:care4u/src/controls/apiHandler/api_handler.dart';
import 'package:care4u/src/controls/localStorage/local_storage.dart';
import 'package:flutter/foundation.dart';

import '../../../controls/localDatabaseHandler/local_db_handler_visit.dart';
import '../../../controls/utils/Tools.dart';
import '../../../controls/utils/oneTimeNetCheck.dart';

class SignInPageProvider extends ChangeNotifier {
  bool _isLoading = false;
  int? _loginSuccess = 3;

  bool get isLoading => _isLoading;

  int? get loginSuccess => _loginSuccess;

  final VisitHandler visitHandler = VisitHandler();


  void setLoading({required bool value}) {
    _isLoading = value;
    notifyListeners();
  }

  Future<void> signInUser({
    required BuildContext context,
    required String email,
    required String password,
  }) async {
    if (email.isEmpty || password.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          backgroundColor: Theme.of(context).colorScheme.primary,
          content: const Text('Email and password cannot be empty!'),
          duration: const Duration(seconds: 3),
        ),
      );
      _loginSuccess = 0;
      notifyListeners();
      return;
    }

    setLoading(value: true);
    final data = {
      "P_USER_CODE": email,
      "P_USER_PASSWORD": password,
      "P_USER": email,
      "P_USER_IP":await getIp(),
    };
    final int apiRes = await ApiHandler().loginUser(data: data);
    _loginSuccess = apiRes;

    if (_loginSuccess==1) {
      // Check user code, status, and user type code
      final userLoginDetail = LocalStorage().userLoginDetail;
      if (userLoginDetail.value != null &&
          userLoginDetail.value!.isNotEmpty &&
          userLoginDetail.value![0].status == "1" &&
          userLoginDetail.value![0].userTypeCode == "03") {
        // Sign in if user code, status, and user type code are correct
        if(await uploadData()??false){
          await ApiHandler().downloadData();
        }else{
          await ApiHandler().downloadData();
        }
      } else {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            backgroundColor: Theme.of(context).colorScheme.primary,
            content: const Text('CareerWorker LogIn only'),
            duration: const Duration(seconds: 3),
          ),
        );
        // Set login success to false
        _loginSuccess = 0;
        notifyListeners();
        return;
      }
    } else if(loginSuccess == 0) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          backgroundColor: Theme.of(context).colorScheme.primary,
          content: const Text('Incorrect email and password!'),
          duration: const Duration(seconds: 3),
        ),
      );
      _loginSuccess = 0;
    }
    else{
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          backgroundColor: Theme.of(context).colorScheme.primary,
          content: const Text('Something wrong try again'),
          duration: const Duration(seconds: 3),
        ),
      );
    }

    setLoading(value: false);
    notifyListeners();
  }

  Future<bool?> uploadData() async {

    List<Map<String, dynamic>> result = await visitHandler.getUnUploadedData();

    if (await getConnection()) {
      bool temp = false;

      await Future.forEach(result ?? [], (element) async {

        temp = await visitHandler.getAllVisitData(element['CARER_VISIT_MST_ID'].toString());

      });

      if (temp) {
        return true;
      } else {
        return false;

      }

    }

    return false;
  }
}
