import 'package:animate_do/animate_do.dart';
import 'package:care4u/src/views/signinPage/providers/password_visibility.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

FadeInUp inputFieldArea({
  required BuildContext context,
  required TextEditingController emailController,
  required TextEditingController passwordController,
}) {
  final passwordVisibilityProvider = Provider.of<PasswordVisibilityProvider>(context);

  return FadeInUp(
    duration: const Duration(milliseconds: 1800),
    child: Container(
      padding: const EdgeInsets.all(5),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(10),
        border: Border.all(
          color: const Color.fromRGBO(143, 148, 251, 1),
        ),
        boxShadow: const [
          BoxShadow(
            color: Color.fromRGBO(143, 148, 251, .2),
            blurRadius: 20.0,
            offset: Offset(0, 10),
          ),
        ],
      ),
      child: Column(
        children: <Widget>[
          Container(
            padding: const EdgeInsets.all(5.0),
            decoration: const BoxDecoration(
              border: Border(
                bottom: BorderSide(
                  color: Color.fromRGBO(143, 148, 251, 1),
                ),
              ),
            ),
            child: TextFormField(
              controller: emailController,
              validator: (value) {
                if (value == null || value.isEmpty) {
                  return 'Please enter your email';
                }
                return null;
              },
              decoration: InputDecoration(
                border: InputBorder.none,
                prefixIcon: Icon(
                  Icons.email,
                  color: Theme.of(context).colorScheme.primary,
                ),
                hintText: "Type your Email",
                hintStyle: TextStyle(
                  fontFamily: 'Montserrat',
                  color: Colors.grey[700],
                ),
              ),
            ),
          ),
          Container(
            padding: const EdgeInsets.all(5.0),
            child: TextFormField(
              controller: passwordController,
              validator: (value) {
                if (value == null || value.isEmpty) {
                  return 'Please enter your password';
                }
                return null;
              },
              obscureText: !passwordVisibilityProvider.isPasswordVisible,
              decoration: InputDecoration(
                border: InputBorder.none,
                prefixIcon: Icon(
                  Icons.lock,
                  color: Theme.of(context).colorScheme.primary,
                ),
                suffixIcon: IconButton(
                  icon: Icon(
                    passwordVisibilityProvider.isPasswordVisible ? Icons.visibility_off : Icons.visibility,
                    color: Theme.of(context).colorScheme.primary,
                  ),
                  onPressed: () {
                    passwordVisibilityProvider.togglePasswordVisibility();
                  },
                ),
                hintText: "Type your Password",
                hintStyle: TextStyle(
                  fontFamily: 'Montserrat',
                  color: Colors.grey[700],
                ),
              ),
            ),
          ),
        ],
      ),
    ),
  );
}
