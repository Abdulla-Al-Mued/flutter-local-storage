import 'package:animate_do/animate_do.dart';
import 'package:flutter/material.dart';

FadeInUp forgetPasswordButton(BuildContext context) {
  return FadeInUp(
    duration: const Duration(milliseconds: 2000),
    child: Text(
      "Forgot Password?",
      style: TextStyle(
        fontFamily: 'Montserrat',
        color: Theme.of(context).colorScheme.primary,
      ),
    ),
  );
}
