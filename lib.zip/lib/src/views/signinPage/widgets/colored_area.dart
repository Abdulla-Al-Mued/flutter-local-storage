import 'package:flutter/material.dart';

Align coloredArea(BuildContext context) {
  return Align(
    alignment: Alignment.bottomCenter,
    child: Container(
      width: MediaQuery.of(context).size.width,
      height: MediaQuery.of(context).size.height / 1.8, //second back
      decoration: BoxDecoration(
        color: Theme.of(context).colorScheme.primary,
      ),
    ),
  );
}
