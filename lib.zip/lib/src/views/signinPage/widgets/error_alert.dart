import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

Container errorAlert({required String errorMsg}) {
  return Container(
    decoration: BoxDecoration(
      color: Colors.red.shade50,
      // Set your desired background color here
      border: Border.all(color: Colors.red.shade600),
      borderRadius: BorderRadius.circular(5),
    ),
    child: Padding(
      padding: const EdgeInsets.all(5.0),
      child: Row(
        children: [
          Icon(
            Icons.error_outline,
            // Choose the icon you want to use
            color: Colors.red.shade500,
          ), // Adjust the spacing between icon and text
          Expanded(
            child: Text(
              errorMsg,
              style: GoogleFonts.roboto(color: Colors.red.shade500),
              textAlign: TextAlign.center,
            ),
          ),
        ],
      ),
    ),
  );
}
