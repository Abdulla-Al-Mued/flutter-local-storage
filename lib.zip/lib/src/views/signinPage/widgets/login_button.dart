import 'package:animate_do/animate_do.dart';
import 'package:care4u/src/views/passcodeSetupPage/passcode_welcome_screen.dart';
import 'package:care4u/src/views/signinPage/providers/sign_page_provider.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../../controls/utils/global_internet_check.dart';

Widget loginButton({
  required BuildContext context,
  required bool isLoading,
  required String email,
  required String password,
}) {
  final signInPageProvider = Provider.of<SignInPageProvider>(context, listen: false);
  final networkProvider = Provider.of<InternetConnectionCheck>(context, listen: false);
  networkProvider.checkConnection();

  return FadeInUp(
    duration: const Duration(milliseconds: 1900),
    child: GestureDetector(
      onTap: () async {
        signInPageProvider.setLoading(value: true);

        try {
          final isConnected =networkProvider.isConnected; ;
          if (!isConnected) {
            ScaffoldMessenger.of(context).showSnackBar(
              SnackBar(
                backgroundColor: Theme.of(context).colorScheme.primary,
                content: const Text('Please check your internet connection'),
                duration: const Duration(seconds: 3),
              ),
            );
            signInPageProvider.setLoading(value: false);
            return;
          }
        } catch (e) {
          // Handle error when checking internet connectivity
          print('Error checking internet connectivity: $e');
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
              backgroundColor: Theme.of(context).colorScheme.primary,
              content: const Text('Error checking internet connection'),
              duration: const Duration(seconds: 3),
            ),
          );
          signInPageProvider.setLoading(value: false);
          return;
        }

        // Perform sign-in operation
        await signInPageProvider.signInUser(
          context: context,
          email: email,
          password: password,
        ).then((value) {
          if (signInPageProvider.loginSuccess==1) {
            // Navigate to the next page upon successful login
            Navigator.pushAndRemoveUntil(
              context,
              MaterialPageRoute(builder: (context) => const WelcomeSetPasscodeScreen()),
                  (route) => false,
            );
          } else {
            // Hide circular progress indicator if login fails
            signInPageProvider.setLoading(value: false);
          }
        });
      },
      child: Container(
        height: MediaQuery.of(context).size.height * .07,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(70),
          gradient: const LinearGradient(
            colors: [
              Color.fromRGBO(37, 134, 134, 1.0),
              Color.fromRGBO(37, 134, 134, 0.6),
            ],
          ),
        ),
        child: Center(
          child: isLoading
              ? const CircularProgressIndicator(
            color: Colors.white,
          )
              : const Text(
            "Login",
            style: TextStyle(
              fontFamily: 'Montserrat',
              color: Colors.white,
              fontWeight: FontWeight.bold,
            ),
          ),
        ),
      ),
    ),
  );
}


