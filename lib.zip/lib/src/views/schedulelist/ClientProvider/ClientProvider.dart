
import 'package:flutter/cupertino.dart';

import '../../../controls/localDatabaseHandler/local_database_handler.dart';
import '../../../models/insertion/CMS_CARER_VISIT_MST.dart';

class ClientProvider extends ChangeNotifier{

  final LocalDatabaseHandler dbHandler = LocalDatabaseHandler();

  late List<Map<String, dynamic>> address = [];
  late List<Map<String, dynamic>> medication = [];
  late List<Map<String, dynamic>> visitList = [];
  late List<Map<String, dynamic>> visitIconList = [];
  late List<Map<String, dynamic>> visitIconListMain = [];
  late List<Map<String, dynamic>> clientDOB = [];
  late String checkedInStatus = '';
  late String checkedInClientId = '';
  late bool _customIcon1 = false;
  late bool _customIcon2 = false;
  late bool _customIcon3 = false;
  late bool _isLoading = false;
  bool get isLoading => _isLoading;
  bool get customIcon1 => _customIcon1;
  bool get customIcon2 => _customIcon2;
  bool get customIcon3 => _customIcon3;


  void toggleLoading(bool value) {
    _isLoading = value;
    notifyListeners(); // Notify listeners of changes
  }

  void toggleCustomIcon1() {
    _customIcon1 = !_customIcon1;
    notifyListeners(); // Notify listeners of changes
  }
  void toggleCustomIcon2() {
    _customIcon2 = !_customIcon2;
    notifyListeners(); // Notify listeners of changes
  }
  void toggleCustomIcon3() {
    _customIcon3 = !_customIcon3;
    notifyListeners(); // Notify listeners of changes
  }


  Future<void> getClientAddress(String userId) async {
    List<Map<String, dynamic>> data = await dbHandler.getClientAddress(userId);
    if (data.isNotEmpty) {

      address = data;
      // print("Address "+address.first['ADDRESS']);
    }
    else{
      address = [];
      print("Empty");
    }

    notifyListeners();

  }

  Future<void> mstIsExist(String clientId) async {

    String? data = await dbHandler.getCarerVisitMstIdBYScheduleID();

    if (data!.isEmpty) {
      checkedInStatus = '1'; // insert no one checked in
      checkedInClientId = data;
    }
    else if(clientId == data){
      checkedInStatus = '2'; // check in possible
      checkedInClientId = data;
    }
    else{
      checkedInStatus = '3'; // already checked in
    }

    notifyListeners();

  }

  Future<void> getClientMedication(String userId) async {
    List<Map<String, dynamic>> data = await dbHandler.getClientMedication(userId);
    if (data.isNotEmpty) {

      medication = data;

    }
    else{
      medication = [];
      print("Empty");
    }

    notifyListeners();

  }

  Future<void> getClientVisitTypeName(String userId) async {
    List<Map<String, dynamic>> data = await dbHandler.getClientVisitTypeName(userId);
    if (data.isNotEmpty) {

      visitList = data;

    }
    else{
      visitList = [];
      print("Empty");
    }

    notifyListeners();

  }

  Future<List<Map<String, dynamic>>> getClientVisitTypeIconByName(String visitType) async {
    List<Map<String, dynamic>> data = await dbHandler.getClientVisitTypeIconByName(visitType);
    if (data.isNotEmpty) {

      visitIconList = data;

      //print(visitIconList);

    }
    else{
      visitIconList = [];
      print("Empty");
    }
    //notifyListeners();
    return data;

  }


  Future<int?> insertData(CarerVisitMst data, String clientDateWiseSchId) async {

    return await dbHandler.insertOrGetMstId(clientDateWiseSchId,data);
    //notifyListeners();

  }

  // Future<void> getClientVisitTypeIcon(String clientId, String visitType) async {
  //
  //   List<Map<String, dynamic>> data = await dbHandler.getClientVisitTypeIcon(clientId, visitType);
  //
  //   if (data.isNotEmpty) {
  //
  //     visitIconList = data;
  //     print(visitType);
  //     print(visitIconList);
  //
  //   }
  //   else{
  //     visitIconList = [];
  //     print("Empty");
  //   }
  //   notifyListeners();
  //
  // }

  Future<void> getClientDOB(String id) async {
    List<Map<String, dynamic>> data = await dbHandler.getClientDOB(id);
    if (data.isNotEmpty) {

      clientDOB = data;
      //print(visitIconList);

    }
    else{
      clientDOB = [];
      print("Empty");
    }
    notifyListeners();

  }


}