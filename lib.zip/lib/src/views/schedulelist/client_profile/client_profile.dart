import 'package:app_settings/app_settings.dart';
import 'package:care4u/src/controls/utils/color_codes.dart';
import 'package:care4u/src/views/report/controller/task_controller.dart';
import 'package:care4u/src/views/report/new_report.dart';
import 'package:care4u/src/views/schedulelist/ClientProvider/ClientProvider.dart';
import 'package:care4u/src/views/schedulelist/client_profile/recent_visit.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter/widgets.dart';
import 'package:geolocator/geolocator.dart';
import 'package:intl/intl.dart';
import 'package:provider/provider.dart';

import '../../../controls/apiHandler/api_handler.dart';
import '../../../controls/localDatabaseHandler/local_database_handler.dart';
import '../../../controls/localStorage/local_storage.dart';
import '../../../controls/utils/Tools.dart';
import '../../../controls/utils/appbar.dart';
import '../../../controls/utils/oneTimeNetCheck.dart';
import '../../../models/LocalModel/LocalDpd_Cms_Carer_Cln_Dtws_Sch_Lst_Model.dart';
import '../../../models/insertion/CMS_CARER_VISIT_MST.dart';
import '../../report/controller/report_visit_controller.dart';
import '../widgets/icon_from_url.dart';

class ClientProfile extends StatefulWidget {
  Value userId;
  String isScheduled;

  ClientProfile( {super.key, required this.userId, required this.isScheduled}) ;

  @override
  _ClientProfileState createState() => _ClientProfileState();
}

class _ClientProfileState extends State<ClientProfile> {

  final LocalDatabaseHandler dbHandler = LocalDatabaseHandler();
  LocalStorage localStorage = LocalStorage();
  final ApiHandler _apiHandler = ApiHandler();
  late String carerId;

  late int? id;

  @override
  void initState() {

    super.initState();
    print("org code - "+widget.userId.orgCode.toString());
    carerId = localStorage.userLoginDetail.value![0].carerId!;

  }

  String convertTo12HourFormat(String time24) {
    final time = TimeOfDay.fromDateTime(DateFormat('HH:mm').parse(time24));
    return time.format(context); // context should be available in the widget's build method
  }

  @override
  Widget build(BuildContext context) {

    print("carerId "+localStorage.userLoginDetail.value![0].carerId!);

    final clientData = Provider.of<ClientProvider>(context,  listen: false);
    final taskData = Provider.of<TaskController>(context, listen: false);
    final visit = Provider.of<VisitTypeController>(context, listen: false);
    clientData.getClientAddress(widget.userId.clientId.toString());
    clientData.getClientMedication(widget.userId.clientId.toString());
    clientData.getClientVisitTypeName(widget.userId.clientId.toString());
    clientData.getClientDOB(widget.userId.clientId.toString());
    clientData.mstIsExist(widget.userId.clientId!);
    //clientData.toggleLoading(false);
    clientData.checkedInStatus == '2'?
    taskData.getAssigned(visit.clientVisitMasterId, widget.userId.clientId!):
    taskData.getAssigned(widget.userId.clientVisitTypeMstId!, widget.userId.clientId!);

    print(widget.userId.clientId);
    return Scaffold(
      appBar: const CustomAppBar(
          backgroundColor: Colors.white,
          title: 'Clients Profile'),
      body: SingleChildScrollView(
        child: Column(
          children: [
            Column(
              children: [
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 20.0),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    children: [
                      Padding(
                        padding: const EdgeInsets.symmetric(vertical: 20.0),
                        child: Text(
                          widget.userId.clientName.toString(),
                          style: const TextStyle(
                            fontFamily: 'PoppinsBold',
                            fontSize: 22.0,
                            color: heading
                          ),
                        ),
                      ),
                      const SizedBox(height: 8.0),
                      Consumer3<ClientProvider, TaskController, VisitTypeController>(builder: (BuildContext context, ClientProvider value,TaskController task,VisitTypeController visitController, Widget? child) {

                        return Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            GestureDetector(
                              onTap:value.checkedInStatus == '2' || value.checkedInStatus == '1'?() async {

                                clientData.toggleLoading(true);
                                task.toggleLoading(false);

                                Position? position1;

                                //determinePosition();

                                if(value.checkedInStatus == '1'){
                                  print("first checked in");
                                  bool checkPermission = await checkLocationStatus();
                                  if(!checkPermission){
                                    const snackBar = SnackBar(
                                      content: Text('You must turn on location to check in'),
                                      duration: Duration(seconds: 3), // Adjust the duration as needed
                                    );
                                    ScaffoldMessenger.of(context).showSnackBar(snackBar);
                                    clientData.toggleLoading(false);

                                  }

                                  Position position;
                                  try {
                                    position1 = await Geolocator.getCurrentPosition(desiredAccuracy: LocationAccuracy.high);
                                    position = await Geolocator.getCurrentPosition();

                                  } on PlatformException catch (e) {

                                    if (e.code == 'PERMISSION_DENIED') {
                                      showSnackBar(context,'Error getting location: $e');
                                    } else {
                                      showSnackBar(context,'Error getting location: $e');
                                    }
                                    clientData.toggleLoading(false);
                                    return;
                                  } catch (e) {
                                    // Handle other generic exceptions
                                    Geolocator.openLocationSettings();
                                    const snackBar = SnackBar(
                                      content: Text('check your location permission'),
                                      duration: Duration(seconds: 3), // Adjust the duration as needed
                                    );
                                    ScaffoldMessenger.of(context).showSnackBar(snackBar);
                                    clientData.toggleLoading(false);
                                    print('Error: $e');
                                    return;
                                  }
                                  //Position position = await Geolocator.getCurrentPosition(desiredAccuracy: LocationAccuracy.high);
                                  print("location");
                                  //print();
                                  print(position.latitude.toString()+", "+position.longitude.toString());

                                  Map<String, dynamic> apiData = {
                                    "P_CARER_VISIT_CHK_INOUT_ID":"",
                                    "P_ORG_CODE":widget.userId.orgCode,
                                    "P_CLIENT_DATEWISE_SCH_ID":widget.userId.clientDatewiseSchId,
                                    "P_CLIENT_ID":widget.userId.clientId,
                                    "P_CLIENT_CODE":widget.userId.clientCode,
                                    "P_CLIENT_VISIT_TYPE_MST_ID":widget.userId.clientVisitTypeMstId,
                                    "P_VISIT_DATE":getCurrentDate(),
                                    "P_CHECK_IN_DATE":getCurrentDate(),
                                    "P_CHECK_IN_TIME":"${TimeOfDay.now().hour.toString().padLeft(2, '0')}:${TimeOfDay.now().minute.toString().padLeft(2, '0')}",
                                    "P_CHECK_IN_LATTITUDE":position.latitude.toString(),
                                    "P_CHECK_IN_LONGLITUDE":position.longitude.toString(),
                                    "P_CARER_ID":carerId,
                                    "P_CARER_CODE":localStorage.userLoginDetail.value?[0].carerCode,
                                    "P_CARER_ID2": '',
                                    "P_CARER_CODE2": '',
                                    "P_CHECK_OUT_DATE":"",
                                    "P_CHECK_OUT_TIME":"",
                                    "P_WORKING_TIME":"0",
                                    "P_CHECK_OUT_LATTITUDE":"",
                                    "P_CHECK_OUT_LONGLITUDE":"",
                                    "P_RowStatus":"1",
                                    "P_CLIENT_ADDRESS":"",
                                    "P_User":localStorage.userLoginDetail.value?[0].userCode,
                                    "P_USER_IP":await getIp()
                                  };

                                  if(await getConnection()){
                                    if(!await _apiHandler.checkInOut(apiData)){
                                      clientData.toggleLoading(false);
                                    }
                                  }
                                }

                                CarerVisitMst data = CarerVisitMst(
                                  orgCode: widget.userId.orgCode,
                                  clientId: int.parse(widget.userId.clientId ?? '0'),
                                  clientCode: widget.userId.clientCode,
                                  CLIENT_VISIT_TYPE_MST_ID: widget.userId.clientVisitTypeMstId,
                                  CLIENT_DATEWISE_SCH_ID: widget.userId.clientDatewiseSchId,
                                  CARER_ID2: '',
                                  CARER_CODE2: '',
                                  CARER_ID: localStorage.userLoginDetail.value?[0].carerId,
                                  CARER_CODE: localStorage.userLoginDetail.value?[0].carerCode,
                                  CHECK_IN_TIME: "${TimeOfDay.now().hour.toString().padLeft(2, '0')}:${TimeOfDay.now().minute.toString().padLeft(2, '0')}",
                                  CHECK_IN_DATE: getCurrentDate(),
                                  CHECK_IN_LATTITUDE: position1!=null?position1.latitude.toString():"",
                                  CHECK_IN_LONGITUDE: position1!=null?position1.longitude.toString():"",
                                  VISIT_DATE: getCurrentDate(),
                                  ANOTHER_CARER_STATUS: "N",
                                  IS_SCHEDULED: widget.isScheduled,
                                  // HOW_DID_CLIENT_EMOJI_CODE: '2'
                                );

                                id = await clientData.insertData(data, widget.userId.clientId!);

                                clientData.mstIsExist(widget.userId.clientId!);

                                print("master id");
                                //print(id.toString());

                                Navigator.push(
                                  context,
                                  MaterialPageRoute(
                                    builder: (context) => NewReport(userId: widget.userId, id: id, scType: widget.isScheduled),
                                  ),
                                );

                                clientData.toggleLoading(false);

                              } : null,



                              child: Container(
                                padding: const EdgeInsets.all(15.0),
                                width: double.infinity,
                                decoration: BoxDecoration(
                                  color: value.checkedInStatus == '2'?Colors.blue :value.checkedInStatus == '1'? Colors.green : Colors.grey,
                                  borderRadius: BorderRadius.circular(40),
                                ),
                                child: value.isLoading? Center(child: CircularProgressIndicator(color: Colors.white)) :
                                value.checkedInStatus == '2'? const Text(
                                  'Checked in - return to report',
                                  textAlign: TextAlign.center,
                                  style: TextStyle(
                                    color: Colors.white,
                                    fontSize: 16.0,
                                  ),
                                ) :value.checkedInStatus == '1'? const Text(
                                  'Check In',
                                  textAlign: TextAlign.center,
                                  style: TextStyle(
                                    color: Colors.white,
                                    fontSize: 16.0,
                                  ),
                                ) :  const Text(
                                  'Checked in into another client',
                                  textAlign: TextAlign.center,
                                  style: TextStyle(
                                    color: Colors.white,
                                    fontSize: 16.0,
                                  ),
                                ),
                              ),
                            ),
                            const SizedBox(
                              height: 10,
                            ),
                            Text(
                              "${widget.userId.startTime!}-${widget.userId.endTime!}",
                              textAlign: TextAlign.center,
                            ),
                            const SizedBox(height: 10),
                            if(task.aAllTask!.isNotEmpty)
                            SizedBox(
                              height: 30,
                              child: ListView.builder(
                                shrinkWrap: true,
                                scrollDirection: Axis.horizontal,
                                itemCount: task.aAllTask?.length,
                                itemBuilder: (context, index) {
                                  return IconFromUrl(imageUrl: task.aAllTask?[index]['TASK_CODE']);
                                },
                              ),
                            ),
                            const SizedBox(height: 20)
                          ],
                        );
                      },),

                    ],
                  ),
                ),
                Divider(
                  thickness: 10,
                  color: Colors.grey.shade200,
                  height: 5,
                ),
                Padding(
                  padding: EdgeInsets.all(20.0),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    children: [
                      const Padding(
                        padding: EdgeInsets.only(bottom: 16.0),
                        child: Text(
                          'Contact details',
                          style: TextStyle(
                            fontFamily: 'PoppinsBold',
                              fontSize: 16,
                              fontWeight: FontWeight.bold,
                              color: heading
                          ),
                        ),
                      ),
                      Row(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          const Icon(Icons.home_filled,color: heading),
                          const SizedBox(width: 10),
                          Flexible(
                            child: SizedBox(
                              width: 300, // Adjust the width as needed
                              child: Consumer<ClientProvider>(
                                builder: (context, clientProvider, child) {
                                  if (clientProvider.address.isNotEmpty) {
                                    return Text(
                                      clientProvider.address.first['ADDRESS'],
                                      maxLines: 10,
                                      overflow: TextOverflow.ellipsis,
                                      style: TextStyle(
                                        fontSize: 16,
                                        color: text ,
                                      ),
                                    );
                                  } else {
                                    // Handle the case where the address list is empty
                                    print("no element found");
                                    return const Text('No address available');
                                  }
                                },
                              ),
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              ],
            ),
            Divider(
              thickness: 10,
              color: Colors.grey.shade200,
              height: 5,
            ),
            InkWell(
              onTap: () => Navigator.push(context, MaterialPageRoute(builder: (context) => RecentVisit(clientId: widget.userId.clientId),)),
              child: const Padding(
                padding: EdgeInsets.symmetric(vertical: 26, horizontal: 20),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text(
                      'Recently visits',
                      style: TextStyle(
                        fontSize: 18,
                        fontWeight: FontWeight.bold,
                        color: heading,
                      ),
                    ),
                    Icon(Icons.arrow_forward_ios, size: 25,),
                  ],
                ),
              ),
            ),
            Divider(
              thickness: 10,
              color: Colors.grey.shade200,
              height: 5,
            ),
            Padding(
              padding: const EdgeInsets.symmetric(vertical: 15),
              child: Theme(
                data: ThemeData(
                  dividerColor: Colors.transparent,
                  splashColor: Colors.transparent,
                  highlightColor: Colors.transparent,
                ),
                child: Consumer<ClientProvider>(
                  builder: (BuildContext context, value, Widget? child) {
                    return ExpansionTile(
                      title: const Text("Medication",
                        style: TextStyle(fontSize: 18,
                        fontWeight: FontWeight.bold,
                          color: heading
                        ),),
                      trailing: Icon(
                        value.customIcon1 ? Icons.keyboard_arrow_up : Icons.keyboard_arrow_down, size: 40,
                      ),
                      children: <Widget>[
                            if (value.medication.isNotEmpty)
                              Column(
                                children: List.generate(
                                  value.medication.length,
                                      (index) => getMedicationSingleItem(value.medication[index]), // Assuming you want 2 items
                                ),
                              )
                            else
                              const Text('No medication available'),
                      ],
                      onExpansionChanged: (bool expanded) {
                        value.toggleCustomIcon1();
                      },
                    );
                  },
                ),
              ),
            ),
            Divider(
              thickness: 10,
              color: Colors.grey.shade200,
              height: 5,
            ),
            Padding(
              padding: const EdgeInsets.symmetric(vertical: 15),
              child: Theme(
                data: ThemeData(
                  dividerColor: Colors.transparent,
                  splashColor: Colors.transparent,
                  highlightColor: Colors.transparent,
                ),
                child: Consumer<ClientProvider>(
                  builder: (BuildContext context, value, Widget? child) {

                    return ExpansionTile(
                      title: const Text("Visit Type",style: TextStyle(
                          fontSize: 18,
                          fontWeight: FontWeight.bold,
                          color: heading
                      ),),
                      trailing: Icon(
                        value.customIcon2 ? Icons.keyboard_arrow_up : Icons.keyboard_arrow_down, size: 40,
                      ),
                      children: <Widget>[
                            if (value.visitList.isNotEmpty)
                              Column(
                                children: List.generate(
                                  value.visitList.length,
                                      (index) => FutureBuilder<Column>(
                                    future: getVisitSingleItem(value.visitList[index], clientData, context), // Pass the context
                                    builder: (context, snapshot) {
                                      if (snapshot.connectionState == ConnectionState.waiting) {
                                        return Container(); // Placeholder while waiting for data
                                      } else if (snapshot.hasError) {
                                        return Text('Error: ${snapshot.error}');
                                      } else {
                                        return snapshot.data ?? const SizedBox(); // Return the data if available
                                      }
                                    },
                                  ),
                                ),
                              )
                              else
                              const Text('No Visiting Time available'),
                      ],
                      onExpansionChanged: (bool expanded) {
                        value.toggleCustomIcon2();
                      },
                    );

                  },
                ),
              ),
            ),
            Divider(
              thickness: 10,
              color: Colors.grey.shade200,
              height: 5,
            ),
            Padding(
              padding: const EdgeInsets.symmetric(vertical: 15),
              child: Theme(
                data: ThemeData(
                  dividerColor: Colors.transparent,
                  splashColor: Colors.transparent,
                  highlightColor: Colors.transparent,
                ),
                child: Consumer<ClientProvider>(
                  builder: (BuildContext context, value, Widget? child) {
                    return ExpansionTile(
                      title: const Text("Personal Details",style: TextStyle(
                          fontSize: 18,
                          fontWeight: FontWeight.bold,
                          color: heading
                      ),),
                      trailing: Icon(
                        value.customIcon3 ? Icons.keyboard_arrow_up : Icons.keyboard_arrow_down, size: 40,
                      ),
                      children: <Widget>[
                        if (value.clientDOB.isNotEmpty)
                            Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Padding(
                                  padding: const EdgeInsets.only(left: 18.0),
                                  child: Align(
                                    alignment: Alignment.centerLeft,
                                    child: RichText(
                                      text: TextSpan(
                                        style: DefaultTextStyle.of(context).style,
                                        children: [
                                          TextSpan(
                                            text: value.clientDOB.first['DOB']+"("+dateToDays(value.clientDOB.first['DOB'])+" years old) ",
                                            style: const TextStyle(
                                                fontSize: 16,
                                                color: text // Adjust the color as needed
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                  ),
                                ),
                            // Add more Align widgets for additional text or other widgets here
                              ],
                            )
                        else
                          const Padding(
                            padding: EdgeInsets.all(8.0),
                            child: Text('No personal data available'),
                          ),

                      ],
                      onExpansionChanged: (bool expanded) {
                        value.toggleCustomIcon3();
                      },
                    );
                  },
                ),
              ),
            ),
            Divider(
              thickness: 10,
              color: Colors.grey.shade200,
              height: 5,
            ),

          ],
        ),
      ),
    );
  }

  Widget _buildIconWithBorder(IconData iconData) {
    return Padding(
      padding: const EdgeInsets.all(12.0),
      child: Container(
        padding: const EdgeInsets.all(8.0),
        decoration: BoxDecoration(
          border: Border.all(
            color: Colors.grey,
            width: 1.0,
          ),
          borderRadius: BorderRadius.circular(8.0),
        ),
        child: Icon(
          iconData,
          size: 12.0,
        ),
      ),
    );
  }

  Column getMedicationSingleItem(Map<String, dynamic> medication){

    return Column(
      children: [
        Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Padding(
              padding: const EdgeInsets.only(left: 18.0),
              child: Align(
                alignment: Alignment.centerLeft,
                child: RichText(
                  text: TextSpan(
                    style: DefaultTextStyle.of(context).style,
                    children: [
                      TextSpan(
                        text: medication['MEDICATION_NAME']!,
                        style: const TextStyle(
                          fontSize: 16,
                          color: heading ,
                          decoration: TextDecoration.none,
                        ),
                      ),
                      TextSpan(
                        text: " "+medication['DOSAGE'],
                        style: const TextStyle(
                          fontSize: 14, // Adjust the font size as needed
                          color: Colors.black45, // Adjust the color as needed
                          decoration: TextDecoration.none,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
            Container(
              padding: const EdgeInsets.only(left: 14.0),
              child: Align(
                alignment: Alignment.centerLeft,
                child: Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: Text(
                    getVisitTime(medication),
                    style: const TextStyle(
                      fontSize: 14,
                      color: Colors.black45,
                    ),
                  ),
                ),
              ),
            ),

            Container(
              padding: const EdgeInsets.only(left: 14.0),
              margin: EdgeInsets.only(bottom: 10),
              child: Align(
                alignment: Alignment.centerLeft,
                child: Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: Text(
                    getVisitDay(medication),
                    style: const TextStyle(
                      fontSize: 14,
                      color: Colors.black45,
                    ),
                  ),
                ),
              ),
            ),
            // Add more Align widgets for additional text or other widgets here
          ],
        ),
      ],
    );
  }

  Future<Column> getVisitSingleItem(Map<String, dynamic> visitName, ClientProvider clientData, BuildContext context) async {
    List<Map<String, dynamic>> visitIconList = await clientData.getClientVisitTypeIconByName(visitName['VISIT_TYPE_NAME']);

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Container(
          margin: EdgeInsets.only(top: 5),
          padding: const EdgeInsets.only(left: 18.0),
          child: Align(
            alignment: Alignment.centerLeft,
            child: RichText(
              text: TextSpan(
                style: DefaultTextStyle.of(context).style,
                children: [
                  TextSpan(
                    text: visitName['VISIT_TYPE_NAME'],
                    style: const TextStyle(
                        fontSize: 16,
                        color: text ,
                        decoration: TextDecoration.none
                    ),
                  ),
                  const TextSpan(
                    text: ' Visit',
                    style: TextStyle(
                        fontSize: 16,
                        color: text ,
                        decoration: TextDecoration.none
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
        Container(
          height: 30,
          margin: const EdgeInsets.only(left: 18, top: 5, bottom: 5),
          child: ListView.builder(
            scrollDirection: Axis.horizontal,
            itemCount: visitIconList.length,
            itemBuilder: (context, index) {
              return IconFromUrl(imageUrl: visitIconList[index]['TASK_CODE']);
            },
          ),
        ),
      ],
    );
  }

  Padding getVisitIcons(String visitIconList){

    return Padding(
      padding: EdgeInsets.only(left: 14.0),
      child: Align(
        alignment: Alignment.centerLeft,
        child: Padding(
          padding: EdgeInsets.all(8.0),
          child: Text(
            'text',
            style: TextStyle(
              fontSize: 14,
              color: Colors.black87,
            ),
          ),
        ),
      ),
    );
  }

  String getVisitTime(Map<String, dynamic> medication) {

    String visitTime = "";

    if(medication['MORNING_SCHEDULE'] == 'Y') {
      visitTime = "Morning" + ", " + visitTime;
    }
    if(medication['LUNCHTIME_SCHEDULE'] == 'Y') {
      visitTime = "Lunch Time" + ", " + visitTime;
    }
    if(medication['EVENING_SCHEDULE'] == 'Y') {
      visitTime = "Evening" + ", " + visitTime;
    }
    if(medication['BEDTIME_SCHEDULE'] == 'Y') {
      visitTime = "Bed Time" + ", " + visitTime;
    }
    if(medication['AS_NEEDED_SCHEDULE'] == 'Y') {
      visitTime = "As Needed Schedule" + ", " + visitTime;
    }
    if(visitTime.isEmpty){
      return "No Visiting Time Found";
    }else {
      visitTime = visitTime.substring(0, visitTime.length - 2);
      return visitTime;
    }
  }

  String getVisitDay(Map<String, dynamic> medication) {

    String visitDay = "";

    if(medication['MONDAY_SCHEDULE'] == 'Y') {
      visitDay = "Monday" + ", " + visitDay;
    }
    if(medication['TUESDAY_SCHEDULE'] == 'Y') {
      visitDay = "Tuesday" + ", " + visitDay;
    }
    if(medication['WEDNESDAY_SCHEDULE'] == 'Y') {
      visitDay = "Wednesday" + ", " + visitDay;
    }
    if(medication['THURSDAY_SCHEDULE'] == 'Y') {
      visitDay = "Thursday" + ", " + visitDay;
    }
    if(medication['FRIDAY_SCHEDULE'] == 'Y') {
      visitDay = "Friday" + ", " + visitDay;
    }
    if(medication['SATURDAY_SCHEDULE'] == 'Y') {
      visitDay = "Saturday" + ", " + visitDay;
    }
    if(medication['SUNDAY_SCHEDULE'] == 'Y') {
      visitDay = "Sunday" + ", " + visitDay;
    }
    if(visitDay.isEmpty){
      return "No Visiting Time Found";
    }else {
      visitDay = visitDay.substring(0, visitDay.length - 2);
      return visitDay;
    }

  }

}
