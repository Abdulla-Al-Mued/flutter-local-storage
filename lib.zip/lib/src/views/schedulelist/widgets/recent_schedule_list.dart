import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import '../../../controls/localDatabaseHandler/local_db_handler_report.dart';
import '../../../models/report_model/report_summary.dart';
import '../../reportPage/report_screen.dart';

FutureBuilder<List<dynamic>> recent_schedule_list(String? clientId) {
  final ReportHandler dbHandler = ReportHandler();
  return FutureBuilder<List<dynamic>>(
    future: dbHandler.getRecentVisit(clientId!),
    builder: (context, snapshot) {
      if (snapshot.connectionState == ConnectionState.waiting) {
        return Center(child: SizedBox(
          height: MediaQuery.of(context).size.height*.7,
          child: Container(
              height: 50,
              width: 50,
              child: Image.asset('assets/images/loading.gif')
          ),
        ));
      } else if (snapshot.hasError) {
        return Text('Error: ${snapshot.error}');
      } else if (snapshot.hasData) {
        List<dynamic> dataList = snapshot.data!;
        List<Map<String, dynamic>> data = dataList.cast<Map<String, dynamic>>();

        if(data.isEmpty) {
          return Container(
            height: MediaQuery.of(context).size.height * 0.7,
            alignment: Alignment.center,
            child: const Text(
                'No data found',
              textAlign: TextAlign.center,
            ),
          );
        }else{
          String? currentDate;
          return ListView.builder(
            scrollDirection: Axis.vertical,
            shrinkWrap: true,
            primary: false,
            itemCount: data.length ?? 0,
            itemBuilder: (context, index) {
              Map<String, dynamic> jsonMap = data[index];
              CarerVisitReportSummary summary =
              CarerVisitReportSummary.fromJson(jsonMap);

              // Parse start and end time strings into DateTime objects

              // Determine if it's today, tomorrow, or a specific date

              // Check if a new header is needed
              return InkWell(
                  onTap: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(builder: (context) => ReportPage(visitSummary : summary)),
                    );
                  },
                  child: buildScheduleTile(summary, index, data));
            },
          );
        }


      } else {
        return const Center(child: Text('No data found'));
      }
    },
  );
}

String getHeaderText(String? scheduleDate) {
  DateFormat dateFormat = DateFormat('dd/MM/yyyy');
  DateTime currentDateFormatted = dateFormat.parse(scheduleDate ?? '');
  DateTime today = DateTime.now();
  if (currentDateFormatted.year == today.year &&
      currentDateFormatted.month == today.month &&
      currentDateFormatted.day == today.day) {
    return 'Today, ${DateFormat('EEEE, dd MMM').format(currentDateFormatted)}';
  } else {
    DateTime tomorrow = today.add(const Duration(days: 1));
    if (currentDateFormatted.year == tomorrow.year &&
        currentDateFormatted.month == tomorrow.month &&
        currentDateFormatted.day == tomorrow.day) {
      return 'Tomorrow, ${DateFormat('EEEE, dd MMM').format(currentDateFormatted)}';
    } else {
      return DateFormat('EEEE, dd MMM').format(currentDateFormatted);
    }
  }
}

Widget buildScheduleTile(CarerVisitReportSummary summary, int index,
    List<Map<String, dynamic>> data) {
  String headerText = getHeaderText(summary.checkInDate);
  String currentText = "";
  bool temp = true;
  if (index != 0) {
    currentText = getHeaderText(data[index - 1]['CHECK_IN_DATE']);
  }

  return Column(
    children: [
      const SizedBox(height: 10),
      if (currentText != headerText)
        Container(
          width: double.infinity,
          height: 36,
          color: Colors.blue.shade50,
          padding: const EdgeInsets.symmetric(vertical: 8, horizontal: 20),
          child: Text(
            headerText,
            style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w600),
          ),
        ),
      Padding(
        padding: const EdgeInsets.symmetric(horizontal: 20.0, vertical: 15),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // time and Name and visit type

            Padding(
              padding: const EdgeInsets.only(right: 20.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      const Padding(
                        padding: EdgeInsets.only(right: 8.0),
                        child: Icon(
                          Icons.arrow_circle_right_outlined,
                          size: 15,
                        ),
                      ),
                      Text(
                        summary.checkInTime ?? 'No Client Code',
                        style: const TextStyle(fontSize: 14),
                      ),
                    ],
                  ),
                  Row(
                    children: [
                      const Padding(
                        padding: EdgeInsets.only(right: 8.0),
                        child: Icon(
                          Icons.arrow_circle_left_outlined,
                          size: 15,
                        ),
                      ),
                      Text(
                        summary.checkOutTime ?? 'No Client Code',
                        style: const TextStyle(fontSize: 14),
                      ),
                    ],
                  ),
                  Row(
                    children: [
                      const Padding(
                        padding: EdgeInsets.only(right: 8.0),
                        child: Icon(
                          size: 15,
                          Icons.access_time,
                        ),
                      ),
                      Text(
                        '${summary.workingTime}h',
                        style: const TextStyle(fontSize: 14),
                      ),
                    ],
                  ),
                ],
              ),
            ),
            // divide--------------------------------------->
            Flexible(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    summary.carerName!,
                    style: const TextStyle(
                        fontFamily: 'Montserrat',
                        fontSize: 18,
                        overflow: TextOverflow.ellipsis,
                        fontWeight: FontWeight.bold),
                  ),
                  if (summary.taskData != null) // Check if taskData is not null
                    SingleChildScrollView(
                      // Wrap with SingleChildScrollView to allow horizontal scrolling
                      scrollDirection: Axis.horizontal,
                      child: Wrap(
                        children: [
                          for (Task task in summary.taskData!)
                            iconSingleItem(task),
                        ],
                      ),
                    ),
                ],
              ),
            ),
          ],
        ),
      ),
      Divider(
        height: 1,
        color: Colors.grey.shade300,
        thickness: 1,
      )
    ],
  );
}

Widget iconSingleItem(Task taskData) {
  var iconPath;

  switch (taskData.taskCode) {
    case "01":
      iconPath = 'assets/task/medication.png';
      break;
    case "02":
      iconPath = 'assets/task/bodymap.png';
      break;
    case "03":
      iconPath = 'assets/task/food.png';
      break;
    case "04":
      iconPath = 'assets/task/drinks.png';
      break;
    case "05":
      iconPath = 'assets/task/care.png';
      break;
    case "06":
      iconPath = 'assets/task/toilet_assistance.png';
      break;
    case "07":
      iconPath = 'assets/task/repositioning.png';
      break;
    case "08":
      iconPath = 'assets/task/campanionship.png';
      break;
    case "09":
      iconPath = 'assets/task/laundry.png';
      break;
    case "10":
      iconPath = 'assets/task/groceries.png';
      break;
    case "11":
      iconPath = 'assets/task/housework.png';
      break;
    case "12":
      iconPath = 'assets/task/household.png';
      break;
    case "99":
      iconPath = 'assets/task/unable_deliver.png';
      break;
  // Add more cases as needed
    default:
    // Set a default icon path if task code doesn't match any case
      iconPath =
      'assets/icons/unable_deliver.png'; // Change to your default icon path
      break;
  }
  return Column(
    children: [
      Container(
        margin: const EdgeInsets.all(5),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(8),
          border: Border.all(
            color: Colors.grey.shade300, // Set the border color here
            width: 2, // Set the border width here
          ),
        ),
        child: Padding(
          padding: const EdgeInsets.all(5),
          child: Image.asset(
            iconPath,
            width: 20,
            height: 20,
          ),
        ),
      ),
    ],
  );
}

