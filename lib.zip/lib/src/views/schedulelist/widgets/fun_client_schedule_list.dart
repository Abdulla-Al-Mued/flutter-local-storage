import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:care4u/src/controls/localDatabaseHandler/local_database_handler.dart';
import '../../../controls/utils/color_codes.dart';
import '../../../models/LocalModel/LocalDpd_Cms_Carer_Cln_Dtws_Sch_Lst_Model.dart';
import '../client_profile/client_profile.dart';

FutureBuilder<List<dynamic>> client_schedule_list() {
  final LocalDatabaseHandler dbHandler = LocalDatabaseHandler();
  String? currentDate = "";
  return FutureBuilder<List<dynamic>>(
    future: dbHandler.getDpdCmsCarerClnDtwsSchLst(),
    builder: (context, snapshot) {
      if (snapshot.connectionState == ConnectionState.waiting) {
        return Center(child: SizedBox(
          height: MediaQuery.of(context).size.height*.7,
          child: Container(
              height: 50,
              width: 50,
              child: Image.asset('assets/images/loading.gif')
          ),
        ));
      } else if (snapshot.hasError) {
        return Text('Error: ${snapshot.error}');
      } else if (snapshot.hasData) {
        List<dynamic> dataList = snapshot.data!;
        print(dataList.length.toString());
        print(dataList);
        List<Map<String, dynamic>> data = dataList.cast<Map<String, dynamic>>();
        LocalDpdCmsCarerClnDtwsSchLstModel model = LocalDpdCmsCarerClnDtwsSchLstModel.fromJson({"Value": data});

        if(data.isEmpty) {
          return Container(
            height: MediaQuery.of(context).size.height * 0.7,
            alignment: Alignment.center,
            child: const Text(
              'No data found',
              textAlign: TextAlign.center,
            ),
          );
        }


        return ListView.builder(
          scrollDirection: Axis.vertical,
          shrinkWrap: true,
          primary: false,
          itemCount: model.value?.length,
          itemBuilder: (context, index) {
            Value? clientScheduleList = model.value?[index];


            DateFormat timeFormat = DateFormat('HH:mm');
            DateTime startTime = timeFormat.parse(clientScheduleList?.startTime ?? '00:00');
            DateTime endTime = timeFormat.parse(clientScheduleList?.endTime ?? '00:00');

            // Calculate total time difference
            Duration totalTime = endTime.difference(startTime);

            return InkWell(
                onTap: (){

                  String headerText = getHeaderText(clientScheduleList?.scheduleDate);

                  if(headerText.contains("Today", 0) && clientScheduleList?.clientVisitTypeMstId != null){
                    navigateToClientProfile(model.value![index], context);
                  }
                  print("clicked");
                },
                child: buildScheduleTile(clientScheduleList, totalTime, index, model.value!)
            );

            // Check if a new header is needed
            // if (currentDate != headerText) {
            //   currentDate = headerText;
            //
            //   print(currentDate);
            //
            //
            // }
            // else {
            //
            //   currentDate = headerText;
            //
            //   return GestureDetector(
            //     onTap: (){
            //       navigateToClientProfile(model.value![index], context);
            //     },
            //       child: buildScheduleTile(clientScheduleList, totalTime)
            //   );
            // }
          },
        );
      } else {
        return const Center(child: Text('No data found'));
      }
    },
  );
}


void navigateToClientProfile(Value clientProfile, BuildContext context) {
  Navigator.push(
    context,
    MaterialPageRoute(
      builder: (context) => ClientProfile(userId: clientProfile, isScheduled : 'Y'),
    ),
  );
}


String getHeaderText(String? scheduleDate) {
  DateFormat dateFormat = DateFormat('dd/MM/yyyy');
  DateTime currentDateFormatted = dateFormat.parse(scheduleDate ?? '');
  DateTime today = DateTime.now();
  if (currentDateFormatted.year == today.year &&
      currentDateFormatted.month == today.month &&
      currentDateFormatted.day == today.day) {
    return 'Today, ${DateFormat('EEEE, dd MMM').format(currentDateFormatted)}';
  } else {
    DateTime tomorrow = today.add(const Duration(days: 1));
    if (currentDateFormatted.year == tomorrow.year &&
        currentDateFormatted.month == tomorrow.month &&
        currentDateFormatted.day == tomorrow.day) {
      return 'Tomorrow, ${DateFormat('EEEE, dd MMM').format(currentDateFormatted)}';
    } else {
      return DateFormat('EEEE, dd MMM').format(currentDateFormatted);
    }
  }
}


Column buildScheduleTile(Value? clientScheduleList, Duration totalTime, int index, List<Value> value) {

  // Parse start and end time strings into DateTime objects

  // Determine if it's today, tomorrow, or a specific date
  String headerText = getHeaderText(clientScheduleList?.scheduleDate);
  String currentText = "";
  bool temp = true;
  if(index!=0){
    currentText = getHeaderText(value[index-1].scheduleDate);
  }

  return Column(
    children: [
      // End of date time
      //Time list

      const SizedBox(height: 10),
      if(currentText!=headerText)
      Container(
        width: double.infinity,
        height: 36,
        color: Colors.blue.shade50,
        padding: const EdgeInsets.symmetric(vertical: 8, horizontal: 20),
        child: Text(
          headerText,
          style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w600),
        ),
      ),

      Padding(
        padding: const EdgeInsets.symmetric(horizontal: 20.0, vertical: 15),
        child: Row(
          children: [
            // time and Name and visit type
            Padding(
              padding: const EdgeInsets.only(right: 20.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Padding(
                        padding: const EdgeInsets.only(right: 8.0),
                        child: Icon(
                          Icons.arrow_circle_right_outlined, size: 15,
                          color: !headerText.contains("Today", 0)? Colors.grey : Colors.black87,
                        ),
                      ),
                      Text(
                        clientScheduleList?.startTime ?? 'No Client Code',
                        style: TextStyle(
                            fontSize: 14,
                          color: !headerText.contains("Today", 0)? Colors.grey : Colors.black87,
                        ),
                      ),
                    ],
                  ),
                  Row(
                    children: [
                      Padding(
                        padding: const EdgeInsets.only(right: 8.0),
                        child: Icon(
                          Icons.arrow_circle_left_outlined, size: 15,
                          color: !headerText.contains("Today", 0)? Colors.grey : Colors.black87,
                        ),
                      ),
                      Text(clientScheduleList?.endTime ?? 'No Client Code',
                        style: TextStyle(
                            fontSize: 14,
                          color: !headerText.contains("Today", 0)? Colors.grey : Colors.black87,
                        ),),
                    ],
                  ),
                  Row(
                    children: [
                      Padding(
                        padding: const EdgeInsets.only(right: 8.0),
                        child: Icon(
                          size: 15, Icons.access_time,
                          color: !headerText.contains("Today", 0)? Colors.grey : Colors.black87,
                        ),
                      ),
                      Text(
                        '${totalTime.inHours}h ${totalTime.inMinutes.remainder(60)}m',
                        style: TextStyle(
                            fontSize: 14,
                          color: !headerText.contains("Today", 0)? Colors.grey : Colors.black87,
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),

            Expanded(
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(clientScheduleList?.clientName ?? 'No Client Name', style:
                      TextStyle(
                          fontFamily:'Montserrat',fontSize: 18,fontWeight: FontWeight.bold,
                          color: !headerText.contains("Today", 0)? Colors.grey : Colors.black87
                      ),),
                      Text(clientScheduleList?.visitTypeName ?? 'No visit time',
                        style: TextStyle(fontFamily:'Montserrat',fontSize: 14, color: !headerText.contains("Today", 0)? Colors.grey : Colors.black87),),
                      if(clientScheduleList?.carerName2 != "  ")
                        Text('with ${clientScheduleList?.carerName2}', style:  TextStyle(fontFamily:'Montserrat',fontSize: 10, color: !headerText.contains("Today", 0)? Colors.grey : Colors.black87),)
                    ],
                  ),
                Icon(
                      Icons.arrow_forward_ios_sharp,
                    color: !headerText.contains("Today", 0)? Colors.grey : Colors.black87,
                  ),
                ],
              ),
            ),

          ],
        ),
      ),
      Divider(
        height: 1,
        color: Colors.grey.shade300,
        thickness: 1,
      )
    ],
  );
}
