import 'package:flutter/material.dart';

class IconFromUrl extends StatelessWidget {
  final String imageUrl;

  const IconFromUrl({super.key, required this.imageUrl});

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.only(left: 2),
      padding: const EdgeInsets.all(5),
      decoration: BoxDecoration(
        border: Border.all(
          color: Colors.grey,
          width: 1.0,
        ),
        borderRadius: BorderRadius.circular(4.0),
      ),
      child: Image.asset(
        getIconPath(imageUrl),
        width: 25,
        height: 33,
      ),
    );
  }

  String getIconPath(String taskCode) {
    switch (taskCode) {
      case "01":
        return 'assets/task/medication.png';
      case "02":
        return 'assets/task/bodymap.png';
      case "03":
        return 'assets/task/food.png';
      case "04":
        return 'assets/task/drinks.png';
      case "05":
        return 'assets/task/care.png';
      case "06":
        return 'assets/task/toilet_assistance.png';
      case "07":
        return 'assets/task/repositioning.png';
      case "08":
        return 'assets/task/campanionship.png';
      case "09":
        return 'assets/task/laundry.png';
      case "10":
        return 'assets/task/groceries.png';
      case "11":
        return 'assets/task/housework.png';
      case "12":
        return 'assets/task/household.png';
      case "99":
        return 'assets/task/unable_deliver.png';
    // Add more cases as needed
      default:
        return 'assets/icons/unable_deliver.png';
    }
  }

}