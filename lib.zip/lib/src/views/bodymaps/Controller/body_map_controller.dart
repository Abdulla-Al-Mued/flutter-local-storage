import 'package:flutter/cupertino.dart';

import '../../../controls/localDatabaseHandler/body_map_db_handler.dart';

class BodyMapController extends ChangeNotifier{

  late String headData = "";
  late String frshoulder = "";
  late String flshoulder = "";
  late String rightelbow = "";
  late String leftelbow = "";
  late String abdomenData = "";
  late String flhandData = "";
  late String frhandData = "";
  late String FRChest = "";
  late String FLChest = "";
  late String FRForearm = "";
  late String FLForearm = "";
  late String FGroin = "";
  late String FRUpperLeg = "";
  late String FLUpperLeg = "";
  late String FRKnee = "";
  late String FLKnee = "";
  late String FRLowerLeg = "";
  late String FlLowerLeg = "";
  late String FRfoot = "";
  late String FLfoot = "";
  // Back
  late String BheadData = "";
  late String BRshoulder = "";
  late String BLshoulder = "";
  late String BRelbowData = "";
  late String BLelbowData = "";
  late String BRforearm = "";
  late String BLforearm = "";
  late String BLhand = "";
  late String BRhand = "";
  late String BlowerBack = "";
  late String Bottom = "";
  late String UpperBack = "";
  late String LowerBack = "";
  late String BLfoot = "";
  late String BRfoot = "";
  late String BRknee = "";
  late String BLknee = "";
  late String BLupperLeg = "";
  late String BRupperLeg = "";
  late String BRlowerLeg = "";
  late String BLlowerLeg = "";


  final BodyMapHandler dbHandler = BodyMapHandler();

  Future<void> getStatusByMstId(String masterId) async {
    Map<String, dynamic>? data = await dbHandler.getBodyMapDataByMstId(masterId);
    if (data!=null) {

      if(data['FRONT_HEAD_NECK']!=null) {
        headData = data['FRONT_HEAD_NECK'];
      }
      else{
        headData = "";
      }
      if(data['FRONT_RIGHT_SHOULDER']!=null) {
        frshoulder = data['FRONT_RIGHT_SHOULDER'];
      }
      else{
        frshoulder = "";
      }
      if(data['FRONT_LEFT_SHOULDER']!=null) {
        flshoulder = data['FRONT_LEFT_SHOULDER'];
      }
      else{
        flshoulder = "";
      }
      if(data['FRONT_RIGHT_UPPER_ARM_ELBOW']!=null) {
        rightelbow = data['FRONT_RIGHT_UPPER_ARM_ELBOW'];
      }
      else{
        rightelbow = "";
      }
      if(data['FRONT_ABDOMEN']!=null) {
        abdomenData = data['FRONT_ABDOMEN'];
      }
      else{
        abdomenData = "";
      }
      if(data['FRONT_LEFT_HAND_WRIST']!=null) {
        flhandData = data['FRONT_LEFT_HAND_WRIST'];
      }
      else{
        flhandData = "";
      }
      if(data['FRONT_RIGHT_HAND_WRIST']!=null) {
        frhandData = data['FRONT_RIGHT_HAND_WRIST'];
      }
      else{
        frhandData = "";
      }

      if(data['FRONT_LEFT_UPPER_ARM_ELBOW']!=null) {
        leftelbow = data['FRONT_LEFT_UPPER_ARM_ELBOW'];
      }
      else{
        leftelbow = "";
      }
      if(data['FRONT_RIGHT_CHEST']!=null) {
        FRChest = data['FRONT_RIGHT_CHEST'];
      }
      else{
        FRChest = "";
      }
      if(data['FRONT_LEFT_CHEST']!=null) {
        FLChest = data['FRONT_LEFT_CHEST'];
      }
      else{
        FLChest = "";
      }
      if(data['FRONT_LEFT_FOREARM']!=null) {
        FLForearm = data['FRONT_LEFT_FOREARM'];
      }
      else{
        FLForearm = "";
      }
      if(data['FRONT_RIGHT_FOREARM']!=null) {
        FRForearm = data['FRONT_RIGHT_FOREARM'];
      }
      else{
        FRForearm = "";
      }
      if(data['FRONT_GROIN']!=null) {
        FGroin = data['FRONT_GROIN'];
      }
      else{
        FGroin = "";
      }
      if(data['FRONT_RIGHT_UPPER_LEG']!=null) {
        FRUpperLeg = data['FRONT_RIGHT_UPPER_LEG'];
      }
      else{
        FRUpperLeg = "";
      }
      if(data['FRONT_LEFT_UPPER_LEG']!=null) {
        FLUpperLeg = data['FRONT_LEFT_UPPER_LEG'];
      }
      else{
        FLUpperLeg = "";
      }
      if(data['FRONT_RIGHT_KNEE']!=null) {
        FRKnee = data['FRONT_RIGHT_KNEE'];
      }
      else{
        FRKnee = "";
      }
      if(data['FRONT_LEFT_KNEE']!=null) {
        FLKnee = data['FRONT_LEFT_KNEE'];
      }
      else{
        FLKnee = "";
      }
      if(data['FRONT_RIGHT_LOWER_LEG']!=null) {
        FRLowerLeg = data['FRONT_RIGHT_LOWER_LEG'];
      }
      else{
        FRLowerLeg = "";
      }
      if(data['FRONT_LEFT_LOWER_LEG']!=null) {
        FlLowerLeg = data['FRONT_LEFT_LOWER_LEG'];
      }
      else{
        FlLowerLeg = "";
      }
      if(data['FRONT_RIGHT_FOOT_ANKLE']!=null) {
        FRfoot = data['FRONT_RIGHT_FOOT_ANKLE'];
      }
      else{
        FRfoot = "";
      }
      if(data['FRONT_LEFT_FOOT_ANKLE']!=null) {
        FLfoot = data['FRONT_LEFT_FOOT_ANKLE'];
      }
      else{
        FLfoot = "";
      }
      // Beck------------------------------->
      if(data['BACK_HEAD_NECK']!=null) {
        BheadData = data['BACK_HEAD_NECK'];
      }
      else{
        BheadData = "";
      }
      if(data['BACK_RIGHT_SHOULDER']!=null) {
        BRshoulder = data['BACK_RIGHT_SHOULDER'];
      }
      else{
        BRshoulder = "";
      }
      if(data['BACK_LEFT_SHOULDER']!=null) {
        BLshoulder = data['BACK_LEFT_SHOULDER'];
      }
      else{
        BLshoulder = "";
      }
      if(data['BACK_RIGHT_UPPER_ARM_ELBOW']!=null) {//
        BRelbowData = data['BACK_RIGHT_UPPER_ARM_ELBOW'];
      }
      else{
        BRelbowData = "";
      }
      if(data['BACK_LEFT_UPPER_ARM_ELBOW']!=null) {
        BLelbowData = data['BACK_LEFT_UPPER_ARM_ELBOW'];
      }
      else{
        BLelbowData = "";
      }
      if(data['BACK_RIGHT_HAND_WRIST']!=null) {
        BRhand = data['BACK_RIGHT_HAND_WRIST'];
      }
      else{
        BRhand = "";
      }
      if(data['BACK_LEFT_HAND_WRIST']!=null) {
        BLhand = data['BACK_LEFT_HAND_WRIST'];
      }
      else{
        BLhand = "";
      }

      if(data['BACK_LOWER_BACK']!=null) {
        BlowerBack = data['BACK_LOWER_BACK'];
      }
      else{
        BlowerBack = "";
      }

      if(data['BACK_BOTTOM_SACRUM']!=null) {
        Bottom = data['BACK_BOTTOM_SACRUM'];
      }
      else{
        Bottom = "";
      }
      if(data['BACK_UPPER_BACK']!=null) {
        UpperBack = data['BACK_UPPER_BACK'];
      }
      else{
        UpperBack = "";
      }
      if(data['BACK_LOWER_BACK']!=null) {
        LowerBack = data['BACK_LOWER_BACK'];
      }
      else{
        LowerBack = "";
      }

      if(data['BACK_LEFT_FOOT_ANKLE']!=null) {
        BLfoot = data['BACK_LEFT_FOOT_ANKLE'];
      }
      else{
        BLfoot = "";
      }
      if(data['BACK_RIGHT_FOOT_ANKLE']!=null) {
        BRfoot = data['BACK_RIGHT_FOOT_ANKLE'];
      }
      else{
        BRfoot = "";
      }
      if(data['BACK_RIGHT_KNEE']!=null) {
        BRknee = data['BACK_RIGHT_KNEE'];
      }
      else{
        BRknee = "";
      }
      if(data['BACK_LEFT_KNEE']!=null) {
        BLknee = data['BACK_LEFT_KNEE'];
      }
      else{
        BLknee = "";
      }
      if(data['BACK_RIGHT_UPPER_LEG']!=null) {
        BRupperLeg = data['BACK_RIGHT_UPPER_LEG'];
      }
      else{
        BRupperLeg = "";
      }
      if(data['BACK_LEFT_UPPER_LEG']!=null) {
        BLupperLeg = data['BACK_LEFT_UPPER_LEG'];
      }
      else{
        BLupperLeg = "";
      }
      if(data['BACK_RIGHT_LOWER_LEG']!=null) {
        BRlowerLeg = data['BACK_RIGHT_LOWER_LEG'];
      }
      else{
        BRlowerLeg = "";
      }
      if(data['BACK_LEFT_LOWER_LEG']!=null) {
        BLlowerLeg = data['BACK_LEFT_LOWER_LEG'];
      }
      else{
        BLlowerLeg = "";
      }
      if(data['BACK_RIGHT_FOREARM']!=null) {
        BRforearm = data['BACK_RIGHT_FOREARM'];
      }
      else{
        BRforearm = "";
      }
      if(data['BACK_LEFT_FOREARM']!=null) {
        BLforearm = data['BACK_LEFT_FOREARM'];
      }
      else{
        BLforearm = "";
      }
    }
    else{

      print("deleted Empty");
    }

    notifyListeners();

  }

}