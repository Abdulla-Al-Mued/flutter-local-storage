import 'package:flutter/material.dart';

class FormData extends StatefulWidget {
  const FormData({super.key});

  @override
  State<FormData> createState() => _FormDataState();
}

class _FormDataState extends State<FormData> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        automaticallyImplyLeading: false,
        title: const Text("Front head and neck", style: TextStyle(fontWeight: FontWeight.w700),),
        actions: [
          IconButton(
            icon: const Icon(Icons.close, weight: 15, size: 30),
            onPressed: () {
              Navigator.of(context).pop();
            },
          ),
        ],
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            const SizedBox(height: 20.0),
            Expanded(
              child: SingleChildScrollView(
                child: Form(
                  child: TextFormField(
                    decoration: const InputDecoration(
                      hintText: "Enter your information...",
                      labelText: "Information",
                      border: OutlineInputBorder(),
                    ),
                  ),
                ),
              ),
            ),
            const SizedBox(height: 20.0),
            ElevatedButton(
              onPressed: () {
                // Implement save functionality here
              },
              child: const Text("Save"),
            ),
          ],
        ),
      ),
    );
  }
}
