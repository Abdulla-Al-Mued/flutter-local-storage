import 'package:care4u/src/controls/utils/Tools.dart';
import 'package:care4u/src/controls/utils/color_codes.dart';
import 'package:care4u/src/views/bodymaps/Controller/body_map_controller.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../../controls/localDatabaseHandler/body_map_db_handler.dart';
import '../../../models/LocalModel/LocalDpd_Cms_Carer_Cln_Dtws_Sch_Lst_Model.dart';

class BLforearm extends StatefulWidget {
  final String taskName;
  final int? masterId;
  const BLforearm({super.key, required this.taskName, required this.masterId, required this.userData});
  final Value? userData;


  @override
  State<BLforearm> createState() => _BLforearmState();
}

class _BLforearmState extends State<BLforearm> {

  final TextEditingController _textEditingController = TextEditingController();
  FocusNode BLforearm = FocusNode();
  final BodyMapHandler dbHandler = BodyMapHandler();

  @override
  void dispose() {
    // TODO: implement dispose
    super.dispose();
    _textEditingController.dispose();
    BLforearm.dispose();
  }

  void hideKeyboard(){
    if(BLforearm.hasFocus){
      BLforearm.unfocus();
    }
  }

  @override
  Widget build(BuildContext context) {

    final bodyMap = Provider.of<BodyMapController>(context,  listen: false);
    bodyMap.getStatusByMstId(widget.masterId.toString());

    return Scaffold(
      appBar: AppBar(
        backgroundColor: Theme.of(context).colorScheme.primary,
        centerTitle: true,
        title: Text(
          widget.taskName.toString(),
          style: const TextStyle(
              color: Colors.white,
              fontFamily: 'PoppinsBold',
              fontWeight: FontWeight.w800,
              fontSize: 18
          ),
        ),
        iconTheme: const IconThemeData(color: Colors.white),
      ),
      resizeToAvoidBottomInset: false,
      body: SingleChildScrollView(
        child: Container(
          margin: const EdgeInsets.only(left: 20, right: 20, top: 40),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                margin: const EdgeInsets.only(top: 10),
                child: Theme(
                  data: ThemeData(
                    primaryColor: lightPrimaryColor,
                    primaryColorDark: lightPrimaryColor,
                  ),
                  child: TextField(
                    controller: _textEditingController,
                    maxLines: 10,
                    focusNode: BLforearm,
                    keyboardType: TextInputType.multiline,
                    decoration: const InputDecoration(
                      hintText: 'Please leave some notes about how you\'ve helped with  this task',
                      contentPadding: EdgeInsets.symmetric(vertical: 10, horizontal: 10),
                      border: OutlineInputBorder(
                        borderSide: BorderSide(
                          color: lightPrimaryColor,
                          width: 1.0,
                        ),
                      ),
                    ),),
                ),
              ),

              FutureBuilder<String?>(
                future: isExist(),
                builder: (context, snapshot) {
                  if (snapshot.connectionState == ConnectionState.waiting) {
                    // Show a loading indicator if the future is still processing
                    return const CircularProgressIndicator();
                  } else {
                    // Show the appropriate widget based on the result of the future
                    if (snapshot.hasError) {
                      return Text('Error: ${snapshot.error}');
                    } else {
                      String? data = snapshot.data;

                      if (data != null && data.isNotEmpty) {
                        bool exists = data.isNotEmpty;

                        if (exists) {
                          WidgetsBinding.instance.addPostFrameCallback((_) {
                            _textEditingController.value = TextEditingValue(
                              text: data, // Set text from data
                              selection: TextSelection.collapsed(
                                offset: data.length,
                              ), // Move cursor to the end
                            );
                          });

                          return Container(
                            margin: const EdgeInsets.only(top: 20),
                            child: Row(
                              children: [
                                Expanded(
                                  child: Container(
                                    margin: const EdgeInsets.only(right: 10),
                                    child: ElevatedButton(
                                      onPressed: () {
                                        deleteBLforearmByMstId(bodyMap);
                                      },
                                      style: ButtonStyle(
                                        // Change background color
                                        backgroundColor:
                                        MaterialStateProperty.all<Color>(Colors.red),
                                        // Change text color
                                        foregroundColor:
                                        MaterialStateProperty.all<Color>(Colors.white),
                                        minimumSize: MaterialStateProperty.all<Size>(
                                            const Size(double.infinity, 50)),
                                      ),
                                      child: const Text('Remove '),
                                    ),
                                  ),
                                ),
                                Expanded(
                                  child: Container(
                                    margin: const EdgeInsets.only(left: 10),
                                    child: ElevatedButton(
                                      onPressed: () {
                                        saveToDatabase(bodyMap);
                                      },
                                      style: ButtonStyle(
                                        // Change background color
                                        backgroundColor:
                                        MaterialStateProperty.all<Color>(Colors.indigo),
                                        // Change text color
                                        foregroundColor:
                                        MaterialStateProperty.all<Color>(Colors.white),
                                        minimumSize: MaterialStateProperty.all<Size>(
                                            const Size(double.infinity, 50)),
                                      ),
                                      child: const Text('Save'),
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          );
                        } else {
                          return Container(
                            margin: const EdgeInsets.only(top: 20),
                            child: ElevatedButton(
                              onPressed: () {
                                hideKeyboard();

                                if (_textEditingController.text.isNotEmpty) {
                                  saveToDatabase(bodyMap);
                                } else {}
                              },
                              style: ButtonStyle(
                                // Change background color
                                backgroundColor:
                                MaterialStateProperty.all<Color>(Colors.indigo),
                                // Change text color
                                foregroundColor:
                                MaterialStateProperty.all<Color>(Colors.white),
                                minimumSize: MaterialStateProperty.all<Size>(
                                    const Size(double.infinity, 50)),
                              ),
                              child: const Text(
                                'Save',
                                style: TextStyle(fontSize: 16),
                              ),
                            ),
                          );
                        }
                      } else {
                        // Handle the case when data is empty
                        return Container(
                          margin: const EdgeInsets.only(top: 20),
                          child: ElevatedButton(
                            onPressed: () {
                              hideKeyboard();

                              if (_textEditingController.text.isNotEmpty) {
                                saveToDatabase(bodyMap);
                              } else {}
                            },
                            style: ButtonStyle(
                              // Change background color
                              backgroundColor: MaterialStateProperty.all<Color>(Colors.indigo),
                              // Change text color
                              foregroundColor: MaterialStateProperty.all<Color>(Colors.white),
                              minimumSize: MaterialStateProperty.all<Size>(const Size(double.infinity, 50)),
                            ),
                            child: const Text(
                              'Save',
                              style: TextStyle(fontSize: 16),
                            ),
                          ),
                        );
                      }
                    }
                  }
                },
              )
            ],
          ),
        ),
      ),
    );
  }

  void saveToDatabase(BodyMapController clientData) {

    dbHandler.updateBLforearm(_textEditingController.text, widget.masterId.toString());
    showToastInfo('Data inserted successfully!');

    clientData.getStatusByMstId(widget.masterId.toString());

    Navigator.pop(context);

  }



  void deleteBLforearmByMstId(BodyMapController clientData) {
    dbHandler.deleteBLforearmByMstId(widget.masterId.toString());
    showToastInfo('Deleted successfully!');

    clientData.getStatusByMstId(widget.masterId.toString());

    Navigator.pop(context);
  }
  Future<String?> isExist() async {
    Map<String, dynamic>? data = await dbHandler.getBodyMapDataByMstId(widget.masterId.toString());
    if (data?['BACK_LEFT_FOREARM'] != null) {
      return data?['BACK_LEFT_FOREARM'];
    } else {
      return '';
    }
  }
}
