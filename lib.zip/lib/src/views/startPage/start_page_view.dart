import 'package:care4u/src/controls/localStorage/local_storage.dart';
import 'package:care4u/src/views/passcodeSetupPage/passcode_enter_screen.dart';
import 'package:care4u/src/views/passcodeSetupPage/passcode_welcome_screen.dart';
import 'package:care4u/src/views/signinPage/signin_page_view.dart';
import 'package:flutter/material.dart';

class StartPageView extends StatefulWidget {
  const StartPageView({super.key});

  @override
  State<StartPageView> createState() => _StartPageViewState();
}

class _StartPageViewState extends State<StartPageView> {
  final LocalStorage _localStorage = LocalStorage();

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    print("Passcode: ${_localStorage.getPasscode}");
    if(_localStorage.userLoginDetail.value==null){
      return const SignInPage();
    }else{
      if (_localStorage.userLoginDetail.value!.isNotEmpty  && _localStorage.userLoginDetail.value![0].status == '1' && _localStorage.userLoginDetail.value![0].userTypeCode == '03') {
        if (_localStorage.getPasscode.isNotEmpty) {
          return const EnterPasscodeScreen();
        } else {
          return const WelcomeSetPasscodeScreen();
        }
      } else {
        return const SignInPage();
      }
    }

  }
}
