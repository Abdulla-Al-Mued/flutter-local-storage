import 'package:care4u/src/models/report_model/report_summary.dart';
import 'package:flutter/material.dart';

import '../../controls/utils/appbar.dart';
import '../../controls/utils/color_codes.dart';

class ReportDetails extends StatefulWidget {
  String taskName;
  Task description;
  ReportDetails({super.key, required this.taskName, required this.description});

  @override
  State<ReportDetails> createState() => _ReportDetailsState();
}

class _ReportDetailsState extends State<ReportDetails> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: const CustomAppBar(
          backgroundColor: Colors.white,
          title: 'Task Details'),
      body: Column(
        children: [
          Container(
            margin: EdgeInsets.only(left: 10, right: 10, bottom: 20),
            child: Card(
              elevation: 5,
              color: Colors.white,
              child: Container(
                margin: const EdgeInsets.all(10),
                child: Column(
                  //crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    IntrinsicWidth(
                      child: Container(
                        margin: EdgeInsets.only(top: 5, bottom: 15),
                        child: Column(
                          children: [
                            Container(
                              margin: EdgeInsets.only(left: 10, right: 10),
                              child: Text(
                                widget.description.taskDesc!,
                                textAlign: TextAlign.center,
                                style: TextStyle(
                                    color: primaryColor,
                                    fontSize: 18,
                                    fontWeight: FontWeight.w700
                                ),
                              ),
                            ),
                            Container(
                              color: primaryColor,
                              height: 1.7,
                              //width: 120,
                            )
                          ],
                        ),
                      ),
                    ),
                    SingleChildScrollView(
                      child: Container(
                        width: double.infinity,
                        height: 150,
                        //decoration: BoxDecoration( borderRadius: BorderRadius.circular(0)),
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.start,
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Flexible(
                              child: SingleChildScrollView(
                                child: Container(
                                  child: Text(
                                    widget.taskName,
                                    style: const TextStyle(fontSize: 16, color: Colors.black87, decoration: TextDecoration.none, fontFamily: 'system', fontWeight: FontWeight.normal),
                                  ),
                                ),
                              ),
                            ),
                            const SizedBox(height: 24),
                          ],
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
