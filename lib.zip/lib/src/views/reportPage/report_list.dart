import 'dart:async';

import 'package:care4u/src/views/reportPage/widgets/fun_report_list.dart';
import 'package:flutter/material.dart';
import 'package:swipe_refresh/swipe_refresh.dart';
import 'package:care4u/src/controls/utils/appbar.dart';

import '../../controls/apiHandler/api_handler.dart';
import '../../controls/localDatabaseHandler/local_db_handler_visit.dart';
import '../../controls/utils/oneTimeNetCheck.dart';

class ReportList extends StatefulWidget {
  const ReportList({super.key});

  @override
  State<ReportList> createState() => _ReportListState();
}

class _ReportListState extends State<ReportList> {

  final _controller = StreamController<SwipeRefreshState>.broadcast();
  final ScrollController _scrollController = ScrollController();
  final VisitHandler visitHandler = VisitHandler();


  Stream<SwipeRefreshState> get _stream => _controller.stream;

  Future<void> refresh() async {

    if(await uploadData()??false){
      await ApiHandler().downloadData();
      setState(() {

      });
      _controller.sink.add(SwipeRefreshState.hidden);
    }else{
      await ApiHandler().downloadData();
      setState(() {

      });
      _controller.sink.add(SwipeRefreshState.hidden);
    }
  }

  Future<bool?> uploadData() async {

    List<Map<String, dynamic>> result = await visitHandler.getUnUploadedData();

    if (await getConnection()) {
      bool temp = false;

      await Future.forEach(result ?? [], (element) async {

        temp = await visitHandler.getAllVisitData(element['CARER_VISIT_MST_ID'].toString());

      });

      if (temp) {
        return true;
      } else {
        return false;

      }

    }

    return false;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: const CustomAppBar(
          backgroundColor: Colors.white,
          title: 'Report List'),
      body: SwipeRefresh.material(
          scrollController: _scrollController,
          stateStream: _stream,
          onRefresh: refresh,
          children: [
            SingleChildScrollView(
              child: Container(
                color: Colors.white,
                child: report_list(),
              ),
            ),
          ]
      ),
    );
  }
}
