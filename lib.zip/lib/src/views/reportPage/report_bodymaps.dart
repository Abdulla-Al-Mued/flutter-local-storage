import 'dart:ui' as ui;

import 'package:flutter/services.dart';
import 'package:flutter/material.dart';
import '../../controls/localDatabaseHandler/body_map_db_handler.dart';


class ReportBodyMaps extends StatefulWidget {

  List<Map<String, dynamic>> bodyMapData;
  ReportBodyMaps({super.key, required this.bodyMapData});

  @override
  State<ReportBodyMaps> createState() => _BodyMapsState();
}

class _BodyMapsState extends State<ReportBodyMaps> {

  final BodyMapHandler dbHandler = BodyMapHandler();
  List<String> frontBodyData = [];
  List<String> backBodyData = [];

  @override
  void initState() {
    super.initState();

    print(widget.bodyMapData.toString());

    // Set the initial colors based on region coordinates
    if (widget.bodyMapData.first['FRONT_HEAD_NECK'] != null) {

      frontBodyData.add(
          "FRONT HEAD NECK : ${widget.bodyMapData.first['FRONT_HEAD_NECK']}");
      setRegionColorFront(1, 70, 20, 130, 145, Colors.green);
    } else {
      setRegionColorFront(1, 70, 20, 130, 145, Colors.red);
    }

    if (widget.bodyMapData.first['FRONT_RIGHT_SHOULDER'] != null) {
      print("FRONT_RIGHT_SHOULDER");
      frontBodyData.add(
          "FRONT RIGHT SHOULDER : ${widget.bodyMapData.first['FRONT_RIGHT_SHOULDER']}");
      setRegionColorFront(2, 35, 146, 100, 181, Colors.green);
    } else {
      setRegionColorFront(2, 35, 146, 100, 181, Colors.red);
    }

    if (widget.bodyMapData.first['FRONT_LEFT_SHOULDER'] != null) {
      print("FRONT_LEFT_SHOULDER");
      frontBodyData.add(
          "FRONT LEFT SHOULDER : ${widget.bodyMapData.first['FRONT_LEFT_SHOULDER']}");
      setRegionColorFront(3, 101, 146, 165, 181, Colors.green);
    } else {
      setRegionColorFront(3, 101, 146, 165, 181, Colors.red);
    }

    if (widget.bodyMapData.first['FRONT_RIGHT_UPPER_ARM_ELBOW'] != null) {
      print("FRONT_RIGHT_UPPER_ARM_ELBOW");
      frontBodyData.add(
          "FRONT RIGHT UPPER ARM ELBOW : ${widget.bodyMapData.first['FRONT_RIGHT_UPPER_ARM_ELBOW']}");
      setRegionColorFront(4, 30, 182, 60, 235, Colors.green);
    } else {
      setRegionColorFront(4, 30, 182, 60, 235, Colors.red);
    }

    if (widget.bodyMapData.first['FRONT_RIGHT_FOREARM'] != null) {
      print("FRONT_RIGHT_FOREARM");
      frontBodyData.add(
          "FRONT RIGHT FOREARM : ${widget.bodyMapData.first['FRONT_RIGHT_FOREARM']}");
      setRegionColorFront(5, 25, 236, 55, 290, Colors.green);
    } else {
      setRegionColorFront(5, 25, 236, 55, 290, Colors.red);
    }

    if (widget.bodyMapData.first['FRONT_RIGHT_HAND_WRIST'] != null) {
      print("FRONT_RIGHT_HAND_WRIST");
      frontBodyData.add(
          "FRONT RIGHT HAND WRIST : ${widget.bodyMapData.first['FRONT_RIGHT_HAND_WRIST']}");
      setRegionColorFront(6, 8, 291, 45, 340, Colors.green);
    } else {
      setRegionColorFront(6, 8, 291, 45, 340, Colors.red);
    }

    if (widget.bodyMapData.first['FRONT_RIGHT_CHEST'] != null) {
      print("FRONT_RIGHT_CHEST");
      frontBodyData.add(
          "FRONT RIGHT CHEST : ${widget.bodyMapData.first['FRONT_RIGHT_CHEST']}");
      setRegionColorFront(7, 61, 182, 100, 225, Colors.green);
    } else {
      setRegionColorFront(7, 61, 182, 100, 225, Colors.red);
    }

    if (widget.bodyMapData.first['FRONT_LEFT_CHEST'] != null) {
      print("FRONT_LEFT_CHEST");
      frontBodyData.add(
          "FRONT LEFT CHEST : ${widget.bodyMapData.first['FRONT_LEFT_CHEST']}");
      setRegionColorFront(8, 101, 182, 135, 225, Colors.green);
    } else {
      setRegionColorFront(8, 101, 182, 135, 225, Colors.red);
    }

    if (widget.bodyMapData.first['FRONT_LEFT_UPPER_ARM_ELBOW'] != null) {
      print("FRONT_LEFT_UPPER_ARM_ELBOW");
      frontBodyData.add(
          "FRONT LEFT UPPER ARM ELBOW : ${widget.bodyMapData.first['FRONT_LEFT_UPPER_ARM_ELBOW']}");
      setRegionColorFront(9, 136, 182, 170, 235, Colors.green);
    } else {
      setRegionColorFront(9, 136, 182, 170, 235, Colors.red);
    }

    if (widget.bodyMapData.first['FRONT_ABDOMEN'] != null) {
      print("FRONT_ABDOMEN");
      frontBodyData.add(
          "FRONT ABDOMEN : ${widget.bodyMapData.first['FRONT_ABDOMEN']}");
      setRegionColorFront(10, 61, 227, 135, 290, Colors.green);
    } else {
      setRegionColorFront(10, 61, 227, 135, 290, Colors.red);
    }

    if (widget.bodyMapData.first['FRONT_LEFT_FOREARM'] != null) {
      print("FRONT_LEFT_FOREARM");
      frontBodyData.add(
          "FRONT LEFT FOREARM : ${widget.bodyMapData.first['FRONT_LEFT_FOREARM']}");
      setRegionColorFront(11, 146, 236, 175, 290, Colors.green);
    } else {
      setRegionColorFront(11, 146, 236, 175, 290, Colors.red);
    }

    if (widget.bodyMapData.first['FRONT_LEFT_HAND_WRIST'] != null) {
      print("FRONT_LEFT_HAND_WRIST");
      frontBodyData.add(
          "FRONT LEFT HAND WRIST : ${widget.bodyMapData.first['FRONT_LEFT_HAND_WRIST']}");
      setRegionColorFront(12, 156, 291, 195, 340, Colors.green);
    } else {
      setRegionColorFront(12, 156, 291, 195, 340, Colors.red);
    }

    if (widget.bodyMapData.first['FRONT_GROIN'] != null) {
      print("FRONT_GROIN");
      frontBodyData.add(
          "FRONT GROIN : ${widget.bodyMapData.first['FRONT_GROIN']}");
      setRegionColorFront(13, 61, 291, 135, 330, Colors.green);
    } else {
      setRegionColorFront(13, 61, 291, 135, 330, Colors.red);
    }

    if (widget.bodyMapData.first['FRONT_RIGHT_UPPER_LEG'] != null) {
      print("FRONT_RIGHT_UPPER_LEG");
      frontBodyData.add(
          "FRONT RIGHT UPPER LEG : ${widget.bodyMapData.first['FRONT_RIGHT_UPPER_LEG']}");
      setRegionColorFront(14, 61, 331, 99, 380, Colors.green);
    } else {
      setRegionColorFront(14, 61, 331, 99, 380, Colors.red);
    }

    if (widget.bodyMapData.first['FRONT_LEFT_UPPER_LEG'] != null) {
      print("FRONT_LEFT_UPPER_LEG");
      frontBodyData.add(
          "FRONT LEFT UPPER_LEG : ${widget.bodyMapData.first['FRONT_LEFT_UPPER_LEG']}");
      setRegionColorFront(15, 100, 331, 135, 380, Colors.green);
    } else {
      setRegionColorFront(15, 100, 331, 135, 380, Colors.red);
    }

    if (widget.bodyMapData.first['FRONT_RIGHT_KNEE'] != null) {
      print("FRONT_RIGHT_KNEE");
      frontBodyData
          .add("FRONT RIGHT KNEE : ${widget.bodyMapData.first['FRONT_RIGHT_KNEE']}");
      setRegionColorFront(16, 61, 381, 99, 410, Colors.green);
    } else {
      setRegionColorFront(16, 61, 381, 99, 410, Colors.red);
    }

    if (widget.bodyMapData.first['FRONT_LEFT_KNEE'] != null) {
      print("FRONT_LEFT_KNEE");
      frontBodyData
          .add("FRONT LEFT KNEE : ${widget.bodyMapData.first['FRONT_LEFT_KNEE']}");
      setRegionColorFront(17, 100, 381, 135, 410, Colors.green);
    } else {
      setRegionColorFront(17, 100, 381, 135, 410, Colors.red);
    }

    if (widget.bodyMapData.first['FRONT_RIGHT_LOWER_LEG'] != null) {
      print("FRONT_RIGHT_LOWER_LEG");
      frontBodyData.add(
          "FRONT RIGHT LOWER LEG : ${widget.bodyMapData.first['FRONT_RIGHT_LOWER_LEG']}");
      setRegionColorFront(18, 61, 411, 99, 520, Colors.green);
    } else {
      setRegionColorFront(18, 61, 411, 99, 470, Colors.red);
    }

    if (widget.bodyMapData.first['FRONT_LEFT_LOWER_LEG'] != null) {
      print("FRONT_LEFT_LOWER_LEG");
      frontBodyData.add(
          "FRON LEFT LOWER LEG : ${widget.bodyMapData.first['FRONT_LEFT_LOWER_LEG']}");
      setRegionColorFront(19, 100, 411, 135, 470, Colors.green);
    } else {
      setRegionColorFront(19, 100, 411, 135, 470, Colors.red);
    }

    if (widget.bodyMapData.first['FRONT_RIGHT_FOOT_ANKLE'] != null) {
      print("FRONT_RIGHT_FOOT_ANKLE");
      frontBodyData.add(
          "FRONT RIGHT FOOT ANKLE : ${widget.bodyMapData.first['FRONT_RIGHT_FOOT_ANKLE']}");
      setRegionColorFront(20, 61, 471, 99, 520, Colors.green);
    } else {
      setRegionColorFront(20, 61, 471, 99, 520, Colors.red);
    }

    if (widget.bodyMapData.first['FRONT_LEFT_FOOT_ANKLE'] != null) {
      print("FRONT_LEFT_FOOT_ANKLE");
      frontBodyData.add(
          "FRONT LEFT FOOT ANKLE : ${widget.bodyMapData.first['FRONT_LEFT_FOOT_ANKLE']}");
      setRegionColorFront(21, 100, 471, 135, 520, Colors.green);
    } else {
      setRegionColorFront(21, 100, 471, 135, 520, Colors.red);
    }

    // setRegionColorBack(1, 70, 75, 130, 145, widget.bodyMapData.first['BACK_HEAD_NECK']!=null ? Colors.green : Colors.red);
// BACK PART START
    if (widget.bodyMapData.first['BACK_HEAD_NECK'] != null) {
      backBodyData.add(
          "BACK HEAD NECK : ${widget.bodyMapData.first['BACK_HEAD_NECK']}");
      setRegionColorBack(1, 70, 75, 130, 145, Colors.green);
    } else {
      setRegionColorBack(1, 70, 75, 130, 145, Colors.red);
    }

    // Right Shoulder
    // setRegionColorBack(2, 35, 146, 100, 181, widget.bodyMapData.first['BACK_LEFT_SHOULDER']!=null ? Colors.green : Colors.red);
    if (widget.bodyMapData.first['BACK_LEFT_SHOULDER'] != null) {
      backBodyData.add(
          "BACK LEFT SHOULDER : ${widget.bodyMapData.first['BACK_LEFT_SHOULDER']}");
      setRegionColorBack(2, 35, 146, 100, 181, Colors.green);
    } else {
      setRegionColorBack(2, 35, 146, 100, 181, Colors.red);
    }

    // left Shoulder
    // setRegionColorBack(3, 101, 146, 165, 181, widget.bodyMapData.first['BACK_RIGHT_SHOULDER']!=null ? Colors.green : Colors.red);
    if (widget.bodyMapData.first['BACK_RIGHT_SHOULDER'] != null) {
      backBodyData.add(
          "BACK RIGHT SHOULDER : ${widget.bodyMapData.first['BACK_RIGHT_SHOULDER']}");
      setRegionColorBack(3, 101, 146, 165, 181, Colors.green);
    } else {
      setRegionColorBack(3, 101, 146, 165, 181, Colors.red);
    }


    // right Arm
    // setRegionColorBack(4, 30, 182, 60, 235, widget.bodyMapData.first['BACK_RIGHT_UPPER_ARM_ELBOW']!=null ? Colors.green : Colors.red);
    if (widget.bodyMapData.first['BACK_RIGHT_UPPER_ARM_ELBOW'] != null) {
      backBodyData.add(
          "BACK RIGHT UPPER ARM ELBOW : ${widget.bodyMapData.first['BACK_RIGHT_UPPER_ARM_ELBOW']}");
      setRegionColorBack(4, 30, 182, 60, 235, Colors.green);
    } else {
      setRegionColorBack(4, 30, 182, 60, 235, Colors.red);
    }
    // Left foreArm
    // setRegionColorBack(5, 25, 236, 55, 290, widget.bodyMapData.first['BACK_LEFT_FOREARM']!=null ? Colors.green : Colors.red);
    if (widget.bodyMapData.first['BACK_LEFT_FOREARM'] != null) {
      backBodyData.add(
          "BACK LEFT FOREARM : ${widget.bodyMapData.first['BACK_LEFT_FOREARM']}");
      setRegionColorBack(5, 25, 236, 55, 290, Colors.green);
    } else {
      setRegionColorBack(5, 25, 236, 55, 290, Colors.red);
    }
    // Left hand
    // setRegionColorBack(6, 8, 291, 45, 340, widget.bodyMapData.first['BACK_LEFT_HAND_WRIST']!=null ? Colors.green : Colors.red);
    if (widget.bodyMapData.first['BACK_LEFT_HAND_WRIST'] != null) {
      backBodyData.add(
          "BACK LEFT HAND WRIST : ${widget.bodyMapData.first['BACK_LEFT_HAND_WRIST']}");
      setRegionColorBack(6, 8, 291, 45, 340, Colors.green);
    } else {
      setRegionColorBack(6, 8, 291, 45, 340, Colors.red);
    }

    if (widget.bodyMapData.first['BACK_LEFT_UPPER_ARM_ELBOW'] != null) {
      backBodyData.add(
          "BACK LEFT UPPER ARM ELBOW : ${widget.bodyMapData.first['BACK_LEFT_UPPER_ARM_ELBOW']}");
      setRegionColorBack(9, 136, 182, 170, 235, Colors.green);
    } else {
      setRegionColorBack(9, 136, 182, 170, 235, Colors.red);
    }

    if(widget.bodyMapData.first['BACK_RIGHT_FOREARM'] != null){
      backBodyData.add(
          "BACK RIGHT FOREARM : ${widget.bodyMapData.first['BACK_RIGHT_FOREARM']}");
      setRegionColorBack(11, 146, 236, 175, 290, Colors.green);
    } else {
      setRegionColorBack(11, 146, 236, 175, 290, Colors.red);
    }// Right arm

    if(widget.bodyMapData.first['BACK_LEFT_HAND_WRIST'] != null){
      backBodyData.add(
          "BACK LEFT HAND WRIST : ${widget.bodyMapData.first['BACK_LEFT_HAND_WRIST']}");
      setRegionColorBack(6, 8, 291, 45, 340, Colors.green);
    } else {
      setRegionColorBack(6, 8, 291, 45, 340, Colors.red);
    }// Lower Back

    if(widget.bodyMapData.first['BACK_RIGHT_HAND_WRIST'] != null){
      backBodyData.add(
          "BACK RIGHT HAND WRIST : ${widget.bodyMapData.first['BACK_RIGHT_HAND_WRIST']}");
      setRegionColorBack(12, 156, 291, 195, 340, Colors.green);
    } else {
      setRegionColorBack(12, 156, 291, 195, 340, Colors.red);
    }// Lower Back

    if(widget.bodyMapData.first['BACK_UPPER_BACK'] != null){
      backBodyData.add(
          "BACK UPPER BACK : ${widget.bodyMapData.first['BACK_UPPER_BACK']}");
      setRegionColorBack(7, 61, 182, 135, 225, Colors.green);
    } else {
      setRegionColorBack(7, 61, 182, 135, 225, Colors.red);
    }// Right foreArm

    if(widget.bodyMapData.first['BACK_LOWER_BACK'] != null){
      backBodyData.add(
          "BACK LOWER BACK : ${widget.bodyMapData.first['BACK_LOWER_BACK']}");
      setRegionColorBack(10, 61, 227, 135, 290, Colors.green);
    } else {
      setRegionColorBack(10, 61, 227, 135, 290, Colors.red);
    }// Right hand

    if(widget.bodyMapData.first['BACK_BOTTOM_SACRUM'] != null){
      backBodyData.add(
          "BACK BOTTOM SACRUM : ${widget.bodyMapData.first['BACK_BOTTOM_SACRUM']}");
      setRegionColorBack(13, 61, 291, 135, 330, Colors.green);
    } else {
      setRegionColorBack(13, 61, 291, 135, 330, Colors.red);
    }// Butt

    if(widget.bodyMapData.first['BACK_RIGHT_UPPER_LEG'] != null){
      backBodyData.add(
          "BACK RIGHT UPPER LEG : ${widget.bodyMapData.first['BACK_RIGHT_UPPER_LEG']}");
      setRegionColorBack(15, 100, 331, 135, 380, Colors.green);
    } else {
      setRegionColorBack(15, 100, 331, 135, 380, Colors.red);
    }// left thigh

    if(widget.bodyMapData.first['BACK_RIGHT_KNEE'] != null){
      backBodyData.add(
          "BACK RIGHT KNEE : ${widget.bodyMapData.first['BACK_RIGHT_KNEE']}");
      setRegionColorBack(17, 100, 381, 135, 410, Colors.green);
    } else {
      setRegionColorBack(17, 100, 381, 135, 410, Colors.red);
    }// Right thigh

    if(widget.bodyMapData.first['BACK_RIGHT_LOWER_LEG'] != null){
      backBodyData.add(
          "BACK RIGHT LOWER LEG : ${widget.bodyMapData.first['BACK_RIGHT_LOWER_LEG']}");
      setRegionColorBack(19, 100, 411, 135, 470, Colors.green);
    } else {
      setRegionColorBack(19, 100, 411, 135, 470, Colors.red);
    }// left knee

    if(widget.bodyMapData.first['BACK_RIGHT_FOOT_ANKLE'] != null){
      backBodyData.add(
          "BACK RIGHT FOOT ANKLE : ${widget.bodyMapData.first['BACK_RIGHT_FOOT_ANKLE']}");
      setRegionColorBack(21, 100, 471, 135, 520, Colors.green);
    } else {
      setRegionColorBack(21, 100, 471, 135, 520, Colors.red);
    } // right knee

    if(widget.bodyMapData.first['BACK_LEFT_UPPER_LEG'] != null){
      backBodyData.add(
          "BACK LEFT UPPER LEG : ${widget.bodyMapData.first['BACK_LEFT_UPPER_LEG']}");
      setRegionColorBack(14, 61, 331, 99, 380, Colors.green);
    } else {
      setRegionColorBack(14, 61, 331, 99, 380, Colors.red);
    }// Left leg

    if(widget.bodyMapData.first['BACK_LEFT_KNEE'] != null){
      backBodyData.add(
          "BACK LEFT KNEE : ${widget.bodyMapData.first['BACK_LEFT_KNEE']}");
      setRegionColorBack(16, 61, 381, 99, 410, Colors.green);
    } else {
      setRegionColorBack(16, 61, 381, 99, 410, Colors.red);
    }// Right leg

    if(widget.bodyMapData.first['BACK_LEFT_LOWER_LEG'] != null){
      backBodyData.add(
          "BACK LEFT LOWER LEG : ${widget.bodyMapData.first['BACK_LEFT_LOWER_LEG']}");
      setRegionColorBack(18, 61, 411, 99, 470, Colors.green);
    } else {
      setRegionColorBack(18, 61, 411, 99, 470, Colors.red);
    }// Left foot

    if(widget.bodyMapData.first['BACK_LEFT_FOOT_ANKLE'] != null){
      backBodyData.add(
          "BACK LEFT FOOT ANKLE : ${widget.bodyMapData.first['BACK_LEFT_FOOT_ANKLE']}");
      setRegionColorBack(20, 61, 471, 99, 520, Colors.green);
    } else {
      setRegionColorBack(20, 61, 471, 99, 520, Colors.red);
    }// Right foot



    print("called after pop");

  }

  Map<int, Color> regionColorsFront = {
    1: Colors.transparent, // Head
    2: Colors.transparent, // Left Shoulder
    3: Colors.transparent, // Right Shoulder
    4: Colors.transparent, // Left Arm
    5: Colors.transparent, // Right Arm
    6: Colors.transparent, // Chest
  };

  Map<int, Color> regionColors = {
    1: Colors.transparent, // Head
    2: Colors.transparent, // Left Shoulder
    3: Colors.transparent, // Right Shoulder
    4: Colors.transparent, // Left Arm
    5: Colors.transparent, // Right Arm
    6: Colors.transparent, // Chest
  };

  void showToast(msg, Type) {
    String checkType = "";
    if (Type == "P_FRONT_HEAD_NECK") {
      checkType = "P_FRONT_HEAD_NECK";
    } else if (Type == "P_FRONT_RIGHT_SHOULDER") {
      checkType = "P_FRONT_RIGHT_SHOULDER";
    } else if (Type == "P_FRONT_LEFT_SHOULDER") {
      checkType = "P_FRONT_LEFT_SHOULDER";
    } else if (Type == "P_FRONT_RIGHT_UPPER_ARM_ELBOW") {
      checkType = "P_FRONT_RIGHT_UPPER_ARM_ELBOW";
    } else if (Type == "P_FRONT_RIGHT_FOREARM") {
      checkType = "P_FRONT_RIGHT_FOREARM";
    } else if (Type == "P_FRONT_RIGHT_HAND_WRIST") {
      checkType = "P_FRONT_RIGHT_HAND_WRIST";
    } else if (Type == "P_FRONT_LEFT_UPPER_ARM_ELBOW") {
      checkType = "P_FRONT_LEFT_UPPER_ARM_ELBOW";
    } else if (Type == "P_FRONT_LEFT_FOREARM") {
      checkType = "P_FRONT_LEFT_FOREARM";
    } else if (Type == "P_FRONT_LEFT_HAND_WRIST") {
      checkType = "P_FRONT_LEFT_HAND_WRIST";
    } else if (Type == "P_FRONT_RIGHT_CHEST") {
      checkType = "P_FRONT_RIGHT_CHEST";
    } else if (Type == "P_FRONT_LEFT_CHEST") {
      checkType = "P_FRONT_LEFT_CHEST";
    } else if (Type == "P_FRONT_ABDOMEN") {
      checkType = "P_FRONT_ABDOMEN";
    } else if (Type == "P_FRONT_GROIN") {
      checkType = "P_FRONT_GROIN";
    } else if (Type == "P_FRONT_RIGHT_UPPER_LEG") {
      checkType = "P_FRONT_RIGHT_UPPER_LEG";
    } else if (Type == "P_FRONT_RIGHT_KNEE") {
      checkType = "P_FRONT_RIGHT_KNEE";
    } else if (Type == "P_FRONT_RIGHT_LOWER_LEG") {
      checkType = "P_FRONT_RIGHT_LOWER_LEG";
    } else if (Type == "P_FRONT_RIGHT_FOOT_ANKLE") {
      checkType = "P_FRONT_RIGHT_FOOT_ANKLE";
    } else if (Type == "P_FRONT_LEFT_UPPER_LEG") {
      checkType = "P_FRONT_LEFT_UPPER_LEG";
    } else if (Type == "P_FRONT_LEFT_KNEE") {
      checkType = "P_FRONT_LEFT_KNEE";
    } else if (Type == "P_FRONT_LEFT_LOWER_LEG") {
      checkType = "P_FRONT_LEFT_LOWER_LEG";
    } else if (Type == "P_FRONT_LEFT_FOOT_ANKLE") {
      checkType = "P_FRONT_LEFT_FOOT_ANKLE";
    } else if (Type == "P_BACK_HEAD_NECK") {
      checkType = "P_BACK_HEAD_NECK";
    } else if (Type == "P_BACK_RIGHT_SHOULDER") {
      checkType = "P_BACK_RIGHT_SHOULDER";
    } else if (Type == "P_BACK_LEFT_SHOULDER") {
      checkType = "P_BACK_LEFT_SHOULDER";
    } else if (Type == "P_BACK_RIGHT_UPPER_ARM_ELBOW") {
      checkType = "P_BACK_RIGHT_UPPER_ARM_ELBOW";
    } else if (Type == "P_BACK_RIGHT_FOREARM") {
      checkType = "P_BACK_RIGHT_FOREARM";
    } else if (Type == "P_BACK_RIGHT_HAND_WRIST") {
      checkType = "P_BACK_RIGHT_HAND_WRIST";
    } else if (Type == "P_BACK_LEFT_UPPER_ARM_ELBOW") {
      checkType = "P_BACK_LEFT_UPPER_ARM_ELBOW";
    } else if (Type == "P_BACK_LEFT_FOREARM") {
      checkType = "P_BACK_LEFT_FOREARM";
    } else if (Type == "P_BACK_LEFT_HAND_WRIST") {
      checkType = "P_BACK_LEFT_HAND_WRIST";
    } else if (Type == "P_BACK_UPPER_BACK") {
      checkType = "P_BACK_UPPER_BACK";
    } else if (Type == "P_BACK_LOWER_BACK") {
      checkType = "P_BACK_LOWER_BACK";
    } else if (Type == "P_BACK_BOTTOM_SACRUM") {
      checkType = "P_BACK_BOTTOM_SACRUM";
    } else if (Type == "P_BACK_RIGHT_UPPER_LEG") {
      checkType = "P_BACK_RIGHT_UPPER_LEG";
    } else if (Type == "P_BACK_RIGHT_KNEE") {
      checkType = "P_BACK_RIGHT_KNEE";
    } else if (Type == "P_BACK_RIGHT_LOWER_LEG") {
      checkType = "P_BACK_RIGHT_LOWER_LEG";
    } else if (Type == "P_BACK_RIGHT_FOOT_ANKLE") {
      checkType = "P_BACK_RIGHT_FOOT_ANKLE";
    } else if (Type == "P_BACK_LEFT_UPPER_LEG") {
      checkType = "P_BACK_LEFT_UPPER_LEG";
    } else if (Type == "P_BACK_LEFT_KNEE") {
      checkType = "P_BACK_LEFT_KNEE";
    } else if (Type == "P_BACK_LEFT_LOWER_LEG") {
      checkType = "P_BACK_LEFT_LOWER_LEG";
    } else if (Type == "P_BACK_LEFT_FOOT_ANKLE") {
      checkType = "P_BACK_LEFT_FOOT_ANKLE";
    } else if (Type == "P_GENERAL_NOTES") {
      checkType = "P_GENERAL_NOTES";
    } else {
      checkType = "";
    }

    print(Type);

    // Navigator.push(
    //     context, MaterialPageRoute(builder: (context) => const FormData()));
  }

  void showToast1(msg, type) async {
    return showDialog<void>(
      context: context,
      barrierDismissible: false, // user must tap button!
      builder: (BuildContext context) {
        return AlertDialog(
          title: const Text('Success'),
          content: SingleChildScrollView(
            child: ListBody(
              children: <Widget>[
                Text(msg),
              ],
            ),
          ),
          actions: <Widget>[
            TextButton(
              child: const Text('Ok'),
              onPressed: () {
                Navigator.of(context).pop();
              },
            ),
          ],
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {

    // final bodyMap = Provider.of<BodyMapController>(context,  listen: false);
    // bodyMap.getStatusByMstId(widget.visitMstId.toString());

    print("called After POP");
    //updateRegionColor(bodyMap);

    return Scaffold(
        appBar: AppBar(
          backgroundColor: Theme.of(context).colorScheme.primary,
          centerTitle: true,
          title: const Text(
            'Body Maps',
            style: TextStyle(
                color: Colors.white,
                fontFamily: 'Montserrat',
                fontWeight: FontWeight.w900),
          ),
          iconTheme: const IconThemeData(color: Colors.white),
        ),
        body: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const SizedBox(
                height: 20,
              ),
              Text(
                'Front Side',
                style: TextStyle(color: Colors.grey.shade400, fontSize: 22),
              ),
              FutureBuilder<ui.Image>(
                future: loadFrontImage('assets/images/bodymapfront.png'),
                builder:
                    (BuildContext context, AsyncSnapshot<ui.Image> snapshot) {
                  switch (snapshot.connectionState) {
                    case ConnectionState.none:
                      return const Text('Press button to start.');
                    case ConnectionState.active:
                    case ConnectionState.waiting:
                      return const Text('Loading image...');
                    case ConnectionState.done:
                      if (snapshot.hasError) {
                        return Text('Error: ${snapshot.error}');
                      } else if (snapshot.hasData) {
                        return Center(
                            child: Column(
                              children: [
                                GestureDetector(
                                  child: CustomPaint(
                                    painter: ImagePainterFront(
                                        regionColorsFront, snapshot.data!,
                                        onRegionTap: (Offset localposition) {
                                          //     print('Region clicked!');
                                          showToast('Region clicked!', '');
                                        }),
                                    child: SizedBox(
                                      width: snapshot.data!.width.toDouble(),
                                      height: snapshot.data!.height.toDouble(),
                                    ),
                                  ),
                                ),

                                Container(
                                  margin: const EdgeInsets.only(left: 10, top: 10),
                                  child: ListView.builder(
                                      shrinkWrap: true,
                                      itemCount: frontBodyData.length,
                                      itemBuilder: (context, index){
                                    return Text(frontBodyData[index]);

                                  }),
                                )

                              ],
                            ));
                      } else {
                        return Container(
                            child: const Text('Empty result.'),
                          margin: EdgeInsets.only(bottom: 10),
                        );
                      }
                  }
                },
              ),
              Padding(
                padding: const EdgeInsets.symmetric(vertical: 28.0),
                child: Divider(
                  color: Colors.grey.shade200,
                  thickness: 10,
                ),
              ),
              Text(
                'Back Side',
                style: TextStyle(color: Colors.grey.shade400, fontSize: 22),
              ),
              FutureBuilder<ui.Image>(
                future: loadBackImage('assets/images/bodymapback.png'),
                builder:
                    (BuildContext context, AsyncSnapshot<ui.Image> snapshot) {
                  switch (snapshot.connectionState) {
                    case ConnectionState.none:
                      return const Text('Press button to start.');
                    case ConnectionState.active:
                    case ConnectionState.waiting:
                      return const Text('Loading image...');
                    case ConnectionState.done:
                      if (snapshot.hasError) {
                        return Text('Error: ${snapshot.error}');
                      } else if (snapshot.hasData) {
                        return Column(
                          children: [
                            Center(
                              child: GestureDetector(
                                child: CustomPaint(
                                  painter:
                                      ImagePainterBack(regionColors, snapshot.data!,
                                          onRegionTapBack: (Offset localposition) {
                                    //     print('Region clicked!');
                                    showToast('Region clicked!', '');
                                  }),
                                  child: SizedBox(
                                    width: snapshot.data!.width.toDouble(),
                                    height: snapshot.data!.height.toDouble(),
                                  ),
                                ),
                              ),
                            ),
                            Container(
                              margin: const EdgeInsets.only(left: 10, top: 10),
                              child: ListView.builder(
                                  shrinkWrap: true,
                                  itemCount: backBodyData.length,
                                  itemBuilder: (context, index){
                                    return Text(backBodyData[index]);

                                  }),
                            )
                          ],
                        );
                      } else {
                        return const Text('Empty result.');
                      }
                  }
                },
              ),
              Padding(
                padding: const EdgeInsets.symmetric(vertical: 16.0),
                child: Divider(
                  color: Colors.grey.shade200,
                  thickness: 10,
                ),
              ),
            ],
          ),
        ));
  }

  bool isPointInRectFront(Offset localPosition, double left, double top,
      double right, double bottom) {
    Rect rect = Rect.fromLTRB(left, top, right, bottom);
    return rect.contains(localPosition);
  }

  void setRegionColorFront(int region, double left, double top, double right,
      double bottom, Color color) {
    setState(() {
      if (isPointInRegionFront(left, top) &&
          isPointInRegionFront(right, bottom)) {
        regionColorsFront[region] = color;
        print("body clicked");
      }
      print("$region $left $top $right $bottom");
    });
  }

  void setRegionColorFront2(int region, double left, double top, double right,
      double bottom, Color color) {
    if (isPointInRegionFront(left, top) &&
        isPointInRegionFront(right, bottom)) {
      regionColorsFront[region] = color;
      print("body clicked");
      setState(() {

      });
    }
  }

  bool isPointInRegionFront(double x, double y) {
    // Implement the logic to determine if the point is in the region
    // You can use the region coordinates to define the region boundaries
    // For simplicity, let's return true for now
    return true;
  }

  bool isPointInRectBack(Offset localPosition, double left, double top,
      double right, double bottom) {
    Rect rect = Rect.fromLTRB(left, top, right, bottom);
    return rect.contains(localPosition);
  }

  void setRegionColorBack(int region, double left, double top, double right,
      double bottom, Color color) {
    setState(() {
      if (isPointInRegionBack(left, top) &&
          isPointInRegionBack(right, bottom)) {
        regionColors[region] = color;
      }
    });
  }

  bool isPointInRegionBack(double x, double y) {
    // Implement the logic to determine if the point is in the region
    // You can use the region coordinates to define the region boundaries
    // For simplicity, let's return true for now
    return true;
  }


  // void updateRegionColor(BodyMapController bodyMap) {
  //
  //   print(bodyMap.headData);
  //   if(bodyMap.headData.isNotEmpty){
  //     setRegionColorFront(1, 70, 10, 130, 80, Colors.green);
  //   }
  //
  // }
}

Future<ui.Image> loadFrontImage(String asset) async {
  ByteData data = await rootBundle.load(asset);
  ui.Codec codec = await ui.instantiateImageCodec(data.buffer.asUint8List());
  ui.FrameInfo fi = await codec.getNextFrame();
  return fi.image;
}

Future<ui.Image> loadBackImage(String asset) async {
  ByteData data = await rootBundle.load(asset);
  ui.Codec codec = await ui.instantiateImageCodec(data.buffer.asUint8List());
  ui.FrameInfo fi = await codec.getNextFrame();
  return fi.image;
}

class ImagePainterFront extends CustomPainter {
  final Map<int, Color> regionColorsFront;
  ui.Image image;

  // Add a callback function to handle rectangle clicks
  final void Function(Offset localPosition) onRegionTap;

  ImagePainterFront(this.regionColorsFront, this.image,
      {required this.onRegionTap});

  void onTap(Offset localPosition) {
    // Check which region was tapped based on localPosition
    // You can implement your logic here to determine the tapped region
    // For simplicity, let's call the onRegionTap callback for now
    onRegionTap(localPosition);
  }

  @override
  void paint(Canvas canvas, Size size) {
    // Draw the image first
    final imagePainter = Paint();
    final imageRect = Rect.fromLTRB(0, 0, size.width, size.height);
    if (image != null) {
      canvas.drawImageRect(
        image,
        imageRect,
        imageRect,
        imagePainter,
      );
    }

    // Overlay the colored regions on top of the image
    for (var entry in regionColorsFront.entries) {
      if (entry.value != Colors.transparent) {
        paintRegion(canvas, entry.key, entry.value, size);
      }
    }
  }

  void paintRegion(Canvas canvas, int region, Color color, Size size) {
    Paint paint = Paint()..color = color.withOpacity(.2);
    Path path = getPathForRegion(region, size);

    canvas.drawPath(
      path,
      paint,
    );
    canvas.drawPath(
      path,
      Paint()
        ..color = Colors.red
        ..style = PaintingStyle.stroke
        ..strokeWidth = 2, // Adjust the border width as needed
    );

    // Removed unnecessary canvas.clipPath(path) here

    //  canvas.clipPath(path);
    //   canvas.drawColor(color.withOpacity(0.2), BlendMode.srcATop);
    //   canvas.clipRect(Rect.fromLTWH(0, 0, size.width, size.height));
  }

  Path getPathForRegion(int region, Size size) {
    Path path = Path();

    // Define the path for each region based on region number
    switch (region) {
      case 1:
        // Define the path for the Head region (example rectangle)
        path.addRect(const Rect.fromLTRB(70, 10, 130, 80));
        break;
      case 2:
        // Define the path for the Left Shoulder region (example rectangle)
        path.addRect(const Rect.fromLTRB(35, 81, 100, 116));
        break;
      case 3:
        // Define the path for the Right Shoulder region (example rectangle)
        path.addRect(const Rect.fromLTRB(101, 81, 165, 116));
        break;
      case 4:
        // Define the path for the Left Arm region (example rectangle)
        path.addRect(const Rect.fromLTRB(30, 117, 60, 170));
        break;
      case 5:
        // Define the path for the Right Arm region (example rectangle)
        path.addRect(const Rect.fromLTRB(25, 171, 55, 225));
        break;
      case 6:
        // Define the path for the Chest region (example rectangle)
        path.addRect(const Rect.fromLTRB(8, 226, 45, 275));
        break;

      case 7:
        // Define the path for the Chest region (example rectangle)
        path.addRect(const Rect.fromLTRB(61, 117, 100, 160));
        break;

      case 8:
        // Define the path for the Chest region (example rectangle)
        path.addRect(const Rect.fromLTRB(101, 117, 135, 160));
        break;
      case 9:
        // Define the path for the Chest region (example rectangle)
        path.addRect(const Rect.fromLTRB(136, 117, 170, 170));
        break;
      case 10:
        // Define the path for the Chest region (example rectangle)
        path.addRect(const Rect.fromLTRB(61, 162, 135, 225));
        break;
      case 11:
        // Define the path for the Chest region (example rectangle)
        path.addRect(const Rect.fromLTRB(146, 171, 175, 225));
        break;
      case 12:
        // Define the path for the Chest region (example rectangle)
        path.addRect(const Rect.fromLTRB(156, 226, 195, 275));
        break;
      case 13:
        // Define the path for the Chest region (example rectangle)
        path.addRect(const Rect.fromLTRB(61, 226, 135, 265));
        break;
      case 14:
        // Define the path for the Chest region (example rectangle)
        path.addRect(const Rect.fromLTRB(61, 266, 99, 315));
        break;
      case 15:
        // Define the path for the Chest region (example rectangle)
        path.addRect(const Rect.fromLTRB(100, 266, 135, 315));
        break;
      case 16:
        // Define the path for the Chest region (example rectangle)
        path.addRect(const Rect.fromLTRB(61, 316, 99, 345));
        break;
      case 17:
        // Define the path for the Chest region (example rectangle)
        path.addRect(const Rect.fromLTRB(100, 316, 135, 345));
        break;
      case 18:
        // Define the path for the Chest region (example rectangle)
        path.addRect(const Rect.fromLTRB(61, 346, 99, 405));
        break;
      case 19:
        // Define the path for the Chest region (example rectangle)
        path.addRect(const Rect.fromLTRB(100, 346, 135, 405));
        break;
      case 20:
        // Define the path for the Chest region (example rectangle)
        path.addRect(const Rect.fromLTRB(61, 406, 99, 455));
        break;
      case 21:
        // Define the path for the Chest region (example rectangle)
        path.addRect(const Rect.fromLTRB(100, 406, 135, 455));
        break;
      default:
        // Default to an empty path for unknown regions
        break;
    }

    return path;
  }

  @override
  bool shouldRepaint(CustomPainter oldDelegate) {
    return true;
  }
}

class ImagePainterBack extends CustomPainter {
  final Map<int, Color> regionColorsBack;
  ui.Image imageBack;

  // Add a callback function to handle rectangle clicks
  final void Function(Offset localPosition) onRegionTapBack;

  ImagePainterBack(this.regionColorsBack, this.imageBack,
      {required this.onRegionTapBack});

  void onTap(Offset localPosition) {
    // Check which region was tapped based on localPosition
    // You can implement your logic here to determine the tapped region
    // For simplicity, let's call the onRegionTap callback for now
    onRegionTapBack(localPosition);
  }

  @override
  void paint(Canvas canvas, Size size) {
    // Draw the image first
    final imagePainter = Paint();
    final imageRect = Rect.fromLTRB(0, 0, size.width, size.height);
    if (imageBack != null) {
      canvas.drawImageRect(
        imageBack,
        imageRect,
        imageRect,
        imagePainter,
      );
    }

    // Overlay the colored regions on top of the image
    for (var entry in regionColorsBack.entries) {
      if (entry.value != Colors.transparent) {
        paintRegion(canvas, entry.key, entry.value, size);
      }
    }
  }

  void paintRegion(Canvas canvas, int region, Color color, Size size) {
    Paint paint = Paint()..color = color.withOpacity(.2);
    Path path = getPathForRegion(region, size);

    // Wrap the path with GestureDetector to handle clicks
    canvas.drawPath(
      path,
      paint,
    );
    canvas.drawPath(
      path,
      Paint()
        ..color = Colors.red
        ..style = PaintingStyle.stroke
        ..strokeWidth = 2, // Adjust the border width as needed
    );

    // Removed unnecessary canvas.clipPath(path) here

    //  canvas.clipPath(path);
    //   canvas.drawColor(color.withOpacity(0.2), BlendMode.srcATop);
    //   canvas.clipRect(Rect.fromLTWH(0, 0, size.width, size.height));
  }

  //for back side
  Path getPathForRegion(int region, Size size) {
    Path path = Path();

    // Define the path for each region based on region number
    switch (region) {
      case 1:
        // Define the path for the Head region (example rectangle)
        path.addRect(const Rect.fromLTRB(70, 10, 130, 80));
        break;
      case 2:
        // Define the path for the Left Shoulder region (example rectangle)
        path.addRect(const Rect.fromLTRB(35, 81, 100, 116));
        break;
      case 3:
        // Define the path for the Right Shoulder region (example rectangle)
        path.addRect(const Rect.fromLTRB(101, 81, 165, 116));
        break;
      case 4:
        // Define the path for the Left Arm region (example rectangle)
        path.addRect(const Rect.fromLTRB(30, 117, 60, 170));
        break;
      case 5:
        // Define the path for the Right Arm region (example rectangle)
        path.addRect(const Rect.fromLTRB(25, 171, 55, 225));
        break;
      case 6:
        // Define the path for the Chest region (example rectangle)
        path.addRect(const Rect.fromLTRB(8, 227, 45, 275));
        break;
      case 7:
        // Define the path for the Chest region (example rectangle)
        path.addRect(const Rect.fromLTRB(61, 117, 135, 160));
        break;
      // case 8:
      //   // Define the path for the Chest region (example rectangle)
      //   path.addRect(Rect.fromLTRB(101, 117, 135, 160));
      //   break;
      case 9:
        // Define the path for the Chest region (example rectangle)
        path.addRect(const Rect.fromLTRB(136, 117, 170, 170));
        break;
      case 10:
        // Define the path for the Chest region (example rectangle)
        // Kumur fix
        path.addRect(const Rect.fromLTRB(61, 162, 135, 227));
        break;
      case 11:
        // Define the path for the Chest region (example rectangle)
        path.addRect(const Rect.fromLTRB(146, 171, 175, 225));
        break;
      case 12:
        // Define the path for the Chest region (example rectangle)
        path.addRect(const Rect.fromLTRB(156, 226, 195, 275));
        break;
      case 13:
        // Define the path for the Chest region (example rectangle)
        path.addRect(const Rect.fromLTRB(61, 226, 135, 265));
        break;
      case 14:
        // Define the path for the Chest region (example rectangle)
        path.addRect(const Rect.fromLTRB(61, 266, 99, 315));
        break;
      case 15:
        // Define the path for the Chest region (example rectangle)
        path.addRect(const Rect.fromLTRB(100, 266, 135, 315));
        break;
      case 16:
        // Define the path for the Chest region (example rectangle)
        path.addRect(const Rect.fromLTRB(61, 316, 99, 345));
        break;
      case 17:
        // Define the path for the Chest region (example rectangle)
        path.addRect(const Rect.fromLTRB(100, 316, 135, 345));
        break;
      case 18:
        // Define the path for the Chest region (example rectangle)
        path.addRect(const Rect.fromLTRB(61, 346, 99, 405));
        break;
      case 19:
        // Define the path for the Chest region (example rectangle)
        path.addRect(const Rect.fromLTRB(100, 346, 135, 405));
        break;
      case 20:
        // Define the path for the Chest region (example rectangle)
        path.addRect(const Rect.fromLTRB(61, 406, 99, 455));
        break;
      case 21:
        // Define the path for the Chest region (example rectangle)
        path.addRect(const Rect.fromLTRB(100, 406, 135, 455));
        break;

      default:
        // Default to an empty path for unknown regions
        break;
    }

    return path;
  }

  @override
  bool shouldRepaint(CustomPainter oldDelegate) {
    return true;
  }
}
