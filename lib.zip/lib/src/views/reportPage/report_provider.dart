

import 'dart:core';

import 'package:care4u/src/controls/localDatabaseHandler/local_db_handler_report.dart';
import 'package:flutter/cupertino.dart';

class ReportController extends ChangeNotifier{

  ReportHandler handler = ReportHandler();

  Map<String, dynamic>? reportDetail = {};
  List<Map<String, dynamic>>? agencyData = [];

  Future<void> getReportDetail(String masterId) async {
    Map<String, dynamic>? data0 = await handler.getReportDetails(masterId);
    if (data0.isNotEmpty) {
      reportDetail = data0;
      //print("deleted "+data['FRONT_HEAD_NECK']);
    }
    else {
      print("data Empty");
    }

    List<Map<String, dynamic>>? result = await handler.getAgencyReport(masterId);
    if (result.isNotEmpty) {
      agencyData = result;
      //print("deleted "+data['FRONT_HEAD_NECK']);
    }
    else {
      agencyData = [];
      print("data Empty");
    }

    notifyListeners();
  }

}