import 'package:flutter/material.dart';

class AgencySingleItem extends StatelessWidget {
  Map<String, dynamic> agencyData;
  AgencySingleItem({super.key, required this.agencyData});

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          agencyData['USER_NAME'],
          style: const TextStyle(
            fontSize: 17,
            color: Colors.black87,
            decoration: TextDecoration.none,
            fontFamily: 'system',
          ),
        ),
        Text(
          agencyData['AGENCY_NOTE_DATE_TIME'],
          style: const TextStyle(
            fontSize: 16,
            color: Colors.black87,
            decoration: TextDecoration.none,
            fontFamily: 'system',
            fontWeight: FontWeight.normal,
          ),
        ),
        Text(
          agencyData['AGENCY_NOTE'],
          style: const TextStyle(
            fontSize: 16,
            color: Colors.black87,
            decoration: TextDecoration.none,
            fontFamily: 'system',
            fontWeight: FontWeight.normal,
          ),
        ),
      ],
    );
  }
}
