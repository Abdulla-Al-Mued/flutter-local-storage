import 'package:care4u/src/controls/localDatabaseHandler/local_db_handler_report.dart';
import 'package:care4u/src/controls/utils/appbar.dart';
import 'package:care4u/src/controls/utils/color_codes.dart';
import 'package:care4u/src/models/report_model/report_summary.dart';
import 'package:care4u/src/views/homePage/widgets/user_data.dart';
import 'package:care4u/src/views/reportPage/report_bodymaps.dart';
import 'package:care4u/src/views/reportPage/report_details.dart';
import 'package:care4u/src/views/reportPage/report_provider.dart';
import 'package:care4u/src/views/reportPage/widgets/AgencySingleItem.dart';
import 'package:care4u/src/views/reportPage/widgets/medication_report_details.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../controls/localStorage/local_storage.dart';

class ReportPage extends StatefulWidget {

  CarerVisitReportSummary? visitSummary;

  ReportPage({super.key, required this.visitSummary});

  @override
  State<ReportPage> createState() => _ReportPageState();
}

class _ReportPageState extends State<ReportPage> {

  LocalStorage localStorage = LocalStorage();
  ReportHandler handler = ReportHandler();

  @override
  Widget build(BuildContext context) {

    final clientData = Provider.of<ReportController>(context, listen: false);

    clientData.getReportDetail(widget.visitSummary!.carerVisitMstId!);

    return Scaffold(
        appBar: const CustomAppBar(
            backgroundColor: Colors.white,
            title: 'Report'),
        body:  SingleChildScrollView(
          child: Consumer<ReportController> (builder: (BuildContext context, ReportController value, Widget? child) {
            return Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // Name section
            Padding(
                  padding: const EdgeInsets.symmetric(vertical: 20.0, horizontal: 20),
                  child: Text(value.reportDetail?['NAME'] ?? '',
                      style: const TextStyle(
                        // fontFamily: 'PoppinsBold',
                          fontSize: 20,
                          fontWeight: FontWeight.bold,
                          color: heading)),
                ),
                Divider(
                  color: Colors.grey.shade200,
                  thickness: 8,
                ),
                Padding(
                  padding: const EdgeInsets.symmetric(vertical: 20.0, horizontal: 20),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Padding(
                        padding: EdgeInsets.symmetric(vertical: 15.0,),
                        child: Text('Visit details',
                            style: TextStyle(
                                fontSize: 18,
                                fontWeight: FontWeight.bold,
                                color: heading)),
                      ),
                      userData(title: 'Visit Type', value: value.reportDetail?['VISIT_TYPE_NAME'] ?? ''),
                      userData(title: 'Care worker', value: value.reportDetail?['CARER_NAME'] ?? ''),
                      userData(title: 'Date of visit', value: value.reportDetail?['VISIT_DAY'] ?? ''),
                      userData(title: 'Check in', value: value.reportDetail?['CHECK_IN_TIME'] ?? ''),
                      userData(title: 'Check Out', value: value.reportDetail?['CHECK_OUT_TIME'] ?? ''),
                      userData(title: 'Duration', value: (value.reportDetail?['WORKING_TIME'] ?? "N/A")+"m"),
                      userData(title: value.reportDetail?['NAME']!=null?value.reportDetail!['NAME']+" Seems": "", value: getImojiReactDesc(value.reportDetail?['HOW_DID_CLIENT_EMOJI_CODE']??'')),
                    ],
                  ),
                ),
                Divider(
                  color: Colors.grey.shade200,
                  thickness: 8,
                ),
                Padding(
                  padding: const EdgeInsets.symmetric(vertical: 20.0, horizontal: 20),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text('Tasks',
                          style: TextStyle(
                              fontSize: 17,
                              fontWeight: FontWeight.bold,
                              color: heading)),
                      ListView.builder(
                        shrinkWrap: true,
                        physics: const NeverScrollableScrollPhysics(),
                        itemCount: widget.visitSummary?.taskData?.length ?? 0,
                        itemBuilder: (context, index) {
                          final Task task = widget.visitSummary!.taskData![index];
                          return FutureBuilder<List<Map<String, dynamic>>>(


                            future: handler.getFoodForCarerVisitMstId(widget.visitSummary!.carerVisitMstId!, getTableName(task.taskCode!), getColumnName(task.taskCode!)),
                            builder: (context, snapshot) {
                              if (snapshot.connectionState == ConnectionState.waiting) {
                                return Container();
                              } else if (snapshot.hasError) {
                                return Text('Error: ${snapshot.error}');
                              } else if (snapshot.hasData) {

                                String taskCode = '';
                                List<Map<String, dynamic>> medication = [];
                                List<Map<String, dynamic>> bodyMap = [];
                                final String iconPath = getIconPath(task.taskCode!);
                                print("Data");

                                if(task.taskCode == '01'){

                                  medication = snapshot.data!;
                                  print(snapshot.data);

                                }
                                else if(task.taskCode == '02'){

                                  bodyMap = snapshot.data!;

                                }
                                else{
                                  print(snapshot.data!.first);
                                  taskCode = snapshot.data!.first[getColumnName(task.taskCode!)];

                                }



                                return InkWell(
                                  onTap: (){
                                    if(task.taskCode == '01') {
                                      //showMedicationDetails(medication);
                                      Navigator.push(
                                        context,
                                        MaterialPageRoute(builder: (context) => MedicationReport(medications: medication)),
                                      );
                                    }
                                    else if(task.taskCode == '02'){

                                      Navigator.push(
                                        context,
                                        MaterialPageRoute(builder: (context) => ReportBodyMaps(bodyMapData : bodyMap)),
                                      );

                                    }
                                    else{
                                      //showDetails(task, taskCode);
                                      Navigator.push(
                                        context,
                                        MaterialPageRoute(builder: (context) => ReportDetails(taskName: taskCode,description: task,)),
                                      );
                                    }
                                  },
                                    child: iconSingleItem(taskCode, iconPath, task.taskDesc!)
                                );
                              } else {
                                return Text('No data available');
                              }
                            },
                          );
                        },
                      )

                    ],
                  ),
                ),
                Divider(
                  color: Colors.grey.shade200,
                  thickness: 8,
                ),
                Padding(
                  padding: const EdgeInsets.symmetric(vertical: 20.0, horizontal: 20),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text('Agency notes',
                          style: TextStyle(
                              fontSize: 17,
                              fontWeight: FontWeight.bold,
                              color: heading)
                      ),

                      const SizedBox(height: 10),

                      ListView.builder(
                        shrinkWrap: true,
                        itemCount: value.agencyData?.length,
                        itemBuilder: (context, index){

                          Map<String, dynamic>? agencyData = value.agencyData?[index];

                        return AgencySingleItem(agencyData : agencyData!);
                      },
                      )

                    ],
                  ),
                ),
                Divider(
                  color: Colors.grey.shade200,
                  thickness: 8,
                ),
              ],
            );
          },)       ),

    );
  }

  String getColumnName(String taskCode) {
    switch (taskCode) {
      case "01":
        return 'MEDICATION_NAME';
      case "02":
        return 'assets/task/bodymap.png';
      case "03":
        return 'FOOD';
      case "04":
        return 'DRINKS';
      case "05":
        return 'PERSONAL_CARE';
      case "06":
        return 'TOILET_ASSISTANT';
      case "07":
        return 'REPOSITIONING';
      case "08":
        return 'COMPANIONSHIP_RESPITE';
      case "09":
        return 'LAUNDRY';
      case "10":
        return 'GROCERIES';
      case "11":
        return 'HOUSEWORK';
      case "12":
        return 'HOUSEHOLD_CHORES';
      case "99":
        return 'DPD_CARER_VISIT_UNBLEDLVR_DTL';
    // Add more cases as needed
      default:
        return 'assets/icons/unable_deliver.png';
    }
  }

  String getTableName(String taskCode) {
    switch (taskCode) {
      case "01":
        return 'DPD_CARER_VISIT_MEDICATION_DTL';
      case "02":
        return 'DPD_CARER_VISIT_BODY_MAP_DTL';
      case "03":
        return 'DPD_CARER_VISIT_FOOD_DTL';
      case "04":
        return 'DPD_CARER_VISIT_DRINKS_DTL';
      case "05":
        return 'DPD_CARER_VISIT_PERCARE_DTL';
      case "06":
        return 'DPD_CARER_VISIT_TOIAST_DTL';
      case "07":
        return 'DPD_CARER_VISIT_REPOSNG_DTL';
      case "08":
        return 'DPD_CARER_VISIT_CMPNNSHP_DTL';
      case "09":
        return 'DPD_CARER_VISIT_LAUNDRY_DTL';
      case "10":
        return 'DPD_CARER_VISIT_GROCERI_DTL';
      case "11":
        return 'DPD_CARER_VISIT_HOUSWRK_DTL';
      case "12":
        return 'DPD_CARER_VISIT_HOUSHLDCRS_DTL';
      case "99":
        return 'UNABLE_DELIVER_DTL';
    // Add more cases as needed
      default:
        return 'assets/icons/unable_deliver.png';
    }
  }

  String getIconPath(String taskCode) {
    switch (taskCode) {
      case "01":
        return 'assets/task/medication.png';
      case "02":
        return 'assets/task/bodymap.png';
      case "03":
        return 'assets/task/food.png';
      case "04":
        return 'assets/task/drinks.png';
      case "05":
        return 'assets/task/care.png';
      case "06":
        return 'assets/task/toilet_assistance.png';
      case "07":
        return 'assets/task/repositioning.png';
      case "08":
        return 'assets/task/campanionship.png';
      case "09":
        return 'assets/task/laundry.png';
      case "10":
        return 'assets/task/groceries.png';
      case "11":
        return 'assets/task/housework.png';
      case "12":
        return 'assets/task/household.png';
      case "99":
        return 'assets/task/unable_deliver.png';
    // Add more cases as needed
      default:
        return 'assets/icons/unable_deliver.png';
    }
  }

  Widget iconSingleItem(String taskData, String iconPath, String taskDesc) {
    return Row(
      children: [
        Container(
          margin: const EdgeInsets.only(left: 5, top: 5, bottom: 5, right: 10),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(4),
            border: Border.all(
              color: Colors.grey.shade300,
              width: 1,
            ),
          ),
          child: Padding(
            padding: const EdgeInsets.all(5),
            child: Image.asset(
              iconPath,
              width: 30,
              height: 30,
            ),
          ),
        ),
        Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              taskDesc ?? '',
              style: const TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.bold,
                  color: heading
              ),
            ),
          ],
        ),
      ],
    );
  }

  void showDetails(Task task, String taskCode) {
    showDialog(
        context: context,
        builder: (BuildContext context) {
          return AlertDialog(
            shape: RoundedRectangleBorder( // Remove rounded corners
              borderRadius: BorderRadius.circular(10),
            ),
            content: SingleChildScrollView(
              child: Container(
                width: double.infinity,
                height: 150,
                //decoration: BoxDecoration( borderRadius: BorderRadius.circular(0)),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.start,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Container(
                        margin: const EdgeInsets.only(top: 10, right: 10),
                        child: Text(
                          task.taskDesc!,
                          style: const TextStyle(fontSize: 20, color: Colors.black87, decoration: TextDecoration.none, fontFamily: 'system', fontWeight: FontWeight.bold),
                        )),
                    Flexible(
                      child: SingleChildScrollView(
                        child: Container(
                          child: Text(
                            taskCode,
                            style: const TextStyle(fontSize: 16, color: Colors.black87, decoration: TextDecoration.none, fontFamily: 'system', fontWeight: FontWeight.normal),
                          ),
                        ),
                      ),
                    ),
                    const SizedBox(height: 24),
                  ],
                ),
              ),
            ),
          );
        });
  }

  void showMedicationDetails(List<Map<String, dynamic>> medication) {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        var height = MediaQuery.of(context).size.height * 0.5;
        var width = MediaQuery.of(context).size.width;
        return AlertDialog(
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(5),
          ),
          content: SingleChildScrollView(
            child: Container(
              height: height,
              width: width,
              child: Column(
                mainAxisAlignment: MainAxisAlignment.start,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Container(
                    margin: const EdgeInsets.only(top: 10, right: 10),
                    child: const Text(
                      "Medication Details",
                      style: TextStyle(
                        fontSize: 20,
                        color: Colors.black87,
                        decoration: TextDecoration.none,
                        fontFamily: 'system',
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ),
                  const SizedBox(height: 24),
                  // List of medication details
                  SizedBox(
                    height: height-80,
                    child: ListView.builder(
                      shrinkWrap: true,
                      itemCount: medication.length,
                      itemBuilder: (context, index) {
                        // Access medication data for the current index
                        Map<String, dynamic> medData = medication[index];
                        // Extract necessary fields
                        String medicationName = medData['MEDICATION_NAME'] ?? '';
                        String takenStatus = medData['TAKEN_STATUS'] ?? '';
                        String takenRemarks = medData['TAKEN_REMARKS'] ?? '';
                        String notTakenStatus = medData['NOT_TAKEN_STATUS'] ?? '';
                        String notTakenRemarks = medData['NOT_TAKEN_REMARKS'] ?? '';

                        // Return a ListTile with medication details
                        return Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              medicationName.trim(),
                              style: const TextStyle(
                                fontSize: 16,
                                color: Colors.black87,
                                decoration: TextDecoration.none,
                                fontFamily: 'system',
                                fontWeight: FontWeight.normal,
                              ),
                            ),
                            takenStatus.trim() == 'Y' || notTakenStatus.trim() == 'Y'?
                            takenStatus.trim() == 'Y'?
                            Column(
                              children: [
                                const Text(
                                  'TAKEN',
                                  style: TextStyle(
                                    fontSize: 14,
                                    color: Colors.grey,
                                    decoration: TextDecoration.none,
                                    fontFamily: 'system',
                                    fontWeight: FontWeight.normal,
                                  ),
                                ),
                                Text(
                                  takenRemarks,
                                  style: const TextStyle(
                                    fontSize: 14,
                                    color: Colors.grey,
                                    decoration: TextDecoration.none,
                                    fontFamily: 'system',
                                    fontWeight: FontWeight.normal,
                                  ),
                                ),
                              ],
                            ) :
                            Column(
                              children: [
                                const Text(
                                  'NOT TAKEN',
                                  style: TextStyle(
                                    fontSize: 14,
                                    color: Colors.grey,
                                    decoration: TextDecoration.none,
                                    fontFamily: 'system',
                                    fontWeight: FontWeight.normal,
                                  ),
                                ),
                                Text(
                                  notTakenRemarks,
                                  style: const TextStyle(
                                    fontSize: 14,
                                    color: Colors.grey,
                                    decoration: TextDecoration.none,
                                    fontFamily: 'system',
                                    fontWeight: FontWeight.normal,
                                  ),
                                ),
                              ],
                            ) :
                            const Text(
                              'No Info',
                              style: TextStyle(
                                fontSize: 14,
                                color: Colors.grey,
                                decoration: TextDecoration.none,
                                fontFamily: 'system',
                                fontWeight: FontWeight.normal,
                              ),
                            ),
                            const SizedBox(height: 10)
                          ],
                        );
                      },
                    ),
                  ),
                ],
              ),
            ),
          ),
        );
      },
    );
  }

  String getImojiReactDesc(String react) {
    if(react.trim() == '0'){
      return 'Angry';
    }
    else if(react.trim() == '1'){
      return 'Not Satisfied';
    }
    else if(react.trim() == '2'){
      return 'Ok';
    }
    else if(react.trim() == '3'){
      return 'Good';
    }
    else if(react.trim() == '4'){
      return 'Happy';
    }
    else{
      return 'Not Captured';
    }
  }

}
