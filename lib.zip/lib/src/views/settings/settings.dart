import 'dart:async';

import 'package:care4u/src/controls/localStorage/local_storage.dart';
import 'package:care4u/src/controls/utils/appbar.dart';
import 'package:care4u/src/controls/utils/image_url.dart';
import 'package:care4u/src/views/settings/screens/Terms_and_condition.dart';
import 'package:care4u/src/views/settings/screens/contact_page.dart';
import 'package:care4u/src/views/settings/widgets/settings_data.dart';
import 'package:connectivity_plus/connectivity_plus.dart';
import 'package:flutter/material.dart';

import '../passcodeSetupPage/reset_passcode.dart';

class Settings extends StatefulWidget {
  const Settings({Key? key});

  @override
  State<Settings> createState() => _SettingsState();
}

class _SettingsState extends State<Settings> {
  String _appVersion = 'Unknown';

  bool isConnected = true;
  late Connectivity connectivity;
  late StreamSubscription<List<ConnectivityResult>> connectivitySubscription;

  Future<void> checkConnection() async{

    connectivitySubscription = connectivity.onConnectivityChanged.listen((event) {
      if (event.contains(ConnectivityResult.mobile)) {
        isConnected = true;
      } else if (event.contains(ConnectivityResult.wifi)) {
        isConnected = true;
      } else if (event.contains(ConnectivityResult.ethernet)) {
        isConnected = true;
      } else if (event.contains(ConnectivityResult.vpn)) {
        isConnected = true;
      } else if (event.contains(ConnectivityResult.bluetooth)) {
        isConnected = true;
      } else if (event.contains(ConnectivityResult.other)) {
        isConnected = true;
      } else if (event.contains(ConnectivityResult.none)) {
        isConnected = false;
      }
      setState(() {

      });
    });



  }
  @override
  void initState() {
    super.initState();
    _getAppVersion();
    connectivity = Connectivity();
    checkConnection();

  }

  @override
  void dispose() {
    super.dispose();
    connectivitySubscription.cancel();
  }

  Future<void> _getAppVersion() async {
    //PackageInfo packageInfo = await PackageInfo.fromPlatform();
    setState(() {
      _appVersion = "";
    });
  }


  @override
  Widget build(BuildContext context) {
    LocalStorage localStorage = LocalStorage();
    return Scaffold(
      backgroundColor: Colors.grey.shade200,
      appBar:  CustomAppBar(
          backgroundColor: Colors.grey.shade200,
          title: 'Settings'),
      body: Column(
        children: [
          SingleChildScrollView(
            child: Padding(
              padding:
                  const EdgeInsets.symmetric(horizontal: 10.0),
              child: Column(
                children: [
                  ClipRRect(
                    borderRadius: BorderRadius.circular(50),
                    child: isConnected && localStorage
                        .userLoginDetail.value![0].carerImagePath != null
                        ? Image.network(
                            CARER_IMAGE_URL+localStorage
                                .userLoginDetail.value![0].carerImagePath!,
                            width: 100,
                            height: 100,
                            fit: BoxFit.cover,
                      errorBuilder: (context, error, stackTrace) {
                        // Error occurred while loading image
                        return const CircleAvatar(
                          backgroundColor: Colors.purple,
                          radius: 40,
                          child: Icon(Icons.person),
                        );
                      },
                          )
                        : const CircleAvatar(
                            backgroundColor: Colors.blue,
                            radius: 50,
                            child: Icon(
                              Icons.person,
                              size: 40,
                            ),
                          ),
                  ),
                  Padding(
                    padding: const EdgeInsets.symmetric(vertical: 20.0),
                    child: Center(
                      child: Text(
                        '${localStorage.userLoginDetail.value![0].firstName}${localStorage.userLoginDetail.value![0].lastName}',
                        style: const TextStyle(
                            fontSize: 22, fontWeight: FontWeight.w700),
                      ),
                    ),
                  ),
                  Column(
                    children: [
                      settingsData(
                        iconlogo: Icons.people,
                        text: 'Contact Us',
                        context: context,
                        nextPage: const ContactUsPage(),
                      ),
                      settingsData(
                        iconlogo: Icons.password_outlined,
                        text: 'Change Passcode',
                        context: context,
                        nextPage: const ChangePasscodeScreen(),
                      ),
                      settingsData(
                        iconlogo: Icons.document_scanner_outlined,
                        text: 'Terms and Conditions',
                        context: context,
                        nextPage: const TermAndCondition(),
                      ),
                      Container(
                        decoration: const BoxDecoration(
                          borderRadius: BorderRadius.all(Radius.circular(40)),
                        ),
                        margin: const EdgeInsets.only(bottom: 10),
                        child: Card(
                          margin: const EdgeInsets.symmetric(vertical: 10),
                          child: ListTile(
                            tileColor: Colors.white,
                            leading: Container(
                              padding: const EdgeInsets.all(8.0),
                              decoration: BoxDecoration(
                                color: Theme.of(context).colorScheme.primary,
                                borderRadius: BorderRadius.circular(5.0),
                              ),
                              child: const Icon(
                                Icons.security_update_warning,
                                size: 14.0,
                                color: Colors.white,
                              ),
                            ),
                            title: const Text(
                              'App Version',
                              style: TextStyle(
                                  fontSize: 16, fontWeight: FontWeight.w600),
                            ),
                            trailing: Text(
                              ' $_appVersion',
                              style: const TextStyle(
                                  color: Colors.grey,
                                  fontSize: 16,
                                  fontWeight: FontWeight.w700),
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}
