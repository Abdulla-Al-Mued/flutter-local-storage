import 'package:care4u/src/controls/utils/appbar.dart';
import 'package:flutter/material.dart';

class ContactUsPage extends StatelessWidget {
  const ContactUsPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: CustomAppBar(
          backgroundColor: Colors.grey.shade200,
          title: 'Contact Page'),
      backgroundColor: Colors.grey.shade200,
      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.all(20.0),
          child: Column(
            children: [
              // Text('Our customisable and easy-to-use software supports recording at the point of care, saving time and allowing for more accurate notes.', textAlign: TextAlign.justify, style: TextStyle(fontFamily: 'Montserrat',fontSize: 16, fontWeight: FontWeight.w700, color: Colors.grey.shade700),),
              Container(
                margin: const EdgeInsets.symmetric(vertical: 20),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(18),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Padding(
                      padding: EdgeInsets.all(20.0),
                      child: Text(
                        'Customer Support',
                        style: TextStyle(
                            fontSize: 18, fontWeight: FontWeight.w700),
                      ),
                    ),
                    // Row(
                    //   children: <Widget>[
                    //     Center(
                    //       child: Padding(
                    //         padding:
                    //             const EdgeInsets.only(left: 20.0, right: 10),
                    //         child: Container(
                    //           width: 35,
                    //           height: 35,
                    //           decoration: const BoxDecoration(
                    //             color: Colors.grey, // Background color
                    //             shape: BoxShape.circle, // Circular shape
                    //           ),
                    //           child: const Center(
                    //             child: ClipOval(
                    //               child: Icon(
                    //                 Icons.phone_rounded,
                    //                 size: 22, // Adjust icon size as needed
                    //                 color: Colors.white, // Icon color
                    //               ),
                    //             ),
                    //           ),
                    //         ),
                    //       ),
                    //     ),
                    //     Column(
                    //       crossAxisAlignment: CrossAxisAlignment.start,
                    //       children: [
                    //         Text(
                    //           'Contact Number',
                    //           style: TextStyle(
                    //               color: Colors.grey.shade600,
                    //               fontSize: 14,
                    //               fontWeight: FontWeight.w600),
                    //         ),
                    //         Text(
                    //           '+44 07877663306',
                    //           style: TextStyle(
                    //               color: Colors.grey.shade600,
                    //               fontSize: 18,
                    //               fontWeight: FontWeight.w600),
                    //         ),
                    //       ],
                    //     ),
                    //   ],
                    // ),
                    Row(
                      children: <Widget>[
                        Center(
                          child: Padding(
                            padding:
                                const EdgeInsets.only(left: 20.0, right: 10),
                            child: Container(
                              width: 35,
                              height: 35,
                              decoration: const BoxDecoration(
                                color: Colors.grey, // Background color
                                shape: BoxShape.circle, // Circular shape
                              ),
                              child: const Center(
                                child: ClipOval(
                                  child: Icon(
                                    Icons.email,
                                    size: 22, // Adjust icon size as needed
                                    color: Colors.white, // Icon color
                                  ),
                                ),
                              ),
                            ),
                          ),
                        ),
                        Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              'Email Address',
                              style: TextStyle(
                                  color: Colors.grey.shade600,
                                  fontSize: 14,
                                  fontWeight: FontWeight.w600),
                            ),
                            Text(
                              'support@caresoft4u.com',
                              style: TextStyle(
                                  color: Colors.grey.shade600,
                                  fontSize: 18,
                                  fontWeight: FontWeight.w600),
                            ),
                          ],
                        ),
                      ],
                    ),
                    const Padding(
                      padding: EdgeInsets.all(20.0),
                      child: Text(
                        'Demo Contact',
                        style: TextStyle(
                            fontSize: 18, fontWeight: FontWeight.w700),
                      ),
                    ),
                    Row(
                      children: <Widget>[
                        Center(
                          child: Padding(
                            padding:
                            const EdgeInsets.only(left: 20.0, right: 10),
                            child: Container(
                              width: 35,
                              height: 35,
                              decoration: const BoxDecoration(
                                color: Colors.grey, // Background color
                                shape: BoxShape.circle, // Circular shape
                              ),
                              child: const Center(
                                child: ClipOval(
                                  child: Icon(
                                    Icons.email,
                                    size: 22, // Adjust icon size as needed
                                    color: Colors.white, // Icon color
                                  ),
                                ),
                              ),
                            ),
                          ),
                        ),
                        Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              'Email Address',
                              style: TextStyle(
                                  color: Colors.grey.shade600,
                                  fontSize: 14,
                                  fontWeight: FontWeight.w600),
                            ),
                            Text(
                              'demo@caresoft4u.com',
                              style: TextStyle(
                                  color: Colors.grey.shade600,
                                  fontSize: 18,
                                  fontWeight: FontWeight.w600),
                            ),
                          ],
                        ),
                      ],
                    ),
                    SizedBox(height: 20,)
                  ],
                ),
              ),
              // Container(
              //   margin: const EdgeInsets.symmetric(vertical: 20),
              //   height: MediaQuery.of(context).size.height * 0.2,
              //   decoration: BoxDecoration(
              //     color: Colors.white,
              //     borderRadius: BorderRadius.circular(18),
              //   ),
              //   child: Column(
              //     crossAxisAlignment: CrossAxisAlignment.start,
              //     children: [
              //       const Padding(
              //         padding: EdgeInsets.all(20.0),
              //         child: Text(
              //           'Address',
              //           style: TextStyle(
              //               fontSize: 18, fontWeight: FontWeight.w700),
              //         ),
              //       ),
              //       Padding(
              //         padding: const EdgeInsets.symmetric(horizontal: 20.0),
              //         child: Text(
              //           '22 Commercial Road, Bedford, Bedfordshire PO No - MK40 1QS, UK.',
              //           style: TextStyle(
              //               color: Colors.grey.shade600,
              //               fontSize: 16,
              //               fontWeight: FontWeight.w600),
              //         ),
              //       ),
              //     ],
              //   ),
              // ),
              Padding(
                padding: const EdgeInsets.only(top: 40.0),
                child: Text(
                  '© Copyright 2023 Care 4 U', textAlign: TextAlign.start,
                  style: TextStyle( fontFamily: 'Montserrat',
                      color: Colors.grey.shade500, fontWeight: FontWeight.w700),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
