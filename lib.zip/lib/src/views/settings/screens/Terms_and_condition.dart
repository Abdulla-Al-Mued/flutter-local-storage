import 'package:care4u/src/controls/utils/Tools.dart';
import 'package:care4u/src/controls/utils/appbar.dart';
import 'package:flutter/material.dart';
import 'package:webview_flutter/webview_flutter.dart';
class TermAndCondition extends StatefulWidget {
  const TermAndCondition({super.key});

  @override
  State<TermAndCondition> createState() => _TermAndConditionState();
}

class _TermAndConditionState extends State<TermAndCondition> {

  var isLoading = ValueNotifier<bool>(true);

  final controller = WebViewController()
    ..setJavaScriptMode(JavaScriptMode.disabled)
    ..loadRequest(Uri.parse('https://caresoft4u.com/terms-conditions/'));

  @override
  void initState() {

    super.initState();
    controller.setNavigationDelegate(
      NavigationDelegate(
        onPageFinished: (String url) {
          isLoading.value = false;
        },
          onWebResourceError: (WebResourceError error) {
          showToastInfo("something went wrong");
          }
      )
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar:  const CustomAppBar(
          backgroundColor: Colors.white,
          title: 'Terms and Conditions'),
      body: ValueListenableBuilder<bool>(
          valueListenable: isLoading,
          builder: (context, value, _) {
            return Scaffold(
              body: Stack(
                children: <Widget>[
                  WebViewWidget(
                    controller: controller,
                  ),
                  (value == true
                      ? Scaffold(
                    body: Center(
                      child: CircularProgressIndicator(),
                    ),
                  )
                      : Container()),
                ],
              ),
            );
            ;
          }),
    );
  }
}

