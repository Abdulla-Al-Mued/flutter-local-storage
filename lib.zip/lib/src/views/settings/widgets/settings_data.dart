import 'package:flutter/material.dart';

Widget settingsData({
  required IconData iconlogo,
  required String text,
  required BuildContext context,
  required Widget nextPage, // Widget representing the next page
}) {
  return GestureDetector(
    onTap: () {
      // Navigate to the next page when the item is tapped
      Navigator.push(
        context,
        MaterialPageRoute(builder: (context) => nextPage),
      );
    },
    child: Card(
      margin: const EdgeInsets.symmetric(vertical: 10),
      child: ListTile(
        tileColor: Colors.white,
        leading: Container(
          padding: const EdgeInsets.all(8.0),
          decoration: BoxDecoration(
            color: Theme.of(context).colorScheme.primary,
            borderRadius: BorderRadius.circular(5.0),
          ),
          child: Icon(
            iconlogo,
            size: 14.0,
            color: Colors.white,
          ),
        ),
        title: Text(
          text,
          style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w600),
        ),
        trailing: const Icon(Icons.arrow_forward_ios, size: 18),
      ),
    ),
  );
}
