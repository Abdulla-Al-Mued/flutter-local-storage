import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';

import '../../../controls/localDatabaseHandler/local_database_handler.dart';

class TaskController extends ChangeNotifier{

  late String status = "";
  late String drinksStatus = "";
  late String careStatus ="";
  late String toiletStatus ="";
  late String repositioningStatus ="";
  late String companionshipStatus ="";
  late String laundryStatus ="";
  late String groceriesStatus  ="";
  late String houseworkStatus  ="";
  late String householdStatus  ="";
  late String unableStatus  ="";
  late String medicationStatus  ="";
  late String bodyMapStatus  ="";
  late List<Map<String, dynamic>>? aAllTask = [];
  late List<Map<String, dynamic>>? aAllTask2 = [];

  late bool _isLoading = false;
  bool get isLoading => _isLoading;


  final LocalDatabaseHandler dbHandler = LocalDatabaseHandler();


  void toggleLoading(bool value) {
    _isLoading = value;
    notifyListeners();
  }

  void setAllItemsToEmpty(){
    status = "";
    drinksStatus = "";
    careStatus ="";
    toiletStatus ="";
    repositioningStatus ="";
    companionshipStatus ="";
    laundryStatus ="";
    groceriesStatus  ="";
    houseworkStatus  ="";
    householdStatus  ="";
    unableStatus  ="";
    medicationStatus  ="";
    bodyMapStatus = "";
  }

  Future<void> getStatusByMstId(String masterId) async {
    String? data = await dbHandler.getStatusByMstId(masterId);
    if (data!.isNotEmpty) {

      status = data;
      // print("Address "+address.first['ADDRESS']);
    }
    else{
      status = "";
      print("Empty");
    }

    String data2 = await dbHandler.isBodyMapExistsByMstId(masterId);
    if (data2.isNotEmpty) {

      bodyMapStatus = data2;
      print("Jjjj"+bodyMapStatus);
      // print("Address "+address.first['ADDRESS']);
    }
    else{
      bodyMapStatus = "";
      print("Empty");
    }

    notifyListeners();
    getDrinksStatusByMstId(masterId);
    getCareStatusByMstId(masterId);
    getToiletStatusByMstId(masterId);
    getRepositioningStatusByMstId(masterId);
    getCompanionshipStatusByMstId(masterId);
    getlaundryStatusByMstId(masterId);
    getGroceriesStatusByMstId(masterId);
    getHouseholdStatusByMstId(masterId);
    getHouseholdStatusByMstId(masterId);
    getHouseholdStatusByMstId(masterId);
    getUnableStatusByMstId(masterId);
    isMedicationExist(masterId);

  }

  bool getTaskName(String taskCode) {
    bool task = false;
    for (var element in aAllTask!) {
      if (element['TASK_CODE'] == taskCode) {
        task = true;
        break;
      }
    }

    return task;

  }

  String getTaskAssignNote(String taskCode) {

    String note = '';
    for (var element in aAllTask!) {
      if (element['TASK_CODE'] == taskCode) {
        note = element['NOTES_FOR_CARER']??"";
        break;
      }
    }

    return note;

  }

  Future<void> getAssigned(String clntVisitTypeMstID, String clientId) async {

    List<Map<String, dynamic>>? taskCode = await dbHandler.getTaskCode(clntVisitTypeMstID, clientId);

    if(taskCode!.isNotEmpty){
      aAllTask = taskCode;
    }
    else{
      aAllTask = [];
    }

    notifyListeners();

  }



  // is medication exist
  Future<void> isMedicationExist(String masterId) async {
    bool? data = await dbHandler.isMedicationExist(masterId);
    if (data!) {

      medicationStatus = "Exist";
      // print("Address "+address.first['ADDRESS']);
    }
    else{
      medicationStatus = "";
      print("Empty");
    }

    notifyListeners();

  }

// ----------------------->      Drinks    <------------------------//
  Future<void> getDrinksStatusByMstId(String masterId) async {
    String? data = await dbHandler.getDrinksStatusByMstId(masterId);
    if (data!.isNotEmpty) {

      drinksStatus = data;
      // print("Address "+address.first['ADDRESS']);
    }
    else{
      drinksStatus = "";
      print("Empty");
    }

    notifyListeners();

  }
    // ----------------------->      Care    <------------------------//
  Future<void> getCareStatusByMstId(String masterId) async {
    String? data = await dbHandler.getCareStatusByMstId(masterId);
    if (data!.isNotEmpty) {

      careStatus = data;
      // print("Address "+address.first['ADDRESS']);
    }
    else{
      careStatus = "";
      print("Empty");
    }

    notifyListeners();

  }

  // ----------------------->      Toilet    <------------------------//
  Future<void> getToiletStatusByMstId(String masterId) async {
    String? data = await dbHandler.getToiletStatusByMstId(masterId);
    if (data!.isNotEmpty) {

      toiletStatus = data;
      // print("Address "+address.first['ADDRESS']);
    }
    else{
      toiletStatus = "";
      print("Empty");
    }

    notifyListeners();


  }

  // ----------------------->      Repositioning    <------------------------//
  Future<void> getRepositioningStatusByMstId(String masterId) async {
    String? data = await dbHandler.getRepositioningStatusByMstId(masterId);
    if (data!.isNotEmpty) {

      repositioningStatus = data;
      // print("Address "+address.first['ADDRESS']);
    }
    else{
      repositioningStatus = "";
      print("Empty");
    }

    notifyListeners();

  }


  //----------------------->      Companionship   <------------------------//

  Future<void> getCompanionshipStatusByMstId(String masterId) async {
    String? data = await dbHandler.getCompanionshipStatusByMstId(masterId);
    if (data!.isNotEmpty) {

      companionshipStatus = data;
      // print("Address "+address.first['ADDRESS']);
    }
    else{
      companionshipStatus = "";
      print("Empty");
    }

    notifyListeners();

  }

  //----------------------->      laundry   <------------------------//

  Future<void> getlaundryStatusByMstId(String masterId) async {
    String? data = await dbHandler.getLaundryStatusByMstId(masterId);
    if (data!.isNotEmpty) {
      laundryStatus = data;
      // print("Address "+address.first['ADDRESS']);
    }
    else{
      laundryStatus = "";
      print("Empty");
    }
    notifyListeners();
  }

  //----------------------->      Groceries   <------------------------//

  Future<void> getGroceriesStatusByMstId(String masterId) async {
    String? data = await dbHandler.getGroceriesStatusByMstId(masterId);
    if (data!.isNotEmpty) {
      groceriesStatus = data;
      // print("Address "+address.first['ADDRESS']);
    }
    else{
      groceriesStatus = "";
      print("Empty");
    }
    notifyListeners();
  }
  //----------------------->      Housework   <------------------------//

  Future<void> getHouseworkStatusByMstId(String masterId) async {
    String? data = await dbHandler.getHouseworkStatusByMstId(masterId);
    if (data!.isNotEmpty) {
      houseworkStatus = data;
      // print("Address "+address.first['ADDRESS']);
    }
    else{
      groceriesStatus = "";
      print("Empty");
    }
    notifyListeners();
  }
  //----------------------->      Household   <------------------------//

  Future<void> getHouseholdStatusByMstId(String masterId) async {
    String? data = await dbHandler.getHouseholdStatusByMstId(masterId);
    if (data!.isNotEmpty) {
      householdStatus = data;
      // print("Address "+address.first['ADDRESS']);
    }
    else{
      householdStatus = "";
      print("Empty");
    }
    notifyListeners();
  }

  //----------------------->      Unable   <------------------------//

  Future<void> getUnableStatusByMstId(String masterId) async {
    String? data = await dbHandler.getUnableStatusByMstId(masterId);
    if (data!.isNotEmpty) {
      unableStatus = data;
      // print("Address "+address.first['ADDRESS']);
    }
    else{
      unableStatus = "";
      print("Empty");
    }
    notifyListeners();
  }

}