import 'package:care4u/src/controls/localDatabaseHandler/local_database_handler.dart';
import 'package:flutter/material.dart';

class EmojiState extends ChangeNotifier {

  LocalDatabaseHandler handler = LocalDatabaseHandler();

  int _selectedEmojiIndex = -1;

  int get selectedEmojiIndex => _selectedEmojiIndex;

  void selectEmoji(int index) {
    _selectedEmojiIndex = index;
    notifyListeners();
  }


  Future<void> getEmojiStatus(String masterId) async {
    String? data = await handler.getEmojiStatusByMstId(masterId);

    if (data.isNotEmpty) {

      _selectedEmojiIndex = int.parse(data);
      print(selectedEmojiIndex);
      // print(visitIconList);

    }
    else{
      //visitIconList = [];
      print("Empty");
    }
    //notifyListeners();

  }

}