import 'package:flutter/material.dart';

class ExpandableRowModel extends ChangeNotifier {
  bool _expanded = false;
  String _additionalText = '';

  bool get expanded => _expanded;
  String get additionalText => _additionalText;

  void toggleExpanded() {
    _expanded = !_expanded;
    notifyListeners();
  }

  void setUnExpanded() {
    _expanded = false;
    notifyListeners();
  }

  void setAdditionalText(String text) {
    _additionalText = text;
    print(text);
    notifyListeners();
  }
}
