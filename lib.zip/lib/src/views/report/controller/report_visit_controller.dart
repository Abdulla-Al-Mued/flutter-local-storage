import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

import '../../../controls/localDatabaseHandler/local_database_handler.dart';
import '../../../controls/localDatabaseHandler/local_db_handler_visit.dart';

class VisitTypeController extends ChangeNotifier{

  late String _visitName = '';
  String get visit_name => _visitName;

  late String _co_carerName = '';
  String get co_carer_name => _co_carerName;

  late String _coCareWorker = '';
  String get co_care_worker => _coCareWorker;

  late String _carerVisitMasterId = '';
  String get clientVisitMasterId => _carerVisitMasterId;

  late String checkInTime = '';
  String get time => checkInTime;

  late String checkInDate = '';
  String get date => checkInDate;

  // late String _carerVisitMasterId = '';
  // String get carerVisitMasterId => _carerVisitMasterId;

  late String _IS_SCHEDULED = '';
  String get isScheduled => _IS_SCHEDULED;

  late String _IS_EDITABLE = '';
  String get isEditAble => _IS_EDITABLE;


  late List<Map<String, dynamic>> coCareWorker = [];
  final LocalDatabaseHandler dbHandler = LocalDatabaseHandler();
  final VisitHandler visitHandler = VisitHandler();


  // void setVisitName(String visitName) {
  //   _visitName = visitName;
  //   notifyListeners();
  // }
  //
  // void setTime(TimeOfDay timeNow){
  //
  //   selectedTime = timeNow;
  //   notifyListeners();
  //
  // }

  Future<void> getNameByCode()async {

    notifyListeners();
  }

  Future<void> getVisitData(String carerVisitMstId, String orgCode) async {

    List<Map<String, dynamic>> data = await visitHandler.getVisitData(carerVisitMstId);
    print("COCARE");
    print(carerVisitMstId.toString());
    if (data.isNotEmpty) {

      //print(data);
      checkInTime = data.first["CHECK_IN_TIME"];
      checkInDate = data.first["CHECK_IN_DATE"];

      if(data.first["CARER_ID2"]!=null){
        _coCareWorker = data.first["CARER_ID2"];
      }
      else{
        _coCareWorker = "";
      }
      if(data.first["CARER_NAME"]!=null){
        _co_carerName = data.first["CARER_NAME"];
      }
      else{
        _co_carerName = "";
      }
      _IS_SCHEDULED = data.first['IS_SCHEDULED'];

      getCarerName(_coCareWorker);


      print(_coCareWorker);

      if(data.first["VISIT_TYPE_NAME"]!=null){
        _visitName = data.first["VISIT_TYPE_NAME"];
      }
      else{
        _visitName = "General";
      }
      if(data.first["CLIENT_VISIT_TYPE_MST_ID"]!=null){
        _carerVisitMasterId = data.first["CLIENT_VISIT_TYPE_MST_ID"];
      }
      else{
        _carerVisitMasterId = "";
      }

    }
    else{

      print("Empty  COCARE");

    }

    String? isEditAbleS = await visitHandler.isTimeEditAble(orgCode);

    if(isEditAbleS.isNotEmpty){
      _IS_EDITABLE = isEditAbleS;
    }


    notifyListeners();

  }

  Future<void> getCarerName(String carerId) async {

    String? data = await visitHandler.getCarerName(carerId);
    print("COCARE");
    if (data!=null && data!.isNotEmpty) {

      _co_carerName = data;

    }
    else{
      print("Empty  name");
    }

    notifyListeners();

  }

  Future<void> updateVisitType(String carerVisitMstId, String newClientVisitTypeId) async {
    await visitHandler.updateVisitType(carerVisitMstId , newClientVisitTypeId);

  }

  Future<void> updateCheckInTime(String carerVisitMstId, String newClientVisitCheckInTime) async {
    await visitHandler.updateCheckInTime(carerVisitMstId , newClientVisitCheckInTime);

  }

  Future<void> updateCoCareWorker(String carerVisitMstId, String coCareWorker, carerCode) async {
    await visitHandler.updateCoCareWorker(carerVisitMstId , coCareWorker, carerCode);

  }

  Future<void> removeCarerId2(String carerVisitMstId) async {
    await visitHandler.removeCarerId2(carerVisitMstId);

  }

  Future<void> getCareWorkerList(String carerId, String orgCode) async {
    List<Map<String, dynamic>> data = await dbHandler.getAdditionalCareWorker(carerId, orgCode);
    if (data.isNotEmpty) {

      coCareWorker = data;

    }
    else{
      coCareWorker = [];
      print("Empty");
    }
    notifyListeners();

  }

}