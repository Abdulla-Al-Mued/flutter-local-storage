import 'package:flutter/material.dart';
import 'package:flutter_svg/svg.dart';
import 'package:provider/provider.dart';
import '../../controls/localStorage/local_storage.dart';
import '../../controls/utils/color_codes.dart';
import '../../models/LocalModel/LocalDpd_Cms_Carer_Cln_Dtws_Sch_Lst_Model.dart';
import '../schedulelist/ClientProvider/ClientProvider.dart';
import 'controller/report_visit_controller.dart';

class CoCareWorker extends StatefulWidget {
  Value userId;
  int? id;
  String carer;
  CoCareWorker({super.key, required this.userId, required this.id, required this.carer});

  @override
  State<CoCareWorker> createState() => _CoCareWorkerState();
}

class _CoCareWorkerState extends State<CoCareWorker> {

  LocalStorage localStorage = LocalStorage();

  @override
  Widget build(BuildContext context) {
    final clientData = Provider.of<VisitTypeController>(context,  listen: false);
    clientData.getCareWorkerList(localStorage.userLoginDetail.value![0].carerId!, widget.userId.orgCode.toString());

    return Scaffold(
      appBar: AppBar(
        backgroundColor: Theme.of(context).colorScheme.primary,
        centerTitle: true,
        title: const Text(
          'Additional Care Worker',
          style: TextStyle(
              color: Colors.white,
              fontSize: 20,
              fontFamily: 'Montserrat',
              fontWeight: FontWeight.w900),
        ),
        iconTheme: const IconThemeData(color: Colors.white),
      ),
      backgroundColor: Colors.grey.shade200,
      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.all(20.0),
          child: Column(
            children: [
              // Text('Our customisable and easy-to-use software supports recording at the point of care, saving time and allowing for more accurate notes.', textAlign: TextAlign.justify, style: TextStyle(fontFamily: 'Montserrat',fontSize: 16, fontWeight: FontWeight.w700, color: Colors.grey.shade700),),

              const Text(
                'Who was there with you?',
                style: TextStyle(
                    fontSize: 18, fontWeight: FontWeight.w700),
              ),

              Consumer<VisitTypeController>(
                builder: (context, value, child) {
                  return Container(
                    margin: const EdgeInsets.symmetric(vertical: 20),
                    padding: EdgeInsets.only(top: 10, bottom: 10),
                    decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(10),
                    ),
                    child: value.coCareWorker.isNotEmpty?
                    Column(
                      children: List.generate(
                        value.coCareWorker.length,
                            (index) => FutureBuilder<Column>(
                          future: getVisitSingleItem(value.coCareWorker[index], context, index), // Pass the context
                          builder: (context, snapshot) {
                            if (snapshot.connectionState == ConnectionState.waiting) {
                              return const CircularProgressIndicator();
                            } else if (snapshot.hasError) {
                              return Text('Error: ${snapshot.error}');
                            } else {

                              return GestureDetector(
                                onTap: () {
                                  //print('Item clicked: ${value.visitList[index]['VISIT_TYPE_NAME']}');
                                  value.updateCoCareWorker(widget.id.toString(), value.coCareWorker[index]['CARER_ID'], value.coCareWorker[index]['CARER_CODE']);
                                  clientData.getVisitData(widget.id.toString(), widget.userId.orgCode!);
                                  Navigator.pop(context);
                                  //print(value.coCareWorker[index]['CARER_ID']);
                                },
                                child: snapshot.data ?? const SizedBox(), // Return the data if available
                              );
                            }
                          },
                        ),
                      ),
                    )
                        :
                    const Text('No Care Worker available available'),
                  );
                },
              ),

            ],
          ),
        ),
      ),


      bottomNavigationBar: widget.carer.isNotEmpty ?
      Container(

        margin: EdgeInsets.only(left: 20,right: 20, bottom: 30),

        child: ElevatedButton(
          onPressed: () {
            removeCarer(clientData);

            Navigator.pop(context);
          },
          child: const Text('Remove additional care worker'),

          style: ButtonStyle(
            // Change background color
            backgroundColor: MaterialStateProperty.all<Color>(Colors.red),
            // Change text color
            foregroundColor: MaterialStateProperty.all<Color>(Colors.white),
            minimumSize: MaterialStateProperty.all<Size>(const Size(double.infinity, 50)),
          ),

        ),

      ) : Card(),
    );
  }


  Future<Column> getVisitSingleItem(Map<String, dynamic> visitName, BuildContext context, int index) async {

    return Column(
      crossAxisAlignment: CrossAxisAlignment.center,
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        if(index != 0)
          Container(
            color: Colors.grey.shade200,
            height: 2,
          ),
        Row(
          children: [
            Expanded(
              child: Column(
                children: [
                  Container(
                    margin: EdgeInsets.only(top: 5, bottom: 5),
                    padding: const EdgeInsets.only(left: 18.0),
                    child: Align(
                      alignment: Alignment.centerLeft,
                      child: RichText(
                        text: TextSpan(
                          style: DefaultTextStyle.of(context).style,
                          children: [
                            TextSpan(
                              text: visitName['CARER_NAME'],
                              style: const TextStyle(
                                  color: grayColor,
                                  fontSize: 16,
                                  fontWeight: FontWeight.w600),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),

                ],
              ),
            ),

            visitName['CARER_ID'] != widget.carer ?

            Container(
              width: 23, // Adjust according to your needs
              height: 23, // Adjust according to your needs
              margin: EdgeInsets.only(right: 40, top: 5, bottom: 5),
              decoration: BoxDecoration(
                shape: BoxShape.circle, // Shape of the container
                border: Border.all(
                  color: lightPrimaryColor, // Border color
                  width: 2, // Border width
                ),
              ),
              // You can add child widgets here if needed
            ) :
              Container(
              width: 23, // Adjust according to your needs
              height: 23, // Adjust according to your needs
                margin: EdgeInsets.only(right: 40, top: 5, bottom: 5),
              decoration: BoxDecoration(
                shape: BoxShape.circle, // Shape of the container
                border: Border.all(
                color: lightPrimaryColor, // Border color
                width: 2, // Border width
              ),
            ),
            child: SvgPicture.asset(
            'assets/images/ic_correct.svg',
              height: 20,
              width: 20,
              color: lightPrimaryColor,
              ),
              // You can add child widgets here if needed
              ),
          ],
        ),
      ],
    );
  }

  void removeCarer(VisitTypeController clientData) {

    clientData.removeCarerId2(widget.id.toString());

    clientData.getVisitData(widget.id.toString(), widget.userId.orgCode!);

  }

}
