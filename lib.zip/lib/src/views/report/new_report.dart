import 'package:care4u/src/controls/utils/appbar.dart';
import 'package:care4u/src/controls/utils/color_codes.dart';
import 'package:care4u/src/views/homePage/home_screen.dart';
import 'package:care4u/src/views/report/visit_type.dart';
import 'package:care4u/src/views/report/widgets/all_task.dart';
import 'package:connectivity_plus/connectivity_plus.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter/widgets.dart';
import 'package:flutter_svg/svg.dart';
import 'package:geolocator/geolocator.dart';
import 'package:intl/intl.dart';
import 'package:provider/provider.dart';

import '../../controls/apiHandler/api_handler.dart';
import '../../controls/localDatabaseHandler/local_db_handler_visit.dart';
import '../../controls/localStorage/local_storage.dart';
import '../../controls/utils/Tools.dart';
import '../../controls/utils/oneTimeNetCheck.dart';
import '../../models/LocalModel/LocalDpd_Cms_Carer_Cln_Dtws_Sch_Lst_Model.dart';
import 'co_care_worker.dart';
import 'controller/expended_controller.dart';
import 'controller/report_visit_controller.dart';
import 'controller/task_controller.dart';
import 'widgets/emoji_row.dart';

class NewReport extends StatefulWidget {
  final Value userId;
  final int? id;
  final String? scType;

  const NewReport(
      {super.key,
      required this.userId,
      required this.id,
      required this.scType});

  @override
  State<NewReport> createState() => _NewReportState();
}

class _NewReportState extends State<NewReport> {
  final TextEditingController _textEditingController = TextEditingController();
  final TextEditingController _alertEditingController = TextEditingController();
  final VisitHandler visitHandler = VisitHandler();
  LocalStorage localStorage = LocalStorage();
  late String carerId;
  final ApiHandler _apiHandler = ApiHandler();
  String alert = 'N';

  @override
  void initState() {
    // TODO: implement initState
    super.initState();

    carerId = localStorage.userLoginDetail.value![0].carerId!;
  }

  void getVisitData(VisitTypeController clientData) {
    clientData.getVisitData(widget.id.toString(), widget.userId.orgCode!);
  }

  String convertTo12HourFormat(String time24) {
    final time = TimeOfDay.fromDateTime(DateFormat('HH:mm').parse(time24));
    return time.format(
        context); // context should be available in the widget's build method
  }

  @override
  Widget build(BuildContext context) {
    final clientData = Provider.of<VisitTypeController>(context, listen: false);
    final taskController = Provider.of<TaskController>(context, listen: false);
    final model = Provider.of<ExpandableRowModel>(context, listen: false);

    getVisitData(clientData);

    return Scaffold(
      appBar: const CustomAppBar(
          backgroundColor: Colors.white, title: 'New Report'),
      body: SingleChildScrollView(
        child: Column(
          children: [
            Consumer<VisitTypeController>(
              builder: (BuildContext context, value, Widget? child) {
                return Column(
                  children: [
                    Container(
                      margin: const EdgeInsets.only(
                          left: 20, right: 20, top: 45, bottom: 45),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.stretch,
                        children: [
                          const Text(
                            "About your visit",
                            style: TextStyle(
                              fontFamily: 'Monserarat',
                              fontWeight: FontWeight.w600,
                              fontSize: 24.0,
                            ),
                          ),
                          const SizedBox(
                            height: 10,
                          ),
                          const Text(
                            "Visit Type:",
                            style: TextStyle(
                              // fontFamily: 'PoppinsBold',
                              fontSize: 16.0,
                              color: grayColor,
                            ),
                          ),
                          GestureDetector(
                            onTap: () {
                              if (value.isScheduled != 'Y') {
                                Navigator.push(
                                  context,
                                  MaterialPageRoute(
                                      builder: (context) => VisitType(
                                          userId: widget.userId,
                                          visitMaster: widget.id.toString())),
                                );
                              }

                              // print(selectedVisitType);
                              // clientData.setVisitName(selectedVisitType.toString());
                            },
                            child: Container(
                              margin: const EdgeInsets.only(top: 5),
                              padding: const EdgeInsets.only(
                                  top: 15, bottom: 15, left: 12, right: 12),
                              decoration: BoxDecoration(
                                border: Border.all(
                                  color: primaryColor,
                                  width: 1.0,
                                ),
                                borderRadius: BorderRadius.circular(5.0),
                              ),
                              child: Row(
                                mainAxisAlignment:
                                    MainAxisAlignment.spaceBetween,
                                children: [
                                  value.visit_name.isNotEmpty
                                      ? Text(
                                          value.visit_name,
                                          style: const TextStyle(
                                              fontSize: 16,
                                              color: Colors.black87),
                                        )
                                      : const Text(
                                          "Empty",
                                          style: TextStyle(
                                              fontSize: 16,
                                              color: Colors.black87),
                                        ),
                                  if (value.isScheduled != 'Y')
                                    const Icon(
                                      Icons.edit,
                                      size: 20,
                                      color: primaryColor,
                                    )
                                ],
                              ),
                            ),
                          ),
                          const SizedBox(
                            height: 10,
                          ),
                          const Text(
                            "You arrived at:",
                            style: TextStyle(
                              // fontFamily: 'PoppinsBold',
                              fontSize: 16.0,
                              color: grayColor,
                            ),
                          ),
                          GestureDetector(
                            onTap: () async {
                              if (value.isEditAble == 'Y') {
                                final TimeOfDay? timeOfTheDay =
                                    await showTimePicker(
                                        context: context,
                                        initialTime: TimeOfDay.now(),
                                        initialEntryMode:
                                            TimePickerEntryMode.dial);

                                if (timeOfTheDay != null) {
                                  value.updateCheckInTime(
                                      widget.id.toString(),
                                      convertTo12HourFormat(
                                          "${timeOfTheDay.hour}:${timeOfTheDay.minute}"));
                                  value.getVisitData(widget.id.toString(),
                                      widget.userId.orgCode!);
                                }
                              }
                            },
                            child: Container(
                              margin: const EdgeInsets.only(top: 5),
                              padding: const EdgeInsets.only(
                                  top: 15, bottom: 15, left: 12, right: 12),
                              decoration: BoxDecoration(
                                border: Border.all(
                                  color: primaryColor,
                                  width: 1.0,
                                ),
                                borderRadius: BorderRadius.circular(5.0),
                              ),
                              child: Row(
                                mainAxisAlignment:
                                    MainAxisAlignment.spaceBetween,
                                children: [
                                  Text(
                                    value.time,
                                    style: const TextStyle(
                                        fontSize: 16, color: Colors.black87),
                                  ),
                                  if (value.isEditAble == 'Y')
                                    const Icon(
                                      Icons.edit,
                                      size: 20,
                                      color: primaryColor,
                                    )
                                ],
                              ),
                            ),
                          ),
                          const SizedBox(
                            height: 30,
                          ),
                          const Text(
                            "Was there any other care worker with you?",
                            style: TextStyle(
                              // fontFamily: 'PoppinsBold',
                              fontSize: 16.0,
                              color: grayColor,
                            ),
                          ),
                          const SizedBox(
                            height: 10,
                          ),
                          GestureDetector(
                            onTap: () async {
                              Navigator.push(
                                context,
                                MaterialPageRoute(
                                    builder: (context) => CoCareWorker(
                                        userId: widget.userId,
                                        id: widget.id,
                                        carer: value.co_care_worker)),
                              );
                            },
                            child: !value.co_care_worker.isNotEmpty
                                ? Row(
                                    children: [
                                      Container(
                                        width:
                                            23, // Adjust according to your needs
                                        height:
                                            23, // Adjust according to your needs
                                        decoration: BoxDecoration(
                                          shape: BoxShape.circle,
                                          // Shape of the container
                                          border: Border.all(
                                            color:
                                                primaryColor, // Border color
                                            width: 2, // Border width
                                          ),
                                        ),
                                        child: SvgPicture.asset(
                                          'assets/images/ic_correct.svg',
                                          height: 20,
                                          width: 20,
                                          //color: lightPrimaryColor,
                                        ),
                                      ),
                                      Container(
                                          margin:
                                              const EdgeInsets.only(left: 8),
                                          child: const Text(
                                            "No",
                                            style: TextStyle(fontSize: 16),
                                          )),
                                      Container(
                                        width:
                                            23, // Adjust according to your needs
                                        height:
                                            23, // Adjust according to your needs
                                        margin: const EdgeInsets.only(left: 40),
                                        decoration: BoxDecoration(
                                          shape: BoxShape.circle,
                                          // Shape of the container
                                          border: Border.all(
                                            color:
                                                primaryColor, // Border color
                                            width: 2, // Border width
                                          ),
                                        ),
                                        // You can add child widgets here if needed
                                      ),
                                      Container(
                                          margin:
                                              const EdgeInsets.only(left: 8),
                                          child: const Text(
                                            "Yes",
                                            style: TextStyle(fontSize: 16),
                                          )),
                                    ],
                                  )
                                : Container(
                                    decoration: BoxDecoration(
                                      border: Border.all(
                                        color: primaryColor,
                                        width: 1.0,
                                      ),
                                      borderRadius: BorderRadius.circular(5.0),
                                    ),
                                    height: 50,
                                    child: Align(
                                      alignment: Alignment.center,
                                      // Align text in center
                                      child: Text(value.co_carer_name),
                                    ),
                                  ),
                          )
                        ],
                      ),
                    ),
                    Divider(
                      thickness: 10,
                      color: Colors.grey.shade200,
                      height: 1,
                    ),
                    AllTask(
                        user: widget.userId,
                        masterId: widget.id!,
                        clientVisitTypeMatId: value.clientVisitMasterId)
                  ],
                );
              },
            ),
            Container(
              margin: const EdgeInsets.only(left: 15, right: 15),
              child: Column(
                children: [
                  const SizedBox(height: 30),
                  Container(
                    alignment: Alignment.topLeft,
                    child: Text(
                      "How did ${widget.userId.clientName} seem? (optional)",
                      style: const TextStyle(
                        // fontFamily: 'PoppinsBold',
                        fontSize: 16.0,
                        color: grayColor,
                      ),
                    ),
                  ),
                  const SizedBox(height: 10),
                  EmojiRow(visitMstrId: widget.id!),
                  const SizedBox(height: 25),
                  Container(
                    alignment: Alignment.topLeft,
                    child: const Text(
                      "Summary (optional)",
                      style: TextStyle(
                        // fontFamily: 'PoppinsBold',
                        fontSize: 16.0,
                        color: grayColor,
                      ),
                    ),
                  ),
                  Container(
                    margin: const EdgeInsets.only(top: 10),
                    child: TextField(
                      controller: _textEditingController,
                      maxLines: 5,
                      // Allows the text field to expand to multiple lines
                      keyboardType: TextInputType.multiline,
                      decoration: const InputDecoration(
                        hintText: 'Enter a Summary',
                        contentPadding:
                            EdgeInsets.symmetric(vertical: 10, horizontal: 10),
                        border:
                            OutlineInputBorder(), // Aligns the hint text to the top left corner
                      ),
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 20),
            Consumer<ExpandableRowModel>(builder: (BuildContext context, ExpandableRowModel value, Widget? child) {
              return Padding(
                padding: const EdgeInsets.only(right: 10.0, left: 10, bottom: 20),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: <Widget>[
                    GestureDetector(
                      onTap: () {
                        value.toggleExpanded();
                      },
                      child: Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 10.0),
                        child: Row(
                          children: <Widget>[
                            const Icon(
                              Icons.warning_amber_outlined,
                              color: Colors.red,
                              size: 28,
                            ),
                            const SizedBox(width: 10),
                            const Text(
                              "Raise an alert for this report?",
                              style: TextStyle(
                                  fontSize: 18, fontWeight: FontWeight.w500),
                            ),
                            const Spacer(),
                            Icon(
                              color: Colors.redAccent,
                              size: 26,
                              value.expanded
                                  ? Icons.check_circle
                                  : Icons.circle_outlined,
                            ),
                          ],
                        ),
                      ),
                    ),
                    if (value.expanded) ...[
                      Padding(
                        padding: const EdgeInsets.symmetric(
                            horizontal: 20.0, vertical: 10),
                        child: RichText(
                          text: const TextSpan(
                              style: TextStyle(fontSize: 16, color: Colors.black),
                              children: [
                                TextSpan(
                                    text: 'Why are you raising this alert? ',
                                    style: TextStyle(fontSize: 16)),
                                TextSpan(
                                  text: '(Required)',
                                  style:
                                  TextStyle(color: Colors.red, fontSize: 16),
                                ),
                              ]),
                        ),
                      ),
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 10),
                        margin: const EdgeInsets.only(top: 10),
                        child: TextField(
                          controller: _alertEditingController,
                          onChanged: (text) {
                            // model.setAdditionalText(_textEditingController.text);
                            // print(_textEditingController.text);
                          },
                          maxLines: 5,
                          keyboardType: TextInputType.multiline,
                          decoration: const InputDecoration(
                            hintText: 'Leave notes about this alert',
                            contentPadding: EdgeInsets.symmetric(
                                vertical: 10, horizontal: 10),
                            border: OutlineInputBorder(
                              borderSide: BorderSide(color: Colors.red),
                            ),
                          ),
                        ),
                      ),
                    ],
                  ],
                ),
              );
            },),
            // Checked out in botton
            Padding(
              padding: const EdgeInsets.all(20.0),
              child: Container(
                  margin: const EdgeInsets.only(left: 10),
                  child: Consumer2<TaskController, VisitTypeController>(
                    builder: (BuildContext context, TaskController value, VisitTypeController visitController,
                        Widget? child) {
                      return ElevatedButton(
                        onPressed: value.isLoading?null:() async {
                          //visitHandler.getMedicationData(widget.id.toString());

                          value.toggleLoading(true);

                          if (model.expanded && _alertEditingController.text.isEmpty) {
                            showSnackBar('Note Required');
                            value.toggleLoading(false);

                            return;
                          }

                          bool check = await checkBeforeCheckOut(value);

                          if (!check) {
                            value.toggleLoading(false);
                            return;
                          }

                          //print(visitController.clientVisitMasterId + value.aAllTask.toString());
                          //bool assignTasks = await assignTaskCheck(value);
                          //return;

                          if(visitController.clientVisitMasterId!='0'){
                            bool assignTasks = await assignTaskCheck(value);
                            if (!assignTasks) {
                              notAssignTaskDoneDialog(value, model, clientData);
                            } else {
                              checkOut(model, value, clientData);
                            }
                          }else{
                            checkOut(model, value, clientData);
                          }

                          //
                        },
                        style: ButtonStyle(
                          backgroundColor:
                              MaterialStateProperty.all<Color>(Colors.indigo),
                          // Change text color
                          foregroundColor:
                              MaterialStateProperty.all<Color>(Colors.white),
                          minimumSize: MaterialStateProperty.all<Size>(
                              const Size(double.infinity, 50)),
                        ),
                        child: value.isLoading
                            ? const Center(
                                child: CircularProgressIndicator(
                                    color: Colors.white))
                            : const Text('Checked out'),
                      );
                    },
                  )),
            ),
          ],
        ),
      ),
    );
  }

  void showAlert() {
    showDialog(
        context: context,
        builder: (BuildContext context) {
          return AlertDialog(
            shape: RoundedRectangleBorder(
              // Remove rounded corners
              borderRadius: BorderRadius.circular(10),
            ),
            content: SingleChildScrollView(
              child: Container(
                width: double.infinity,
                height: 150,
                //decoration: BoxDecoration( borderRadius: BorderRadius.circular(0)),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.start,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Container(
                      alignment: Alignment.center,
                      margin: const EdgeInsets.only(bottom: 20, top: 5),
                      child: const Icon(
                        Icons.warning_amber_outlined,
                        color: color2,
                        size: 30,
                      ),
                    ),
                    const Flexible(
                      child: SingleChildScrollView(
                        child: Text(
                          "Complete At least one task to check out",
                          textAlign: TextAlign.center,
                          style: TextStyle(
                              fontSize: 16,
                              color: heading,
                              decoration: TextDecoration.none,
                              fontFamily: 'system',
                              fontWeight: FontWeight.normal),
                        ),
                      ),
                    ),
                    const SizedBox(height: 24),
                  ],
                ),
              ),
            ),
          );
        });
  }

  void showSnackBar(String s) {
    var snackBar = SnackBar(
      content: Text(s),
      duration: const Duration(seconds: 3), // Adjust the duration as needed
    );
    ScaffoldMessenger.of(context).showSnackBar(snackBar);
  }

  void checkOutNavigateToHome() {
    showSnackBar("Check out success");
    Navigator.pushReplacement(
        context, MaterialPageRoute(builder: (context) => const HomeScreen()));
  }

  Future<bool> checkBeforeCheckOut(TaskController value) async {
    bool food = await visitHandler.checkBeforeCheckOut(
        widget.id.toString(), "CMS_CARER_VISIT_FOOD");
    bool cmsCarerVisitBodyMap = await visitHandler.checkBeforeCheckOut(
        widget.id.toString(), "CMS_CARER_VISIT_BODY_MAP");
    bool cmsCarerVisitPersonalCare = await visitHandler.checkBeforeCheckOut(
        widget.id.toString(), "CMS_CARER_VISIT_PERSONAL_CARE");
    bool cmsCarerVisitUnbleDlvrDtl = await visitHandler.checkBeforeCheckOut(
        widget.id.toString(), "CMS_CARER_VISIT_UNBLE_DLVR_DTL");
    bool cmsCarerVisitHoushldChores = await visitHandler.checkBeforeCheckOut(
        widget.id.toString(), "CMS_CARER_VISIT_HOUSHLD_CHORES");
    bool cmsCarerVisitLaundry = await visitHandler.checkBeforeCheckOut(
        widget.id.toString(), "CMS_CARER_VISIT_LAUNDRY");
    bool cmsCarerVisitCmpnnshpRespt = await visitHandler.checkBeforeCheckOut(
        widget.id.toString(), "CMS_CARER_VISIT_CMPNNSHP_RESPT");
    bool cmsCarerVisitRepositioning = await visitHandler.checkBeforeCheckOut(
        widget.id.toString(), "CMS_CARER_VISIT_REPOSITIONING");
    bool cmsCarerVisitToiletAssist = await visitHandler.checkBeforeCheckOut(
        widget.id.toString(), "CMS_CARER_VISIT_TOILET_ASSIST");
    bool cmsCarerVisitHousework = await visitHandler.checkBeforeCheckOut(
        widget.id.toString(), "CMS_CARER_VISIT_HOUSEWORK");
    bool cmsCarerVisitDrinks = await visitHandler.checkBeforeCheckOut(
        widget.id.toString(), "CMS_CARER_VISIT_DRINKS");
    bool cmsCarerVisitGroceries = await visitHandler.checkBeforeCheckOut(
        widget.id.toString(), "CMS_CARER_VISIT_GROCERIES");
    bool cmsCarerVisitMedication = await visitHandler.checkBeforeCheckOut(
        widget.id.toString(), "CMS_CARER_VISIT_MEDICATION");

    if (food &&
        cmsCarerVisitBodyMap &&
        cmsCarerVisitPersonalCare &&
        cmsCarerVisitUnbleDlvrDtl &&
        cmsCarerVisitHoushldChores &&
        cmsCarerVisitLaundry &&
        cmsCarerVisitCmpnnshpRespt &&
        cmsCarerVisitRepositioning &&
        cmsCarerVisitToiletAssist &&
        cmsCarerVisitHousework &&
        cmsCarerVisitDrinks &&
        cmsCarerVisitGroceries &&
        cmsCarerVisitMedication) {
      value.toggleLoading(false);
      showAlert();
      return false;
    }

    return true;
  }

  Future<bool> assignTaskCheck(TaskController value) async {
    int count = 0;
    print(value.aAllTask);

    await Future.forEach(value.aAllTask ?? [], (element) async {
      bool temp = await visitHandler.checkBeforeCheckOut(widget.id.toString(), getTableName(element['TASK_CODE']));
      print(temp.toString());
      if (!temp) {
        count++;
      }
    });

    if (count == 0) {
      print("equal");
      return false;
    } else {
      return true;
    }
  }

  String getTableName(String taskCode) {
    switch (taskCode) {
      case "01":
        return 'CMS_CARER_VISIT_MEDICATION';
      case "02":
        return 'CMS_CARER_VISIT_BODY_MAP';
      case "03":
        return 'CMS_CARER_VISIT_FOOD';
      case "04":
        return 'CMS_CARER_VISIT_DRINKS';
      case "05":
        return 'CMS_CARER_VISIT_PERSONAL_CARE';
      case "06":
        return 'CMS_CARER_VISIT_TOILET_ASSIST';
      case "07":
        return 'CMS_CARER_VISIT_REPOSITIONING';
      case "08":
        return 'CMS_CARER_VISIT_CMPNNSHP_RESPT';
      case "09":
        return 'CMS_CARER_VISIT_LAUNDRY';
      case "10":
        return 'CMS_CARER_VISIT_GROCERIES';
      case "11":
        return 'CMS_CARER_VISIT_HOUSEWORK';
      case "12":
        return 'CMS_CARER_VISIT_HOUSHLD_CHORES';
      case "99":
        return 'CMS_CARER_VISIT_UNBLE_DLVR_DTL';
      // Add more cases as needed
      default:
        return 'assets/icons/unable_deliver.png';
    }
  }

  void notAssignTaskDoneDialog(TaskController value, ExpandableRowModel model,
      VisitTypeController clientData) {
    value.toggleLoading(false);
    showAlert2(value, model, clientData);
  }

  void showAlert2(TaskController value, ExpandableRowModel model, clientData) {
    showDialog(
        context: context,
        builder: (BuildContext context) {
          return AlertDialog(
            shape: RoundedRectangleBorder(
              // Remove rounded corners
              borderRadius: BorderRadius.circular(10),
            ),
            content: SingleChildScrollView(
              child: Container(
                width: MediaQuery.of(context).size.width * 0.9,
                height: 180,
                //decoration: BoxDecoration( borderRadius: BorderRadius.circular(0)),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.start,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Container(
                        margin: const EdgeInsets.only(top: 10, right: 10),
                        child: const Text(
                          "Note",
                          style: TextStyle(
                              fontSize: 20,
                              color: Colors.black87,
                              decoration: TextDecoration.none,
                              fontFamily: 'system',
                              fontWeight: FontWeight.bold),
                        )),
                    Flexible(
                      child: SingleChildScrollView(
                        child: Container(
                          child: const Text(
                            "No Assign task done",
                            style: TextStyle(
                                fontSize: 16,
                                color: Colors.black87,
                                decoration: TextDecoration.none,
                                fontFamily: 'system',
                                fontWeight: FontWeight.normal),
                          ),
                        ),
                      ),
                    ),
                    const SizedBox(height: 55),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                      children: [
                        Expanded(
                          child: ElevatedButton(
                              onPressed: () {
                                checkOut(model, value, clientData);
                                value.toggleLoading(true);
                                Navigator.of(context).pop();
                              },
                              child: Container(
                                padding: EdgeInsets.only(top: 5, bottom: 5),
                                child: const Text(
                                  "Confirm check out",
                                ),
                              )),
                        ),
                        const SizedBox(width: 10),
                        Expanded(
                          child: ElevatedButton(
                              onPressed: () {
                                value.toggleLoading(false);
                                Navigator.of(context).pop();
                              },
                              child: Container(
                                  padding: EdgeInsets.only(top: 5, bottom: 5),
                                  child: const Text("Continue report"))),
                        )
                      ],
                    )
                  ],
                ),
              ),
            ),
          );
        });
  }

  Future<void> checkOut(ExpandableRowModel model, TaskController value, VisitTypeController clientData) async {
    Position? position;

    try {
      LocationPermission permission = await Geolocator.checkPermission();
      if (permission == LocationPermission.denied) {
        showSnackBar('You must turn on location to check out');
      } else {
        position = await Geolocator.getCurrentPosition(
          desiredAccuracy: LocationAccuracy.high,
        );
      }
    } on PlatformException catch (e) {
      print('Error getting location: $e');
      showSnackBar('Error getting location: $e');
    } catch (e) {
      print('Unexpected error getting location: $e');
      showSnackBar('Unexpected error getting location: $e');
    }


    String checkOutTime =
        "${TimeOfDay.now().hour.toString().padLeft(2, '0')}:${TimeOfDay.now().minute.toString().padLeft(2, '0')}";

    if (model.expanded) {
      alert = 'Y';
    } else {
      alert = 'N';
    }

    visitHandler.updateCheckOut(
      getCurrentDate(),
      checkOutTime,
      position!=null?position.latitude.toString():"",
      position!=null?position.longitude.toString():"",
      widget.id.toString(),
      alert,
      _alertEditingController.text,
      getDurationFromDate(clientData.date, clientData.time).toString(),
      _textEditingController.text,
    );

    model.setUnExpanded();
    value.setAllItemsToEmpty();


    if(await uploadData()){
      await ApiHandler().downloadData();
    }

    checkOutNavigateToHome();
  }

  Future<bool> uploadData() async {

    List<Map<String, dynamic>> result = await visitHandler.getUnUploadedData();

    if (await getConnection()) {

      print(widget.id.toString());
      bool temp = false;

      await Future.forEach(result ?? [], (element) async {

        temp = await visitHandler.getAllVisitData(element['CARER_VISIT_MST_ID'].toString());

      });

      if (temp) {
        return true;
      } else {
        return false;

      }

    } else {
      showSnackBar("no internet connection");

    }

    return false;
  }

}
