import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

class TaskContainer extends StatelessWidget {
  final String title;
  final String imagePath;
  final Function() onTap;

  const TaskContainer({
    required this.title,
    required this.imagePath,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Padding(
        padding: const EdgeInsets.only(bottom: 10.0),
        child: Card(
          clipBehavior: Clip.antiAlias,
          color: Colors.blue.shade50,
          margin: const EdgeInsets.symmetric(horizontal: 5),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(16.0),
          ),
          elevation: 3,
          child: LayoutBuilder(
            builder: (context, constraints) {
              final isLandscape =
                  MediaQuery.of(context).orientation == Orientation.landscape;
              final iconHeight = isLandscape
                  ? constraints.maxHeight * 0.2
                  : MediaQuery.of(context).size.height * 0.04;
              final textSize = isLandscape
                  ? constraints.maxHeight * 0.07
                  : MediaQuery.of(context).size.height * 0.014;

              return SizedBox(
                height: MediaQuery.of(context).size.height * 0.18,
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Container(
                      margin: const EdgeInsets.only(bottom: 10),
                      child: Image.asset(
                        imagePath,
                        height: iconHeight,
                        width: iconHeight,
                      ),
                    ),
                    Text(
                      title,
                      textAlign: TextAlign.center,
                      style: TextStyle(
                        fontSize: textSize,
                      ),
                    ),
                  ],
                ),
              );
            },
          ),
        ),
      ),
    );
  }
}
