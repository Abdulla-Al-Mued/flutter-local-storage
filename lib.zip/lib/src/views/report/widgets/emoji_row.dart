import 'package:care4u/src/controls/localDatabaseHandler/local_db_handler_visit.dart';
import 'package:care4u/src/views/report/controller/emoji_controller.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:provider/provider.dart';

class EmojiRow extends StatelessWidget {

  final int visitMstrId; // Parameter to receive visitMstrId

  EmojiRow({required this.visitMstrId});

  VisitHandler handler = VisitHandler();

  @override
  Widget build(BuildContext context) {
    final emojiState = Provider.of<EmojiState>(context);
    emojiState.getEmojiStatus(visitMstrId.toString());
    return Consumer<EmojiState>(
      builder: (BuildContext context, value, Widget? child) {
        return Row(
          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
          children: [
            _buildEmoji(context, emojiState, 0, 'assets/emotions/too_sad.svg'),
            _buildEmoji(context, emojiState, 1, 'assets/emotions/sad.svg'),
            _buildEmoji(context, emojiState, 2, 'assets/emotions/nutral.svg'),
            _buildEmoji(context, emojiState, 3, 'assets/emotions/happy.svg'),
            _buildEmoji(context, emojiState, 4, 'assets/emotions/too_happy.svg'),
          ],
        );
      },

    );
  }

  Widget _buildEmoji(BuildContext context, EmojiState emojiState, int index, String assetName) {
    return GestureDetector(
      onTap: () {
        emojiState.selectEmoji(index);
        handler.updateRating(visitMstrId.toString(), index.toString());
      },
      child: SvgPicture.asset(
        assetName,
        width: 50,
        color: emojiState.selectedEmojiIndex == index ? Colors.blue : Colors.grey,
      ),
    );
  }
}