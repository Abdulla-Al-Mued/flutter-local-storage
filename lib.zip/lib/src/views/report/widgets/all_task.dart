import 'package:care4u/src/controls/utils/color_codes.dart';
import 'package:care4u/src/views/report/tasks_screen/Household.dart';
import 'package:care4u/src/views/report/tasks_screen/companionship.dart';
import 'package:care4u/src/views/report/tasks_screen/drinks_task.dart';
import 'package:care4u/src/views/report/tasks_screen/groceries.dart';
import 'package:care4u/src/views/report/tasks_screen/housework.dart';
import 'package:care4u/src/views/report/tasks_screen/laundry.dart';
import 'package:care4u/src/views/report/tasks_screen/medication/medication.dart';
import 'package:care4u/src/views/report/tasks_screen/personal_care.dart';
import 'package:care4u/src/views/report/tasks_screen/repositioning.dart';
import 'package:care4u/src/views/report/tasks_screen/toilet_assistance.dart';
import 'package:care4u/src/views/report/tasks_screen/food.dart';
import 'package:care4u/src/views/report/tasks_screen/unable.dart';
import 'package:care4u/src/views/report/widgets/single_task.dart';
import 'package:care4u/src/views/report/widgets/single_task_done.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../../models/LocalModel/LocalDpd_Cms_Carer_Cln_Dtws_Sch_Lst_Model.dart';
import '../../bodymaps/newbodymaps.dart';
import '../controller/task_controller.dart';

class AllTask extends StatefulWidget {
  final Value user;
  final int masterId;
  final String clientVisitTypeMatId;


  const AllTask(
      {super.key,
      required this.user,
      required this.masterId,
        required this.clientVisitTypeMatId
      });

  @override
  State<AllTask> createState() => _AllTaskState();
}

class _AllTaskState extends State<AllTask> {
  List<Map<String, dynamic>>? taskCode;

  @override
  void initState() {
    super.initState();
  }


  @override
  Widget build(BuildContext context) {

    final clientData = Provider.of<TaskController>(context, listen: false);
    clientData.getStatusByMstId(widget.masterId.toString());
    clientData.getAssigned(widget.clientVisitTypeMatId, widget.user.clientId!);


    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 10.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const SizedBox(
            height: 20,
          ),
          Container(
            alignment: Alignment.topLeft,
            margin: const EdgeInsets.only(left: 10, right: 10),
            child: Text(
              "How have you helped ${widget.user.clientName}?",
              style: const TextStyle(
                // fontFamily: 'PoppinsBold',
                fontSize: 18.0,
                fontWeight: FontWeight.bold,
                color: color2
              ),
            ),
          ),
          const SizedBox(
            height: 10,
          ),
          // widget.clntVisitTypeMstID != '0' ?
          //  :
          // Container(),
          Consumer<TaskController>(
            builder:
                (BuildContext context, TaskController value, Widget? child) {
              // Filter tasks based on taskCode


              return value.aAllTask!.isNotEmpty?Card(
                child: Column(
                  children: [
                
                    value.aAllTask!.isNotEmpty?Container(
                        margin: const EdgeInsets.only(top: 10),
                        padding: const EdgeInsets.all(5),
                        width: double.infinity,
                        height: 50,
                        //decoration: const BoxDecoration(color: Colors.white),
                        child: const Text(
                          'Assigned',
                          textAlign: TextAlign.center,
                          style: TextStyle(
                              color: color1,
                              fontSize: 18,
                              fontWeight: FontWeight.w700),
                        )): Container(),
                    GridView.count(
                      crossAxisCount: 3,
                      shrinkWrap: true,
                      physics: const NeverScrollableScrollPhysics(),
                      children: [
                        if (value.getTaskName("01"))
                          value.medicationStatus != "Exist"
                              ? TaskContainer(
                                  title: "Medication",
                                  imagePath: 'assets/task/medication.png',
                                  onTap: () {
                                    Navigator.push(
                                      context,
                                      MaterialPageRoute(
                                          builder: (context) => MedicationTask(
                                            taskNote:value.getTaskAssignNote('01'),
                                              masterID: widget.masterId,
                                              userInfo: widget.user)),
                                    );
                                  },
                                )
                              : TaskDoneContainer(
                                  title: "Medication",
                                  imagePath: 'assets/task/medication.png',
                                  onTap: () {
                                    Navigator.push(
                                      context,
                                      MaterialPageRoute(
                                          builder: (context) => MedicationTask(
                                              taskNote:value.getTaskAssignNote('01'),
                                              masterID: widget.masterId,
                                              userInfo: widget.user)),
                                    );
                                  },
                                ),
                        if (value.getTaskName("02"))
                          value.bodyMapStatus == '02'
                        ?TaskDoneContainer(
                            title: "Body Map",
                            imagePath: 'assets/task/bodymap.png',
                            onTap: () {
                              Navigator.push(
                                context,
                                MaterialPageRoute(
                                    builder: (context) => BodyMaps(
                                        taskNote:value.getTaskAssignNote('02'),
                                        visitMstId: widget.masterId,
                                        userInfo: widget.user)),
                              );
                            },
                          ):TaskContainer(
                            title: "Body Map",
                            imagePath: 'assets/task/bodymap.png',
                            onTap: () {
                              Navigator.push(
                                context,
                                MaterialPageRoute(
                                    builder: (context) => BodyMaps(
                                        taskNote:value.getTaskAssignNote('02'),
                                        visitMstId: widget.masterId,
                                        userInfo: widget.user)),
                              );
                            },
                          ),
                        if (value.getTaskName("03"))
                          value.status != "Y"
                              ? TaskContainer(
                                  title: "Food",
                                  imagePath: 'assets/task/food.png',
                                  onTap: () {
                                    Navigator.push(
                                      context,
                                      MaterialPageRoute(
                                          builder: (context) => FoodTaskPage(
                                              taskName: "Food",
                                              taskNote:value.getTaskAssignNote('03'),
                                              masterId: widget.masterId,
                                              userData: widget.user)),
                                    );
                                  },
                                )
                              : TaskDoneContainer(
                                  title: "Food",
                                  imagePath: 'assets/task/food.png',
                                  onTap: () {
                                    Navigator.push(
                                      context,
                                      MaterialPageRoute(
                                          builder: (context) => FoodTaskPage(
                                              taskName: "Food",
                                              taskNote:value.getTaskAssignNote('03'),
                                              masterId: widget.masterId,
                                              userData: widget.user)),
                                    );
                                  },
                                ),
                        //-------------------------> Drinks Section <---------------------------------//
                        if (value.getTaskName("04"))
                          value.drinksStatus != "Y"
                              ? TaskContainer(
                                  title: "Drinks",
                                  imagePath: 'assets/task/drinks.png',
                                  onTap: () {
                                    Navigator.push(
                                      context,
                                      MaterialPageRoute(
                                          builder: (context) => DrinksTaskPage(
                                              taskName: "Drinks",
                                              taskNote:value.getTaskAssignNote('04'),
                                              masterId: widget.masterId,
                                              userData: widget.user)),
                                    );
                                  },
                                )
                              : TaskDoneContainer(
                                  title: "Drinks",
                                  imagePath: 'assets/task/drinks.png',
                                  onTap: () {
                                    Navigator.push(
                                      context,
                                      MaterialPageRoute(
                                          builder: (context) => DrinksTaskPage(
                                              taskName: "Drinks",
                                              taskNote:value.getTaskAssignNote('04'),
                                              masterId: widget.masterId,
                                              userData: widget.user)),
                                    );
                                  },
                                ),
                        //-------------------------> Personal Care Section <---------------------------------//
                        if (value.getTaskName("05"))
                          value.careStatus != "Y"
                              ? TaskContainer(
                                  title: "Personal Care",
                                  imagePath: 'assets/task/care.png',
                                  onTap: () {
                                    Navigator.push(
                                      context,
                                      MaterialPageRoute(
                                          builder: (context) =>
                                              PersonalCareTaskPage(
                                                  taskName: "Personal Care",
                                                  taskNote:value.getTaskAssignNote('05'),
                                                  masterId: widget.masterId,
                                                  userData: widget.user)),
                                    );
                                  },
                                )
                              : TaskDoneContainer(
                                  title: "Personal Care",
                                  imagePath: 'assets/task/care.png',
                                  onTap: () {
                                    Navigator.push(
                                      context,
                                      MaterialPageRoute(
                                          builder: (context) =>
                                              PersonalCareTaskPage(
                                                  taskName: "Personal Care",
                                                  masterId: widget.masterId,
                                                  taskNote:value.getTaskAssignNote('05'),
                                                  userData: widget.user)),
                                    );
                                  },
                                ),
                
                        //-------------------------> Toilet assistance Section <---------------------------------//
                        if (value.getTaskName("06"))
                          value.toiletStatus != "Y"
                              ? TaskContainer(
                                  title: "Toilet Assistance",
                                  imagePath: 'assets/task/toilet_assistance.png',
                                  onTap: () {
                                    Navigator.push(
                                      context,
                                      MaterialPageRoute(
                                          builder: (context) => ToiletTaskPage(
                                              taskName: "Toilet Assistance",
                                              taskNote:value.getTaskAssignNote('06'),
                                              masterId: widget.masterId,
                                              userData: widget.user)),
                                    );
                                  },
                                )
                              : TaskDoneContainer(
                                  title: "Toilet Assistance",
                                  imagePath: 'assets/task/toilet_assistance.png',
                                  onTap: () {
                                    Navigator.push(
                                      context,
                                      MaterialPageRoute(
                                          builder: (context) => ToiletTaskPage(
                                              taskName: "Toilet Assistance",
                                              taskNote:value.getTaskAssignNote('06'),
                                              masterId: widget.masterId,
                                              userData: widget.user)),
                                    );
                                  },
                                ),
                        //-------------------------> Repositioning Section <---------------------------------//
                        if (value.getTaskName("07"))
                        value.repositioningStatus != "Y"
                            ? TaskContainer(
                          title: "Repositioning",
                          imagePath:
                          'assets/task/repositioning.png', // Add your image path
                          onTap: () {
                            Navigator.push(
                              context,
                              MaterialPageRoute(
                                  builder: (context) =>
                                      RepositioningTaskPage(
                                          taskNote:value.getTaskAssignNote('07'),
                                          taskName: "Repositioning",
                                          masterId: widget.masterId,
                                          userData: widget.user)),
                            );
                          },
                        )
                            : TaskDoneContainer(
                          title: "Repositioning",
                          imagePath:
                          'assets/task/repositioning.png', // Add your image path
                          onTap: () {
                            Navigator.push(
                              context,
                              MaterialPageRoute(
                                  builder: (context) =>
                                      RepositioningTaskPage(
                                          taskNote:value.getTaskAssignNote('07'),
                                          taskName: "Repositioning",
                                          masterId: widget.masterId,
                                          userData: widget.user)),
                            );
                          },
                        ),
                        //-------------------------> Companionship Section <---------------------------------//
                        if (value.getTaskName("08"))
                          value.companionshipStatus != "Y"
                              ? TaskContainer(
                                  title: "Companionship",
                                  imagePath: 'assets/task/campanionship.png',
                                  onTap: () {
                                    Navigator.push(
                                      context,
                                      MaterialPageRoute(
                                          builder: (context) =>
                                              CompanionshipTaskPage(
                                                  taskNote:value.getTaskAssignNote('08'),
                                                  taskName: "Companionship",
                                                  masterId: widget.masterId,
                                                  userData: widget.user)),
                                    );
                                  },
                                )
                              : TaskDoneContainer(
                                  title: "Companionship",
                                  imagePath: 'assets/task/campanionship.png',
                                  onTap: () {
                                    Navigator.push(
                                      context,
                                      MaterialPageRoute(
                                          builder: (context) =>
                                              CompanionshipTaskPage(
                                                  taskNote:value.getTaskAssignNote('08'),
                                                  taskName: "Companionship",
                                                  masterId: widget.masterId,
                                                  userData: widget.user)),
                                    );
                                  },
                                ),
                        //-------------------------> Laundry Section <---------------------------------//
                        if (value.getTaskName("09"))
                          value.laundryStatus != "Y"
                              ? TaskContainer(
                                  title: "Laundry",
                                  imagePath: 'assets/task/laundry.png',
                                  onTap: () {
                                    Navigator.push(
                                      context,
                                      MaterialPageRoute(
                                          builder: (context) => LaundryTaskPage(
                                              taskNote:value.getTaskAssignNote('09'),
                                              taskName: "Laundry",
                                              masterId: widget.masterId,
                                              userData: widget.user)),
                                    );
                                  },
                                )
                              : TaskDoneContainer(
                                  title: "Laundry",
                                  imagePath: 'assets/task/laundry.png',
                                  onTap: () {
                                    Navigator.push(
                                      context,
                                      MaterialPageRoute(
                                          builder: (context) => LaundryTaskPage(
                                              taskNote:value.getTaskAssignNote('09'),
                                              taskName: "Laundry",
                                              masterId: widget.masterId,
                                              userData: widget.user)),
                                    );
                                  },
                                ),
                        //-------------------------> Groceries Section <---------------------------------//
                        if (value.getTaskName("10"))
                          value.groceriesStatus != "Y"
                              ? TaskContainer(
                                  title: "Groceries",
                                  imagePath: 'assets/task/groceries.png',
                                  onTap: () {
                                    Navigator.push(
                                      context,
                                      MaterialPageRoute(
                                          builder: (context) => GroceriesTaskPage(
                                              taskNote:value.getTaskAssignNote('10'),
                                              taskName: "Groceries",
                                              masterId: widget.masterId,
                                              userData: widget.user)),
                                    );
                                  },
                                )
                              : TaskDoneContainer(
                                  title: "Groceries",
                                  imagePath: 'assets/task/groceries.png',
                                  onTap: () {
                                    Navigator.push(
                                      context,
                                      MaterialPageRoute(
                                          builder: (context) => GroceriesTaskPage(
                                              taskNote:value.getTaskAssignNote('10'),
                                              taskName: "Groceries",
                                              masterId: widget.masterId,
                                              userData: widget.user)),
                                    );
                                  },
                                ),
                        //-------------------------> Housework Section <---------------------------------//
                        if (value.getTaskName("11"))
                          value.houseworkStatus != "Y"
                              ? TaskContainer(
                                  title: "Housework",
                                  imagePath: 'assets/task/housework.png',
                                  onTap: () {
                                    Navigator.push(
                                      context,
                                      MaterialPageRoute(
                                          builder: (context) => HouseworkTaskPage(
                                              taskName: "Housework",
                                              taskNote:value.getTaskAssignNote('11'),
                                              masterId: widget.masterId,
                                              userData: widget.user)),
                                    );
                                  },
                                )
                              : TaskDoneContainer(
                                  title: "Housework",
                                  imagePath: 'assets/task/housework.png',
                                  onTap: () {
                                    Navigator.push(
                                      context,
                                      MaterialPageRoute(
                                          builder: (context) => HouseworkTaskPage(
                                              taskName: "Housework",
                                              taskNote:value.getTaskAssignNote('11'),
                                              masterId: widget.masterId,
                                              userData: widget.user)),
                                    );
                                  },
                                ),
                        //-------------------------> Household Section <---------------------------------//
                        if (value.getTaskName("12"))
                          value.householdStatus != "Y"
                              ? TaskContainer(
                                  title: "Household",
                                  imagePath: 'assets/task/household.png',
                                  onTap: () {
                                    Navigator.push(
                                      context,
                                      MaterialPageRoute(
                                          builder: (context) => HouseholdTaskPage(
                                              taskNote:value.getTaskAssignNote('12'),
                                              taskName: "Household",
                                              masterId: widget.masterId,
                                              userData: widget.user)),
                                    );
                                  },
                                )
                              : TaskDoneContainer(
                                  title: "Household",
                                  imagePath: 'assets/task/household.png',
                                  onTap: () {
                                    Navigator.push(
                                      context,
                                      MaterialPageRoute(
                                          builder: (context) => HouseholdTaskPage(
                                              taskNote:value.getTaskAssignNote('12'),
                                              taskName: "Household",
                                              masterId: widget.masterId,
                                              userData: widget.user)),
                                    );
                                  },
                                ),
                        //-------------------------> Unable Section <---------------------------------//
                        if (value.getTaskName("99"))
                          value.unableStatus != "Y"
                              ? TaskContainer(
                                  title: "Unable",
                                  imagePath: 'assets/task/unable_deliver.png',
                                  onTap: () {
                                    Navigator.push(
                                      context,
                                      MaterialPageRoute(
                                          builder: (context) => UnableTaskPage(
                                              taskNote:value.getTaskAssignNote('99'),
                                              taskName: "Unable",
                                              masterId: widget.masterId,
                                              userData: widget.user)),
                                    );
                                  },
                                )
                              : TaskDoneContainer(
                                  title: "Unable",
                                  imagePath: 'assets/task/unable_deliver.png',
                                  onTap: () {
                                    Navigator.push(
                                      context,
                                      MaterialPageRoute(
                                          builder: (context) => UnableTaskPage(
                                              taskNote:value.getTaskAssignNote('99'),
                                              taskName: "Unable",
                                              masterId: widget.masterId,
                                              userData: widget.user)),
                                    );
                                  },
                                ),
                      ],
                    ),
                  ],
                ),
              ):Container();
            },
          ),
          const SizedBox(height: 20),

          Consumer<TaskController>(
            builder:
                (BuildContext context, TaskController value, Widget? child) {
                  // Filter tasks based on taskCode
              return Card(

                child: Column(
                  children: [
                    Container(
                        margin: const EdgeInsets.only(top: 10),
                        padding: const EdgeInsets.all(5),
                        width: double.infinity,
                        height: 50,
                        //decoration: const BoxDecoration(color: Colors.white),
                        child: const Text(
                          'Non Assigned',
                          textAlign: TextAlign.center,
                          style: TextStyle(
                              color: color1,
                              fontSize: 18,
                              fontWeight: FontWeight.w700),
                        )),
                    GridView.count(
                      crossAxisCount: 3,
                      shrinkWrap: true,
                      physics: const NeverScrollableScrollPhysics(),
                      children: [
                        if (!value.getTaskName("01"))
                          value.medicationStatus != "Exist"
                              ? TaskContainer(
                            title: "Medication",
                            imagePath: 'assets/task/medication.png',
                            onTap: () {
                              Navigator.push(
                                context,
                                MaterialPageRoute(
                                    builder: (context) => MedicationTask(
                                        taskNote:'',
                                        masterID: widget.masterId,
                                        userInfo: widget.user)),
                              );
                            },
                          )
                              : TaskDoneContainer(
                            title: "Medication",
                            imagePath: 'assets/task/medication.png',
                            onTap: () {
                              Navigator.push(
                                context,
                                MaterialPageRoute(
                                    builder: (context) => MedicationTask(
                                        taskNote:'',
                                        masterID: widget.masterId,
                                        userInfo: widget.user)),
                              );
                            },
                          ),
                        if (!value.getTaskName("02"))
                          value.bodyMapStatus == '02'
                              ?TaskDoneContainer(
                            title: "Body Map",
                            imagePath: 'assets/task/bodymap.png',
                            onTap: () {
                              Navigator.push(
                                context,
                                MaterialPageRoute(
                                    builder: (context) => BodyMaps(
                                        taskNote:value.getTaskAssignNote('02'),
                                        visitMstId: widget.masterId,
                                        userInfo: widget.user)),
                              );
                            },
                          ):TaskContainer(
                            title: "Body Map",
                            imagePath: 'assets/task/bodymap.png',
                            onTap: () {
                              Navigator.push(
                                context,
                                MaterialPageRoute(
                                    builder: (context) => BodyMaps(
                                        taskNote:value.getTaskAssignNote('02'),
                                        visitMstId: widget.masterId,
                                        userInfo: widget.user)),
                              );
                            },
                          ),
                        if (!value.getTaskName("03"))
                          value.status != "Y"
                              ? TaskContainer(
                            title: "Food",
                            imagePath: 'assets/task/food.png',
                            onTap: () {
                              Navigator.push(
                                context,
                                MaterialPageRoute(
                                    builder: (context) => FoodTaskPage(
                                        taskNote:'',
                                        taskName: "Food",
                                        masterId: widget.masterId,
                                        userData: widget.user)),
                              );
                            },
                          )
                              : TaskDoneContainer(
                            title: "Food",
                            imagePath: 'assets/task/food.png',
                            onTap: () {
                              Navigator.push(
                                context,
                                MaterialPageRoute(
                                    builder: (context) => FoodTaskPage(
                                        taskNote:'',
                                        taskName: "Food",
                                        masterId: widget.masterId,
                                        userData: widget.user)),
                              );
                            },
                          ),
                        //-------------------------> Drinks Section <---------------------------------//
                        if (!value.getTaskName("04"))
                          value.drinksStatus != "Y"
                              ? TaskContainer(
                            title: "Drinks",
                            imagePath: 'assets/task/drinks.png',
                            onTap: () {
                              Navigator.push(
                                context,
                                MaterialPageRoute(
                                    builder: (context) => DrinksTaskPage(
                                        taskNote:'',
                                        taskName: "Drinks",
                                        masterId: widget.masterId,
                                        userData: widget.user)),
                              );
                            },
                          )
                              : TaskDoneContainer(
                            title: "Drinks",
                            imagePath: 'assets/task/drinks.png',
                            onTap: () {
                              Navigator.push(
                                context,
                                MaterialPageRoute(
                                    builder: (context) => DrinksTaskPage(
                                        taskNote:'',
                                        taskName: "Drinks",
                                        masterId: widget.masterId,
                                        userData: widget.user)),
                              );
                            },
                          ),
                        //-------------------------> Personal Care Section <---------------------------------//
                        if (!value.getTaskName("05"))
                          value.careStatus != "Y"
                              ? TaskContainer(
                            title: "Personal Care",
                            imagePath: 'assets/task/care.png',
                            onTap: () {
                              Navigator.push(
                                context,
                                MaterialPageRoute(
                                    builder: (context) =>
                                        PersonalCareTaskPage(
                                            taskNote:'',
                                            taskName: "Personal Care",
                                            masterId: widget.masterId,
                                            userData: widget.user)),
                              );
                            },
                          )
                              : TaskDoneContainer(
                            title: "Personal Care",
                            imagePath: 'assets/task/care.png',
                            onTap: () {
                              Navigator.push(
                                context,
                                MaterialPageRoute(
                                    builder: (context) =>
                                        PersonalCareTaskPage(
                                            taskNote:'',
                                            taskName: "Personal Care",
                                            masterId: widget.masterId,
                                            userData: widget.user)),
                              );
                            },
                          ),

                        //-------------------------> Toilet assistance Section <---------------------------------//
                        if (!value.getTaskName("06"))
                          value.toiletStatus != "Y"
                              ? TaskContainer(
                            title: "Toilet Assistance",
                            imagePath: 'assets/task/toilet_assistance.png',
                            onTap: () {
                              Navigator.push(
                                context,
                                MaterialPageRoute(
                                    builder: (context) => ToiletTaskPage(
                                        taskNote:'',
                                        taskName: "Toilet Assistance",
                                        masterId: widget.masterId,
                                        userData: widget.user)),
                              );
                            },
                          )
                              : TaskDoneContainer(
                            title: "Toilet Assistance",
                            imagePath: 'assets/task/toilet_assistance.png',
                            onTap: () {
                              Navigator.push(
                                context,
                                MaterialPageRoute(
                                    builder: (context) => ToiletTaskPage(
                                        taskNote:'',
                                        taskName: "Toilet Assistance",
                                        masterId: widget.masterId,
                                        userData: widget.user)),
                              );
                            },
                          ),
                        //-------------------------> Repositioning Section <---------------------------------//
                        if (!value.getTaskName("07"))
                          value.repositioningStatus != "Y"
                              ? TaskContainer(
                            title: "Repositioning",
                            imagePath:
                            'assets/task/repositioning.png', // Add your image path
                            onTap: () {
                              Navigator.push(
                                context,
                                MaterialPageRoute(
                                    builder: (context) =>
                                        RepositioningTaskPage(
                                            taskNote:'',
                                            taskName: "Repositioning",
                                            masterId: widget.masterId,
                                            userData: widget.user)),
                              );
                            },
                          )
                              : TaskDoneContainer(
                            title: "Repositioning",
                            imagePath:
                            'assets/task/repositioning.png', // Add your image path
                            onTap: () {
                              Navigator.push(
                                context,
                                MaterialPageRoute(
                                    builder: (context) =>
                                        RepositioningTaskPage(
                                            taskNote:'',
                                            taskName: "Repositioning",
                                            masterId: widget.masterId,
                                            userData: widget.user)),
                              );
                            },
                          ),
                        //-------------------------> Companionship Section <---------------------------------//
                        if (!value.getTaskName("08"))
                          value.companionshipStatus != "Y"
                              ? TaskContainer(
                            title: "Companionship",
                            imagePath: 'assets/task/campanionship.png',
                            onTap: () {
                              Navigator.push(
                                context,
                                MaterialPageRoute(
                                    builder: (context) =>
                                        CompanionshipTaskPage(
                                            taskNote:'',
                                            taskName: "Companionship",
                                            masterId: widget.masterId,
                                            userData: widget.user)),
                              );
                            },
                          )
                              : TaskDoneContainer(
                            title: "Companionship",
                            imagePath: 'assets/task/campanionship.png',
                            onTap: () {
                              Navigator.push(
                                context,
                                MaterialPageRoute(
                                    builder: (context) =>
                                        CompanionshipTaskPage(
                                            taskNote:'',
                                            taskName: "Companionship",
                                            masterId: widget.masterId,
                                            userData: widget.user)),
                              );
                            },
                          ),
                        //-------------------------> Laundry Section <---------------------------------//
                        if (!value.getTaskName("09"))
                          value.laundryStatus != "Y"
                              ? TaskContainer(
                            title: "Laundry",
                            imagePath: 'assets/task/laundry.png',
                            onTap: () {
                              Navigator.push(
                                context,
                                MaterialPageRoute(
                                    builder: (context) => LaundryTaskPage(
                                        taskNote:'',
                                        taskName: "Laundry",
                                        masterId: widget.masterId,
                                        userData: widget.user)),
                              );
                            },
                          )
                              : TaskDoneContainer(
                            title: "Laundry",
                            imagePath: 'assets/task/laundry.png',
                            onTap: () {
                              Navigator.push(
                                context,
                                MaterialPageRoute(
                                    builder: (context) => LaundryTaskPage(
                                        taskNote:'',
                                        taskName: "Laundry",
                                        masterId: widget.masterId,
                                        userData: widget.user)),
                              );
                            },
                          ),
                        //-------------------------> Groceries Section <---------------------------------//
                        if (!value.getTaskName("10"))
                          value.groceriesStatus != "Y"
                              ? TaskContainer(
                            title: "Groceries",
                            imagePath: 'assets/task/groceries.png',
                            onTap: () {
                              Navigator.push(
                                context,
                                MaterialPageRoute(
                                    builder: (context) => GroceriesTaskPage(
                                        taskNote:'',
                                        taskName: "Groceries",
                                        masterId: widget.masterId,
                                        userData: widget.user)),
                              );
                            },
                          )
                              : TaskDoneContainer(
                            title: "Groceries",
                            imagePath: 'assets/task/groceries.png',
                            onTap: () {
                              Navigator.push(
                                context,
                                MaterialPageRoute(
                                    builder: (context) => GroceriesTaskPage(
                                        taskNote:'',
                                        taskName: "Groceries",
                                        masterId: widget.masterId,
                                        userData: widget.user)),
                              );
                            },
                          ),
                        //-------------------------> Housework Section <---------------------------------//
                        if (!value.getTaskName("11"))
                          value.houseworkStatus != "Y"
                              ? TaskContainer(
                            title: "Housework",
                            imagePath: 'assets/task/housework.png',
                            onTap: () {
                              Navigator.push(
                                context,
                                MaterialPageRoute(
                                    builder: (context) => HouseworkTaskPage(
                                        taskNote:'',
                                        taskName: "Housework",
                                        masterId: widget.masterId,
                                        userData: widget.user)),
                              );
                            },
                          )
                              : TaskDoneContainer(
                            title: "Housework",
                            imagePath: 'assets/task/housework.png',
                            onTap: () {
                              Navigator.push(
                                context,
                                MaterialPageRoute(
                                    builder: (context) => HouseworkTaskPage(
                                        taskNote:'',
                                        taskName: "Housework",
                                        masterId: widget.masterId,
                                        userData: widget.user)),
                              );
                            },
                          ),
                        //-------------------------> Household Section <---------------------------------//
                        if (!value.getTaskName("12"))
                          value.householdStatus != "Y"
                              ? TaskContainer(
                            title: "Household",
                            imagePath: 'assets/task/household.png',
                            onTap: () {
                              Navigator.push(
                                context,
                                MaterialPageRoute(
                                    builder: (context) => HouseholdTaskPage(
                                        taskNote:'',
                                        taskName: "Household",
                                        masterId: widget.masterId,
                                        userData: widget.user)),
                              );
                            },
                          )
                              : TaskDoneContainer(
                            title: "Household",
                            imagePath: 'assets/task/household.png',
                            onTap: () {
                              Navigator.push(
                                context,
                                MaterialPageRoute(
                                    builder: (context) => HouseholdTaskPage(
                                        taskNote:'',
                                        taskName: "Household",
                                        masterId: widget.masterId,
                                        userData: widget.user)),
                              );
                            },
                          ),
                        //-------------------------> Unable Section <---------------------------------//
                        if (!value.getTaskName("99"))
                          value.unableStatus != "Y"
                              ? TaskContainer(
                            title: "Unable",
                            imagePath: 'assets/task/unable_deliver.png',
                            onTap: () {
                              Navigator.push(
                                context,
                                MaterialPageRoute(
                                    builder: (context) => UnableTaskPage(
                                        taskNote:'',
                                        taskName: "Unable",
                                        masterId: widget.masterId,
                                        userData: widget.user)),
                              );
                            },
                          )
                              : TaskDoneContainer(
                            title: "Unable",
                            imagePath: 'assets/task/unable_deliver.png',
                            onTap: () {
                              Navigator.push(
                                context,
                                MaterialPageRoute(
                                    builder: (context) => UnableTaskPage(
                                        taskNote:'',
                                        taskName: "Unable",
                                        masterId: widget.masterId,
                                        userData: widget.user)),
                              );
                            },
                          ),
                      ],
                    ),
                  ],
                ),
              );
            },
          ),
        ],
      ),
    );
  }
}
