import 'package:flutter/material.dart';

import '../../../../controls/utils/color_codes.dart';

ButtonStyle taskButtonSaveStyle(){

  return ButtonStyle(
    // Change background color
    backgroundColor: MaterialStateProperty
        .all<Color>(primaryColor),
    // Change text color
    foregroundColor: MaterialStateProperty
        .all<Color>(Colors.white),
    minimumSize: MaterialStateProperty.all<
        Size>(
        const Size(double.infinity, 50)),
  );
}
ButtonStyle taskButtonRemoveStyle(){

  return ButtonStyle(
    // Change background color
    backgroundColor: MaterialStateProperty
        .all<Color>(Colors.red),
    // Change text color
    foregroundColor: MaterialStateProperty
        .all<Color>(Colors.white),
    minimumSize: MaterialStateProperty.all<
        Size>(
        const Size(double.infinity, 50)),
  );
}
