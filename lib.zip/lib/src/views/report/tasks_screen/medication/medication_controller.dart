import 'package:care4u/src/controls/localDatabaseHandler/local_db_handler_medication.dart';
import 'package:flutter/cupertino.dart';

import '../../../../models/insertion/Medication.dart';

class MedicationController extends ChangeNotifier{

  List<Map<String, dynamic>>? morningMed = [];
  List<Map<String, dynamic>>? lunchMed = [];
  List<Map<String, dynamic>>? eveningMed = [];
  List<Map<String, dynamic>>? bedTimeMed = [];
  List<Map<String, dynamic>>? asNeededMed = [];
  List<CarerVisitMedication> morningList = [];
  List<int> indexMorningList = [];

  List<CarerVisitMedication> lunchTimeList = [];
  List<int> indexLunchTimeList = [];

  List<CarerVisitMedication> eveningList = [];
  List<int> indexEveningList = [];

  List<CarerVisitMedication> bedTimeList = [];
  List<int> indexBedTimeList = [];

  List<CarerVisitMedication> asNeededList = [];
  List<int> indexAsNeededList = [];

  final MedicationHandler dbHandler = MedicationHandler();

  Map<int, String> textFieldsData = {};
  Map<int, String> temp = {};
  late String test = "no";

  Future<void> getMedicationLunchSchedules(int clientId,String masterId) async {

    List<Map<String, dynamic>>? data0 = await dbHandler.getMedicationSchedules(clientId, masterId);
    print("Morning Med");
    if (data0.isNotEmpty) {
      morningMed = data0;
      //print("deleted "+data['FRONT_HEAD_NECK']);
    }
    else{

      print("data Empty");
    }

    List<Map<String, dynamic>>? data = await dbHandler.getMedicationLunchSchedules(clientId, masterId);
    if (data.isNotEmpty) {
      lunchMed = data;
      //print("deleted "+data['FRONT_HEAD_NECK']);
    }
    else{

      print("data Empty");
    }
    List<Map<String, dynamic>>? data1 = await dbHandler.getMedicationEveningSchedules(clientId, masterId);
    if (data1.isNotEmpty) {
      eveningMed = data1;
      //print("deleted "+data['FRONT_HEAD_NECK']);
    }
    else{

      print("data Empty");
    }
    List<Map<String, dynamic>>? data2 = await dbHandler.getMedicationBedTimeSchedules(clientId, masterId);
    if (data2.isNotEmpty) {
      bedTimeMed = data2;
      //print("deleted "+data['FRONT_HEAD_NECK']);
    }
    else{

      print("data Empty");
    }
    List<Map<String, dynamic>>? data3 = await dbHandler.getMedicationAsNeededSchedules(clientId, masterId);
    if (data3.isNotEmpty) {
      asNeededMed = data3;
      //print("deleted "+data['FRONT_HEAD_NECK']);
    }
    else{

      print("data Empty");
    }

    notifyListeners();

  }




}