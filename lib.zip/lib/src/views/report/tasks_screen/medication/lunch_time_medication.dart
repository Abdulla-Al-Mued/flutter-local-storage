import 'package:care4u/src/views/report/tasks_screen/medication/medication.dart';
import 'package:flutter/material.dart';
import '../../../../controls/utils/Tools.dart';

class MedicationTileLunchTime extends StatefulWidget {
  final String time;
  final int? medsCount;
  final IconData leadingIcon;
  final List<Map<String, dynamic>> data;
  final List<TextEditingController> areaController;
  final List<FocusNode> focusNode;
  final int visitMstId;

  const MedicationTileLunchTime(
      {Key? key,
      required this.time,
      this.medsCount,
      required this.leadingIcon,
      required this.data,
      required this.areaController,
      required this.focusNode,
      required this.visitMstId})
      : super(key: key);

  @override
  State<MedicationTileLunchTime> createState() => _MedicationTileState();
}

class _MedicationTileState extends State<MedicationTileLunchTime> {
  @override
  void initState() {
    super.initState();
  }

  @override
  void dispose() {
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    //widget.areaController.clear();

    return widget.medsCount != null && widget.medsCount != 0
        ? Container(
            padding: const EdgeInsets.symmetric(vertical: 5, horizontal: 5),
            margin: const EdgeInsets.symmetric(vertical: 10, horizontal: 10),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(40),
              color: Colors.white,
            ),
            child: Theme(
              data:
                  Theme.of(context).copyWith(dividerColor: Colors.transparent),
              child: ExpansionTile(
                leading: Icon(widget.leadingIcon),
                title: Text(
                  '${widget.time} (${(widget.medsCount != null && widget.medsCount != 0) ? widget.medsCount! : 'No'} meds)',
                  style: const TextStyle(
                    fontFamily: 'PoppinsMedium',
                  ),
                ),
                children: <Widget>[
                  Column(
                    children: List.generate(
                      widget.medsCount!,
                      (index) => MedicationCardLunchTime(
                          data: widget.data[index],
                          visitMstId: widget.visitMstId,
                          controller: widget.areaController,
                          focusNode: widget.focusNode,
                          index: index),
                    ),
                  ),
                ],
              ),
            ),
          )
        : Container(
            padding: const EdgeInsets.symmetric(vertical: 5, horizontal: 5),
            margin: const EdgeInsets.symmetric(vertical: 10, horizontal: 10),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(40),
              color: Colors.white,
            ),
            child: ListTile(
              leading: Icon(widget.leadingIcon),
              title: Text(
                '${widget.time} (No meds)',
                style: const TextStyle(
                  color: Colors.grey,
                  fontFamily: 'PoppinsMedium',
                ),
              ),
            ),
          );
  }
}

class MedicationCardLunchTime extends StatefulWidget {
  final Map<String, dynamic> data;
  final List<TextEditingController> controller;
  final int index;
  final int visitMstId;
  final List<FocusNode> focusNode;

  const MedicationCardLunchTime(
      {Key? key,
      required this.data,
      required this.controller,
      required this.index,
      required this.focusNode,
      required,
      required this.visitMstId})
      : super(key: key);

  @override
  State<MedicationCardLunchTime> createState() => _MedicationCardState();
}

class _MedicationCardState extends State<MedicationCardLunchTime> {
  bool _isNotTakenExpanded = false;
  bool _isTakenExpanded = false;

  @override
  void initState() {
// TODO: implement initState
    super.initState();
    _isTakenExpanded = widget.data['TAKEN_STATUS'] == 'Y' ? true : false;
    _isNotTakenExpanded = widget.data['NOT_TAKEN_STATUS'] == 'Y' ? true : false;
  }

  void _toggleNotTakenExpanded() {
    widget.focusNode[widget.index].requestFocus();
    setState(() {
      _isNotTakenExpanded = !_isNotTakenExpanded;
      _isTakenExpanded = false;
    });

    if (_isNotTakenExpanded) {
      MedicationTask.carerVisitLunchMedList[widget.index].notTakenStatus = 'Y';
      MedicationTask.carerVisitLunchMedList[widget.index].takenStatus = null;
    } else if (!_isNotTakenExpanded) {
      MedicationTask.carerVisitLunchMedList[widget.index].notTakenStatus = null;
    }
    MedicationTask.carerVisitLunchMedList[widget.index].dataCapturedDate =
        getCurrentDate();
    MedicationTask.carerVisitLunchMedList[widget.index].dataCapturedTime =
        "${DateTime.now().hour.toString().padLeft(2, '0')}:${DateTime.now().minute.toString().padLeft(2, '0')}";
  }

  void _toggleTakenExpanded() {
    widget.focusNode[widget.index].requestFocus();
    setState(() {
      _isTakenExpanded = !_isTakenExpanded;
      _isNotTakenExpanded = false;
    });

    if (_isTakenExpanded) {
      MedicationTask.carerVisitLunchMedList[widget.index].takenStatus = 'Y';
      MedicationTask.carerVisitLunchMedList[widget.index].notTakenStatus = null;
    } else if (!_isTakenExpanded) {
      MedicationTask.carerVisitLunchMedList[widget.index].takenStatus = null;
    }
    MedicationTask.carerVisitLunchMedList[widget.index].dataCapturedDate =
        getCurrentDate();
    MedicationTask.carerVisitLunchMedList[widget.index].dataCapturedTime =
        "${DateTime.now().hour.toString().padLeft(2, '0')}:${DateTime.now().minute.toString().padLeft(2, '0')}";
  }

  String getVisitDay(Map<String, dynamic> medication) {
    String visitDay = "";

    if (medication['MONDAY_SCHEDULE'] == 'Y') {
      visitDay = "Monday" + ", " + visitDay;
    }
    if (medication['TUESDAY_SCHEDULE'] == 'Y') {
      visitDay = "Tuesday" + ", " + visitDay;
    }
    if (medication['WEDNESDAY_SCHEDULE'] == 'Y') {
      visitDay = "Wednesday" + ", " + visitDay;
    }
    if (medication['THURSDAY_SCHEDULE'] == 'Y') {
      visitDay = "Thursday" + ", " + visitDay;
    }
    if (medication['FRIDAY_SCHEDULE'] == 'Y') {
      visitDay = "Friday" + ", " + visitDay;
    }
    if (medication['SATURDAY_SCHEDULE'] == 'Y') {
      visitDay = "Saturday" + ", " + visitDay;
    }
    if (medication['SUNDAY_SCHEDULE'] == 'Y') {
      visitDay = "Sunday" + ", " + visitDay;
    }
    if (visitDay.isEmpty) {
      return "No Visiting Time Found";
    } else {
      return visitDay;
    }
  }

  @override
  Widget build(BuildContext context) {
    widget.controller[widget.index].value = TextEditingValue(
      text: widget.data['NOT_TAKEN_REMARKS'] ??
          widget.data['TAKEN_REMARKS'] ??
          '', // Set text from data
// selection: TextSelection.collapsed(offset: widget.data['NOT_TAKEN_REMARKS'].length
//     .length), // Move cursor to the end
    );

    return Padding(
      padding: const EdgeInsets.only(bottom: 8.0, left: 8, right: 8),
      child: Container(
        color: Colors.white,
        child: Padding(
          padding: const EdgeInsets.all(10.0),
          child: Form(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  widget.data['MEDICATION_NAME'],
                  style: const TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  widget.data['DOSAGE'],
                  style: const TextStyle(
                    color: Colors.grey,
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  getVisitDay(widget.data),
                  style: const TextStyle(
                    fontStyle: FontStyle.italic,
                  ),
                ),
                const SizedBox(height: 8),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: [
                    Expanded(
                      child: GestureDetector(
                        onTap: _toggleNotTakenExpanded,
                        child: Container(
                          decoration: BoxDecoration(
                            border: Border.all(color: Colors.red),
                            borderRadius: BorderRadius.circular(40),
                            color: _isNotTakenExpanded
                                ? Colors.red
                                : Colors.transparent,
                          ),
                          padding: const EdgeInsets.symmetric(
                              vertical: 8, horizontal: 12),
                          child: Text(
                            'Not taken',
                            textAlign: TextAlign.center,
                            style: TextStyle(
                              color: _isNotTakenExpanded
                                  ? Colors.white
                                  : Colors.red,
                            ),
                          ),
                        ),
                      ),
                    ),
                    const SizedBox(width: 8),
                    Expanded(
                      child: GestureDetector(
                        onTap: _toggleTakenExpanded,
                        child: Container(
                          decoration: BoxDecoration(
                            border: Border.all(color: Colors.green),
                            borderRadius: BorderRadius.circular(40),
                            color: _isTakenExpanded
                                ? Colors.green
                                : Colors.transparent,
                          ),
                          padding: const EdgeInsets.symmetric(
                              vertical: 8, horizontal: 12),
                          child: Text(
                            'Taken',
                            textAlign: TextAlign.center,
                            style: TextStyle(
                              color: _isTakenExpanded
                                  ? Colors.white
                                  : Colors.green,
                            ),
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
                if (_isNotTakenExpanded) ...[
                  const SizedBox(height: 8),
                  const Text(
                    'Why was this not taken?',
                    style: TextStyle(
                      color: Colors.red,
                    ),
                  ),
                  const SizedBox(height: 4),
                ],
                if (_isTakenExpanded) ...[
                  const SizedBox(height: 8),
                  const Text('Notes (optional)'),
                  const SizedBox(height: 4),
                ],
                if (_isNotTakenExpanded || _isTakenExpanded) ...[
                  TextFormField(
                    controller: widget.controller[widget.index],
                    focusNode: widget.focusNode[widget.index],
                    decoration: const InputDecoration(
                      border: OutlineInputBorder(),
                    ),
                    onTapOutside: (event) {},
                    onChanged: (value) {
                      for (int i = 0; i < widget.controller.length; i++) {
                        var value = widget.controller[widget.index].text;

                        if (_isTakenExpanded) {
                          MedicationTask.carerVisitLunchMedList[widget.index]
                              .takenStatus = 'Y';
                          MedicationTask.carerVisitLunchMedList[widget.index]
                              .takenRemarks = value;
                          MedicationTask.carerVisitLunchMedList[widget.index]
                              .notTakenStatus = null;
                          MedicationTask.carerVisitLunchMedList[widget.index]
                              .notTakenRemarks = null;
                          MedicationTask.carerVisitLunchMedList[widget.index]
                              .dataCapturedDate = getCurrentDate();
                          MedicationTask.carerVisitLunchMedList[widget.index]
                                  .dataCapturedTime =
                              "${DateTime.now().hour.toString().padLeft(2, '0')}:${DateTime.now().minute.toString().padLeft(2, '0')}";
                        } else if (_isNotTakenExpanded) {
                          MedicationTask.carerVisitLunchMedList[widget.index]
                              .notTakenStatus = 'Y';
                          MedicationTask.carerVisitLunchMedList[widget.index]
                              .notTakenRemarks = value;
                          MedicationTask.carerVisitLunchMedList[widget.index]
                              .takenStatus = null;
                          MedicationTask.carerVisitLunchMedList[widget.index]
                              .takenRemarks = null;
                          MedicationTask.carerVisitLunchMedList[widget.index]
                              .dataCapturedDate = getCurrentDate();
                          MedicationTask.carerVisitLunchMedList[widget.index]
                                  .dataCapturedTime =
                              "${DateTime.now().hour.toString().padLeft(2, '0')}:${DateTime.now().minute.toString().padLeft(2, '0')}";
                        }
                      }
                    },
                  ),
                ],
                const SizedBox(height: 8),
                Padding(
                  padding: const EdgeInsets.symmetric(vertical: 8.0),
                  child: Text(
                    'Last report as Taken, 10 days ago, by Nasir Uddin Babor',
                    style: TextStyle(
                      color: Colors.grey.shade400,
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
