import 'package:care4u/src/controls/localDatabaseHandler/local_db_handler_medication.dart';
import 'package:care4u/src/controls/utils/Tools.dart';
import 'package:care4u/src/controls/utils/color_codes.dart';
import 'package:care4u/src/views/report/tasks_screen/medication/medication_controller.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../../../controls/localStorage/local_storage.dart';
import '../../../../models/LocalModel/LocalDpd_Cms_Carer_Cln_Dtws_Sch_Lst_Model.dart';
import '../../../../models/insertion/Medication.dart';
import '../../controller/task_controller.dart';
import 'as_needed_medication.dart';
import 'bed_time_medication.dart';
import 'evening_medication.dart';
import 'lunch_time_medication.dart';

class MedicationTask extends StatelessWidget {
  int masterID;
  Value userInfo;
  String taskNote;
  static List<CarerVisitMedication> carerVisitMedList = [];
  static List<CarerVisitMedication> carerVisitLunchMedList = [];
  static List<CarerVisitMedication> carerVisitEveningMedList = [];
  static List<CarerVisitMedication> carerVisitBedTimeList = [];
  static List<CarerVisitMedication> carerVisitAsNeededMedList = [];

  MedicationTask(
      {super.key,
      required this.masterID,
      required this.userInfo,
      required this.taskNote});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.grey.shade200,
      appBar: AppBar(
        centerTitle: true,
        backgroundColor: Theme.of(context).colorScheme.primary,
        title: const Text(
          'Medications',
          style: TextStyle(
            color: Colors.white,
            fontFamily: 'PoppinsBold',
            fontWeight: FontWeight.w800,
          ),
        ),
        iconTheme: const IconThemeData(color: Colors.white),
      ),
      body: MedicationList(
          userInfo: userInfo, visitMstId: masterID, taskNote: taskNote),
    );
  }
}

class MedicationList extends StatefulWidget {
  final Value userInfo;
  final int visitMstId;
  String taskNote;

  MedicationList(
      {Key? key,
      required this.userInfo,
      required this.visitMstId,
      required this.taskNote})
      : super(key: key);

  @override
  State<MedicationList> createState() => _MedicationListState();
}

class _MedicationListState extends State<MedicationList> {
  List<TextEditingController> areaController = [];
  List<FocusNode> _focusNode = [];
  List<TextEditingController> areaControllerLunchTime = [];
  List<FocusNode> _focusNodeLunchTime = [];
  List<TextEditingController> controllerEvening = [];
  List<FocusNode> _focusNodeEvening = [];
  List<TextEditingController> controllerBedTime = [];
  List<FocusNode> _focusNodeBedTime = [];
  List<TextEditingController> controllerAsNeeded = [];
  List<FocusNode> _focusNodeAsNeeded = [];
  MedicationHandler handler = MedicationHandler();
  LocalStorage localStorage = LocalStorage();

  @override
  void dispose() {
    // TODO: implement dispose
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final medication =
        Provider.of<MedicationController>(context, listen: false);
    final taskController = Provider.of<TaskController>(context, listen: false);

    medication.getMedicationLunchSchedules(
        int.parse(widget.userInfo.clientId!), widget.visitMstId.toString());

    return Consumer<MedicationController>(
      builder:
          (BuildContext context, MedicationController value, Widget? child) {
        print("build provider");

        controllerAsNeeded.clear();
        controllerBedTime.clear();
        controllerEvening.clear();
        areaControllerLunchTime.clear();
        areaController.clear();
        controllers(value);
        focusNode(value);
        MedicationTask.carerVisitMedList.clear();
        MedicationTask.carerVisitBedTimeList.clear();
        MedicationTask.carerVisitAsNeededMedList.clear();
        MedicationTask.carerVisitEveningMedList.clear();
        MedicationTask.carerVisitLunchMedList.clear();

        tempMorningList(value);
        tempLunchList(value);
        tempEveningList(value);
        tempBedTimeList(value);
        tempAsNeededList(value);

        //handler.isIdExist(carerVisitMedicationId);

        return Column(
          children: [
            Expanded(
                child: ListView(
              children: [
                widget.taskNote.isNotEmpty?Card(
                  color: Colors.white,
                  margin: const EdgeInsets.only(bottom: 20,top: 30, left: 15, right: 15),
                  elevation: 5,
                  child: Container(
                    margin: EdgeInsets.all(10),
                    child: Column(
                      children: [
                        Container(
                          margin: EdgeInsets.only(top: 5, bottom: 10),
                          child: Column(
                            children: [
                              const Text(
                                "Assign Note",
                                textAlign: TextAlign.center,
                                style: TextStyle(
                                    color: primaryColor,
                                    fontSize: 18,
                                    fontWeight: FontWeight.w700
                                ),
                              ),
                              Container(
                                color: primaryColor,
                                height: 1.7,
                                width: 120,
                              )
                            ],
                          ),
                        ),
                        Text(
                          widget.taskNote,
                          style: const TextStyle(
                              fontSize: 16,
                              color: primaryColor2
                          ),
                        ),
                      ],
                    ),
                  ),
                ) : Container(),
                MedicationTile(
                    time: 'Morning',
                    visitMstId: widget.visitMstId,
                    medsCount: value.morningMed?.length,
                    leadingIcon: Icons.wb_twilight_sharp,
                    data: value.morningMed!,
                    areaController: areaController,
                    focusNode: _focusNode),
                MedicationTileLunchTime(
                    time: 'Lunchtime',
                    medsCount: value.lunchMed?.length != null
                        ? value.lunchMed?.length
                        : null,
                    leadingIcon: Icons.sunny,
                    data: value.lunchMed!,
                    visitMstId: widget.visitMstId,
                    areaController: areaControllerLunchTime,
                    focusNode: _focusNodeLunchTime),
                MedicationTileEvening(
                    time: 'Evening',
                    medsCount: value.eveningMed?.length != null
                        ? value.eveningMed?.length
                        : null,
                    leadingIcon: Icons.sunny_snowing,
                    data: value.eveningMed!,
                    visitMstId: widget.visitMstId,
                    areaController: controllerEvening,
                    focusNode: _focusNodeEvening),
                MedicationTileBedTime(
                    time: 'Bed Time',
                    medsCount: value.bedTimeMed?.length != null
                        ? value.bedTimeMed?.length
                        : null,
                    leadingIcon: Icons.mode_night,
                    data: value.bedTimeMed!,
                    visitMstId: widget.visitMstId,
                    areaController: controllerBedTime,
                    focusNode: _focusNodeBedTime),
                MedicationTileAsNeeded(
                    time: 'As Needed',
                    medsCount: value.asNeededMed?.length != null
                        ? value.asNeededMed?.length
                        : null,
                    leadingIcon: Icons.access_time,
                    data: value.asNeededMed!,
                    visitMstId: widget.visitMstId,
                    areaController: controllerAsNeeded,
                    focusNode: _focusNodeAsNeeded),
              ],
            )),
            Container(
              width: double.infinity,
              padding: const EdgeInsets.symmetric(vertical: 20.0),
              color: Colors.white,
              child: GestureDetector(
                onTap: () {
                  // Save button clicked
                  _saveButtonClicked(context, value, taskController);
                },
                child: Container(
                  margin: const EdgeInsets.all(20),
                  width: MediaQuery.of(context).size.width / 1.3,
                  height: 50,
                  decoration: BoxDecoration(
                    color: Colors.blue,
                    borderRadius: BorderRadius.circular(40),
                  ),
                  child: const Center(
                    child: Text(
                      'Save',
                      style: TextStyle(
                        fontSize: 18,
                        fontWeight: FontWeight.bold,
                        color: Colors.white,
                      ),
                    ),
                  ),
                ),
              ),
            ),
          ],
        );
      },
    );
  }

  Future<void> _saveButtonClicked(BuildContext context,
      MedicationController value, TaskController taskController) async {
    print('Save button clicked...');
    //print(MedicationTask.carerVisitMedList.toString());
    print("list controlrer");
    print(areaController.length.toString());

    //setFocusNodeToUnFocus();

    // handler.deleteAllMedications();
    //
    // return;

    int tag = 1;

    //check empty
    // morning
    print("Morning Visit");
    print(MedicationTask.carerVisitMedList.length.toString());
    for (var element in MedicationTask.carerVisitMedList) {
      if (element.notTakenStatus == 'Y' &&
          element.notTakenStatus != null &&
          (element.notTakenRemarks == null ||
              element.notTakenRemarks!.isEmpty)) {
        late var snackBar = SnackBar(
          content:
              Text('Not taken Note Required on ' + element.medicationName!),
          duration: Duration(seconds: 3),
        );
        ScaffoldMessenger.of(context).showSnackBar(snackBar);

        tag = 0;

        return;
      }
    }
    if (tag == 0) {
      return;
    }
    //check empty
    // lunchtime
    for (var element in MedicationTask.carerVisitLunchMedList) {
      if (element.notTakenStatus == 'Y' &&
          element.notTakenStatus != null &&
          (element.notTakenRemarks == null ||
              element.notTakenRemarks!.isEmpty)) {
        late var snackBar = SnackBar(
          content:
              Text('Not taken Note Required on ${element.medicationName!}'),
          duration: const Duration(seconds: 3),
        );
        ScaffoldMessenger.of(context).showSnackBar(snackBar);

        tag = 0;

        return;
      }
    }
    if (tag == 0) {
      return;
    }
    //check empty
    // evening
    for (var element in MedicationTask.carerVisitEveningMedList) {
      if (element.notTakenStatus == 'Y' &&
          (element.notTakenRemarks == null ||
              element.notTakenRemarks!.isEmpty)) {
        late var snackBar = SnackBar(
          content:
              Text('Not taken Note Required on ${element.medicationName!}'),
          duration: const Duration(seconds: 3),
        );
        ScaffoldMessenger.of(context).showSnackBar(snackBar);

        tag = 0;

        return;
      }
    }
    if (tag == 0) {
      return;
    }
    //check empty
    // bed time
    print("bed time Visit");
    print(MedicationTask.carerVisitBedTimeList.length.toString());
    for (var element in MedicationTask.carerVisitBedTimeList) {
      if (element.notTakenStatus == 'Y' &&
          (element.notTakenRemarks == null ||
              element.notTakenRemarks!.isEmpty)) {
        late var snackBar = SnackBar(
          content:
              Text('Not taken Note Required on ${element.medicationName!}'),
          duration: const Duration(seconds: 3),
        );
        ScaffoldMessenger.of(context).showSnackBar(snackBar);

        tag = 0;

        return;
      }
    }
    if (tag == 0) {
      return;
    }
    for (var element in MedicationTask.carerVisitAsNeededMedList) {
      if (element.notTakenStatus == 'Y' &&
          (element.notTakenRemarks == null ||
              element.notTakenRemarks!.isEmpty)) {
        late var snackBar = SnackBar(
          content:
              Text('Not taken Note Required on ${element.medicationName!}'),
          duration: const Duration(seconds: 3),
        );
        ScaffoldMessenger.of(context).showSnackBar(snackBar);

        tag = 0;

        return;
      }
    }
    if (tag == 0) {
      return;
    }

    uploadAllData();

    //handler.insertOrUpdateMedication(element);

    if (tag == 1) {
      MedicationTask.carerVisitMedList.clear();
      MedicationTask.carerVisitLunchMedList.clear();
      MedicationTask.carerVisitBedTimeList.clear();
      MedicationTask.carerVisitEveningMedList.clear();
      MedicationTask.carerVisitAsNeededMedList.clear();
      areaController.clear();
      _focusNode.clear();
      taskController.getStatusByMstId(widget.visitMstId.toString());
      //
      Navigator.pop(context);
    }
  }

  void controllers(MedicationController value) {
    // morning
    areaController.addAll(List.generate(
      value.morningMed!.length,
      (index) => TextEditingController(),
    ));

    // lunch time
    areaControllerLunchTime.addAll(List.generate(
      value.lunchMed!.length,
      (index) => TextEditingController(),
    ));

    // evening
    controllerEvening.addAll(List.generate(
      value.eveningMed!.length,
      (index) => TextEditingController(),
    ));

    // bed time
    controllerBedTime.addAll(List.generate(
      value.bedTimeMed!.length,
      (index) => TextEditingController(),
    ));

    // as needed
    controllerAsNeeded.addAll(List.generate(
      value.asNeededMed!.length,
      (index) => TextEditingController(),
    ));
  }

  void focusNode(MedicationController value) {
    // morning
    _focusNode.addAll(List.generate(
      value.morningMed!.length,
      (index) => FocusNode(),
    ));

    // lunch time
    _focusNodeLunchTime.addAll(List.generate(
      value.lunchMed!.length,
      (index) => FocusNode(),
    ));

    // evening
    _focusNodeEvening.addAll(List.generate(
      value.eveningMed!.length,
      (index) => FocusNode(),
    ));

    // bed time
    _focusNodeBedTime.addAll(List.generate(
      value.bedTimeMed!.length,
      (index) => FocusNode(),
    ));

    // as needed
    _focusNodeAsNeeded.addAll(List.generate(
      value.asNeededMed!.length,
      (index) => FocusNode(),
    ));
  }

  void tempMorningList(MedicationController value) {
    // morning med
    CarerVisitMedication medicationData = CarerVisitMedication();

    for (int i = 0; i < value.morningMed!.length; i++) {
      medicationData = CarerVisitMedication(
          medicationName: value.morningMed?[i]['MEDICATION_NAME'],
          carerVisitMstId: widget.visitMstId.toString(),
          dosage: value.morningMed?[i]['DOSAGE'],
          notTakenStatus: value.morningMed?[i]['NOT_TAKEN_STATUS'] != null
              ? value.morningMed![i]['NOT_TAKEN_STATUS']
              : null,
          takenStatus: value.morningMed?[i]['TAKEN_STATUS'] != null
              ? value.morningMed![i]['TAKEN_STATUS']
              : null,
          morningSchedule: 'Y',
          saturdaySchedule: value.morningMed?[i]['SATURDAY_SCHEDULE'],
          sundaySchedule: value.morningMed?[i]['SUNDAY_SCHEDULE'],
          mondaySchedule: value.morningMed?[i]['MONDAY_SCHEDULE'],
          tuesdaySchedule: value.morningMed?[i]['TUESDAY_SCHEDULE'],
          wednesdaySchedule: value.morningMed?[i]['WEDNESDAY_SCHEDULE'],
          thursdaySchedule: value.morningMed?[i]['THURSDAY_SCHEDULE'],
          fridaySchedule: value.morningMed?[i]['FRIDAY_SCHEDULE'],
          orgCode: widget.userInfo.orgCode,
          clientId: widget.userInfo.clientId,
          clientCode: widget.userInfo.clientCode,
          carerId: localStorage.userLoginDetail.value![0].carerId!,
          carerCode: localStorage.userLoginDetail.value![0].carerCode!,
          taskCode: '01',
          medicationDetailId: value.morningMed?[i]['CLIENT_MEDICATION_DTL_ID'],
          createDate: getCurrentDate(),
          notTakenRemarks: value.morningMed?[i]['NOT_TAKEN_REMARKS'] != null
              ? value.morningMed![i]['NOT_TAKEN_REMARKS']
              : null,
          takenRemarks: value.morningMed?[i]['TAKEN_REMARKS'] != null
              ? value.morningMed![i]['TAKEN_REMARKS']
              : null);

      MedicationTask.carerVisitMedList.add(medicationData);
    }
  }

  void tempLunchList(MedicationController value) {
    // morning med
    CarerVisitMedication medicationData = CarerVisitMedication();

    for (int i = 0; i < value.lunchMed!.length; i++) {
      medicationData = CarerVisitMedication(
        medicationName: value.lunchMed?[i]['MEDICATION_NAME'],
        carerVisitMstId: widget.visitMstId.toString(),
        dosage: value.lunchMed?[i]['DOSAGE'],
        notTakenStatus: value.lunchMed?[i]['NOT_TAKEN_STATUS'] != null
            ? value.lunchMed![i]['NOT_TAKEN_STATUS']
            : null,
        takenStatus: value.lunchMed?[i]['TAKEN_STATUS'] != null
            ? value.lunchMed![i]['TAKEN_STATUS']
            : null,
        lunchtimeSchedule: 'Y',
        saturdaySchedule: value.lunchMed?[i]['SATURDAY_SCHEDULE'],
        sundaySchedule: value.lunchMed?[i]['SUNDAY_SCHEDULE'],
        mondaySchedule: value.lunchMed?[i]['MONDAY_SCHEDULE'],
        tuesdaySchedule: value.lunchMed?[i]['TUESDAY_SCHEDULE'],
        wednesdaySchedule: value.lunchMed?[i]['WEDNESDAY_SCHEDULE'],
        thursdaySchedule: value.lunchMed?[i]['THURSDAY_SCHEDULE'],
        fridaySchedule: value.lunchMed?[i]['FRIDAY_SCHEDULE'],
        orgCode: widget.userInfo.orgCode,
        clientId: widget.userInfo.clientId,
        clientCode: widget.userInfo.clientCode,
        carerId: localStorage.userLoginDetail.value![0].carerId!,
        carerCode: localStorage.userLoginDetail.value![0].carerCode!,
        taskCode: '01',
        medicationDetailId: value.lunchMed?[i]['CLIENT_MEDICATION_DTL_ID'],
        createDate: getCurrentDate(),
        notTakenRemarks: value.lunchMed?[i]['NOT_TAKEN_REMARKS'] != null
            ? value.lunchMed![i]['NOT_TAKEN_REMARKS']
            : null,
        takenRemarks: value.lunchMed?[i]['TAKEN_REMARKS'] != null
            ? value.lunchMed![i]['TAKEN_REMARKS']
            : null,
      );

      MedicationTask.carerVisitLunchMedList.add(medicationData);
    }
  }

  void tempEveningList(MedicationController value) {
    // morning med
    CarerVisitMedication medicationData = CarerVisitMedication();

    for (int i = 0; i < value.eveningMed!.length; i++) {
      medicationData = CarerVisitMedication(
          medicationName: value.eveningMed?[i]['MEDICATION_NAME'],
          carerVisitMstId: widget.visitMstId.toString(),
          dosage: value.eveningMed?[i]['DOSAGE'],
          notTakenStatus: value.eveningMed?[i]['NOT_TAKEN_STATUS'] != null
              ? value.eveningMed![i]['NOT_TAKEN_STATUS']
              : null,
          takenStatus: value.eveningMed?[i]['TAKEN_STATUS'] != null
              ? value.eveningMed![i]['TAKEN_STATUS']
              : null,
          eveningSchedule: 'Y',
          saturdaySchedule: value.eveningMed?[i]['SATURDAY_SCHEDULE'],
          sundaySchedule: value.eveningMed?[i]['SUNDAY_SCHEDULE'],
          mondaySchedule: value.eveningMed?[i]['MONDAY_SCHEDULE'],
          tuesdaySchedule: value.eveningMed?[i]['TUESDAY_SCHEDULE'],
          wednesdaySchedule: value.eveningMed?[i]['WEDNESDAY_SCHEDULE'],
          thursdaySchedule: value.eveningMed?[i]['THURSDAY_SCHEDULE'],
          fridaySchedule: value.eveningMed?[i]['FRIDAY_SCHEDULE'],
          orgCode: widget.userInfo.orgCode,
          clientId: widget.userInfo.clientId,
          clientCode: widget.userInfo.clientCode,
          carerId: localStorage.userLoginDetail.value![0].carerId!,
          carerCode: localStorage.userLoginDetail.value![0].carerCode!,
          taskCode: '01',
          medicationDetailId: value.eveningMed?[i]['CLIENT_MEDICATION_DTL_ID'],
          createDate: getCurrentDate(),
          notTakenRemarks: value.eveningMed?[i]['NOT_TAKEN_REMARKS'] != null
              ? value.eveningMed![i]['NOT_TAKEN_REMARKS']
              : null,
          takenRemarks: value.eveningMed?[i]['TAKEN_REMARKS'] != null
              ? value.eveningMed![i]['TAKEN_REMARKS']
              : null);

      MedicationTask.carerVisitEveningMedList.add(medicationData);
    }
  }

  void tempBedTimeList(MedicationController value) {
    // morning med
    CarerVisitMedication medicationBTData = CarerVisitMedication();

    for (int i = 0; i < value.bedTimeMed!.length; i++) {
      medicationBTData = CarerVisitMedication(
        medicationName: value.bedTimeMed?[i]['MEDICATION_NAME'],
        carerVisitMstId: widget.visitMstId.toString(),
        dosage: value.bedTimeMed?[i]['DOSAGE'],
        notTakenStatus: value.bedTimeMed?[i]['NOT_TAKEN_STATUS'] != null
            ? value.bedTimeMed![i]['NOT_TAKEN_STATUS']
            : null,
        takenStatus: value.bedTimeMed?[i]['TAKEN_STATUS'] != null
            ? value.bedTimeMed![i]['TAKEN_STATUS']
            : null,
        bedtimeSchedule: 'Y',
        saturdaySchedule: value.bedTimeMed?[i]['SATURDAY_SCHEDULE'],
        sundaySchedule: value.bedTimeMed?[i]['SUNDAY_SCHEDULE'],
        mondaySchedule: value.bedTimeMed?[i]['MONDAY_SCHEDULE'],
        tuesdaySchedule: value.bedTimeMed?[i]['TUESDAY_SCHEDULE'],
        wednesdaySchedule: value.bedTimeMed?[i]['WEDNESDAY_SCHEDULE'],
        thursdaySchedule: value.bedTimeMed?[i]['THURSDAY_SCHEDULE'],
        fridaySchedule: value.bedTimeMed?[i]['FRIDAY_SCHEDULE'],
        orgCode: widget.userInfo.orgCode,
        clientId: widget.userInfo.clientId,
        clientCode: widget.userInfo.clientCode,
        carerId: localStorage.userLoginDetail.value![0].carerId!,
        carerCode: localStorage.userLoginDetail.value![0].carerCode!,
        taskCode: '01',
        medicationDetailId: value.bedTimeMed?[i]['CLIENT_MEDICATION_DTL_ID'],
        createDate: getCurrentDate(),
        notTakenRemarks: value.bedTimeMed?[i]['NOT_TAKEN_REMARKS'] != null
            ? value.bedTimeMed![i]['NOT_TAKEN_REMARKS']
            : null,
        takenRemarks: value.bedTimeMed?[i]['TAKEN_REMARKS'] != null
            ? value.bedTimeMed![i]['TAKEN_REMARKS']
            : null,
      );

      MedicationTask.carerVisitBedTimeList.add(medicationBTData);
    }
  }

  void tempAsNeededList(MedicationController value) {
    // morning med
    CarerVisitMedication medicationData = CarerVisitMedication();

    for (int i = 0; i < value.asNeededMed!.length; i++) {
      medicationData = CarerVisitMedication(
        medicationName: value.asNeededMed?[i]['MEDICATION_NAME'],
        carerVisitMstId: widget.visitMstId.toString(),
        dosage: value.asNeededMed?[i]['DOSAGE'],
        notTakenStatus: value.asNeededMed?[i]['NOT_TAKEN_STATUS'] != null
            ? value.asNeededMed![i]['NOT_TAKEN_STATUS']
            : null,
        takenStatus: value.asNeededMed?[i]['TAKEN_STATUS'] != null
            ? value.asNeededMed![i]['TAKEN_STATUS']
            : null,
        asNeededSchedule: 'Y',
        saturdaySchedule: value.asNeededMed?[i]['SATURDAY_SCHEDULE'],
        sundaySchedule: value.asNeededMed?[i]['SUNDAY_SCHEDULE'],
        mondaySchedule: value.asNeededMed?[i]['MONDAY_SCHEDULE'],
        tuesdaySchedule: value.asNeededMed?[i]['TUESDAY_SCHEDULE'],
        wednesdaySchedule: value.asNeededMed?[i]['WEDNESDAY_SCHEDULE'],
        thursdaySchedule: value.asNeededMed?[i]['THURSDAY_SCHEDULE'],
        fridaySchedule: value.asNeededMed?[i]['FRIDAY_SCHEDULE'],
        orgCode: widget.userInfo.orgCode,
        clientId: widget.userInfo.clientId,
        clientCode: widget.userInfo.clientCode,
        carerId: localStorage.userLoginDetail.value![0].carerId!,
        carerCode: localStorage.userLoginDetail.value![0].carerCode!,
        taskCode: '01',
        medicationDetailId: value.asNeededMed?[i]['CLIENT_MEDICATION_DTL_ID'],
        createDate: getCurrentDate(),
        notTakenRemarks: value.asNeededMed?[i]['NOT_TAKEN_REMARKS'] != null
            ? value.asNeededMed![i]['NOT_TAKEN_REMARKS']
            : null,
        takenRemarks: value.asNeededMed?[i]['TAKEN_REMARKS'] != null
            ? value.asNeededMed![i]['TAKEN_REMARKS']
            : null,
      );

      MedicationTask.carerVisitAsNeededMedList.add(medicationData);
    }
  }

  void uploadAllData() {
    for (var element in MedicationTask.carerVisitMedList) {
      print("morning");
      print(element.toMap());
      handler.insertOrUpdateMedication(element, "MORNING_SCHEDULE");
    }

    //check empty
    // lunchtime
    for (var element in MedicationTask.carerVisitLunchMedList) {
      handler.insertOrUpdateMedication(element, "LUNCHTIME_SCHEDULE");
    }

    //check empty
    // evening
    for (var element in MedicationTask.carerVisitEveningMedList) {
      handler.insertOrUpdateMedication(element, "EVENING_SCHEDULE");
    }

    //check empty
    // bed time
    for (var element in MedicationTask.carerVisitBedTimeList) {
      print("Bed Time");
      print(element.toMap());
      handler.insertOrUpdateMedication(element, "BEDTIME_SCHEDULE");
    }

    for (var element in MedicationTask.carerVisitAsNeededMedList) {
      handler.insertOrUpdateMedication(element, "AS_NEEDED_SCHEDULE");
    }
  }

  void setFocusNodeToUnFocus() {
    for (var element in _focusNode) {
      if (element.hasFocus) {
        element.unfocus();
      }
    }

    for (var element in _focusNodeLunchTime) {
      if (element.hasFocus) {
        element.unfocus();
      }
    }

    for (var element in _focusNodeEvening) {
      if (element.hasFocus) {
        element.unfocus();
      }
    }

    for (var element in _focusNodeBedTime) {
      if (element.hasFocus) {
        element.unfocus();
      }
    }

    for (var element in _focusNodeAsNeeded) {
      if (element.hasFocus) {
        element.unfocus();
      }
    }
  }
}

class MedicationTile extends StatefulWidget {
  final String time;
  final int? medsCount;
  final IconData leadingIcon;
  final List<Map<String, dynamic>> data;
  final List<TextEditingController> areaController;
  final List<FocusNode> focusNode;
  final int visitMstId;

  MedicationTile(
      {Key? key,
      required this.time,
      this.medsCount,
      required this.leadingIcon,
      required this.data,
      required this.areaController,
      required this.focusNode,
      required this.visitMstId})
      : super(key: key);

  @override
  State<MedicationTile> createState() => _MedicationTileState();
}

class _MedicationTileState extends State<MedicationTile> {
  @override
  void initState() {
    super.initState();
  }

  @override
  void dispose() {
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    //widget.areaController.clear();

    return widget.medsCount != null && widget.medsCount != 0
        ? Container(
            padding: const EdgeInsets.symmetric(vertical: 5, horizontal: 5),
            margin: const EdgeInsets.symmetric(vertical: 10, horizontal: 10),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(40),
              color: Colors.white,
            ),
            child: Theme(
              data:
                  Theme.of(context).copyWith(dividerColor: Colors.transparent),
              child: ExpansionTile(
                leading: Icon(widget.leadingIcon),
                title: Text(
                  '${widget.time} (${(widget.medsCount != null && widget.medsCount != 0) ? widget.medsCount! : 'No'} meds)',
                  style: const TextStyle(
                    fontFamily: 'PoppinsMedium',
                  ),
                ),
                children: <Widget>[
                  Column(
                    children: List.generate(
                      widget.medsCount!,
                      (index) => MedicationCard(
                          data: widget.data[index],
                          visitMstId: widget.visitMstId,
                          controller: widget.areaController,
                          focusNode: widget.focusNode,
                          index: index),
                    ),
                  ),
                ],
              ),
            ),
          )
        : Container(
            padding: const EdgeInsets.symmetric(vertical: 5, horizontal: 5),
            margin: const EdgeInsets.symmetric(vertical: 10, horizontal: 10),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(40),
              color: Colors.white,
            ),
            child: ListTile(
              leading: Icon(widget.leadingIcon),
              title: Text(
                '${widget.time} (No meds)',
                style: const TextStyle(
                  color: Colors.grey,
                  fontFamily: 'PoppinsMedium',
                ),
              ),
            ),
          );
  }
}

class MedicationCard extends StatefulWidget {
  final Map<String, dynamic> data;
  final List<TextEditingController> controller;
  final int index;
  final int visitMstId;
  final List<FocusNode> focusNode;

  const MedicationCard(
      {Key? key,
      required this.data,
      required this.controller,
      required this.index,
      required this.focusNode,
      required,
      required this.visitMstId})
      : super(key: key);

  @override
  State<MedicationCard> createState() => _MedicationCardState();
}

class _MedicationCardState extends State<MedicationCard> {
  String _notTakenReason = '';
  String _takenReason = '';
//static final GlobalKey<_MedicationCardState> medicationCardKey = GlobalKey();
//TextEditingController controller = TextEditingController();
  bool _isNotTakenExpanded = false;
  bool _isTakenExpanded = false;

  @override
  void initState() {
// TODO: implement initState
    super.initState();
    _isTakenExpanded = widget.data['TAKEN_STATUS'] == 'Y' ? true : false;
    _isNotTakenExpanded = widget.data['NOT_TAKEN_STATUS'] == 'Y' ? true : false;
  }

  void _toggleNotTakenExpanded() {
    widget.focusNode[widget.index].requestFocus();
    setState(() {
      _isNotTakenExpanded = !_isNotTakenExpanded;
      _isTakenExpanded = false;
    });
    if (_isNotTakenExpanded) {
      MedicationTask.carerVisitMedList[widget.index].notTakenStatus = 'Y';
      MedicationTask.carerVisitMedList[widget.index].takenStatus = null;
    } else if (!_isNotTakenExpanded) {
      MedicationTask.carerVisitMedList[widget.index].notTakenStatus = null;
    }

MedicationTask.carerVisitMedList[widget.index]
    .dataCapturedDate = getCurrentDate();
MedicationTask.carerVisitMedList[widget.index]
    .dataCapturedTime =
"${DateTime.now().hour.toString().padLeft(2, '0')}:${DateTime.now().minute.toString().padLeft(2, '0')}";

// if (_isNotTakenExpanded == false && _isTakenExpanded == false) {
//   MedicationTask.carerVisitMedList[widget.index].notTakenStatus = null;
//   MedicationTask.carerVisitMedList[widget.index].notTakenRemarks = null;
//   MedicationTask.carerVisitMedList[widget.index].takenStatus = null;
//   MedicationTask.carerVisitMedList[widget.index].takenRemarks = null;
// }
  }

  void _toggleTakenExpanded() {
    widget.focusNode[widget.index].requestFocus();
    setState(() {
      _isTakenExpanded = !_isTakenExpanded;
      _isNotTakenExpanded = false;
    });
    if (_isTakenExpanded) {
      MedicationTask.carerVisitMedList[widget.index].takenStatus = 'Y';
      MedicationTask.carerVisitMedList[widget.index].notTakenStatus = null;
    } else if (!_isTakenExpanded) {
      MedicationTask.carerVisitMedList[widget.index].takenStatus = null;
    }
MedicationTask.carerVisitMedList[widget.index]
    .dataCapturedDate = getCurrentDate();
MedicationTask.carerVisitMedList[widget.index]
    .dataCapturedTime =
"${DateTime.now().hour.toString().padLeft(2, '0')}:${DateTime.now().minute.toString().padLeft(2, '0')}";

// if (_isNotTakenExpanded == false && _isTakenExpanded == false) {
//   MedicationTask.carerVisitMedList[widget.index].notTakenStatus = null;
//   MedicationTask.carerVisitMedList[widget.index].notTakenRemarks = null;
//   MedicationTask.carerVisitMedList[widget.index].takenStatus = null;
//   MedicationTask.carerVisitMedList[widget.index].takenRemarks = null;
// }
  }

  String getVisitDay(Map<String, dynamic> medication) {
    String visitDay = "";

    if (medication['MONDAY_SCHEDULE'] == 'Y') {
      visitDay = "Monday" + ", " + visitDay;
    }
    if (medication['TUESDAY_SCHEDULE'] == 'Y') {
      visitDay = "Tuesday" + ", " + visitDay;
    }
    if (medication['WEDNESDAY_SCHEDULE'] == 'Y') {
      visitDay = "Wednesday" + ", " + visitDay;
    }
    if (medication['THURSDAY_SCHEDULE'] == 'Y') {
      visitDay = "Thursday" + ", " + visitDay;
    }
    if (medication['FRIDAY_SCHEDULE'] == 'Y') {
      visitDay = "Friday" + ", " + visitDay;
    }
    if (medication['SATURDAY_SCHEDULE'] == 'Y') {
      visitDay = "Saturday" + ", " + visitDay;
    }
    if (medication['SUNDAY_SCHEDULE'] == 'Y') {
      visitDay = "Sunday" + ", " + visitDay;
    }
    if (visitDay.isEmpty) {
      return "No Visiting Time Found";
    } else {
      return visitDay;
    }
  }

  @override
  Widget build(BuildContext context) {
    widget.controller[widget.index].value = TextEditingValue(
      text: widget.data['NOT_TAKEN_REMARKS'] ??
          widget.data['TAKEN_REMARKS'] ??
          '', // Set text from data
// selection: TextSelection.collapsed(offset: widget.data['NOT_TAKEN_REMARKS'].length
//     .length), // Move cursor to the end
    );

    return Padding(
      padding: const EdgeInsets.only(bottom: 8.0, left: 8, right: 8),
      child: Container(
        color: Colors.white,
        child: Padding(
          padding: const EdgeInsets.all(10.0),
          child: Form(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  widget.data['MEDICATION_NAME'],
                  style: const TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  widget.data['DOSAGE'],
                  style: const TextStyle(
                    color: Colors.grey,
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  getVisitDay(widget.data),
                  style: const TextStyle(
                    fontStyle: FontStyle.italic,
                  ),
                ),
                const SizedBox(height: 8),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: [
                    Expanded(
                      child: GestureDetector(
                        onTap: _toggleNotTakenExpanded,
                        child: Container(
                          decoration: BoxDecoration(
                            border: Border.all(color: Colors.red),
                            borderRadius: BorderRadius.circular(40),
                            color: _isNotTakenExpanded
                                ? Colors.red
                                : Colors.transparent,
                          ),
                          padding: const EdgeInsets.symmetric(
                              vertical: 8, horizontal: 12),
                          child: Text(
                            'Not taken',
                            textAlign: TextAlign.center,
                            style: TextStyle(
                              color: _isNotTakenExpanded
                                  ? Colors.white
                                  : Colors.red,
                            ),
                          ),
                        ),
                      ),
                    ),
                    const SizedBox(width: 8),
                    Expanded(
                      child: GestureDetector(
                        onTap: _toggleTakenExpanded,
                        child: Container(
                          decoration: BoxDecoration(
                            border: Border.all(color: Colors.green),
                            borderRadius: BorderRadius.circular(40),
                            color: _isTakenExpanded
                                ? Colors.green
                                : Colors.transparent,
                          ),
                          padding: const EdgeInsets.symmetric(
                              vertical: 8, horizontal: 12),
                          child: Text(
                            'Taken',
                            textAlign: TextAlign.center,
                            style: TextStyle(
                              color: _isTakenExpanded
                                  ? Colors.white
                                  : Colors.green,
                            ),
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
                if (_isNotTakenExpanded) ...[
                  const SizedBox(height: 8),
                  const Text(
                    'Why was this not taken?',
                    style: TextStyle(
                      color: Colors.red,
                    ),
                  ),
                  const SizedBox(height: 4),
                ],
                if (_isTakenExpanded) ...[
                  const SizedBox(height: 8),
                  const Text('Notes (optional)'),
                  const SizedBox(height: 4),
                ],
                if (_isNotTakenExpanded || _isTakenExpanded) ...[
                  TextFormField(
                    controller: widget.controller[widget.index],
                    focusNode: widget.focusNode[widget.index],
                    decoration: const InputDecoration(
                      border: OutlineInputBorder(),
                    ),
                    onChanged: (event) {
                      for (int i = 0; i < widget.controller.length; i++) {
                        var value = widget.controller[widget.index].text;
                        print("index : ${widget.index}");

                        if (_isTakenExpanded) {
                          MedicationTask.carerVisitMedList[widget.index]
                              .takenStatus = 'Y';
                          MedicationTask.carerVisitMedList[widget.index]
                              .takenRemarks = value;
                          MedicationTask.carerVisitMedList[widget.index]
                              .notTakenStatus = null;
                          MedicationTask.carerVisitMedList[widget.index]
                              .notTakenRemarks = null;
                          MedicationTask.carerVisitMedList[widget.index]
                              .dataCapturedDate = getCurrentDate();
                          MedicationTask.carerVisitMedList[widget.index]
                                  .dataCapturedTime =
                              "${DateTime.now().hour.toString().padLeft(2, '0')}:${DateTime.now().minute.toString().padLeft(2, '0')}";
                        } else if (_isNotTakenExpanded) {
                          MedicationTask.carerVisitMedList[widget.index]
                              .notTakenStatus = 'Y';
                          MedicationTask.carerVisitMedList[widget.index]
                              .notTakenRemarks = value;
                          MedicationTask.carerVisitMedList[widget.index]
                              .takenStatus = null;
                          MedicationTask.carerVisitMedList[widget.index]
                              .takenRemarks = null;
                          MedicationTask.carerVisitMedList[widget.index]
                              .dataCapturedDate = getCurrentDate();
                          MedicationTask.carerVisitMedList[widget.index]
                                  .dataCapturedTime =
                              "${DateTime.now().hour.toString().padLeft(2, '0')}:${DateTime.now().minute.toString().padLeft(2, '0')}";
                        }
                      }
                    },
                  ),
                ],
                const SizedBox(height: 8),
                Padding(
                  padding: const EdgeInsets.symmetric(vertical: 8.0),
                  child: Text(
                    'Last report as Taken, 10 days ago, by Nasir Uddin Babor',
                    style: TextStyle(
                      color: Colors.grey.shade400,
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
