//LaundryTaskPage
import 'package:care4u/src/controls/utils/color_codes.dart';
import 'package:care4u/src/models/insertion/CMS_CARER_VISIT_LAUNDRY.dart';
import 'package:care4u/src/views/report/tasks_screen/taskWidgetsStyles/cmn_task_button.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../../controls/localStorage/local_storage.dart';
import '../../../controls/utils/Tools.dart';
import '../../../models/LocalModel/LocalDpd_Cms_Carer_Cln_Dtws_Sch_Lst_Model.dart';
import '../../../controls/localDatabaseHandler/local_database_handler.dart';
import '../controller/task_controller.dart';

class LaundryTaskPage extends StatefulWidget {
  final String taskName;
  final int? masterId;
  final Value? userData;
  final String taskNote;

  const LaundryTaskPage(
      {super.key,
        required this.taskNote,
      required this.taskName,
      required this.masterId,
      required this.userData});

  @override
  State<LaundryTaskPage> createState() => _LaundryTaskPageState();
}

class _LaundryTaskPageState extends State<LaundryTaskPage> {
  final TextEditingController _textEditingController = TextEditingController();
  FocusNode laundryTextNode = FocusNode();
  final LocalDatabaseHandler dbHandler = LocalDatabaseHandler();
  LocalStorage localStorage = LocalStorage();

  @override
  void dispose() {
    // TODO: implement dispose
    super.dispose();
    _textEditingController.dispose();
    laundryTextNode.dispose();
  }

  void hideKeyboard() {
    if (laundryTextNode.hasFocus) {
      laundryTextNode.unfocus();
    }
  }

  @override
  Widget build(BuildContext context) {
    final clientData = Provider.of<TaskController>(context, listen: false);

    return Scaffold(
      appBar: AppBar(
        backgroundColor: Theme.of(context).colorScheme.primary,
        centerTitle: true,
        title: Text(
          widget.taskName.toString(),
          style: const TextStyle(
              color: Colors.white,
              fontFamily: 'PoppinsBold',
              fontWeight: FontWeight.w800,
              fontSize: 18),
        ),
        iconTheme: const IconThemeData(color: Colors.white),
      ),
      resizeToAvoidBottomInset: false,
      body: SingleChildScrollView(
        reverse: true,
        child: Container(
          padding: EdgeInsets.only(bottom: MediaQuery.of(context).viewInsets.bottom),
          margin: const EdgeInsets.only(left: 10, right: 10, top: 30),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              widget.taskNote.isNotEmpty?Card(
                color: Colors.white,
                margin: const EdgeInsets.only(bottom: 20),
                elevation: 5,
                child: Container(
                  margin: EdgeInsets.all(10),
                  child: Column(
                    children: [
                      Container(
                        margin: EdgeInsets.only(top: 5, bottom: 10),
                        child: Column(
                          children: [
                            const Text(
                              "Assign Note",
                              textAlign: TextAlign.center,
                              style: TextStyle(
                                  color: primaryColor,
                                  fontSize: 18,
                                  fontWeight: FontWeight.w700
                              ),
                            ),
                            Container(
                              color: primaryColor,
                              height: 1.7,
                              width: 120,
                            )
                          ],
                        ),
                      ),
                      Text(
                        widget.taskNote,
                        style: const TextStyle(
                            fontSize: 16,
                            color: primaryColor2
                        ),
                      ),
                    ],
                  ),
                ),
              ) : Container(),

              Card(
                elevation: 5,
                color: Colors.white,
                child: Container(
                  margin: EdgeInsets.all(10),
                  child: Column(
                    children: [
                      Container(
                        margin: EdgeInsets.only(top: 5, bottom: 15),
                        child: Column(
                          children: [
                            const Text(
                              "Task Note",
                              textAlign: TextAlign.center,
                              style: TextStyle(
                                  color: primaryColor,
                                  fontSize: 18,
                                  fontWeight: FontWeight.w700
                              ),
                            ),
                            Container(
                              color: primaryColor,
                              height: 1.7,
                              width: 120,
                            )
                          ],
                        ),
                      ),
                      Card(
                        color: Colors.white,
                        margin: const EdgeInsets.only(bottom: 20),
                        elevation: 5,
                        child: Container(
                          margin: const EdgeInsets.all(10),
                          child: Theme(
                            data: ThemeData(
                              primaryColor: lightPrimaryColor,
                              primaryColorDark: lightPrimaryColor,
                            ),
                            child: TextFormField(
                              controller: _textEditingController,
                              maxLines: 8,
                              focusNode: laundryTextNode,
                              keyboardType: TextInputType.multiline,
                              decoration: InputDecoration(
                                hintText: 'Please leave some notes about how you\'ve helped with this task',
                                hintStyle: const TextStyle(
                                    color: grayColor3,
                                    fontWeight: FontWeight.w400,
                                    fontSize: 15
                                ),
                                contentPadding: const EdgeInsets.symmetric(
                                    vertical: 10, horizontal: 10),
                                enabledBorder: OutlineInputBorder(
                                  borderSide: const BorderSide(color: color2, width: 0.0),
                                  borderRadius: BorderRadius.circular(10.0),
                                ),
                                focusedBorder: OutlineInputBorder(
                                  borderSide: const BorderSide(color: primaryColor, width: 1.5), // Set focused border color here
                                  borderRadius: BorderRadius.circular(10.0),
                                ),
                              ),),
                          ),
                        ),
                      ),
                      FutureBuilder<List<dynamic>?>(
                        future: isExist(),
                        builder: (context, snapshot) {
                          if (snapshot.connectionState == ConnectionState.waiting) {
                            // Show a loading indicator if the future is still processing
                            return const CircularProgressIndicator();
                          } else {
                            // Show the appropriate widget based on the result of the future
                            if (snapshot.hasError) {
                              return Text('Error: ${snapshot.error}');
                            } else {
                              List<dynamic> data = snapshot.data!;
                              bool exists = data[0];

                              if (exists) {
                                WidgetsBinding.instance.addPostFrameCallback((_) {
                                  _textEditingController.value = TextEditingValue(
                                    text: data[1], // Set text from data
                                    selection: TextSelection.collapsed(
                                        offset:
                                            data[1].length), // Move cursor to the end
                                  );
                                });

                                return Container(
                                  margin: const EdgeInsets.only(top: 20),
                                  child: Row(
                                    children: [
                                      Expanded(
                                        child: Container(
                                          margin: const EdgeInsets.only(right: 10),
                                          child: ElevatedButton(
                                            onPressed: () {
                                              deleteLaundry(clientData);
                                            },
                                            style: taskButtonRemoveStyle(),
                                            child: const Text('Remove '),
                                          ),
                                        ),
                                      ),
                                      Expanded(
                                        child: Container(
                                          margin: const EdgeInsets.only(left: 10),
                                          child: ElevatedButton(
                                            onPressed: () {
                                              updateLaundry();
                                            },
                                            style: taskButtonSaveStyle(),
                                            child: const Text('Save'),
                                          ),
                                        ),
                                      ),
                                    ],
                                  ),
                                );
                              } else {
                                return Container(
                                  margin: const EdgeInsets.only(top: 20),
                                  child: ElevatedButton(
                                    onPressed: () {
                                      hideKeyboard();

                                      if (_textEditingController.text.isNotEmpty) {
                                        saveToDatabase(clientData);
                                      } else {
                                        showSnackBar(context, "Please Enter Some Data");
                                      }
                                    },
                                    style: taskButtonSaveStyle(),
                                    child: const Text(
                                      'Save',
                                      style: TextStyle(fontSize: 16),
                                    ))

                                );
                              }
                            }
                          }
                        },
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  void saveToDatabase(TaskController clientData) {
    CarerVisitLaundry data = CarerVisitLaundry(
      orgCode: widget.userData?.orgCode.toString(),
      clientId: widget.userData?.clientId.toString(),
      clientCode: widget.userData?.clientCode.toString(),
      carerVisitMstId: widget.masterId.toString(),
      carerId: localStorage.userLoginDetail.value![0].carerId!,
      carerCode: localStorage.userLoginDetail.value![0].carerCode!,
      // anotherCarerStatus:
      taskCode: "09",
      laundry: _textEditingController.text.toString(),
      status: "Y",
      clStatus: widget.userData?.clStatus.toString(),

      // MST_ID: widget.masterId
    );

    dbHandler.insertLaundryData(data);
    const snackBar = SnackBar(
      content: Text('Data inserted successfully!'),
      duration: Duration(seconds: 3), // Adjust the duration as needed
    );
    ScaffoldMessenger.of(context).showSnackBar(snackBar);

    clientData.getlaundryStatusByMstId(widget.masterId.toString());

    Navigator.pop(context);
  }

  void updateLaundry() {
    dbHandler.updateLaundry(
        _textEditingController.text.toString(), widget.masterId.toString());

    const snackBar = SnackBar(
      content: Text('Updated successfully!'),
      duration: Duration(seconds: 3), // Adjust the duration as needed
    );
    ScaffoldMessenger.of(context).showSnackBar(snackBar);
    Navigator.pop(context);
  }

  void deleteLaundry(TaskController clientData) {
    dbHandler.deleteLaundryByMstId(widget.masterId.toString());

    const snackBar = SnackBar(
      content: Text('deleted successfully!'),
      duration: Duration(seconds: 3), // Adjust the duration as needed
    );
    ScaffoldMessenger.of(context).showSnackBar(snackBar);

    clientData.getlaundryStatusByMstId(widget.masterId.toString());

    Navigator.pop(context);
  }

  Future<List<dynamic>?> isExist() async {
    return await dbHandler.isLaundryExistsByMstId(widget.masterId.toString());
  }
}
