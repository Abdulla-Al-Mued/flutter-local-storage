import 'package:care4u/src/controls/utils/appbar.dart';
import 'package:care4u/src/controls/utils/color_codes.dart';
import'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../models/LocalModel/LocalDpd_Cms_Carer_Cln_Dtws_Sch_Lst_Model.dart';
import '../schedulelist/ClientProvider/ClientProvider.dart';
import '../schedulelist/widgets/icon_from_url.dart';
import 'controller/report_visit_controller.dart';

class VisitType extends StatefulWidget {

  Value userId;
  String visitMaster;

  VisitType({super.key, required this.userId, required this.visitMaster});

  @override
  State<VisitType> createState() => _VisitTypeState();
}

class _VisitTypeState extends State<VisitType> {



  @override
  Widget build(BuildContext context) {

    final clientData = Provider.of<ClientProvider>(context,  listen: false);
    clientData.getClientVisitTypeName(widget.userId.clientId.toString());

    final visitTypeData = Provider.of<VisitTypeController>(context,  listen: false);

    return Scaffold(
      appBar: const CustomAppBar(
          backgroundColor: Colors.white,
          title: 'Visit Type'),
      backgroundColor: Colors.grey.shade200,
      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.all(20.0),
          child: Column(
            children: [
              // Text('Our customisable and easy-to-use software supports recording at the point of care, saving time and allowing for more accurate notes.', textAlign: TextAlign.justify, style: TextStyle(fontFamily: 'Montserrat',fontSize: 16, fontWeight: FontWeight.w700, color: Colors.grey.shade700),),

              const Text(
                'Which type of visit is this?',
                style: TextStyle(
                    fontSize: 18, fontWeight: FontWeight.w700),
              ),

              Consumer<ClientProvider>(
                  builder: (context, value, child) {
                    return Container(
                      margin: const EdgeInsets.symmetric(vertical: 20),
                      padding: const EdgeInsets.only(top: 10, bottom: 10),
                      decoration: BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.circular(10),
                      ),
                      child: value.visitList.isNotEmpty?
                      Column(
                        children: List.generate(
                          value.visitList.length,
                              (index) => FutureBuilder<Column>(
                            future: getVisitSingleItem(value.visitList[index], clientData, context, index), // Pass the context
                            builder: (context, snapshot) {
                              if (snapshot.connectionState == ConnectionState.waiting) {
                                return Container(); // Placeholder while waiting for data
                              } else if (snapshot.hasError) {
                                return Text('Error: ${snapshot.error}');
                              } else {
                                // Wrap the generated item with GestureDetector
                                return GestureDetector(
                                  onTap: () {
                                    updateVisitType(value.visitList[index]['CLIENT_VISIT_TYPE_MST_ID'], visitTypeData);
                                    Navigator.pop(context);
                                    //print('Item clicked: ${value.visitList[index]['VISIT_TYPE_NAME']}');
                                  },
                                  child: snapshot.data ?? const SizedBox(), // Return the data if available
                                );
                              }
                            },
                          ),
                        ),
                      )
                          :
                      const Text('No Visiting Time available'),
                    );
                  },
              ),

              //GENERAL VISIT
              GestureDetector(

                onTap: (){
                  updateVisitType("G", visitTypeData);
                  Navigator.pop(context, "General");
                },

                child: Container(
                  margin: const EdgeInsets.symmetric(vertical: 20),
                  height: 70,
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(10),
                  ),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      const Padding(
                        padding: EdgeInsets.symmetric(horizontal: 20.0),
                        child: Text(
                          'General Visit',
                          style: TextStyle(
                              color: grayColor,
                              fontSize: 16,
                              fontWeight: FontWeight.w600),
                        ),
                      ),
                      Container(
                        margin: const EdgeInsets.only(right: 20),
                          child: const Icon(Icons.arrow_forward_ios, size: 18)
                      )
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }



  Future<Column> getVisitSingleItem(Map<String, dynamic> visitName, ClientProvider clientData, BuildContext context, int index) async {
    List<Map<String, dynamic>> visitIconList = await clientData.getClientVisitTypeIconByName(visitName['VISIT_TYPE_NAME']);

    return Column(
      children: [
        if(index != 0)
        Container(
          color: Colors.grey.shade200,
          height: 2,
        ),
        Row(
          children: [
            Expanded(
              child: Column(
                children: [
                  Container(
                    margin: const EdgeInsets.only(top: 5),
                    padding: const EdgeInsets.only(left: 18.0),
                    child: Align(
                      alignment: Alignment.centerLeft,
                      child: RichText(
                        text: TextSpan(
                          style: DefaultTextStyle.of(context).style,
                          children: [
                            TextSpan(
                              text: visitName['VISIT_TYPE_NAME'],
                              style: const TextStyle(
                                  color: grayColor,
                                  fontSize: 16,
                                  fontWeight: FontWeight.w600),
                            ),
                            const TextSpan(
                              text: ' Visit',
                              style: TextStyle(
                                  color: grayColor,
                                  fontSize: 16,
                                  fontWeight: FontWeight.w600),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                  Container(
                    height: 30,
                    margin: const EdgeInsets.only(left: 15, top: 5, bottom: 5),
                    child: ListView.builder(
                      scrollDirection: Axis.horizontal,
                      itemCount: visitIconList.length,
                      itemBuilder: (context, index) {
                        return IconFromUrl(imageUrl: visitIconList[index]['TASK_CODE']);
                      },
                    ),
                  ),

                ],
              ),
            ),
            Container(
                margin: const EdgeInsets.only(right: 20),
                child: const Icon(Icons.arrow_forward_ios, size: 18)
            )
          ],
        ),
      ],
    );
  }

  void updateVisitType(String visitList, VisitTypeController value) {

    print("Update Test");
    print(widget.visitMaster.toString());
    print(visitList.toString());

    value.updateVisitType(widget.visitMaster, visitList);
    value.getVisitData(widget.visitMaster, widget.userId.orgCode!);

  }

}
