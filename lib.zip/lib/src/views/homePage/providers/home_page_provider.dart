import 'package:care4u/src/controls/apiHandler/api_handler.dart';
import 'package:flutter/foundation.dart';

import '../../../controls/localDatabaseHandler/local_db_handler_visit.dart';
import '../../../controls/utils/oneTimeNetCheck.dart';

class HomePageProvider extends ChangeNotifier {
  /*------------------------> Declaring variables <---------------------------*/
  ApiHandler _apiHandler = ApiHandler();
  bool isDownload = false;
  final VisitHandler visitHandler = VisitHandler();
  /* DpdOrgAllClientListModel _dpdOrgAllClientListModel =
      DpdOrgAllClientListModel();

  *//*------------------------> Getting all variables <---------------------------*//*
  DpdOrgAllClientListModel get getDpdOrgAllClientListModel =>
      _dpdOrgAllClientListModel;*/

  /*------------------------> Setting all variables <---------------------------*/
  Future<void> setDpdOrgAllClientListModel() async {
    //  final code = {"P_USER_ID": 20};
    //isDownload = await _apiHandler.downloadData();
    if(await uploadData()??false){
      await ApiHandler().downloadData();
    }else{
      await ApiHandler().downloadData();
    }
    notifyListeners();
  }

  Future<bool?> uploadData() async {

    List<Map<String, dynamic>> result = await visitHandler.getUnUploadedData();

    if (await getConnection()) {
      bool temp = false;

      await Future.forEach(result ?? [], (element) async {

        temp = await visitHandler.getAllVisitData(element['CARER_VISIT_MST_ID'].toString());

      });

      if (temp) {
        return true;
      } else {
        return false;

      }

    }

    return false;
  }
}
