import 'package:flutter/material.dart';

class GlassContainer extends StatelessWidget {
  final IconData icon;
  final String text;
  final int index;

  GlassContainer({required this.icon, required this.text, required this.index});

  @override
  Widget build(BuildContext context) {
    return Container(
      width: MediaQuery.of(context).size.width * 0.37,
      height: MediaQuery.of(context).size.height * 0.22,
      decoration: BoxDecoration(
        boxShadow: [
          BoxShadow(
            color: Colors.grey.withOpacity(0.5),
            spreadRadius: 0,
            blurRadius: 3,
            offset: const Offset(2, 5), // changes position of shadow
          ),
        ],
        borderRadius: index == 1
            ? const BorderRadius.only(
                topLeft: Radius.circular(16),
                topRight: Radius.circular(50),
                bottomLeft: Radius.circular(16),
                bottomRight: Radius.circular(16),
              )
            : BorderRadius.circular(16.0),
        color: Colors.white.withOpacity(0.8),
      ),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(
            icon,
            size: 40.0,
            color: Theme.of(context).colorScheme.primary,
          ),
          const SizedBox(height: 8.0),
          Text(
            text,
            style: const TextStyle(fontSize: 16.0),
          ),
        ],
      ),
    );
  }
}
