import 'package:flutter/material.dart';

import '../../../controls/utils/color_codes.dart';

Widget userData({required String title, required String value}) {
  return Padding(
    padding: const EdgeInsets.symmetric(vertical: 5.0),
    child: Text.rich(
      TextSpan(
        style: const TextStyle(
            fontSize: 16,
            fontWeight: FontWeight.bold,
            color: heading
        ),
        children: [
          TextSpan(
            text: "$title:",
            style: const TextStyle(
                fontSize: 16,
                fontWeight: FontWeight.bold,
                color: heading
            ),
          ),
          TextSpan(
            text: ' $value',
            style: const TextStyle(
                fontSize: 16,
                color: grayColor2,
              fontWeight: FontWeight.normal
            ),
          ),
        ],
      ),
    ),
  );
}
