import 'package:flutter/material.dart';
Widget clientsList({
  required String name,
  required String address,
  required IconData iconName,
  required IconData iconData,
  required BuildContext context,
  required String image,
}) {
  return Padding(
    padding: const EdgeInsets.all(20.0),
    child: Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            CircleAvatar(
              maxRadius: 25,
              backgroundImage: NetworkImage(image),
            ),
            const SizedBox(width: 10.0), // Add some space between the CircleAvatar and the text
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Text(
                        name,
                        style: const TextStyle(
                            fontFamily: 'Montserrat',
                            fontSize: 16,
                            fontWeight: FontWeight.w700),
                      ),
                      const SizedBox(
                        width: 10,
                      ),
                      Icon(iconName, size: 20,color: Colors.grey,),
                    ],
                  ),
                  SizedBox(
                    width: MediaQuery.of(context).size.width * 0.6, // Adjust the width as needed
                    child: Text(
                      address,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(
                          fontFamily: 'Montserrat',
                          fontSize: 14,
                          fontWeight: FontWeight.w400),
                    ),
                  ),
                ],
              ),
            ),
            Icon(iconData, color: Theme.of(context).colorScheme.primary),
          ],
        ),
      ],
    ),
  );
}
