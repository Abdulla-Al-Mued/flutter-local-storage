import 'dart:async';

import 'package:care4u/src/controls/localDatabaseHandler/local_database_handler.dart';
import 'package:care4u/src/controls/localStorage/local_storage.dart';
import 'package:care4u/src/controls/utils/oneTimeNetCheck.dart';
import 'package:connectivity_plus/connectivity_plus.dart';
import 'package:flutter/services.dart';
import '../../controls/utils/image_url.dart';
import '../../models/LocalModel/LocalDpd_Cms_Carer_Cln_Dtws_Sch_Lst_Model.dart';
import 'package:care4u/src/controls/utils/permission.dart';
import 'package:care4u/src/views/reportPage/report_list.dart';
import 'package:flutter/material.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:swipe_refresh/swipe_refresh.dart';
import '../../controls/apiHandler/api_handler.dart';
import '../../controls/localDatabaseHandler/local_db_handler_visit.dart';
import '../../controls/utils/Tools.dart';
import '../clients/clients.dart';
import '../passcodeSetupPage/passcode_enter_screen.dart';
import '../report/new_report.dart';
import '../schedulelist/client_schedule_list.dart';
import '../settings/settings.dart';
import 'widgets/home_page_gridviwer.dart';


class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  int _currentIndex = 0;
  late LocalStorage localStorage;


  int get insertedId_CMS_CARER_VISIT_CHK_INOUT => _currentIndex;
  final _controller = StreamController<SwipeRefreshState>.broadcast();
  final ScrollController _scrollController = ScrollController();
  final VisitHandler visitHandler = VisitHandler();
  LocalDatabaseHandler localDatabaseHandler = LocalDatabaseHandler();


  Stream<SwipeRefreshState> get _stream => _controller.stream;
  bool isConnected = true;
  late Connectivity connectivity;
  late StreamSubscription<List<ConnectivityResult>> connectivitySubscription;

  Future<void> checkConnection() async{

    connectivitySubscription = connectivity.onConnectivityChanged.listen((event) {
      if (event.contains(ConnectivityResult.mobile)) {
        isConnected = true;
      } else if (event.contains(ConnectivityResult.wifi)) {
        isConnected = true;
      } else if (event.contains(ConnectivityResult.ethernet)) {
        isConnected = true;
      } else if (event.contains(ConnectivityResult.vpn)) {
        isConnected = true;
      } else if (event.contains(ConnectivityResult.bluetooth)) {
        isConnected = true;
      } else if (event.contains(ConnectivityResult.other)) {
        isConnected = true;
      } else if (event.contains(ConnectivityResult.none)) {
        isConnected = false;
      }
      setState(() {

      });
    });



  }

  Future<void> refresh() async {

    if(await uploadData()??false){
      await ApiHandler().downloadData();
      setState(() {

      });
      _controller.sink.add(SwipeRefreshState.hidden);
    }else{
      await ApiHandler().downloadData();
      setState(() {

      });
      _controller.sink.add(SwipeRefreshState.hidden);
    }
  }

  Future<bool?> uploadData() async {

    List<Map<String, dynamic>> result = await visitHandler.getUnUploadedData();

    if (await getConnection()) {
      bool temp = false;

      await Future.forEach(result ?? [], (element) async {

        temp = await visitHandler.getAllVisitData(element['CARER_VISIT_MST_ID'].toString());

      });

      if (temp) {
        return true;
      } else {
        return false;

      }

    }

    return false;
  }
  
  @override
  void initState() {
    super.initState();
    localStorage = LocalStorage();
    checkLocationPermission();
    connectivity = Connectivity();
    checkConnection();
    //_checkInternetConnectivity();
  }

  @override
  void dispose() {
    super.dispose();
    // Dispose of the subscription
    connectivitySubscription.cancel();
  }


  @override
  Widget build(BuildContext context) {

    // SystemChrome.setPreferredOrientations([
    //   DeviceOrientation.portraitUp,
    //   DeviceOrientation.portraitDown,
    // ]);

    //checkConnection();

    print(localStorage.userLoginDetail.value![0].carerImagePath);

    final isActive =
        localStorage.userLoginDetail.value![0].userActiveStatus == "Y";
    final activeText = isActive ? 'Active' : 'Offline';
    final iconColor =
    isActive ? Colors.greenAccent : Colors.blueGrey; // Change color to green if active
    return PopScope(
      canPop: false,
      child: Scaffold(
        appBar: AppBar(
          automaticallyImplyLeading: false,
          centerTitle: true,
          title: Image.asset('assets/logo/care4u.png',
              height: MediaQuery.of(context).size.height * .05,
              fit: BoxFit.cover),
          backgroundColor: Theme.of(context).colorScheme.primary,
        ),
        body: SwipeRefresh.material(
            scrollController: _scrollController,
            stateStream: _stream,
            onRefresh: refresh,
            children: [
              SizedBox(
                width: MediaQuery.of(context).size.width,
                height: MediaQuery.of(context).size.height * .80,
                child: Stack(
                  children: [
                    Stack(
                      children: [
                        Container(
                          width: MediaQuery.of(context).size.width,
                          height: MediaQuery.of(context).size.height / 3.0,
                          decoration: const BoxDecoration(
                            color: Colors.white,
                          ),
                        ),
                        Container(
                          width: MediaQuery.of(context).size.width,
                          height: MediaQuery.of(context).size.height / 3.0,
                          decoration: BoxDecoration(
                            color: Theme.of(context).colorScheme.primary,
                            borderRadius: const BorderRadius.only(
                              // bottomLeft: Radius.circular(80),
                            ),
                          ),
                          child: Center(
                            child: Column(
                              mainAxisAlignment: MainAxisAlignment.start,
                              children: [
                                Row(
                                  mainAxisAlignment: MainAxisAlignment.end,
                                  children: [
                                    Icon(
                                      Icons.circle,
                                      size: 10,
                                      color: iconColor,
                                    ),
                                    const SizedBox(
                                      width: 5,
                                    ),
                                    // Display "Offline" text if not active
                                    Text(
                                      activeText,
                                      style: const TextStyle(
                                        fontFamily: 'Montserrat',
                                        fontSize: 12,
                                        color: Colors.white,
                                      ),
                                    ),
                                    const SizedBox(width: 30),
                                  ],
                                ),
                                Column(
                                  children: [
                                    Padding(
                                      padding:
                                      const EdgeInsets.only(right: 20, left: 20),
                                      child: Column(
                                        children: [
                                          Row(
                                            children: [
                                              if (localStorage.userLoginDetail.value![0].carerImagePath != null && isConnected)
                                                ClipRRect(
                                                  borderRadius: BorderRadius.circular(25),
                                                  child: Image.network(
                                                    CARER_IMAGE_URL+localStorage.userLoginDetail.value![0].carerImagePath!,
                                                    width: 50,
                                                    height: 50,
                                                    fit: BoxFit.cover,
                                                    errorBuilder: (context, error, stackTrace) {
                                                      // Error occurred while loading image
                                                      return const CircleAvatar(
                                                        backgroundColor: Colors.purple,
                                                        radius: 40,
                                                        child: Icon(Icons.person),
                                                      );
                                                    },
                                                  ),
                                                )
                                              else
                                                const CircleAvatar(
                                                  backgroundColor: Colors.blue,
                                                  radius: 35,
                                                  child: Icon(Icons.person),
                                                ),
                                              const SizedBox(
                                                width: 15,
                                              ),
                                              Column(
                                                crossAxisAlignment:
                                                CrossAxisAlignment.start,
                                                children: [
                                                  SizedBox(
                                                    width: MediaQuery.of(context)
                                                        .size
                                                        .width *
                                                        .6,
                                                    child: Text(
                                                      '${localStorage.userLoginDetail.value![0].firstName} ${localStorage.userLoginDetail.value![0].lastName}',
                                                      overflow: TextOverflow.ellipsis,
                                                      maxLines: 1,
                                                      style: const TextStyle(
                                                          fontFamily: 'Montserrat',
                                                          fontSize: 16,
                                                          fontWeight: FontWeight.w600,
                                                          color: Colors.white),
                                                    ),
                                                  ),
                                                  const SizedBox(
                                                    height: 8,
                                                  ),
                                                  Text(
                                                    '${localStorage.userLoginDetail.value![0].carerPhone}',
                                                    style: const TextStyle(
                                                        fontFamily: 'Montserrat',
                                                        fontSize: 16,
                                                        fontWeight: FontWeight.w500,
                                                        color: Colors.white),
                                                  ),
                                                ],
                                              ),
                                            ],
                                          ),
                                          const SizedBox(
                                            height: 40,
                                          )
                                        ],
                                      ),
                                    ),
                                  ],
                                ),
                                const SizedBox(
                                  height: 70,
                                ),
                              ],
                            ),
                          ),
                        ),
                      ],
                    ),
                    Align(
                      alignment: Alignment.bottomCenter,
                      child: Container(
                        width: MediaQuery.of(context).size.width,
                        height: MediaQuery.of(context).size.height / 1.5,
                        decoration: BoxDecoration(
                          color: Theme.of(context).colorScheme.primary,
                        ),
                      ),
                    ),
                    Align(
                      alignment: Alignment.bottomCenter,
                      child: Container(
                        width: MediaQuery.of(context).size.width,
                        height: MediaQuery.of(context).size.height / 1.5,
                        decoration: const BoxDecoration(
                          color: Colors.white,
                          borderRadius: BorderRadius.only(
                            topRight: Radius.circular(150),
                          ),
                        ),
                        child: Padding(
                            padding: const EdgeInsets.all(20.0),
                            child: Container(
                              width: 200,
                              height: 150,
                              decoration: BoxDecoration(
                                color: Colors.white,
                                borderRadius: const BorderRadius.only(
                                  topRight: Radius.circular(150.0),
                                  topLeft: Radius.circular(10),
                                  bottomLeft: Radius.circular(10),
                                  bottomRight: Radius.circular(10),
                                ),
                                boxShadow: [
                                  BoxShadow(
                                    color: Colors.grey.withOpacity(0.5),
                                    spreadRadius: 5,
                                    blurRadius: 7,
                                    offset: const Offset(
                                        0, 3), // changes position of shadow
                                  ),
                                ],
                              ),
                              child: Padding(
                                padding: const EdgeInsets.all(16),
                                child: Column(
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  children: [
                                    Row(
                                      mainAxisAlignment:
                                      MainAxisAlignment.spaceEvenly,
                                      children: [
                                        GestureDetector(
                                          onTap: () {
                                            Navigator.push(
                                              context,
                                              MaterialPageRoute(
                                                  builder: (context) =>
                                                  const ClientDetailsScheduleLists()),
                                            );
                                          },
                                          child: GlassContainer(
                                            index: 0,
                                            icon: Icons.schedule,
                                            text: 'Schedule',
                                          ),
                                        ),
                                        GestureDetector(
                                          onTap: () {
                                            Navigator.push(
                                                context,
                                                MaterialPageRoute(
                                                  builder: (context) =>
                                                  const Clients(),
                                                ));
                                          },
                                          child: GlassContainer(
                                            index: 1,
                                            icon: Icons.group,
                                            text: 'Clients',
                                          ),
                                        ),
                                      ],
                                    ),
                                    const SizedBox(height: 16.0),
                                    Row(
                                      mainAxisAlignment:
                                      MainAxisAlignment.spaceEvenly,
                                      children: [
                                        GestureDetector(
                                          onTap: () {
                                            Navigator.push(
                                              context,
                                              MaterialPageRoute(
                                                  builder: (context) =>
                                                  const ReportList()),
                                            );
                                          },
                                          child: GlassContainer(
                                            index: 2,
                                            icon: Icons.newspaper,
                                            text: 'Reports',
                                          ),
                                        ),
                                        GestureDetector(
                                          onTap: () {
                                            Navigator.push(
                                              context,
                                              MaterialPageRoute(
                                                  builder: (context) =>
                                                  const Settings()),
                                            );
                                          },
                                          child: GlassContainer(
                                            index: 3,
                                            icon: Icons.settings,
                                            text: 'Settings',
                                          ),
                                        ),
                                      ],
                                    ),
                                  ],
                                ),
                              ),
                            )),
                      ),
                    ),
                  ],
                ),
              )
            ]
        ),
        bottomNavigationBar: buildBottomNavigationBar(context),
      ),
    );
  }

  BottomNavigationBar buildBottomNavigationBar(BuildContext context) {
    return BottomNavigationBar(
      currentIndex: _currentIndex,
      onTap: (index) {
        setState(() {
          _currentIndex = index;
          if (index == 2) {
            _showLogoutDialog(context);
          }
          if(index == 1){
            checkExist();
          }
          _currentIndex = 0;
        });
      },
      items: const [
        BottomNavigationBarItem(
          icon: Icon(Icons.home_filled ),
          label: 'Home',
        ),
        BottomNavigationBarItem(
          icon: Icon(Icons.pending_actions_outlined),
          label: 'Checked in Task',
        ),
        BottomNavigationBarItem(
          icon: Icon(Icons.logout),
          label: 'Logout',
        ),
      ],
    );
  }

  void checkLocationPermission() {
    checkPermission0(Permission.location, context);
  }

  void _showLogoutDialog(BuildContext context) async {
    final result = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        shape: RoundedRectangleBorder(
          // Remove rounded corners
          borderRadius: BorderRadius.circular(10),
        ),
        content: const Text(
          'Are you sure you want to log out?',
          textAlign: TextAlign.center,
          style: TextStyle(
              fontFamily: 'Montserrat',
              fontSize: 16,
              fontWeight: FontWeight.w500),
        ),
        actions: <Widget>[
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              TextButton(
                onPressed: () {
                  Navigator.of(context).pop(false);
                },
                child: const Text(
                  'Cancel',
                  style: TextStyle(
                      fontFamily: 'Montserrat',
                      fontSize: 14,
                      fontWeight: FontWeight.w500),
                ),
              ),
              const SizedBox(width: 10),
              TextButton(
                onPressed: () {
                  Navigator.of(context).pop(true);
                },
                child: const Text(
                  'Logout',
                  style: TextStyle(
                      fontFamily: 'Montserrat',
                      fontSize: 14,
                      fontWeight: FontWeight.w500),
                ),
              ),
            ],
          )
        ],
      ),
    );

    if (result == true) {
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(builder: (context) => const EnterPasscodeScreen()),
      );
    }
  }

  Future<void> checkExist() async {
    var data = await localDatabaseHandler.getMstIdIfExist();
    if(data!=null){
      print(data);
      Value val = Value(
        clientName: data['NAME'],
        clientCode: data['CLIENT_CODE'],
        clientId: data['CLIENT_ID'],
        orgCode: data['ORG_CODE'],
        clientDatewiseSchId: data['CLIENT_DATEWISE_SCH_ID'],
        clientVisitTypeMstId: data['CLIENT_VISIT_TYPE_MST_ID'],
      );

      Navigator.push(
        context,
        MaterialPageRoute(
          builder: (context) => NewReport(userId: val, id: data['CARER_VISIT_MST_ID'], scType: ''),
        ),
      );

    }
    else{
      showToastInfo("No Checked In Task Found");
    }
  }
}