import 'package:care4u/src/views/signinPage/signin_page_view.dart';
import 'package:flutter/material.dart';

GestureDetector loginButtonFromPasscode(BuildContext context) {
  return GestureDetector(
    onTap: () {
      Navigator.pushReplacement(context, MaterialPageRoute(builder: (context) => const SignInPage(),));
    },
    child: Text.rich(
      TextSpan(
        style: const TextStyle(
          fontSize: 20,
        ),
        children: [
          const TextSpan(
            text: 'Click Here To',
          ),
          TextSpan(
            text: ' Log In',
            style: TextStyle(
              color: Theme.of(context).colorScheme.primary,
              fontWeight: FontWeight.bold,
            ),
          )
        ],
      ),
    ),
  );
}
