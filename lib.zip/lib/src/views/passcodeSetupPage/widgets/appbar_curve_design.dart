import 'package:flutter/material.dart';

Stack appBarCurveDesign(BuildContext context) {
  return Stack(
    children: [
      Container(
        width: MediaQuery.of(context).size.width,
        height: MediaQuery.of(context).size.height / 14.0,
        decoration: const BoxDecoration(
          color: Colors.white,
        ),
      ),
      Container(
        width: MediaQuery.of(context).size.width,
        height: MediaQuery.of(context).size.height / 14.0,
        decoration: BoxDecoration(
          color: Theme.of(context).colorScheme.primary,
          borderRadius: const BorderRadius.only(
            bottomRight: Radius.circular(120),
          ),
        ),
      ),
    ],
  );
}
