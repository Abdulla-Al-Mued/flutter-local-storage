import 'package:care4u/src/controls/localStorage/local_storage.dart';
import 'package:care4u/src/views/homePage/home_screen.dart';
import 'package:care4u/src/views/homePage/providers/home_page_provider.dart';
import 'package:care4u/src/views/passcodeSetupPage/passcode_sucessful_screen.dart';
import 'package:care4u/src/views/passcodeSetupPage/widgets/show_alert.dart';
import 'package:flutter/material.dart';
import 'package:path/path.dart';
import 'package:provider/provider.dart';

Row passcodeInputField(
    {required List passcodeControllers,
    required List focusNodes,
    required BuildContext context}) {
  return Row(
    mainAxisAlignment: MainAxisAlignment.center,
    children: List.generate(
      passcodeControllers.length,
      (index) => Container(
        width: 50,
        margin: const EdgeInsets.symmetric(horizontal: 8),
        decoration: BoxDecoration(
          color: Colors.grey.shade200,
          borderRadius: BorderRadius.circular(8),
        ),
        child: TextField(
          autofocus: true,
          controller: passcodeControllers[index],
          maxLength: 1,
          focusNode: focusNodes[index],
          obscureText: true,
          keyboardType: TextInputType.number,
          textAlign: TextAlign.center,
          decoration: InputDecoration(
            counterText: "",
            contentPadding: EdgeInsets.zero,
            enabledBorder: UnderlineInputBorder(
              borderRadius: BorderRadius.circular(10.0),
              borderSide: const BorderSide(
                color: Colors.grey,
                width: 3.0,
              ),
            ),
            focusedBorder: UnderlineInputBorder(
              borderRadius: BorderRadius.circular(10.0),
              borderSide: const BorderSide(
                color: Colors.blue,
                width: 3.0,
              ),
            ),
          ),
          onChanged: (value) {
            if (value.isNotEmpty && index < passcodeControllers.length - 1) {
              focusNodes[index].unfocus();
              focusNodes[index + 1].requestFocus();
            }

            // Check if all fields are filled
            if (passcodeControllers
                .every((controller) => controller.text.isNotEmpty)) {
              // Automatically submit passcode
              submitPasscode(
                  passcodeControllers: passcodeControllers,
                  focusNodes: focusNodes,
                  context: context);
            }
          },
        ),
      ),
    ),
  );
}

void submitPasscode(
    {required List passcodeControllers,
      required List focusNodes,
      required BuildContext context}) async {
  final homePageProvider =
  Provider.of<HomePageProvider>(context, listen: false);
  String enteredPasscode =
  passcodeControllers.map((controller) => controller.text).join();

  if (enteredPasscode.length == 4) {
    // Show circular progress indicator
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (BuildContext context) {
        return Center(child: SizedBox(
          height: MediaQuery.of(context).size.height*.7,
          child: Container(
              height: 50,
              width: 50,
              child: Image.asset('assets/images/loading.gif')
          ),
        ));
      },
    );

    if (LocalStorage().getPasscode == enteredPasscode) {
      await homePageProvider.setDpdOrgAllClientListModel().then((value) {
        // Navigate to the next page upon successful passcode entry
        Navigator.pushAndRemoveUntil(
            context,
            MaterialPageRoute(builder: (context) => const HomeScreen()),
                (route) => false);
      });
    } else {
      Navigator.pop(context); // Close the circular progress indicator dialog
      showSnackBar(message: 'Wrong passcode!', context: context);
    }
  } else {
    showSnackBar(message: 'Please enter a 4-digit passcode.', context: context);
  }
}

