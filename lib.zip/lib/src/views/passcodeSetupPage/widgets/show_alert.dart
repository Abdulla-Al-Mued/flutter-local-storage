import 'package:care4u/src/views/passcodeSetupPage/passcode_sucessful_screen.dart';
import 'package:flutter/material.dart';

showSnackBar({required BuildContext context, required String message}) {
  final snackBar = SnackBar(
    content: Text(
      message,
      style: TextStyle(
        fontSize: 14,
      ),
    ),
    backgroundColor:Theme.of(context).colorScheme.primary,
  );
  ScaffoldMessenger.of(context).showSnackBar(snackBar);
}
// action: SnackBarAction(
//   label: 'OK',
//   onPressed: () {
//     // Some code to run when the user presses the action button
//   },
// ),