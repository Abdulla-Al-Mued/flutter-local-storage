import 'package:flutter/material.dart';

Text labelText() {
  return const Text(
    'Enter Your Passcode',
    style: TextStyle(
        fontFamily: 'Montserrat',
        color: Colors.black,
        fontSize: 18,
        fontWeight: FontWeight.w600),
  );
}
