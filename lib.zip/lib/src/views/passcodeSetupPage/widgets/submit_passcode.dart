import 'package:flutter/material.dart';

void submitPasscode({required List passcodeControllers}) async {
  String enteredPasscode =
      passcodeControllers.map((controller) => controller.text).join();

  // bool isVerified = await verifyPasscode(enteredPasscode);

  // if (isVerified) {
  // } else {
  //   // showAlert('Incorrect passcode. Try again.');
  // }
}
