import 'package:flutter/foundation.dart';

class PasscodeSetupProvider extends ChangeNotifier {}
