import 'package:care4u/src/views/passcodeSetupPage/widgets/appbar_curve_design.dart';
import 'package:care4u/src/views/passcodeSetupPage/widgets/label_text.dart';
import 'package:care4u/src/views/passcodeSetupPage/widgets/login_button.dart';
import 'package:care4u/src/views/passcodeSetupPage/widgets/passcode_input_field.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:care4u/src/views/passcodeSetupPage/widgets/appbar_curve_design.dart';
import 'package:care4u/src/views/passcodeSetupPage/widgets/label_text.dart';
import 'package:care4u/src/views/passcodeSetupPage/widgets/login_button.dart';
import 'package:care4u/src/views/passcodeSetupPage/widgets/passcode_input_field.dart';

class EnterPasscodeScreen extends StatefulWidget {
  const EnterPasscodeScreen({super.key});

  @override
  State<EnterPasscodeScreen> createState() => _EnterPasscodeScreenState();
}

class _EnterPasscodeScreenState extends State<EnterPasscodeScreen> with WidgetsBindingObserver  {
  final List<TextEditingController> _passcodeControllers =
  List.generate(4, (_) => TextEditingController());

  final List<FocusNode> _focusNodes = List.generate(4, (_) => FocusNode());

  @override
  void initState() {
    super.initState();
    //_focusNodes[0].requestFocus();
    WidgetsBinding.instance.addObserver(this);
    WidgetsBinding.instance.addPostFrameCallback((_){
      FocusScope.of(context).requestFocus(_focusNodes[0]);
    });
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    for (var node in _focusNodes) {
      node.dispose();
    }
    super.dispose();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    // if (state == AppLifecycleState.resumed) {
    //   _focusNodes[0].requestFocus();
    // }
  }

  @override
  Widget build(BuildContext context) {

    return RawKeyboardListener(
      focusNode: FocusNode(),
      onKey: (RawKeyEvent event) {
        if (event is RawKeyDownEvent && event.logicalKey == LogicalKeyboardKey.backspace) {
          _handleBackspace();
        }
      },
      child: Scaffold(
        body: GestureDetector(
          onTap: () {
            // Dismiss keyboard when tapping outside the input field
            FocusScope.of(context).unfocus();
          },
          child: SingleChildScrollView(
            child: SizedBox(
              width: MediaQuery.of(context).size.width,
              height: MediaQuery.of(context).size.height,
              child: Stack(
                children: [
                  appBarCurveDesign(context),
                  Align(
                    alignment: Alignment.bottomCenter,
                    child: Container(
                      width: MediaQuery.of(context).size.width,
                      height: MediaQuery.of(context).size.height / 1.21,
                      decoration: const BoxDecoration(
                        color: Colors.white,
                      ),
                      child: Padding(
                        padding: const EdgeInsets.all(16.0),
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.start,
                          children: [
                            const SizedBox(
                              height: 20,
                            ),
                            labelText(),
                            const SizedBox(
                              height: 20,
                            ),
                            passcodeInputField(
                              focusNodes: _focusNodes,
                              passcodeControllers: _passcodeControllers,
                              context: context,
                            ),
                            const SizedBox(height: 40.0),
                            loginButtonFromPasscode(context),
                          ],
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  void _handleBackspace() {
    for (int i = _passcodeControllers.length - 1; i >= 0; i--) {
      if (_passcodeControllers[i].text.isNotEmpty) {
        _passcodeControllers[i].clear();
        if (i > 0) {
          _focusNodes[i - 1].requestFocus();
        }
        break;
      }
    }
  }
}

