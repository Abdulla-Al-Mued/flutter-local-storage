import 'package:care4u/src/controls/localStorage/local_storage.dart';
import 'package:care4u/src/views/passcodeSetupPage/passcode_sucessful_screen.dart';
import 'package:care4u/src/views/passcodeSetupPage/widgets/show_alert.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

class SetPasscodeScreen extends StatefulWidget {
  const SetPasscodeScreen({super.key});

  @override
  State<SetPasscodeScreen> createState() => _SetPasscodeScreenState();
}

class _SetPasscodeScreenState extends State<SetPasscodeScreen> {
  final List<TextEditingController> _passcodeControllers =
      List.generate(4, (_) => TextEditingController());
  final List<FocusNode> _focusNodes = List.generate(4, (_) => FocusNode());
  LocalStorage localStorage = LocalStorage();

  Future<void> savePasscode(String passcode) async {
    if (localStorage.getPasscode.isEmpty) {
      localStorage.setPasscode(value: passcode);
    }if(localStorage.getPasscode.isNotEmpty) {
      localStorage.setPasscode(value: passcode);
    }
  }

  @override
  void dispose() {
    for (var node in _focusNodes) {
      node.dispose();
    }
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    _focusNodes[0].requestFocus();
    return RawKeyboardListener(
      focusNode: FocusNode(),
      onKey: (RawKeyEvent event) {
        if (event is RawKeyDownEvent &&
            event.logicalKey == LogicalKeyboardKey.backspace) {
          _handleBackspace();
        }
      },
      child: Scaffold(
        body: SingleChildScrollView(
          child: SizedBox(
            width: MediaQuery.of(context).size.width,
            height: MediaQuery.of(context).size.height,
            child: Stack(
              children: [
                Stack(
                  children: [
                    Container(
                      width: MediaQuery.of(context).size.width,
                      height: MediaQuery.of(context).size.height / 14.0,
                      decoration: const BoxDecoration(
                        color: Colors.white,
                      ),
                    ),
                    Container(
                      width: MediaQuery.of(context).size.width,
                      height: MediaQuery.of(context).size.height / 14.0,
                      decoration: BoxDecoration(
                        color: Theme.of(context).colorScheme.primary,
                        borderRadius: const BorderRadius.only(
                          bottomRight: Radius.circular(120),
                        ),
                      ),
                    ),
                  ],
                ),
                Align(
                  alignment: Alignment.bottomCenter,
                  child: Container(
                    width: MediaQuery.of(context).size.width,
                    height: MediaQuery.of(context).size.height / 1.21,
                    decoration: const BoxDecoration(
                      color: Colors.white,
                    ),
                    child: Padding(
                      padding: const EdgeInsets.all(20.0),
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.start,
                        children: [
                          const Column(
                            children: [
                              SizedBox(
                                height: 40,
                              ),
                              Text(
                                'Create a four digit passcode',
                                style: TextStyle(
                                    fontFamily: 'Montserrat',
                                    fontSize: 18,
                                    fontWeight: FontWeight.w700),
                              ),
                              Text(
                                'You can use this passcode to quickly log back into care4u without having to enter your full password.',
                                textAlign: TextAlign.center,
                                style: TextStyle(
                                    fontFamily: 'Montserrat',
                                    fontSize: 16,
                                    fontWeight: FontWeight.w500),
                              ),
                            ],
                          ),
                          const SizedBox(
                            height: 40,
                          ),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: List.generate(
                              _passcodeControllers.length,
                              (index) => Container(
                                width: 50,
                                margin:
                                    const EdgeInsets.symmetric(horizontal: 8),
                                decoration: BoxDecoration(
                                  color: Colors.grey.shade200,
                                  borderRadius: BorderRadius.circular(8),
                                ),
                                child: TextField(
                                  controller: _passcodeControllers[index],
                                  maxLength: 1,
                                  focusNode: _focusNodes[index],
                                  obscureText: true,
                                  keyboardType: TextInputType.number,
                                  textAlign: TextAlign.center,
                                  decoration: InputDecoration(
                                    counterText: "",
                                    contentPadding: EdgeInsets.zero,
                                    enabledBorder: UnderlineInputBorder(
                                      borderRadius: BorderRadius.circular(10.0),
                                      borderSide: const BorderSide(
                                        color: Colors.grey,
                                        width: 3.0,
                                      ),
                                    ),
                                    focusedBorder: UnderlineInputBorder(
                                      borderRadius: BorderRadius.circular(10.0),
                                      borderSide: const BorderSide(
                                        color: Colors.blue,
                                        width: 3.0,
                                      ),
                                    ),
                                  ),
                                  onChanged: (value) {
                                    if (value.isNotEmpty &&
                                        index <
                                            _passcodeControllers.length - 1) {
                                      _focusNodes[index].unfocus();
                                      _focusNodes[index + 1].requestFocus();
                                    }

                                    if (_passcodeControllers.every(
                                        (controller) =>
                                            controller.text.isNotEmpty)) {
                                      _submitPasscode();
                                    }
                                  },
                                ),
                              ),
                            ),
                          ),
                          const SizedBox(height: 16.0),
                        ],
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  void _submitPasscode() async {
    String enteredPasscode =
        _passcodeControllers.map((controller) => controller.text).join();

    if (enteredPasscode.length == 4) {
      await savePasscode(enteredPasscode).then((value) async {
        if (localStorage.getPasscode.isNotEmpty) {
          await
              // showAlert(
              //     context: context, message: 'Passcode set successfully!');
              Navigator.pushAndRemoveUntil(
            context,
            MaterialPageRoute(builder: (context) => PasscodeSetSuccessScreen()),
            (route) => false,
          );
        }
      });
    } else {
      showSnackBar(
          message: 'Please enter a 4-digit passcode.', context: context);
    }
  }

  void _handleBackspace() {
    for (int i = _passcodeControllers.length - 1; i >= 0; i--) {
      if (_passcodeControllers[i].text.isNotEmpty) {
        _passcodeControllers[i].clear();
        if (i > 0) {
          _focusNodes[i - 1].requestFocus();
        }
        break;
      }
    }
  }
}
