import 'package:care4u/src/controls/utils/color_codes.dart';
import 'package:care4u/src/views/homePage/home_screen.dart';
import 'package:care4u/src/controls/utils/appbar.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:care4u/src/controls/localStorage/local_storage.dart';
import 'package:flutter/widgets.dart';

class ChangePasscodeScreen extends StatefulWidget {
  const ChangePasscodeScreen({Key? key}) : super(key: key);

  @override
  State<ChangePasscodeScreen> createState() => _ChangePasscodeScreenState();
}

class _ChangePasscodeScreenState extends State<ChangePasscodeScreen> {
  final List<TextEditingController> _passcodeControllers =
  List.generate(12, (_) => TextEditingController());
  final List<FocusNode> _focusNodes = List.generate(12, (_) => FocusNode());
  final LocalStorage localStorage = LocalStorage();

  @override
  void initState() {
    _focusNodes[0].requestFocus();
    super.initState();
  }
  @override
  void dispose() {
    for (var controller in _passcodeControllers) {
      controller.dispose();
    }
    for (var node in _focusNodes) {
      node.dispose();
    }
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    // _focusNodes[0].requestFocus();
    return Scaffold(
      resizeToAvoidBottomInset: false,
      backgroundColor: Colors.grey.shade200,
      appBar:  CustomAppBar(
          backgroundColor: Colors.grey.shade200,
          title: 'Change Passcode'),
      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.all(20.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text(
                'Old Passcode',
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
              ),
              const SizedBox(height: 10),
              _buildPasscodeInput(0),
              const SizedBox(height: 20),
              const Text(
                'New Passcode',
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
              ),
              const SizedBox(height: 10),
              _buildPasscodeInput(1),
              const SizedBox(height: 10),
              const Text(
                'Confirm Passcode',
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
              ),
              const SizedBox(height: 10),
              _buildPasscodeInput(2),
              SizedBox(height: MediaQuery.of(context).size.height*0.07,),
              Center(
                child: GestureDetector(
                  onTap: _resetPasscode,
                  child: Container(
                    height: MediaQuery.of(context).size.height*0.07,
                    width: MediaQuery.of(context).size.width*.6,
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(20),
                      color: primaryColor,
                    ),
                    child: const Center(child: Text("Reset Password", textAlign: TextAlign.center, style: TextStyle(fontFamily: 'Montserrat',
                        fontWeight: FontWeight.w800, color: Colors.white),)),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildPasscodeInput(int index) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: List.generate(
        4,
            (i) => Container(
          margin: const EdgeInsets.symmetric(horizontal: 5),
          width: 50,
          height: 50,
          decoration: BoxDecoration(
            color: Colors.grey[300],
            borderRadius: BorderRadius.circular(10),
          ),
          alignment: Alignment.center,
          child: TextFormField(
            controller: _passcodeControllers[index * 4 + i],
            focusNode: _focusNodes[index * 4 + i],
            keyboardType: TextInputType.number,
            obscureText: true,
            maxLength: 1,
            textAlign: TextAlign.center,
            decoration: const InputDecoration(
              counterText: '',
              border: InputBorder.none,
              contentPadding: EdgeInsets.zero,
            ),
            style: const TextStyle(color: Colors.black, fontSize: 24),
            onChanged: (value) {
              if (value.isNotEmpty && i < 3) {
                FocusScope.of(context).requestFocus(_focusNodes[index * 4 + i + 1]);
              } else if (value.isEmpty && i > 0) {
                FocusScope.of(context).requestFocus(_focusNodes[index * 4 + i - 1]);
              }
            },
          ),
        ),
      ),
    );
  }

  void _resetPasscode() async {
    FocusScope.of(context).unfocus();
    final oldPasscode = _passcodeControllers.sublist(0, 4).map((controller) => controller.text).join();
    final newPasscode = _passcodeControllers.sublist(4, 8).map((controller) => controller.text).join();
    final confirmPasscode = _passcodeControllers.sublist(8, 12).map((controller) => controller.text).join();
    final storedPasscode = localStorage.getPasscode;

    if (oldPasscode.isEmpty || newPasscode.isEmpty || confirmPasscode.isEmpty) {
      _showSnackBar('All passcode fields must be filled');
      return;
    }
    if (oldPasscode != storedPasscode) {
      _showSnackBar('Old passcode is incorrect');
      return;
    }

    if (newPasscode.length != 4) {
      _showSnackBar('New passcode must be 4 digits long');
      return;
    }

    if (newPasscode != confirmPasscode) {
      _showSnackBar('New passcodes do not match');
      return;
    }

    localStorage.setPasscode(value: newPasscode);
    await _showSuccessSnackbar();
    _navigateToHomeScreen();
  }

  Future<void> _showSuccessSnackbar() {
    return Future.delayed(const Duration(seconds: 1), () {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          backgroundColor: Theme.of(context).colorScheme.primary,
          content: const Text('Passcode changed successfully'),
        ),
      );
    });
  }

  void _navigateToHomeScreen() {
    Navigator.pushReplacement(
      context,
      MaterialPageRoute(builder: (context) => const HomeScreen()),
    );
  }

  void _showSnackBar(String message) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        backgroundColor: Theme.of(context).colorScheme.primary,
        content: Text(message),
      ),
    );
  }
}
