import 'package:care4u/src/views/passcodeSetupPage/passcode_enter_screen.dart';
import 'package:care4u/src/views/passcodeSetupPage/passcode_set_screen.dart';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

class PasscodeScreen extends StatefulWidget {
  const PasscodeScreen({super.key});

  @override
  State<PasscodeScreen> createState() => _PasscodeScreenState();
}

class _PasscodeScreenState extends State<PasscodeScreen> {
  bool isPasscodeSet = false;

  @override
  void initState() {
    super.initState();
    checkPasscodeSet();
  }

  Future<void> checkPasscodeSet() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    bool passcodeSet = prefs.containsKey('passcode');

    setState(() {
      isPasscodeSet = passcodeSet;
    });
  }

  @override
  Widget build(BuildContext context) {
    return isPasscodeSet
        ? const EnterPasscodeScreen() // Display EnterPasscodeScreen if passcode is already set
        : const SetPasscodeScreen(); // Display SetPasscodeScreen if passcode is not set
  }
}
