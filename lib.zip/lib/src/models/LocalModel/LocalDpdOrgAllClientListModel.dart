class LocalDpdOrgAllClientListModel {
  int? id;
  String? clientId;
  String? clientCode;
  String? name;
  String? clientImagePath;
  String? address;
  String? phone;
  String? clientStatusTypeCode;
  String? clientStatusTypeDesc;
  String? orgCode;
  String? orgName;
  String? createInfo;
  String? updateInfo;
  String? clStatus;

  LocalDpdOrgAllClientListModel({
    this.id,
    this.clientId,
    this.clientCode,
    this.name,
    this.clientImagePath,
    this.address,
    this.phone,
    this.clientStatusTypeCode,
    this.clientStatusTypeDesc,
    this.orgCode,
    this.orgName,
    this.createInfo,
    this.updateInfo,
    this.clStatus,
  });

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'client_id': clientId,
      'client_code': clientCode,
      'name': name,
      'client_image_path': clientImagePath,
      'address': address,
      'phone': phone,
      'client_status_type_code': clientStatusTypeCode,
      'client_status_type_desc': clientStatusTypeDesc,
      'org_code': orgCode,
      'org_name': orgName,
      'create_info': createInfo,
      'update_info': updateInfo,
      'cl_status': clStatus,
    };
  }

  factory LocalDpdOrgAllClientListModel.fromMap(Map<String, dynamic> map) {
    return LocalDpdOrgAllClientListModel(
      id: map['id'],
      clientId: map['client_id'],
      clientCode: map['client_code'],
      name: map['name'],
      clientImagePath: map['client_image_path'],
      address: map['address'],
      phone: map['phone'],
      clientStatusTypeCode: map['client_status_type_code'],
      clientStatusTypeDesc: map['client_status_type_desc'],
      orgCode: map['org_code'],
      orgName: map['org_name'],
      createInfo: map['create_info'],
      updateInfo: map['update_info'],
      clStatus: map['cl_status'],
    );
  }
}
