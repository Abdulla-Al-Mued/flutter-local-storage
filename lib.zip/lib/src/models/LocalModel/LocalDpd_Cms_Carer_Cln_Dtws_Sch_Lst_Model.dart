// To parse this JSON data, do
//
//     final dpdOrgAllClientListModel = dpdOrgAllClientListModelFromJson(jsonString);

import 'dart:convert';

LocalDpdCmsCarerClnDtwsSchLstModel dpdOrgAllClientListModelFromJson(String str) =>
    LocalDpdCmsCarerClnDtwsSchLstModel.fromJson(json.decode(str));

String dpdOrgAllClientListModelToJson(LocalDpdCmsCarerClnDtwsSchLstModel data) =>
    json.encode(data.toJson());

class LocalDpdCmsCarerClnDtwsSchLstModel {
  String? code;
  String? msg;
  List<Value>? value;

  LocalDpdCmsCarerClnDtwsSchLstModel({
    this.code,
    this.msg,
    this.value,
  });

  factory LocalDpdCmsCarerClnDtwsSchLstModel.fromJson(Map<String, dynamic> json) =>
      LocalDpdCmsCarerClnDtwsSchLstModel(
        code: json["CODE"],
        msg: json["MSG"],
        value: json["Value"] == null
            ? []
            : List<Value>.from(json["Value"]!.map((x) => Value.fromJson(x))),
      );

  Map<String, dynamic> toJson() => {
    "CODE": code,
    "MSG": msg,
    "Value": value == null
        ? []
        : List<dynamic>.from(value!.map((x) => x.toJson())),
  };
}

class Value {
  dynamic id; // Optional field ID
  String? createInfo; // Optional field CREATE_INFO
  String? updateInfo; // Optional field UPDATE_INFO
  String? clStatus; // Optional field CL_STATUS
  String? clientDatewiseSchId;
  String? orgCode;
  String? clientId;
  String? clientCode;
  String? clientName;
  String? scheduleDayCode;
  String? dayDesc;
  String? scheduleDate;
  String? startTimeSlotCode;
  String? startTimeSlot;
  String? startTime;
  String? endTimeSlotCode;
  String? endTimeSlot;
  String? endTime;
  String? clientRateId;
  dynamic clientRateName;
  String? clientVisitTypeMstId;
  String? visitTypeName;
  String? howManyCarerReq;
  String? carerId;
  String? carerCode;
  String? carerName;
  String? carerRateId;
  String? carerRateName;
  dynamic carerId2;
  dynamic carerCode2;
  String? carerName2;
  dynamic carerRateId2;
  dynamic carerRateName2;
  String? dataStatus;

  Value({
    this.id,
    this.createInfo,
    this.updateInfo,
    this.clStatus,
    this.clientDatewiseSchId,
    this.orgCode,
    this.clientId,
    this.clientCode,
    this.clientName,
    this.scheduleDayCode,
    this.dayDesc,
    this.scheduleDate,
    this.startTimeSlotCode,
    this.startTimeSlot,
    this.startTime,
    this.endTimeSlotCode,
    this.endTimeSlot,
    this.endTime,
    this.clientRateId,
    this.clientRateName,
    this.clientVisitTypeMstId,
    this.visitTypeName,
    this.howManyCarerReq,
    this.carerId,
    this.carerCode,
    this.carerName,
    this.carerRateId,
    this.carerRateName,
    this.carerId2,
    this.carerCode2,
    this.carerName2,
    this.carerRateId2,
    this.carerRateName2,
    this.dataStatus,
  });

  factory Value.fromJson(Map<String, dynamic> json) => Value(
    id: json["ID"],
    createInfo: json["CREATE_INFO"],
    updateInfo: json["UPDATE_INFO"],
    clStatus: json["CL_STATUS"],
    clientDatewiseSchId: json["CLIENT_DATEWISE_SCH_ID"],
    orgCode: json["ORG_CODE"],
    clientId: json["CLIENT_ID"],
    clientCode: json["CLIENT_CODE"],
    clientName: json["CLIENT_NAME"],
    scheduleDayCode: json["SCHEDULE_DAY_CODE"],
    dayDesc: json["DAY_DESC"],
    scheduleDate: json["SCHEDULE_DATE"],
    startTimeSlotCode: json["START_TIME_SLOT_CODE"],
    startTimeSlot: json["START_TIME_SLOT"],
    startTime: json["START_TIME"],
    endTimeSlotCode: json["END_TIME_SLOT_CODE"],
    endTimeSlot: json["END_TIME_SLOT"],
    endTime: json["END_TIME"],
    clientRateId: json["CLIENT_RATE_ID"],
    clientRateName: json["CLIENT_RATE_NAME"],
    clientVisitTypeMstId: json["CLIENT_VISIT_TYPE_MST_ID"],
    visitTypeName: json["VISIT_TYPE_NAME"],
    howManyCarerReq: json["HOW_MANY_CARER_REQ"],
    carerId: json["CARER_ID"],
    carerCode: json["CARER_CODE"],
    carerName: json["CARER_NAME"],
    carerRateId: json["CARER_RATE_ID"],
    carerRateName: json["CARER_RATE_NAME"],
    carerId2: json["CARER_ID2"],
    carerCode2: json["CARER_CODE2"],
    carerName2: json["CARER_NAME2"],
    carerRateId2: json["CARER_RATE_ID2"],
    carerRateName2: json["CARER_RATE_NAME2"],
    dataStatus: json["DATA_STATUS"],
  );

  Map<String, dynamic> toJson() => {
    "ID": id,
    "CREATE_INFO": createInfo,
    "UPDATE_INFO": updateInfo,
    "CL_STATUS": clStatus,
    "CLIENT_DATEWISE_SCH_ID": clientDatewiseSchId,
    "ORG_CODE": orgCode,
    "CLIENT_ID": clientId,
    "CLIENT_CODE": clientCode,
    "CLIENT_NAME": clientName,
    "SCHEDULE_DAY_CODE": scheduleDayCode,
    "DAY_DESC": dayDesc,
    "SCHEDULE_DATE": scheduleDate,
    "START_TIME_SLOT_CODE": startTimeSlotCode,
    "START_TIME_SLOT": startTimeSlot,
    "START_TIME": startTime,
    "END_TIME_SLOT_CODE": endTimeSlotCode,
    "END_TIME_SLOT": endTimeSlot,
    "END_TIME": endTime,
    "CLIENT_RATE_ID": clientRateId,
    "CLIENT_RATE_NAME": clientRateName,
    "CLIENT_VISIT_TYPE_MST_ID": clientVisitTypeMstId,
    "VISIT_TYPE_NAME": visitTypeName,
    "HOW_MANY_CARER_REQ": howManyCarerReq,
    "CARER_ID": carerId,
    "CARER_CODE": carerCode,
    "CARER_NAME": carerName,
    "CARER_RATE_ID": carerRateId,
    "CARER_RATE_NAME": carerRateName,
    "CARER_ID2": carerId2,
    "CARER_CODE2": carerCode2,
    "CARER_NAME2": carerName2,
    "CARER_RATE_ID2": carerRateId2,
    "CARER_RATE_NAME2": carerRateName2,
    "DATA_STATUS": dataStatus,
  };
}
