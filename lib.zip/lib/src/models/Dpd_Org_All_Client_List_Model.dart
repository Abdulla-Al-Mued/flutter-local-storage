class LocalDpdOrgAllClientListModel {
  String? code;
  String? msg;
  List<Value>? value;

  LocalDpdOrgAllClientListModel({
    this.code,
    this.msg,
    this.value,
  });

  factory LocalDpdOrgAllClientListModel.fromJson(Map<String, dynamic> json) =>
      LocalDpdOrgAllClientListModel(
        code: json["CODE"],
        msg: json["MSG"],
        value: json["Value"] == null
            ? []
            : List<Value>.from(json["Value"].map((x) => Value.fromJson(x))),
      );

  Map<String, dynamic> toJson() => {
    "CODE": code,
    "MSG": msg,
    "Value": value == null
        ? []
        : List<dynamic>.from(value!.map((x) => x.toJson())),
  };
}

class Value {
  dynamic id;
  String? clientId;
  String? clientCode;
  String? name;
  String? clientImagePath;
  String? address;
  String? phone;
  String? clientStatusTypeCode;
  String? clientStatusTypeDesc;
  String? orgCode;
  String? orgName;
  String? createInfo;
  String? updateInfo;
  String? clStatus;

  Value({
    this.id,
    this.clientId,
    this.clientCode,
    this.name,
    this.clientImagePath,
    this.address,
    this.phone,
    this.clientStatusTypeCode,
    this.clientStatusTypeDesc,
    this.orgCode,
    this.orgName,
    this.createInfo,
    this.updateInfo,
    this.clStatus,
  });

  factory Value.fromJson(Map<String, dynamic> json) => Value(
    id: json["ID"],
    clientId: json["CLIENT_ID"],
    clientCode: json["CLIENT_CODE"],
    name: json["NAME"],
    clientImagePath: json["CLIENT_IMAGE_PATH"],
    address: json["ADDRESS"],
    phone: json["PHONE"],
    clientStatusTypeCode: json["CLIENT_STATUS_TYPE_CODE"],
    clientStatusTypeDesc: json["CLIENT_STATUS_TYPE_DESC"],
    orgCode: json["ORG_CODE"],
    orgName: json["ORG_NAME"],
    createInfo: json["CREATE_INFO"],
    updateInfo: json["UPDATE_INFO"],
    clStatus: json["CL_STATUS"],
  );

  Map<String, dynamic> toJson() => {
    "CLIENT_ID": clientId,
    "CLIENT_CODE": clientCode,
    "NAME": name,
    "CLIENT_IMAGE_PATH": clientImagePath,
    "ADDRESS": address,
    "PHONE": phone,
    "CLIENT_STATUS_TYPE_CODE": clientStatusTypeCode,
    "CLIENT_STATUS_TYPE_DESC": clientStatusTypeDesc,
    "ORG_CODE": orgCode,
    "ORG_NAME": orgName,
    "ID": id,
    "CREATE_INFO": createInfo,
    "UPDATE_INFO": updateInfo,
    "CL_STATUS": clStatus,
  };
}