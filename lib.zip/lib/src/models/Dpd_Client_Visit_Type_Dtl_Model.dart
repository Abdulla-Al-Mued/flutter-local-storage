// To parse this JSON data, do
//
//     final dpdClientVisitTypeDtlModel = dpdClientVisitTypeDtlModelFromJson(jsonString);

import 'dart:convert';

DpdClientVisitTypeDtlModel dpdClientVisitTypeDtlModelFromJson(String str) =>
    DpdClientVisitTypeDtlModel.fromJson(json.decode(str));

String dpdClientVisitTypeDtlModelToJson(DpdClientVisitTypeDtlModel data) =>
    json.encode(data.toJson());

class DpdClientVisitTypeDtlModel {
  String? code;
  String? msg;
  List<Value>? value;

  DpdClientVisitTypeDtlModel({
    this.code,
    this.msg,
    this.value,
  });

  factory DpdClientVisitTypeDtlModel.fromJson(Map<String, dynamic> json) =>
      DpdClientVisitTypeDtlModel(
        code: json["CODE"],
        msg: json["MSG"],
        value: json["Value"] == null
            ? []
            : List<Value>.from(json["Value"]!.map((x) => Value.fromJson(x))),
      );

  Map<String, dynamic> toJson() => {
        "CODE": code,
        "MSG": msg,
        "Value": value == null
            ? []
            : List<dynamic>.from(value!.map((x) => x.toJson())),
      };
}

class Value {
  String? clientVisitTypeMstId;
  String? clientId;
  String? clientCode;
  String? orgCode;
  String? visitTypeName;
  String? taskCode;
  String? taskDesc;
  String? iconImagePath;
  String? notesForCarer;

  Value({
    this.clientVisitTypeMstId,
    this.clientId,
    this.clientCode,
    this.orgCode,
    this.visitTypeName,
    this.taskCode,
    this.taskDesc,
    this.iconImagePath,
    this.notesForCarer,
  });

  factory Value.fromJson(Map<String, dynamic> json) => Value(
        clientVisitTypeMstId: json["CLIENT_VISIT_TYPE_MST_ID"],
        clientId: json["CLIENT_ID"],
        clientCode: json["CLIENT_CODE"],
        orgCode: json["ORG_CODE"],
        visitTypeName: json["VISIT_TYPE_NAME"],
        taskCode: json["TASK_CODE"],
        taskDesc: json["TASK_DESC"],
        iconImagePath: json["ICON_IMAGE_PATH"],
        notesForCarer: json["NOTES_FOR_CARER"],
      );

  Map<String, dynamic> toJson() => {
        "CLIENT_VISIT_TYPE_MST_ID": clientVisitTypeMstId,
        "CLIENT_ID": clientId,
        "CLIENT_CODE": clientCode,
        "ORG_CODE": orgCode,
        "VISIT_TYPE_NAME": visitTypeName,
        "TASK_CODE": taskCode,
        "TASK_DESC": taskDesc,
        "ICON_IMAGE_PATH": iconImagePath,
        "NOTES_FOR_CARER": notesForCarer,
      };
}
