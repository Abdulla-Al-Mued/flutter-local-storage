class CarerVisitFood{

  final int? MST_ID;
  final String? FOOD;
  final int? CARER_VISIT_FOOD_ID;
  final int? CARER_VISIT_MST_ID;
  final String? orgCode;
  final String? clientId;
  final String? clientCode;
  final String? TASK_CODE;
  final String? CARER_ID;
  final String? CARER_CODE;
  final int? ANOTHER_CARER_STATUS;
  final int? CARER_ID2;
  final int? CARER_CODE2;
  final String? STATUS;
  final int? CREATE_DATE;
  final int? CREATE_USER;
  final int? CREATE_IP;
  final int? UPDATE_DATE;
  final int? UPDATE_IP;
  final int? CL_STATUS;
  final int? UPDATE_USER;

  CarerVisitFood({
    this.MST_ID,
    this.FOOD,
    this.CARER_VISIT_MST_ID,
    this.CARER_VISIT_FOOD_ID,
    this.orgCode,
    this.clientId,
    this.clientCode,
    this.TASK_CODE,
    this.CARER_ID,
    this.CARER_CODE,
    this.ANOTHER_CARER_STATUS,
    this.CARER_ID2,
    this.CARER_CODE2,
    this.STATUS,
    this.CREATE_DATE,
    this.CREATE_USER,
    this.CREATE_IP,
    this.UPDATE_DATE,
    this.UPDATE_IP,
    this.CL_STATUS,
    this.UPDATE_USER,
  });


  Map<String, dynamic> toMap() {
    return {
      'MST_ID': MST_ID,
      'FOOD': FOOD,
      'CARER_VISIT_FOOD_ID': CARER_VISIT_FOOD_ID,
      '"CARER_VISIT_MST_ID"': CARER_VISIT_MST_ID,
      'ORG_CODE': orgCode,
      'CLIENT_ID': clientId,
      'CLIENT_CODE': clientCode,
      'TASK_CODE': TASK_CODE,
      'STATUS': STATUS,

      'CARER_ID': CARER_ID,
      'CARER_CODE': CARER_CODE,
      'ANOTHER_CARER_STATUS': ANOTHER_CARER_STATUS,
      'CARER_ID2': CARER_ID2,
      'CARER_CODE2': CARER_CODE2,
      'CREATE_DATE': CREATE_DATE,
      'CREATE_USER': CREATE_USER,
      'CREATE_IP': CREATE_IP,
      'UPDATE_DATE': UPDATE_DATE,
      'UPDATE_IP': UPDATE_IP,
      'CL_STATUS': CL_STATUS,
      'UPDATE_USER': UPDATE_USER,
    };
  }

}