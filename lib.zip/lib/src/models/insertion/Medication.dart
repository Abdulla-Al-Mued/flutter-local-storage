class CarerVisitMedication {

  String? mstId;
  String? carerVisitMstId;
  String? orgCode;
  String? clientId;
  String? clientCode;
  String? carerId;
  String? carerCode;
  String? anotherCarerStatus;
  String? carerId2;
  String? carerCode2;
  String? taskCode;
  String? medicationName;
  String? dosage;
  String? administrationNotes;
  String? morningSchedule;
  String? lunchtimeSchedule;
  String? eveningSchedule;
  String? bedtimeSchedule;
  String? asNeededSchedule;
  String? mondaySchedule;
  String? tuesdaySchedule;
  String? wednesdaySchedule;
  String? thursdaySchedule;
  String? fridaySchedule;
  String? saturdaySchedule;
  String? sundaySchedule;
  String? takenStatus;
  String? takenRemarks;
  String? notTakenStatus;
  String? notTakenRemarks;
  String? dataCapturedDate;
  String? dataCapturedTime;
  String? status;
  String? createDate;
  String? createUser;
  String? createIp;
  String? updateDate;
  String? updateUser;
  String? updateIp;
  String? clStatus;
  String? medicationDetailId;



  CarerVisitMedication({

    this.mstId,
    this.carerVisitMstId,
    this.orgCode,
    this.clientId,
    this.clientCode,
    this.carerId,
    this.carerCode,
    this.anotherCarerStatus,
    this.carerId2,
    this.carerCode2,
    this.taskCode,
    this.medicationName,
    this.dosage,
    this.administrationNotes,
    this.morningSchedule,
    this.lunchtimeSchedule,
    this.eveningSchedule,
    this.bedtimeSchedule,
    this.asNeededSchedule,
    this.mondaySchedule,
    this.tuesdaySchedule,
    this.wednesdaySchedule,
    this.thursdaySchedule,
    this.fridaySchedule,
    this.saturdaySchedule,
    this.sundaySchedule,
    this.takenStatus,
    this.takenRemarks,
    this.notTakenStatus,
    this.notTakenRemarks,
    this.dataCapturedDate,
    this.dataCapturedTime,
    this.status,
    this.createDate,
    this.createUser,
    this.createIp,
    this.updateDate,
    this.updateUser,
    this.updateIp,
    this.clStatus,
    this.medicationDetailId,
  });

  Map<String, dynamic> toMap() {
    return {

      'MST_ID': mstId,
      'CARER_VISIT_MST_ID': carerVisitMstId,
      'ORG_CODE': orgCode,
      'CLIENT_ID': clientId,
      'CLIENT_CODE': clientCode,
      'CARER_ID': carerId,
      'CARER_CODE': carerCode,
      'ANOTHER_CARER_STATUS': anotherCarerStatus,
      'CARER_ID2': carerId2,
      'CARER_CODE2': carerCode2,
      'TASK_CODE': taskCode,
      'MEDICATION_NAME': medicationName,
      'DOSAGE': dosage,
      'ADMINISTRATION_NOTES': administrationNotes,
      'MORNING_SCHEDULE': morningSchedule,
      'LUNCHTIME_SCHEDULE': lunchtimeSchedule,
      'EVENING_SCHEDULE': eveningSchedule,
      'BEDTIME_SCHEDULE': bedtimeSchedule,
      'AS_NEEDED_SCHEDULE': asNeededSchedule,
      'MONDAY_SCHEDULE': mondaySchedule,
      'TUESDAY_SCHEDULE': tuesdaySchedule,
      'WEDNESDAY_SCHEDULE': wednesdaySchedule,
      'THURSDAY_SCHEDULE': thursdaySchedule,
      'FRIDAY_SCHEDULE': fridaySchedule,
      'SATURDAY_SCHEDULE': saturdaySchedule,
      'SUNDAY_SCHEDULE': sundaySchedule,
      'TAKEN_STATUS': takenStatus,
      'TAKEN_REMARKS': takenRemarks,
      'NOT_TAKEN_STATUS': notTakenStatus,
      'NOT_TAKEN_REMARKS': notTakenRemarks,
      'DATA_CAPTURED_DATE': dataCapturedDate,
      'DATA_CAPTURED_TIME': dataCapturedTime,
      'STATUS': status,
      'CREATE_DATE': createDate,
      'CREATE_USER': createUser,
      'CREATE_IP': createIp,
      'UPDATE_DATE': updateDate,
      'UPDATE_USER': updateUser,
      'UPDATE_IP': updateIp,
      'CL_STATUS': clStatus,
      'CLIENT_MEDICATION_DTL_ID': medicationDetailId,
    };
  }
}