class CarerVisitMedication {
  final int? id;
  final int? carerVisitMedicationId;
  final String? mstId;
  final String? carerVisitMstId;
  final String? orgCode;
  final String? clientId;
  final String? clientCode;
  final String? carerId;
  final String? carerCode;
  final String? anotherCarerStatus;
  final String? carerId2;
  final String? carerCode2;
  final String? taskCode;
  final String? medicationName;
  final String? dosage;
  final String? administrationNotes;
  final String? morningSchedule;
  final String? lunchtimeSchedule;
  final String? eveningSchedule;
  final String? bedtimeSchedule;
  final String? asNeededSchedule;
  final String? mondaySchedule;
  final String? tuesdaySchedule;
  final String? wednesdaySchedule;
  final String? thursdaySchedule;
  final String? fridaySchedule;
  final String? saturdaySchedule;
  final String? sundaySchedule;
  final String? takenStatus;
  final String? takenRemarks;
  final String? notTakenStatus;
  final String? notTakenRemarks;
  final String? dataCapturedDate;
  final String? dataCapturedTime;
  final String? status;
  final String? createDate;
  final String? createUser;
  final String? createIp;
  final String? updateDate;
  final String? updateUser;
  final String? updateIp;
  final String? clStatus;

  CarerVisitMedication({
    this.id,
    this.carerVisitMedicationId,
    this.mstId,
    this.carerVisitMstId,
    this.orgCode,
    this.clientId,
    this.clientCode,
    this.carerId,
    this.carerCode,
    this.anotherCarerStatus,
    this.carerId2,
    this.carerCode2,
    this.taskCode,
    this.medicationName,
    this.dosage,
    this.administrationNotes,
    this.morningSchedule,
    this.lunchtimeSchedule,
    this.eveningSchedule,
    this.bedtimeSchedule,
    this.asNeededSchedule,
    this.mondaySchedule,
    this.tuesdaySchedule,
    this.wednesdaySchedule,
    this.thursdaySchedule,
    this.fridaySchedule,
    this.saturdaySchedule,
    this.sundaySchedule,
    this.takenStatus,
    this.takenRemarks,
    this.notTakenStatus,
    this.notTakenRemarks,
    this.dataCapturedDate,
    this.dataCapturedTime,
    this.status,
    this.createDate,
    this.createUser,
    this.createIp,
    this.updateDate,
    this.updateUser,
    this.updateIp,
    this.clStatus,
  });

  Map<String, dynamic> toMap() {
    return {
      'ID': id,
      'CARER_VISIT_MEDICATION_ID': carerVisitMedicationId,
      'MST_ID': mstId,
      'CARER_VISIT_MST_ID': carerVisitMstId,
      'ORG_CODE': orgCode,
      'CLIENT_ID': clientId,
      'CLIENT_CODE': clientCode,
      'CARER_ID': carerId,
      'CARER_CODE': carerCode,
      'ANOTHER_CARER_STATUS': anotherCarerStatus,
      'CARER_ID2': carerId2,
      'CARER_CODE2': carerCode2,
      'TASK_CODE': taskCode,
      'MEDICATION_NAME': medicationName,
      'DOSAGE': dosage,
      'ADMINISTRATION_NOTES': administrationNotes,
      'MORNING_SCHEDULE': morningSchedule,
      'LUNCHTIME_SCHEDULE': lunchtimeSchedule,
      'EVENING_SCHEDULE': eveningSchedule,
      'BEDTIME_SCHEDULE': bedtimeSchedule,
      'AS_NEEDED_SCHEDULE': asNeededSchedule,
      'MONDAY_SCHEDULE': mondaySchedule,
      'TUESDAY_SCHEDULE': tuesdaySchedule,
      'WEDNESDAY_SCHEDULE': wednesdaySchedule,
      'THURSDAY_SCHEDULE': thursdaySchedule,
      'FRIDAY_SCHEDULE': fridaySchedule,
      'SATURDAY_SCHEDULE': saturdaySchedule,
      'SUNDAY_SCHEDULE': sundaySchedule,
      'TAKEN_STATUS': takenStatus,
      'TAKEN_REMARKS': takenRemarks,
      'NOT_TAKEN_STATUS': notTakenStatus,
      'NOT_TAKEN_REMARKS': notTakenRemarks,
      'DATA_CAPTURED_DATE': dataCapturedDate,
      'DATA_CAPTURED_TIME': dataCapturedTime,
      'STATUS': status,
      'CREATE_DATE': createDate,
      'CREATE_USER': createUser,
      'CREATE_IP': createIp,
      'UPDATE_DATE': updateDate,
      'UPDATE_USER': updateUser,
      'UPDATE_IP': updateIp,
      'CL_STATUS': clStatus,
    };
  }
}
