class CarerVisitHousework {
  final int? carerVisitHouseworkId;
  final String? carerVisitMstId;
  final String? orgCode;
  final String? clientId;
  final String? clientCode;
  final String? carerId;
  final String? carerCode;
  final String? anotherCarerStatus;
  final String? carerId2;
  final String? carerCode2;
  final String? taskCode;
  final String? housework;
  final String? status;
  final String? createDate;
  final String? createUser;
  final String? createIp;
  final String? updateDate;
  final String? updateUser;
  final String? updateIp;
  final String? clStatus;

  CarerVisitHousework({
    this.carerVisitHouseworkId,
    this.carerVisitMstId,
    this.orgCode,
    this.clientId,
    this.clientCode,
    this.carerId,
    this.carerCode,
    this.anotherCarerStatus,
    this.carerId2,
    this.carerCode2,
    this.taskCode,
    this.housework,
    this.status,
    this.createDate,
    this.createUser,
    this.createIp,
    this.updateDate,
    this.updateUser,
    this.updateIp,
    this.clStatus,
  });

  Map<String, dynamic> toMap() {
    return {
      'CARER_VISIT_HOUSEWORK_ID': carerVisitHouseworkId,
      'CARER_VISIT_MST_ID': carerVisitMstId,
      'ORG_CODE': orgCode,
      'CLIENT_ID': clientId,
      'CLIENT_CODE': clientCode,
      'CARER_ID': carerId,
      'CARER_CODE': carerCode,
      'ANOTHER_CARER_STATUS': anotherCarerStatus,
      'CARER_ID2': carerId2,
      'CARER_CODE2': carerCode2,
      'TASK_CODE': taskCode,
      'HOUSEWORK': housework,
      'STATUS': status,
      'CREATE_DATE': createDate,
      'CREATE_USER': createUser,
      'CREATE_IP': createIp,
      'UPDATE_DATE': updateDate,
      'UPDATE_USER': updateUser,
      'UPDATE_IP': updateIp,
      'CL_STATUS': clStatus,
    };
  }
}
