class CarerVisitMst {
  // final int? carerVisitMstId;
  // final int? Id;
  final String? orgCode;
  final int? clientId;
  final String? clientCode;
  final String? CLIENT_DATEWISE_SCH_ID;
  final String? CLIENT_VISIT_TYPE_MST_ID;
  final String? VISIT_DATE;
  final String? CHECK_IN_DATE;
  final String? CHECK_IN_TIME;
  final String? CHECK_IN_LATTITUDE;
  final String? CARER_ID;
  final String? CARER_CODE;
  final String? ANOTHER_CARER_STATUS;
  final String? CARER_ID2;
  final String? CARER_CODE2;
  final String? HOW_DID_CLIENT_EMOJI_CODE;
  final String? IS_SCHEDULED;
  final int? VISIT_SUMMARY;
  final int? RAISE_ALERT;
  final int? ALERT_DTL;
  final int? CHECK_OUT_DATE;
  final int? CHECK_OUT_TIME;
  final String? CHECK_OUT_LATTITUDE;
  final String? CHECK_IN_LONGITUDE;
  final int? AGENCY_NOTE;
  final int? AGENCY_USER_ID;
  final int? SHARE_WITH_FAMILY;
  final int? SHARE_WITH_CARER;
  final int? STATUS;
  final int? CREATE_DATE;
  final int? CREATE_USER;
  final int? CREATE_IP;
  final int? UPDATE_DATE;
  final int? UPDATE_IP;
  final int? CL_STATUS;

  CarerVisitMst({
    // this.carerVisitMstId,
    // this.Id,
    this.orgCode,
    this.clientId,
    this.clientCode,
    this.CLIENT_DATEWISE_SCH_ID,
    this.CLIENT_VISIT_TYPE_MST_ID,
    this.IS_SCHEDULED,
    this.VISIT_DATE,
    this.CHECK_IN_DATE,
    this.CHECK_IN_TIME,
    this.CHECK_IN_LATTITUDE,
    this.CHECK_IN_LONGITUDE,
    this.CARER_ID,
    this.CARER_CODE,
    this.ANOTHER_CARER_STATUS,
    this.CARER_ID2,
    this.CARER_CODE2,
    this.HOW_DID_CLIENT_EMOJI_CODE,
    this.VISIT_SUMMARY,
    this.RAISE_ALERT,
    this.ALERT_DTL,
    this.CHECK_OUT_DATE,
    this.CHECK_OUT_TIME,
    this.CHECK_OUT_LATTITUDE,
    this.AGENCY_NOTE,
    this.AGENCY_USER_ID,
    this.SHARE_WITH_FAMILY,
    this.SHARE_WITH_CARER,
    this.STATUS,
    this.CREATE_DATE,
    this.CREATE_USER,
    this.CREATE_IP,
    this.UPDATE_DATE,
    this.UPDATE_IP,
    this.CL_STATUS,
  });

  // Convert the model instance to a map
  Map<String, dynamic> toMap() {
    return {
      // 'CARER_VISIT_MST_ID': carerVisitMstId,
      // 'ID': Id,
      'ORG_CODE': orgCode,
      'CLIENT_ID': clientId,
      'CLIENT_CODE': clientCode,
      'CLIENT_DATEWISE_SCH_ID': CLIENT_DATEWISE_SCH_ID,
      'CLIENT_VISIT_TYPE_MST_ID': CLIENT_VISIT_TYPE_MST_ID,
      'VISIT_DATE': VISIT_DATE,
      'IS_SCHEDULED': IS_SCHEDULED,
      'CHECK_IN_DATE': CHECK_IN_DATE,
      'CHECK_IN_TIME': CHECK_IN_TIME,
      'CHECK_IN_LATTITUDE': CHECK_IN_LATTITUDE,
      'CHECK_IN_LONGITUDE': CHECK_IN_LONGITUDE,
      'CARER_ID': CARER_ID,
      'CARER_CODE': CARER_CODE,
      'ANOTHER_CARER_STATUS': ANOTHER_CARER_STATUS,
      'CARER_ID2': CARER_ID2,
      'CARER_CODE2': CARER_CODE2,
      'HOW_DID_CLIENT_EMOJI_CODE': HOW_DID_CLIENT_EMOJI_CODE,
      'VISIT_SUMMARY': VISIT_SUMMARY,
      'RAISE_ALERT': RAISE_ALERT,
      'ALERT_DTL': ALERT_DTL,
      'CHECK_OUT_DATE': CHECK_OUT_DATE,
      'CHECK_OUT_TIME': CHECK_OUT_TIME,
      'CHECK_OUT_LATTITUDE': CHECK_OUT_LATTITUDE,
      'AGENCY_NOTE': AGENCY_NOTE,
      'AGENCY_USER_ID': AGENCY_USER_ID,
      'SHARE_WITH_FAMILY': SHARE_WITH_FAMILY,
      'SHARE_WITH_CARER': SHARE_WITH_CARER,
      'STATUS': STATUS,
      'CREATE_DATE': CREATE_DATE,
      'CREATE_USER': CREATE_USER,
      'CREATE_IP': CREATE_IP,
      'UPDATE_DATE': UPDATE_DATE,
      'UPDATE_IP': UPDATE_IP,
      'CL_STATUS': CL_STATUS,
    };
  }
}