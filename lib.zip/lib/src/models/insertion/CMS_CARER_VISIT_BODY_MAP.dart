class CarerVisitBodyMap {
  final int? id;
  final int? carerVisitBodyMapId;
  final String? carerVisitMstId;
  final String? orgCode;
  final String? clientId;
  final String? clientCode;
  final String? carerId;
  final String? carerCode;
  final String? anotherCarerStatus;
  final String? carerId2;
  final String? carerCode2;
  final String? taskCode;
  final String? frontHeadNeck;
  final String? frontRightShoulder;
  final String? frontLeftShoulder;
  final String? frontRightUpperArmElbow;
  final String? frontRightForearm;
  final String? frontRightHandWrist;
  final String? frontLeftUpperArmElbow;
  final String? frontLeftForearm;
  final String? frontLeftHandWrist;
  final String? frontRightChest;
  final String? frontLeftChest;
  final String? frontAbdomen;
  final String? frontGroin;
  final String? frontRightUpperLeg;
  final String? frontRightKnee;
  final String? frontRightLowerLeg;
  final String? frontRightFootAnkle;
  final String? frontLeftUpperLeg;
  final String? frontLeftKnee;
  final String? frontLeftLowerLeg;
  final String? frontLeftFootAnkle;
  final String? backHeadNeck;
  final String? backRightShoulder;
  final String? backLeftShoulder;
  final String? backRightUpperArmElbow;
  final String? backRightForearm;
  final String? backRightHandWrist;
  final String? backLeftUpperArmElbow;
  final String? backLeftForearm;
  final String? backLeftHandWrist;
  final String? backUpperBack;
  final String? backLowerBack;
  final String? backBottomSacrum;
  final String? backRightUpperLeg;
  final String? backRightKnee;
  final String? backRightLowerLeg;
  final String? backRightFootAnkle;
  final String? backLeftUpperLeg;
  final String? backLeftKnee;
  final String? backLeftLowerLeg;
  final String? backLeftFootAnkle;
  final String? generalNotes;
  final String? status;
  final String? createDate;
  final String? createUser;
  final String? createIp;
  final String? updateDate;
  final String? updateUser;
  final String? updateIp;
  final String? clStatus;

  CarerVisitBodyMap({
    this.id,
    this.carerVisitBodyMapId,
    this.carerVisitMstId,
    this.orgCode,
    this.clientId,
    this.clientCode,
    this.carerId,
    this.carerCode,
    this.anotherCarerStatus,
    this.carerId2,
    this.carerCode2,
    this.taskCode,
    this.frontHeadNeck,
    this.frontRightShoulder,
    this.frontLeftShoulder,
    this.frontRightUpperArmElbow,
    this.frontRightForearm,
    this.frontRightHandWrist,
    this.frontLeftUpperArmElbow,
    this.frontLeftForearm,
    this.frontLeftHandWrist,
    this.frontRightChest,
    this.frontLeftChest,
    this.frontAbdomen,
    this.frontGroin,
    this.frontRightUpperLeg,
    this.frontRightKnee,
    this.frontRightLowerLeg,
    this.frontRightFootAnkle,
    this.frontLeftUpperLeg,
    this.frontLeftKnee,
    this.frontLeftLowerLeg,
    this.frontLeftFootAnkle,
    this.backHeadNeck,
    this.backRightShoulder,
    this.backLeftShoulder,
    this.backRightUpperArmElbow,
    this.backRightForearm,
    this.backRightHandWrist,
    this.backLeftUpperArmElbow,
    this.backLeftForearm,
    this.backLeftHandWrist,
    this.backUpperBack,
    this.backLowerBack,
    this.backBottomSacrum,
    this.backRightUpperLeg,
    this.backRightKnee,
    this.backRightLowerLeg,
    this.backRightFootAnkle,
    this.backLeftUpperLeg,
    this.backLeftKnee,
    this.backLeftLowerLeg,
    this.backLeftFootAnkle,
    this.generalNotes,
    this.status,
    this.createDate,
    this.createUser,
    this.createIp,
    this.updateDate,
    this.updateUser,
    this.updateIp,
    this.clStatus,
  });

  Map<String, dynamic> toMap() {
    return {
      'ID': id,
      'CARER_VISIT_BODYMAP_ID': carerVisitBodyMapId,
      'CARER_VISIT_MST_ID': carerVisitMstId,
      'ORG_CODE': orgCode,
      'CLIENT_ID': clientId,
      'CLIENT_CODE': clientCode,
      'CARER_ID': carerId,
      'CARER_CODE': carerCode,
      'ANOTHER_CARER_STATUS': anotherCarerStatus,
      'CARER_ID2': carerId2,
      'CARER_CODE2': carerCode2,
      'TASK_CODE': taskCode,
      'FRONT_HEAD_NECK': frontHeadNeck,
      'FRONT_RIGHT_SHOULDER': frontRightShoulder,
      'FRONT_LEFT_SHOULDER': frontLeftShoulder,
      'FRONT_RIGHT_UPPER_ARM_ELBOW': frontRightUpperArmElbow,
      'FRONT_RIGHT_FOREARM': frontRightForearm,
      'FRONT_RIGHT_HAND_WRIST': frontRightHandWrist,
      'FRONT_LEFT_UPPER_ARM_ELBOW': frontLeftUpperArmElbow,
      'FRONT_LEFT_FOREARM': frontLeftForearm,
      'FRONT_LEFT_HAND_WRIST': frontLeftHandWrist,
      'FRONT_RIGHT_CHEST': frontRightChest,
      'FRONT_LEFT_CHEST': frontLeftChest,
      'FRONT_ABDOMEN': frontAbdomen,
      'FRONT_GROIN': frontGroin,
      'FRONT_RIGHT_UPPER_LEG': frontRightUpperLeg,
      'FRONT_RIGHT_KNEE': frontRightKnee,
      'FRONT_RIGHT_LOWER_LEG': frontRightLowerLeg,
      'FRONT_RIGHT_FOOT_ANKLE': frontRightFootAnkle,
      'FRONT_LEFT_UPPER_LEG': frontLeftUpperLeg,
      'FRONT_LEFT_KNEE': frontLeftKnee,
      'FRONT_LEFT_LOWER_LEG': frontLeftLowerLeg,
      'FRONT_LEFT_FOOT_ANKLE': frontLeftFootAnkle,
      'BACK_HEAD_NECK': backHeadNeck,
      'BACK_RIGHT_SHOULDER': backRightShoulder,
      'BACK_LEFT_SHOULDER': backLeftShoulder,
      'BACK_RIGHT_UPPER_ARM_ELBOW': backRightUpperArmElbow,
      'BACK_RIGHT_FOREARM': backRightForearm,
      'BACK_RIGHT_HAND_WRIST': backRightHandWrist,
      'BACK_LEFT_UPPER_ARM_ELBOW': backLeftUpperArmElbow,
      'BACK_LEFT_FOREARM': backLeftForearm,
      'BACK_LEFT_HAND_WRIST': backLeftHandWrist,
      'BACK_UPPER_BACK': backUpperBack,
      'BACK_LOWER_BACK': backLowerBack,
      'BACK_BOTTOM_SACRUM': backBottomSacrum,
      'BACK_RIGHT_UPPER_LEG': backRightUpperLeg,
      'BACK_RIGHT_KNEE': backRightKnee,
      'BACK_RIGHT_LOWER_LEG': backRightLowerLeg,
      'BACK_RIGHT_FOOT_ANKLE': backRightFootAnkle,
      'BACK_LEFT_UPPER_LEG': backLeftUpperLeg,
      'BACK_LEFT_KNEE': backLeftKnee,
      'BACK_LEFT_LOWER_LEG': backLeftLowerLeg,
      'BACK_LEFT_FOOT_ANKLE': backLeftFootAnkle,
      'GENERAL_NOTES': generalNotes,
      'STATUS': status,
      'CREATE_DATE': createDate,
      'CREATE_USER': createUser,
      'CREATE_IP': createIp,
      'UPDATE_DATE': updateDate,
      'UPDATE_USER': updateUser,
      'UPDATE_IP': updateIp,
      'CL_STATUS': clStatus,
    };
  }
}
