class CarerVisitBodyMap {
  int? id;
  int? carerVisitBodymapId;
  String? carerVisitMstId;
  String? orgCode;
  String? clientId;
  String? clientCode;
  String? carerId;
  String? carerCode;
  String? anotherCarerStatus;
  String? carerId2;
  String? carerCode2;
  String? taskCode;
  String? frontHeadNeck;
  String? frontRightShoulder;
  String? frontLeftShoulder;
  String? frontRightUpperArmElbow;
  String? frontRightForearm;
  String? frontRightHandWrist;
  String? frontLeftUpperArmElbow;
  String? frontLeftForearm;
  String? frontLeftHandWrist;
  String? frontRightChest;
  String? frontLeftChest;
  String? frontAbdomen;
  String? frontGroin;
  String? frontRightUpperLeg;
  String? frontRightKnee;
  String? frontRightLowerLeg;
  String? frontRightFootAnkle;
  String? frontLeftUpperLeg;
  String? frontLeftKnee;
  String? frontLeftLowerLeg;
  String? frontLeftFootAnkle;
  String? backHeadNeck;
  String? backRightShoulder;
  String? backLeftShoulder;
  String? backRightUpperArmElbow;
  String? backRightForearm;
  String? backRightHandWrist;
  String? backLeftUpperArmElbow;
  String? backLeftForearm;
  String? backLeftHandWrist;
  String? backUpperBack;
  String? backLowerBack;
  String? backBottomSacrum;
  String? backRightUpperLeg;
  String? backRightKnee;
  String? backRightLowerLeg;
  String? backRightFootAnkle;
  String? backLeftUpperLeg;
  String? backLeftKnee;
  String? backLeftLowerLeg;
  String? backLeftFootAnkle;
  String? generalNotes;
  String? status;
  String? createDate;
  String? createUser;
  String? createIp;
  String? updateDate;
  String? updateUser;
  String? updateIp;
  String? clStatus;

  CarerVisitBodyMap({
    this.id,
    this.carerVisitBodymapId,
    this.carerVisitMstId,
    this.orgCode,
    this.clientId,
    this.clientCode,
    this.carerId,
    this.carerCode,
    this.anotherCarerStatus,
    this.carerId2,
    this.carerCode2,
    this.taskCode,
    this.frontHeadNeck,
    this.frontRightShoulder,
    this.frontLeftShoulder,
    this.frontRightUpperArmElbow,
    this.frontRightForearm,
    this.frontRightHandWrist,
    this.frontLeftUpperArmElbow,
    this.frontLeftForearm,
    this.frontLeftHandWrist,
    this.frontRightChest,
    this.frontLeftChest,
    this.frontAbdomen,
    this.frontGroin,
    this.frontRightUpperLeg,
    this.frontRightKnee,
    this.frontRightLowerLeg,
    this.frontRightFootAnkle,
    this.frontLeftUpperLeg,
    this.frontLeftKnee,
    this.frontLeftLowerLeg,
    this.frontLeftFootAnkle,
    this.backHeadNeck,
    this.backRightShoulder,
    this.backLeftShoulder,
    this.backRightUpperArmElbow,
    this.backRightForearm,
    this.backRightHandWrist,
    this.backLeftUpperArmElbow,
    this.backLeftForearm,
    this.backLeftHandWrist,
    this.backUpperBack,
    this.backLowerBack,
    this.backBottomSacrum,
    this.backRightUpperLeg,
    this.backRightKnee,
    this.backRightLowerLeg,
    this.backRightFootAnkle,
    this.backLeftUpperLeg,
    this.backLeftKnee,
    this.backLeftLowerLeg,
    this.backLeftFootAnkle,
    this.generalNotes,
    this.status,
    this.createDate,
    this.createUser,
    this.createIp,
    this.updateDate,
    this.updateUser,
    this.updateIp,
    this.clStatus,
  });


  Map<String, dynamic> toMap() => {
    'ID': id,
    'CARER_VISIT_BODYMAP_ID': carerVisitBodymapId,
    'CARER_VISIT_MST_ID': carerVisitMstId,
    'ORG_CODE': orgCode,
    'CLIENT_ID': clientId,
    'CLIENT_CODE': clientCode,
    'CARER_ID': carerId,
    'CARER_CODE': carerCode,
    'ANOTHER_CARER_STATUS': anotherCarerStatus,
    'CARER_ID2': carerId2,
    'CARER_CODE2': carerCode2,
    'TASK_CODE': taskCode,
    'FRONT_HEAD_NECK': frontHeadNeck,
    'FRONT_RIGHT_SHOULDER': frontRightShoulder,
    'FRONT_LEFT_SHOULDER': frontLeftShoulder,
    'FRONT_RIGHT_UPPER_ARM_ELBOW': frontRightUpperArmElbow,
    'FRONT_RIGHT_FOREARM': frontRightForearm,
    'FRONT_RIGHT_HAND_WRIST': frontRightHandWrist,
    'FRONT_LEFT_UPPER_ARM_ELBOW': frontLeftUpperArmElbow,
    'FRONT_LEFT_FOREARM': frontLeftForearm,
    'FRONT_LEFT_HAND_WRIST': frontLeftHandWrist,
    'FRONT_RIGHT_CHEST': frontRightChest,
    'FRONT_LEFT_CHEST': frontLeftChest,
    'FRONT_ABDOMEN': frontAbdomen,
    'FRONT_GROIN': frontGroin,
    'FRONT_RIGHT_UPPER_LEG': frontRightUpperLeg,
    'FRONT_RIGHT_KNEE': frontRightKnee,
    'FRONT_RIGHT_LOWER_LEG': frontRightLowerLeg,
    'FRONT_RIGHT_FOOT_ANKLE': frontRightFootAnkle,
    'FRONT_LEFT_UPPER_LEG': frontLeftUpperLeg,
    'FRONT_LEFT_KNEE': frontLeftKnee,
    'FRONT_LEFT_LOWER_LEG': frontLeftLowerLeg,
    'FRONT_LEFT_FOOT_ANKLE': frontLeftFootAnkle,
    'BACK_HEAD_NECK': backHeadNeck,
    'BACK_RIGHT_SHOULDER': backRightShoulder,
    'BACK_LEFT_SHOULDER': backLeftShoulder,
    'BACK_RIGHT_UPPER_ARM_ELBOW': backRightUpperArmElbow,
    'BACK_RIGHT_FOREARM': backRightForearm,
    'BACK_RIGHT_HAND_WRIST': backRightHandWrist,
    'BACK_LEFT_UPPER_ARM_ELBOW': backLeftUpperArmElbow,
    'BACK_LEFT_FOREARM': backLeftForearm,
    'BACK_LEFT_HAND_WRIST': backLeftHandWrist,
    'BACK_UPPER_BACK': backUpperBack,
    'BACK_LOWER_BACK': backLowerBack,
    'BACK_BOTTOM_SACRUM': backBottomSacrum,
    'BACK_RIGHT_UPPER_LEG': backRightUpperLeg,
    'BACK_RIGHT_KNEE': backRightKnee,
    'BACK_RIGHT_LOWER_LEG': backRightLowerLeg,
    'BACK_RIGHT_FOOT_ANKLE': backRightFootAnkle,
    'BACK_LEFT_UPPER_LEG': backLeftUpperLeg,
    'BACK_LEFT_KNEE': backLeftKnee,
    'BACK_LEFT_LOWER_LEG': backLeftLowerLeg,
    'BACK_LEFT_FOOT_ANKLE': backLeftFootAnkle,
    'GENERAL_NOTES': generalNotes,
    'STATUS': status,
    'CREATE_DATE': createDate,
    'CREATE_USER': createUser,
    'CREATE_IP': createIp,
    'UPDATE_DATE': updateDate,
    'UPDATE_USER': updateUser,
    'UPDATE_IP': updateIp,
    'CL_STATUS': clStatus,
  };
}
