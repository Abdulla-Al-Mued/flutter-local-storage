import 'dart:convert';

DpdCarerVisitBodyMapDtl dpdCarerVisitBodyMapDtlFromJson(String str) => DpdCarerVisitBodyMapDtl.fromJson(json.decode(str));

String dpdCarerVisitBodyMapDtlToJson(DpdCarerVisitBodyMapDtl data) => json.encode(data.toJson());

class DpdCarerVisitBodyMapDtl {
  String? code;
  String? msg;
  List<Map<String, String?>>? value;

  DpdCarerVisitBodyMapDtl({
    this.code,
    this.msg,
    this.value,
  });

  factory DpdCarerVisitBodyMapDtl.fromJson(Map<String, dynamic> json) => DpdCarerVisitBodyMapDtl(
    code: json["CODE"],
    msg: json["MSG"],
    value: json["Value"] == null ? [] : List<Map<String, String?>>.from(json["Value"]!.map((x) => Map.from(x).map((k, v) => MapEntry<String, String?>(k, v)))),
  );

  Map<String, dynamic> toJson() => {
    "CODE": code,
    "MSG": msg,
    "Value": value == null ? [] : List<dynamic>.from(value!.map((x) => Map.from(x).map((k, v) => MapEntry<String, dynamic>(k, v)))),
  };
}
