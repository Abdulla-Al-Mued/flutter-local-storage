
import 'dart:convert';

DpdTaskLIstSummRpt dpdTaskLIstSummRptFromJson(String str) => DpdTaskLIstSummRpt.fromJson(json.decode(str));

String dpdTaskLIstSummRptToJson(DpdTaskLIstSummRpt data) => json.encode(data.toJson());

class DpdTaskLIstSummRpt {
  String? code;
  String? msg;
  List<Value>? value;

  DpdTaskLIstSummRpt({
    this.code,
    this.msg,
    this.value,
  });

  factory DpdTaskLIstSummRpt.fromJson(Map<String, dynamic> json) => DpdTaskLIstSummRpt(
    code: json["CODE"],
    msg: json["MSG"],
    value: json["Value"] == null ? [] : List<Value>.from(json["Value"]!.map((x) => Value.fromJson(x))),
  );

  Map<String, dynamic> toJson() => {
    "CODE": code,
    "MSG": msg,
    "Value": value == null ? [] : List<dynamic>.from(value!.map((x) => x.toJson())),
  };
}

class Value {
  String? carerVisitMstId;
  OrgCode? orgCode;
  String? clientId;
  ClientCode? clientCode;
  String? taskCode;
  String? taskDesc;
  String? iconImagePath;

  Value({
    this.carerVisitMstId,
    this.orgCode,
    this.clientId,
    this.clientCode,
    this.taskCode,
    this.taskDesc,
    this.iconImagePath,
  });

  factory Value.fromJson(Map<String, dynamic> json) => Value(
    carerVisitMstId: json["CARER_VISIT_MST_ID"],
    orgCode: orgCodeValues.map[json["ORG_CODE"]]!,
    clientId: json["CLIENT_ID"],
    clientCode: clientCodeValues.map[json["CLIENT_CODE"]]!,
    taskCode: json["TASK_CODE"],
    taskDesc: json["TASK_DESC"],
    iconImagePath: json["ICON_IMAGE_PATH"],
  );

  Map<String, dynamic> toJson() => {
    "CARER_VISIT_MST_ID": carerVisitMstId,
    "ORG_CODE": orgCodeValues.reverse[orgCode],
    "CLIENT_ID": clientId,
    "CLIENT_CODE": clientCodeValues.reverse[clientCode],
    "TASK_CODE": taskCode,
    "TASK_DESC": taskDesc,
    "ICON_IMAGE_PATH": iconImagePath,
  };
}

enum ClientCode {
  CLN_000022
}

final clientCodeValues = EnumValues({
  "CLN-000022": ClientCode.CLN_000022
});

enum OrgCode {
  CO_0000013
}

final orgCodeValues = EnumValues({
  "CO-0000013": OrgCode.CO_0000013
});

class EnumValues<T> {
  Map<String, T> map;
  late Map<T, String> reverseMap;

  EnumValues(this.map);

  Map<T, String> get reverse {
    reverseMap = map.map((k, v) => MapEntry(v, k));
    return reverseMap;
  }
}
