
import 'dart:convert';

DpdCarerVisitPercareDtl dpdCarerVisitPercareDtlFromJson(String str) => DpdCarerVisitPercareDtl.fromJson(json.decode(str));

String dpdCarerVisitPercareDtlToJson(DpdCarerVisitPercareDtl data) => json.encode(data.toJson());

class DpdCarerVisitPercareDtl {
  String? code;
  String? msg;
  List<Value>? value;

  DpdCarerVisitPercareDtl({
    this.code,
    this.msg,
    this.value,
  });

  factory DpdCarerVisitPercareDtl.fromJson(Map<String, dynamic> json) => DpdCarerVisitPercareDtl(
    code: json["CODE"],
    msg: json["MSG"],
    value: json["Value"] == null ? [] : List<Value>.from(json["Value"]!.map((x) => Value.fromJson(x))),
  );

  Map<String, dynamic> toJson() => {
    "CODE": code,
    "MSG": msg,
    "Value": value == null ? [] : List<dynamic>.from(value!.map((x) => x.toJson())),
  };
}

class Value {
  String? carerVisitMstId;
  String? orgCode;
  String? clientId;
  String? clientCode;
  String? taskCode;
  String? personalCare;

  Value({
    this.carerVisitMstId,
    this.orgCode,
    this.clientId,
    this.clientCode,
    this.taskCode,
    this.personalCare,
  });

  factory Value.fromJson(Map<String, dynamic> json) => Value(
    carerVisitMstId: json["CARER_VISIT_MST_ID"],
    orgCode: json["ORG_CODE"],
    clientId: json["CLIENT_ID"],
    clientCode: json["CLIENT_CODE"],
    taskCode: json["TASK_CODE"],
    personalCare: json["PERSONAL_CARE"],
  );

  Map<String, dynamic> toJson() => {
    "CARER_VISIT_MST_ID": carerVisitMstId,
    "ORG_CODE": orgCode,
    "CLIENT_ID": clientId,
    "CLIENT_CODE": clientCode,
    "TASK_CODE": taskCode,
    "PERSONAL_CARE": personalCare,
  };
}
