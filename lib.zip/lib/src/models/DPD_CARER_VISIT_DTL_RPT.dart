
import 'dart:convert';

DpdCarerVisitDtlRpt dpdCarerVisitDtlRptFromJson(String str) => DpdCarerVisitDtlRpt.fromJson(json.decode(str));

String dpdCarerVisitDtlRptToJson(DpdCarerVisitDtlRpt data) => json.encode(data.toJson());

class DpdCarerVisitDtlRpt {
  String? code;
  String? msg;
  List<Value>? value;

  DpdCarerVisitDtlRpt({
    this.code,
    this.msg,
    this.value,
  });

  factory DpdCarerVisitDtlRpt.fromJson(Map<String, dynamic> json) => DpdCarerVisitDtlRpt(
    code: json["CODE"],
    msg: json["MSG"],
    value: json["Value"] == null ? [] : List<Value>.from(json["Value"]!.map((x) => Value.fromJson(x))),
  );

  Map<String, dynamic> toJson() => {
    "CODE": code,
    "MSG": msg,
    "Value": value == null ? [] : List<dynamic>.from(value!.map((x) => x.toJson())),
  };
}

class Value {
  String? visitDay;
  String? checkInDate;
  String? checkInTime;
  String? checkOutDate;
  String? checkOutTime;
  String? workingTime;
  String? carerName;
  String? carerVisitMstId;
  String? clientId;
  String? orgCode;
  String? clientCode;
  String? carerId;
  String? carerId2;
  String? clientDatewiseSchId;
  String? clientVisitTypeMstId;
  String? visitTypeName;
  dynamic howDidClientEmojiCode;
  dynamic emojiDesc;
  dynamic imojiPath;
  dynamic agencyNote;
  dynamic raiseAlert;
  dynamic alertDtl;

  Value({
    this.visitDay,
    this.checkInDate,
    this.checkInTime,
    this.checkOutDate,
    this.checkOutTime,
    this.workingTime,
    this.carerName,
    this.carerVisitMstId,
    this.clientId,
    this.orgCode,
    this.clientCode,
    this.carerId,
    this.carerId2,
    this.clientDatewiseSchId,
    this.clientVisitTypeMstId,
    this.visitTypeName,
    this.howDidClientEmojiCode,
    this.emojiDesc,
    this.imojiPath,
    this.agencyNote,
    this.raiseAlert,
    this.alertDtl,
  });

  factory Value.fromJson(Map<String, dynamic> json) => Value(
    visitDay: json["VISIT_DAY"],
    checkInDate: json["CHECK_IN_DATE"],
    checkInTime: json["CHECK_IN_TIME"],
    checkOutDate: json["CHECK_OUT_DATE"],
    checkOutTime: json["CHECK_OUT_TIME"],
    workingTime: json["WORKING_TIME"],
    carerName: json["CARER_NAME"],
    carerVisitMstId: json["CARER_VISIT_MST_ID"],
    clientId: json["CLIENT_ID"],
    orgCode: json["ORG_CODE"],
    clientCode: json["CLIENT_CODE"],
    carerId: json["CARER_ID"],
    carerId2: json["CARER_ID2"],
    clientDatewiseSchId: json["CLIENT_DATEWISE_SCH_ID"],
    clientVisitTypeMstId: json["CLIENT_VISIT_TYPE_MST_ID"],
    visitTypeName: json["VISIT_TYPE_NAME"],
    howDidClientEmojiCode: json["HOW_DID_CLIENT_EMOJI_CODE"],
    emojiDesc: json["EMOJI_DESC"],
    imojiPath: json["IMOJI_PATH"],
    agencyNote: json["AGENCY_NOTE"],
    raiseAlert: json["RAISE_ALERT"],
    alertDtl: json["ALERT_DTL"],
  );

  Map<String, dynamic> toJson() => {
    "VISIT_DAY": visitDay,
    "CHECK_IN_DATE": checkInDate,
    "CHECK_IN_TIME": checkInTime,
    "CHECK_OUT_DATE": checkOutDate,
    "CHECK_OUT_TIME": checkOutTime,
    "WORKING_TIME": workingTime,
    "CARER_NAME": carerName,
    "CARER_VISIT_MST_ID": carerVisitMstId,
    "CLIENT_ID": clientId,
    "ORG_CODE": orgCode,
    "CLIENT_CODE": clientCode,
    "CARER_ID": carerId,
    "CARER_ID2": carerId2,
    "CLIENT_DATEWISE_SCH_ID": clientDatewiseSchId,
    "CLIENT_VISIT_TYPE_MST_ID": clientVisitTypeMstId,
    "VISIT_TYPE_NAME": visitTypeName,
    "HOW_DID_CLIENT_EMOJI_CODE": howDidClientEmojiCode,
    "EMOJI_DESC": emojiDesc,
    "IMOJI_PATH": imojiPath,
    "AGENCY_NOTE": agencyNote,
    "RAISE_ALERT": raiseAlert,
    "ALERT_DTL": alertDtl,
  };
}
