// To parse this JSON data, do
//
//     final dpdClientVisitTypeMstLstModel = dpdClientVisitTypeMstLstModelFromJson(jsonString);

import 'dart:convert';

DpdClientVisitTypeMstLstModel dpdClientVisitTypeMstLstModelFromJson(
        String str) =>
    DpdClientVisitTypeMstLstModel.fromJson(json.decode(str));

String dpdClientVisitTypeMstLstModelToJson(
        DpdClientVisitTypeMstLstModel data) =>
    json.encode(data.toJson());

class DpdClientVisitTypeMstLstModel {
  String? code;
  String? msg;
  List<Value>? value;

  DpdClientVisitTypeMstLstModel({
    this.code,
    this.msg,
    this.value,
  });

  factory DpdClientVisitTypeMstLstModel.fromJson(Map<String, dynamic> json) =>
      DpdClientVisitTypeMstLstModel(
        code: json["CODE"],
        msg: json["MSG"],
        value: json["Value"] == null
            ? []
            : List<Value>.from(json["Value"]!.map((x) => Value.fromJson(x))),
      );

  Map<String, dynamic> toJson() => {
        "CODE": code,
        "MSG": msg,
        "Value": value == null
            ? []
            : List<dynamic>.from(value!.map((x) => x.toJson())),
      };
}

class Value {
  String? clientVisitTypeMstId;
  String? visitTypeName;
  String? clientId;
  String? clientCode;
  String? orgCode;

  Value({
    this.clientVisitTypeMstId,
    this.visitTypeName,
    this.clientId,
    this.clientCode,
    this.orgCode,
  });

  factory Value.fromJson(Map<String, dynamic> json) => Value(
        clientVisitTypeMstId: json["CLIENT_VISIT_TYPE_MST_ID"],
        visitTypeName: json["VISIT_TYPE_NAME"],
        clientId: json["CLIENT_ID"],
        clientCode: json["CLIENT_CODE"],
        orgCode: json["ORG_CODE"],
      );

  Map<String, dynamic> toJson() => {
        "CLIENT_VISIT_TYPE_MST_ID": clientVisitTypeMstId,
        "VISIT_TYPE_NAME": visitTypeName,
        "CLIENT_ID": clientId,
        "CLIENT_CODE": clientCode,
        "ORG_CODE": orgCode,
      };
}
