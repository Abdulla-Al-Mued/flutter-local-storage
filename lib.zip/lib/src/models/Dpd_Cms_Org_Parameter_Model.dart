// To parse this JSON data, do
//
//     final dpdCmsOrgParameterModel = dpdCmsOrgParameterModelFromJson(jsonString);

import 'dart:convert';

DpdCmsOrgParameterModel dpdCmsOrgParameterModelFromJson(String str) =>
    DpdCmsOrgParameterModel.fromJson(json.decode(str));

String dpdCmsOrgParameterModelToJson(DpdCmsOrgParameterModel data) =>
    json.encode(data.toJson());

class DpdCmsOrgParameterModel {
  String? code;
  String? msg;
  List<Value>? value;

  DpdCmsOrgParameterModel({
    this.code,
    this.msg,
    this.value,
  });

  factory DpdCmsOrgParameterModel.fromJson(Map<String, dynamic> json) =>
      DpdCmsOrgParameterModel(
        code: json["CODE"],
        msg: json["MSG"],
        value: json["Value"] == null
            ? []
            : List<Value>.from(json["Value"]!.map((x) => Value.fromJson(x))),
      );

  Map<String, dynamic> toJson() => {
        "CODE": code,
        "MSG": msg,
        "Value": value == null
            ? []
            : List<dynamic>.from(value!.map((x) => x.toJson())),
      };
}

class Value {
  String? orgParamId;
  String? orgCode;
  String? allwCarerEditCheckinTime;
  String? lateVisitAlerts;
  String? clientBirthdayReminders;
  String? carerVisitAlerts;
  String? missedMedicationAlerts;
  String? clientAndCarerReminders;
  String? visitLateMinCode;

  Value({
    this.orgParamId,
    this.orgCode,
    this.allwCarerEditCheckinTime,
    this.lateVisitAlerts,
    this.clientBirthdayReminders,
    this.carerVisitAlerts,
    this.missedMedicationAlerts,
    this.clientAndCarerReminders,
    this.visitLateMinCode,
  });

  factory Value.fromJson(Map<String, dynamic> json) => Value(
        orgParamId: json["ORG_PARAM_ID"],
        orgCode: json["ORG_CODE"],
        allwCarerEditCheckinTime: json["ALLW_CARER_EDIT_CHECKIN_TIME"],
        lateVisitAlerts: json["LATE_VISIT_ALERTS"],
        clientBirthdayReminders: json["CLIENT_BIRTHDAY_REMINDERS"],
        carerVisitAlerts: json["CARER_VISIT_ALERTS"],
        missedMedicationAlerts: json["MISSED_MEDICATION_ALERTS"],
        clientAndCarerReminders: json["CLIENT_AND_CARER_REMINDERS"],
        visitLateMinCode: json["VISIT_LATE_MIN_CODE"],
      );

  Map<String, dynamic> toJson() => {
        "ORG_PARAM_ID": orgParamId,
        "ORG_CODE": orgCode,
        "ALLW_CARER_EDIT_CHECKIN_TIME": allwCarerEditCheckinTime,
        "LATE_VISIT_ALERTS": lateVisitAlerts,
        "CLIENT_BIRTHDAY_REMINDERS": clientBirthdayReminders,
        "CARER_VISIT_ALERTS": carerVisitAlerts,
        "MISSED_MEDICATION_ALERTS": missedMedicationAlerts,
        "CLIENT_AND_CARER_REMINDERS": clientAndCarerReminders,
        "VISIT_LATE_MIN_CODE": visitLateMinCode,
      };
}
