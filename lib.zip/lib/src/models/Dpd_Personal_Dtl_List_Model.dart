// To parse this JSON data, do
//
//     final dpdPersonalDtlListModel = dpdPersonalDtlListModelFromJson(jsonString);

import 'dart:convert';

DpdPersonalDtlListModel dpdPersonalDtlListModelFromJson(String str) =>
    DpdPersonalDtlListModel.fromJson(json.decode(str));

String dpdPersonalDtlListModelToJson(DpdPersonalDtlListModel data) =>
    json.encode(data.toJson());

class DpdPersonalDtlListModel {
  String? code;
  String? msg;
  List<Value>? value;

  DpdPersonalDtlListModel({
    this.code,
    this.msg,
    this.value,
  });

  factory DpdPersonalDtlListModel.fromJson(Map<String, dynamic> json) =>
      DpdPersonalDtlListModel(
        code: json["CODE"],
        msg: json["MSG"],
        value: json["Value"] == null
            ? []
            : List<Value>.from(json["Value"]!.map((x) => Value.fromJson(x))),
      );

  Map<String, dynamic> toJson() => {
        "CODE": code,
        "MSG": msg,
        "Value": value == null
            ? []
            : List<dynamic>.from(value!.map((x) => x.toJson())),
      };
}

class Value {
  String? clientId;
  String? clientCode;
  String? name;
  String? clientImagePath;
  String? address;
  String? phone;
  String? clientStatusTypeCode;
  String? clientStatusTypeDesc;
  String? orgCode;
  String? orgName;
  String? dob;
  String? mobilityDesc;
  String? likeDislikeDesc;
  String? languageSpeak;
  String? alleryDesc;
  String? interestHobbies;
  String? historyBackground;
  String? livingSituation;
  String? otherPeopleOrgInvolved;
  String? whichAspectsOfLifeImp;
  String? morningRoutine;
  String? lunchtimeRoutine;
  String? teatimeEveningRoutine;
  String? bedtimeRoutine;
  String? otherRoutine;
  String? legalFinancialArrangements;
  String? otherInformation;

  Value({
    this.clientId,
    this.clientCode,
    this.name,
    this.clientImagePath,
    this.address,
    this.phone,
    this.clientStatusTypeCode,
    this.clientStatusTypeDesc,
    this.orgCode,
    this.orgName,
    this.dob,
    this.mobilityDesc,
    this.likeDislikeDesc,
    this.languageSpeak,
    this.alleryDesc,
    this.interestHobbies,
    this.historyBackground,
    this.livingSituation,
    this.otherPeopleOrgInvolved,
    this.whichAspectsOfLifeImp,
    this.morningRoutine,
    this.lunchtimeRoutine,
    this.teatimeEveningRoutine,
    this.bedtimeRoutine,
    this.otherRoutine,
    this.legalFinancialArrangements,
    this.otherInformation,
  });

  factory Value.fromJson(Map<String, dynamic> json) => Value(
        clientId: json["CLIENT_ID"],
        clientCode: json["CLIENT_CODE"],
        name: json["NAME"],
        clientImagePath: json["CLIENT_IMAGE_PATH"],
        address: json["ADDRESS"],
        phone: json["PHONE"],
        clientStatusTypeCode: json["CLIENT_STATUS_TYPE_CODE"],
        clientStatusTypeDesc: json["CLIENT_STATUS_TYPE_DESC"],
        orgCode: json["ORG_CODE"],
        orgName: json["ORG_NAME"],
        dob: json["DOB"],
        mobilityDesc: json["MOBILITY_DESC"],
        likeDislikeDesc: json["LIKE_DISLIKE_DESC"],
        languageSpeak: json["LANGUAGE_SPEAK"],
        alleryDesc: json["ALLERY_DESC"],
        interestHobbies: json["INTEREST_HOBBIES"],
        historyBackground: json["HISTORY_BACKGROUND"],
        livingSituation: json["LIVING_SITUATION"],
        otherPeopleOrgInvolved: json["OTHER_PEOPLE_ORG_INVOLVED"],
        whichAspectsOfLifeImp: json["WHICH_ASPECTS_OF_LIFE_IMP"],
        morningRoutine: json["MORNING_ROUTINE"],
        lunchtimeRoutine: json["LUNCHTIME_ROUTINE"],
        teatimeEveningRoutine: json["TEATIME_EVENING_ROUTINE"],
        bedtimeRoutine: json["BEDTIME_ROUTINE"],
        otherRoutine: json["OTHER_ROUTINE"],
        legalFinancialArrangements: json["LEGAL_FINANCIAL_ARRANGEMENTS"],
        otherInformation: json["OTHER_INFORMATION"],
      );

  Map<String, dynamic> toJson() => {
        "CLIENT_ID": clientId,
        "CLIENT_CODE": clientCode,
        "NAME": name,
        "CLIENT_IMAGE_PATH": clientImagePath,
        "ADDRESS": address,
        "PHONE": phone,
        "CLIENT_STATUS_TYPE_CODE": clientStatusTypeCode,
        "CLIENT_STATUS_TYPE_DESC": clientStatusTypeDesc,
        "ORG_CODE": orgCode,
        "ORG_NAME": orgName,
        "DOB": dob,
        "MOBILITY_DESC": mobilityDesc,
        "LIKE_DISLIKE_DESC": likeDislikeDesc,
        "LANGUAGE_SPEAK": languageSpeak,
        "ALLERY_DESC": alleryDesc,
        "INTEREST_HOBBIES": interestHobbies,
        "HISTORY_BACKGROUND": historyBackground,
        "LIVING_SITUATION": livingSituation,
        "OTHER_PEOPLE_ORG_INVOLVED": otherPeopleOrgInvolved,
        "WHICH_ASPECTS_OF_LIFE_IMP": whichAspectsOfLifeImp,
        "MORNING_ROUTINE": morningRoutine,
        "LUNCHTIME_ROUTINE": lunchtimeRoutine,
        "TEATIME_EVENING_ROUTINE": teatimeEveningRoutine,
        "BEDTIME_ROUTINE": bedtimeRoutine,
        "OTHER_ROUTINE": otherRoutine,
        "LEGAL_FINANCIAL_ARRANGEMENTS": legalFinancialArrangements,
        "OTHER_INFORMATION": otherInformation,
      };
}
