
import 'dart:convert';

DpdCarerVisitSummRpt dpdCarerVisitSummRptFromJson(String str) => DpdCarerVisitSummRpt.fromJson(json.decode(str));

String dpdCarerVisitSummRptToJson(DpdCarerVisitSummRpt data) => json.encode(data.toJson());

class DpdCarerVisitSummRpt {
  String? code;
  String? msg;
  List<Value>? value;

  DpdCarerVisitSummRpt({
    this.code,
    this.msg,
    this.value,
  });

  factory DpdCarerVisitSummRpt.fromJson(Map<String, dynamic> json) => DpdCarerVisitSummRpt(
    code: json["CODE"],
    msg: json["MSG"],
    value: json["Value"] == null ? [] : List<Value>.from(json["Value"]!.map((x) => Value.fromJson(x))),
  );

  Map<String, dynamic> toJson() => {
    "CODE": code,
    "MSG": msg,
    "Value": value == null ? [] : List<dynamic>.from(value!.map((x) => x.toJson())),
  };
}

class Value {
  String? visitDay;
  String? checkInDate;
  String? checkInTime;
  String? checkOutDate;
  String? checkOutTime;
  String? workingTime;
  String? carerName;
  String? carerVisitMstId;
  String? clientId;
  String? carerId;
  String? carerId2;
  String? clientDatewiseSchId;
  String? clientVisitTypeMstId;
  dynamic agencyNote;
  dynamic raiseAlert;
  dynamic alertDtl;
  String? orgCode;

  Value({
    this.visitDay,
    this.checkInDate,
    this.checkInTime,
    this.checkOutDate,
    this.checkOutTime,
    this.workingTime,
    this.carerName,
    this.carerVisitMstId,
    this.clientId,
    this.carerId,
    this.carerId2,
    this.clientDatewiseSchId,
    this.clientVisitTypeMstId,
    this.agencyNote,
    this.raiseAlert,
    this.alertDtl,
    this.orgCode,
  });

  factory Value.fromJson(Map<String, dynamic> json) => Value(
    visitDay: json["VISIT_DAY"],
    checkInDate: json["CHECK_IN_DATE"],
    checkInTime: json["CHECK_IN_TIME"],
    checkOutDate: json["CHECK_OUT_DATE"],
    checkOutTime: json["CHECK_OUT_TIME"],
    workingTime: json["WORKING_TIME"],
    carerName: json["CARER_NAME"],
    carerVisitMstId: json["CARER_VISIT_MST_ID"],
    clientId: json["CLIENT_ID"],
    carerId: json["CARER_ID"],
    carerId2: json["CARER_ID2"],
    clientDatewiseSchId: json["CLIENT_DATEWISE_SCH_ID"],
    clientVisitTypeMstId: json["CLIENT_VISIT_TYPE_MST_ID"],
    agencyNote: json["AGENCY_NOTE"],
    raiseAlert: json["RAISE_ALERT"],
    alertDtl: json["ALERT_DTL"],
    orgCode: json["ORG_CODE"],
  );

  Map<String, dynamic> toJson() => {
    "VISIT_DAY": visitDay,
    "CHECK_IN_DATE": checkInDate,
    "CHECK_IN_TIME": checkInTime,
    "CHECK_OUT_DATE": checkOutDate,
    "CHECK_OUT_TIME": checkOutTime,
    "WORKING_TIME": workingTime,
    "CARER_NAME": carerName,
    "CARER_VISIT_MST_ID": carerVisitMstId,
    "CLIENT_ID": clientId,
    "CARER_ID": carerId,
    "CARER_ID2": carerId2,
    "CLIENT_DATEWISE_SCH_ID": clientDatewiseSchId,
    "CLIENT_VISIT_TYPE_MST_ID": clientVisitTypeMstId,
    "AGENCY_NOTE": agencyNote,
    "RAISE_ALERT": raiseAlert,
    "ALERT_DTL": alertDtl,
    "ORG_CODE": orgCode,
  };
}
