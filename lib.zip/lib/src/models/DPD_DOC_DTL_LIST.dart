// To parse this JSON data, do
//
//     final dpdDocDtlList = dpdDocDtlListFromJson(jsonString);

import 'dart:convert';

DpdDocDtlList dpdDocDtlListFromJson(String str) => DpdDocDtlList.fromJson(json.decode(str));

String dpdDocDtlListToJson(DpdDocDtlList data) => json.encode(data.toJson());

class DpdDocDtlList {
  String? code;
  String? msg;
  List<Value>? value;

  DpdDocDtlList({
    this.code,
    this.msg,
    this.value,
  });

  factory DpdDocDtlList.fromJson(Map<String, dynamic> json) => DpdDocDtlList(
    code: json["CODE"],
    msg: json["MSG"],
    value: json["Value"] == null ? [] : List<Value>.from(json["Value"]!.map((x) => Value.fromJson(x))),
  );

  Map<String, dynamic> toJson() => {
    "CODE": code,
    "MSG": msg,
    "Value": value == null ? [] : List<dynamic>.from(value!.map((x) => x.toJson())),
  };
}

class Value {
  String? clientDocDtlId;
  String? clientId;
  String? clientCode;
  String? orgCode;
  String? docPath;
  String? docDesc;

  Value({
    this.clientDocDtlId,
    this.clientId,
    this.clientCode,
    this.orgCode,
    this.docPath,
    this.docDesc,
  });

  factory Value.fromJson(Map<String, dynamic> json) => Value(
    clientDocDtlId: json["CLIENT_DOC_DTL_ID"],
    clientId: json["CLIENT_ID"],
    clientCode: json["CLIENT_CODE"],
    orgCode: json["ORG_CODE"],
    docPath: json["DOC_PATH"],
    docDesc: json["DOC_DESC"],
  );

  Map<String, dynamic> toJson() => {
    "CLIENT_DOC_DTL_ID": clientDocDtlId,
    "CLIENT_ID": clientId,
    "CLIENT_CODE": clientCode,
    "ORG_CODE": orgCode,
    "DOC_PATH": docPath,
    "DOC_DESC": docDesc,
  };
}
