
import 'dart:convert';

DpdCarerVisitMedicationDtl dpdCarerVisitMedicationDtlFromJson(String str) => DpdCarerVisitMedicationDtl.fromJson(json.decode(str));

String dpdCarerVisitMedicationDtlToJson(DpdCarerVisitMedicationDtl data) => json.encode(data.toJson());

class DpdCarerVisitMedicationDtl {
  String? code;
  String? msg;
  List<Value>? value;

  DpdCarerVisitMedicationDtl({
    this.code,
    this.msg,
    this.value,
  });

  factory DpdCarerVisitMedicationDtl.fromJson(Map<String, dynamic> json) => DpdCarerVisitMedicationDtl(
    code: json["CODE"],
    msg: json["MSG"],
    value: json["Value"] == null ? [] : List<Value>.from(json["Value"]!.map((x) => Value.fromJson(x))),
  );

  Map<String, dynamic> toJson() => {
    "CODE": code,
    "MSG": msg,
    "Value": value == null ? [] : List<dynamic>.from(value!.map((x) => x.toJson())),
  };
}

class Value {
  String? carerVisitMstId;
  String? orgCode;
  String? clientId;
  String? clientCode;
  String? taskCode;
  String? clientMedicationDtlId;
  String? medicationName;
  String? dosage;
  String? administrationNotes;
  String? morningSchedule;
  String? lunchtimeSchedule;
  String? eveningSchedule;
  String? bedtimeSchedule;
  String? asNeededSchedule;
  String? mondaySchedule;
  String? tuesdaySchedule;
  String? wednesdaySchedule;
  String? thursdaySchedule;
  String? fridaySchedule;
  String? saturdaySchedule;
  String? sundaySchedule;
  String? takenStatus;
  dynamic takenRemarks;
  String? notTakenStatus;
  dynamic notTakenRemarks;
  String? dataCapturedDate;
  String? dataCapturedTime;

  Value({
    this.carerVisitMstId,
    this.orgCode,
    this.clientId,
    this.clientCode,
    this.taskCode,
    this.clientMedicationDtlId,
    this.medicationName,
    this.dosage,
    this.administrationNotes,
    this.morningSchedule,
    this.lunchtimeSchedule,
    this.eveningSchedule,
    this.bedtimeSchedule,
    this.asNeededSchedule,
    this.mondaySchedule,
    this.tuesdaySchedule,
    this.wednesdaySchedule,
    this.thursdaySchedule,
    this.fridaySchedule,
    this.saturdaySchedule,
    this.sundaySchedule,
    this.takenStatus,
    this.takenRemarks,
    this.notTakenStatus,
    this.notTakenRemarks,
    this.dataCapturedDate,
    this.dataCapturedTime,
  });

  factory Value.fromJson(Map<String, dynamic> json) => Value(
    carerVisitMstId: json["CARER_VISIT_MST_ID"],
    orgCode: json["ORG_CODE"],
    clientId: json["CLIENT_ID"],
    clientCode: json["CLIENT_CODE"],
    taskCode: json["TASK_CODE"],
    clientMedicationDtlId: json["CLIENT_MEDICATION_DTL_ID"],
    medicationName: json["MEDICATION_NAME"],
    dosage: json["DOSAGE"],
    administrationNotes: json["ADMINISTRATION_NOTES"],
    morningSchedule: json["MORNING_SCHEDULE"],
    lunchtimeSchedule: json["LUNCHTIME_SCHEDULE"],
    eveningSchedule: json["EVENING_SCHEDULE"],
    bedtimeSchedule: json["BEDTIME_SCHEDULE"],
    asNeededSchedule: json["AS_NEEDED_SCHEDULE"],
    mondaySchedule: json["MONDAY_SCHEDULE"],
    tuesdaySchedule: json["TUESDAY_SCHEDULE"],
    wednesdaySchedule: json["WEDNESDAY_SCHEDULE"],
    thursdaySchedule: json["THURSDAY_SCHEDULE"],
    fridaySchedule: json["FRIDAY_SCHEDULE"],
    saturdaySchedule: json["SATURDAY_SCHEDULE"],
    sundaySchedule: json["SUNDAY_SCHEDULE"],
    takenStatus: json["TAKEN_STATUS"],
    takenRemarks: json["TAKEN_REMARKS"],
    notTakenStatus: json["NOT_TAKEN_STATUS"],
    notTakenRemarks: json["NOT_TAKEN_REMARKS"],
    dataCapturedDate: json["DATA_CAPTURED_DATE"],
    dataCapturedTime: json["DATA_CAPTURED_TIME"],
  );

  Map<String, dynamic> toJson() => {
    "CARER_VISIT_MST_ID": carerVisitMstId,
    "ORG_CODE": orgCode,
    "CLIENT_ID": clientId,
    "CLIENT_CODE": clientCode,
    "TASK_CODE": taskCode,
    "CLIENT_MEDICATION_DTL_ID": clientMedicationDtlId,
    "MEDICATION_NAME": medicationName,
    "DOSAGE": dosage,
    "ADMINISTRATION_NOTES": administrationNotes,
    "MORNING_SCHEDULE": morningSchedule,
    "LUNCHTIME_SCHEDULE": lunchtimeSchedule,
    "EVENING_SCHEDULE": eveningSchedule,
    "BEDTIME_SCHEDULE": bedtimeSchedule,
    "AS_NEEDED_SCHEDULE": asNeededSchedule,
    "MONDAY_SCHEDULE": mondaySchedule,
    "TUESDAY_SCHEDULE": tuesdaySchedule,
    "WEDNESDAY_SCHEDULE": wednesdaySchedule,
    "THURSDAY_SCHEDULE": thursdaySchedule,
    "FRIDAY_SCHEDULE": fridaySchedule,
    "SATURDAY_SCHEDULE": saturdaySchedule,
    "SUNDAY_SCHEDULE": sundaySchedule,
    "TAKEN_STATUS": takenStatus,
    "TAKEN_REMARKS": takenRemarks,
    "NOT_TAKEN_STATUS": notTakenStatus,
    "NOT_TAKEN_REMARKS": notTakenRemarks,
    "DATA_CAPTURED_DATE": dataCapturedDate,
    "DATA_CAPTURED_TIME": dataCapturedTime,
  };
}
