// To parse this JSON data, do
//
//     final dpdClientMedicationDtlModel = dpdClientMedicationDtlModelFromJson(jsonString);

import 'dart:convert';

DpdClientMedicationDtlModel dpdClientMedicationDtlModelFromJson(String str) =>
    DpdClientMedicationDtlModel.fromJson(json.decode(str));

String dpdClientMedicationDtlModelToJson(DpdClientMedicationDtlModel data) =>
    json.encode(data.toJson());

class DpdClientMedicationDtlModel {
  String? code;
  String? msg;
  List<Value>? value;

  DpdClientMedicationDtlModel({
    this.code,
    this.msg,
    this.value,
  });

  factory DpdClientMedicationDtlModel.fromJson(Map<String, dynamic> json) =>
      DpdClientMedicationDtlModel(
        code: json["CODE"],
        msg: json["MSG"],
        value: json["Value"] == null
            ? []
            : List<Value>.from(json["Value"]!.map((x) => Value.fromJson(x))),
      );

  Map<String, dynamic> toJson() => {
        "CODE": code,
        "MSG": msg,
        "Value": value == null
            ? []
            : List<dynamic>.from(value!.map((x) => x.toJson())),
      };
}

class Value {
  String? clientId;
  String? clientCode;
  String? orgCode;
  String? medicationName;
  String? dosage;
  dynamic administrationNotes;
  String? morningSchedule;
  String? lunchtimeSchedule;
  String? eveningSchedule;
  String? bedtimeSchedule;
  String? asNeededSchedule;
  String? mondaySchedule;
  String? tuesdaySchedule;
  String? wednesdaySchedule;
  String? thursdaySchedule;
  String? fridaySchedule;
  String? saturdaySchedule;
  String? sundaySchedule;

  Value({
    this.clientId,
    this.clientCode,
    this.orgCode,
    this.medicationName,
    this.dosage,
    this.administrationNotes,
    this.morningSchedule,
    this.lunchtimeSchedule,
    this.eveningSchedule,
    this.bedtimeSchedule,
    this.asNeededSchedule,
    this.mondaySchedule,
    this.tuesdaySchedule,
    this.wednesdaySchedule,
    this.thursdaySchedule,
    this.fridaySchedule,
    this.saturdaySchedule,
    this.sundaySchedule,
  });

  factory Value.fromJson(Map<String, dynamic> json) => Value(
        clientId: json["CLIENT_ID"],
        clientCode: json["CLIENT_CODE"],
        orgCode: json["ORG_CODE"],
        medicationName: json["MEDICATION_NAME"],
        dosage: json["DOSAGE"],
        administrationNotes: json["ADMINISTRATION_NOTES"],
        morningSchedule: json["MORNING_SCHEDULE"],
        lunchtimeSchedule: json["LUNCHTIME_SCHEDULE"],
        eveningSchedule: json["EVENING_SCHEDULE"],
        bedtimeSchedule: json["BEDTIME_SCHEDULE"],
        asNeededSchedule: json["AS_NEEDED_SCHEDULE"],
        mondaySchedule: json["MONDAY_SCHEDULE"],
        tuesdaySchedule: json["TUESDAY_SCHEDULE"],
        wednesdaySchedule: json["WEDNESDAY_SCHEDULE"],
        thursdaySchedule: json["THURSDAY_SCHEDULE"],
        fridaySchedule: json["FRIDAY_SCHEDULE"],
        saturdaySchedule: json["SATURDAY_SCHEDULE"],
        sundaySchedule: json["SUNDAY_SCHEDULE"],
      );

  Map<String, dynamic> toJson() => {
        "CLIENT_ID": clientId,
        "CLIENT_CODE": clientCode,
        "ORG_CODE": orgCode,
        "MEDICATION_NAME": medicationName,
        "DOSAGE": dosage,
        "ADMINISTRATION_NOTES": administrationNotes,
        "MORNING_SCHEDULE": morningSchedule,
        "LUNCHTIME_SCHEDULE": lunchtimeSchedule,
        "EVENING_SCHEDULE": eveningSchedule,
        "BEDTIME_SCHEDULE": bedtimeSchedule,
        "AS_NEEDED_SCHEDULE": asNeededSchedule,
        "MONDAY_SCHEDULE": mondaySchedule,
        "TUESDAY_SCHEDULE": tuesdaySchedule,
        "WEDNESDAY_SCHEDULE": wednesdaySchedule,
        "THURSDAY_SCHEDULE": thursdaySchedule,
        "FRIDAY_SCHEDULE": fridaySchedule,
        "SATURDAY_SCHEDULE": saturdaySchedule,
        "SUNDAY_SCHEDULE": sundaySchedule,
      };
}
