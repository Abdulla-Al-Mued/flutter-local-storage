// To parse this JSON data, do
//
//     final dpdTaskListModel = dpdTaskListModelFromJson(jsonString);

import 'dart:convert';

DpdTaskListModel dpdTaskListModelFromJson(String str) =>
    DpdTaskListModel.fromJson(json.decode(str));

String dpdTaskListModelToJson(DpdTaskListModel data) =>
    json.encode(data.toJson());

class DpdTaskListModel {
  String? code;
  String? msg;
  List<Value>? value;

  DpdTaskListModel({
    this.code,
    this.msg,
    this.value,
  });

  factory DpdTaskListModel.fromJson(Map<String, dynamic> json) =>
      DpdTaskListModel(
        code: json["CODE"],
        msg: json["MSG"],
        value: json["Value"] == null
            ? []
            : List<Value>.from(json["Value"]!.map((x) => Value.fromJson(x))),
      );

  Map<String, dynamic> toJson() => {
        "CODE": code,
        "MSG": msg,
        "Value": value == null
            ? []
            : List<dynamic>.from(value!.map((x) => x.toJson())),
      };
}

class Value {
  String? taskCode;
  String? taskDesc;
  String? iconImagePath;

  Value({
    this.taskCode,
    this.taskDesc,
    this.iconImagePath,
  });

  factory Value.fromJson(Map<String, dynamic> json) => Value(
        taskCode: json["TASK_CODE"],
        taskDesc: json["TASK_DESC"],
        iconImagePath: json["ICON_IMAGE_PATH"],
      );

  Map<String, dynamic> toJson() => {
        "TASK_CODE": taskCode,
        "TASK_DESC": taskDesc,
        "ICON_IMAGE_PATH": iconImagePath,
      };
}
