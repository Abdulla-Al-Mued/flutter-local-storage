// To parse this JSON data, do
//
//     final dpdFrndFmlyListModel = dpdFrndFmlyListModelFromJson(jsonString);

import 'dart:convert';

DpdFrndFmlyListModel dpdFrndFmlyListModelFromJson(String str) =>
    DpdFrndFmlyListModel.fromJson(json.decode(str));

String dpdFrndFmlyListModelToJson(DpdFrndFmlyListModel data) =>
    json.encode(data.toJson());

class DpdFrndFmlyListModel {
  String? code;
  String? msg;
  List<Value>? value;

  DpdFrndFmlyListModel({
    this.code,
    this.msg,
    this.value,
  });

  factory DpdFrndFmlyListModel.fromJson(Map<String, dynamic> json) =>
      DpdFrndFmlyListModel(
        code: json["CODE"],
        msg: json["MSG"],
        value: json["Value"] == null
            ? []
            : List<Value>.from(json["Value"]!.map((x) => Value.fromJson(x))),
      );

  Map<String, dynamic> toJson() => {
        "CODE": code,
        "MSG": msg,
        "Value": value == null
            ? []
            : List<dynamic>.from(value!.map((x) => x.toJson())),
      };
}

class Value {
  String? clientFrndFmlyId;
  String? clientId;
  String? clientCode;
  String? orgCode;
  String? userId;
  String? userCode;
  String? firstName;
  String? lastName;
  String? email;
  String? phone;

  Value({
    this.clientFrndFmlyId,
    this.clientId,
    this.clientCode,
    this.orgCode,
    this.userId,
    this.userCode,
    this.firstName,
    this.lastName,
    this.email,
    this.phone,
  });

  factory Value.fromJson(Map<String, dynamic> json) => Value(
        clientFrndFmlyId: json["CLIENT_FRND_FMLY_ID"],
        clientId: json["CLIENT_ID"],
        clientCode: json["CLIENT_CODE"],
        orgCode: json["ORG_CODE"],
        userId: json["USER_ID"],
        userCode: json["USER_CODE"],
        firstName: json["FIRST_NAME"],
        lastName: json["LAST_NAME"],
        email: json["EMAIL"],
        phone: json["PHONE"],
      );

  Map<String, dynamic> toJson() => {
        "CLIENT_FRND_FMLY_ID": clientFrndFmlyId,
        "CLIENT_ID": clientId,
        "CLIENT_CODE": clientCode,
        "ORG_CODE": orgCode,
        "USER_ID": userId,
        "USER_CODE": userCode,
        "FIRST_NAME": firstName,
        "LAST_NAME": lastName,
        "EMAIL": email,
        "PHONE": phone,
      };
}
