// To parse this JSON data, do
//
//     final dpdClientKeyContactDtlModel = dpdClientKeyContactDtlModelFromJson(jsonString);

import 'dart:convert';

DpdClientKeyContactDtlModel dpdClientKeyContactDtlModelFromJson(String str) =>
    DpdClientKeyContactDtlModel.fromJson(json.decode(str));

String dpdClientKeyContactDtlModelToJson(DpdClientKeyContactDtlModel data) =>
    json.encode(data.toJson());

class DpdClientKeyContactDtlModel {
  String? code;
  String? msg;
  List<Value>? value;

  DpdClientKeyContactDtlModel({
    this.code,
    this.msg,
    this.value,
  });

  factory DpdClientKeyContactDtlModel.fromJson(Map<String, dynamic> json) =>
      DpdClientKeyContactDtlModel(
        code: json["CODE"],
        msg: json["MSG"],
        value: json["Value"] == null
            ? []
            : List<Value>.from(json["Value"]!.map((x) => Value.fromJson(x))),
      );

  Map<String, dynamic> toJson() => {
        "CODE": code,
        "MSG": msg,
        "Value": value == null
            ? []
            : List<dynamic>.from(value!.map((x) => x.toJson())),
      };
}

class Value {
  String? clientKeyContactId;
  String? clientId;
  String? clientCode;
  String? orgCode;
  String? contactName;
  String? relation;
  String? contactDtl;

  Value({
    this.clientKeyContactId,
    this.clientId,
    this.clientCode,
    this.orgCode,
    this.contactName,
    this.relation,
    this.contactDtl,
  });

  factory Value.fromJson(Map<String, dynamic> json) => Value(
        clientKeyContactId: json["CLIENT_KEY_CONTACT_ID"],
        clientId: json["CLIENT_ID"],
        clientCode: json["CLIENT_CODE"],
        orgCode: json["ORG_CODE"],
        contactName: json["CONTACT_NAME"],
        relation: json["RELATION"],
        contactDtl: json["CONTACT_DTL"],
      );

  Map<String, dynamic> toJson() => {
        "CLIENT_KEY_CONTACT_ID": clientKeyContactId,
        "CLIENT_ID": clientId,
        "CLIENT_CODE": clientCode,
        "ORG_CODE": orgCode,
        "CONTACT_NAME": contactName,
        "RELATION": relation,
        "CONTACT_DTL": contactDtl,
      };
}
