
import 'dart:convert';

DpdEmojiList dpdEmojiListFromJson(String str) => DpdEmojiList.fromJson(json.decode(str));

String dpdEmojiListToJson(DpdEmojiList data) => json.encode(data.toJson());

class DpdEmojiList {
  String? code;
  String? msg;
  List<Value>? value;

  DpdEmojiList({
    this.code,
    this.msg,
    this.value,
  });

  factory DpdEmojiList.fromJson(Map<String, dynamic> json) => DpdEmojiList(
    code: json["CODE"],
    msg: json["MSG"],
    value: json["Value"] == null ? [] : List<Value>.from(json["Value"]!.map((x) => Value.fromJson(x))),
  );

  Map<String, dynamic> toJson() => {
    "CODE": code,
    "MSG": msg,
    "Value": value == null ? [] : List<dynamic>.from(value!.map((x) => x.toJson())),
  };
}

class Value {
  String? emojiCode;
  String? emojiDesc;
  dynamic iconImagePath;

  Value({
    this.emojiCode,
    this.emojiDesc,
    this.iconImagePath,
  });

  factory Value.fromJson(Map<String, dynamic> json) => Value(
    emojiCode: json["EMOJI_CODE"],
    emojiDesc: json["EMOJI_DESC"],
    iconImagePath: json["ICON_IMAGE_PATH"],
  );

  Map<String, dynamic> toJson() => {
    "EMOJI_CODE": emojiCode,
    "EMOJI_DESC": emojiDesc,
    "ICON_IMAGE_PATH": iconImagePath,
  };
}
