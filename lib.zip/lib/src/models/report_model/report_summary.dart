import 'dart:convert';

class Task {
  final String? taskCode;
  final String? taskDesc;

  Task({
    required this.taskCode,
    required this.taskDesc,
  });

  factory Task.fromJson(Map<String, dynamic> json) {
    return Task(
      taskCode: json.containsKey('TASK_CODE') ? json['TASK_CODE'] : null,
      taskDesc: json.containsKey('TASK_DESC') ? json['TASK_DESC'] : null,
    );
  }

  Map<String, dynamic> toJson() => {
    'TASK_CODE': taskCode,
    'TASK_DESC': taskDesc,
  };

}


class CarerVisitReportSummary {
  String? carerVisitMstId;
  String? checkInDate;
  String? checkInTime;
  String? checkOutTime;
  String? carerName;
  String? workingTime;
  List<Task>? taskData;

  CarerVisitReportSummary({
    required this.carerVisitMstId,
    required this.checkInDate,
    required this.checkInTime,
    required this.checkOutTime,
    required this.carerName,
    required this.workingTime,
    required this.taskData,
  });


  factory CarerVisitReportSummary.fromJson(Map<String, dynamic> json) {

    return CarerVisitReportSummary(
      carerVisitMstId: json['CARER_VISIT_MST_ID'],
      checkInDate: json['CHECK_IN_DATE'],
      checkInTime: json['CHECK_IN_TIME'],
      checkOutTime: json['CHECK_OUT_TIME'],
      carerName: json['CARER_NAME'],
      workingTime: json['WORKING_TIME'],
      taskData: List<Task>.from(json["TASK_DATA"].map((x) => Task.fromJson(x))),
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'CARER_VISIT_MST_ID': carerVisitMstId,
      'CHECK_IN_DATE': checkInDate,
      'CHECK_IN_TIME': checkInTime,
      'CHECK_OUT_TIME': checkOutTime,
      'CARER_NAME': carerName,
      'WORKING_TIME': workingTime,
      'TASK_DATA': taskData == null ? [] : List<dynamic>.from(taskData!.map((x) => x.toJson())),
    };
  }

}