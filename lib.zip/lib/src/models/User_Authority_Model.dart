import 'dart:convert';

UserAuthorityModel authorityModelFromJson(String str) =>
    UserAuthorityModel.fromJson(json.decode(str));

String authorityModelToJson(UserAuthorityModel model) =>
    json.encode(model.toJson());

class UserAuthorityModel {
  String? mail;
  String? password;
  int? userId;
  String? startTime;
  String? endTime;

  UserAuthorityModel(
      {this.mail, this.password, this.userId, this.startTime, this.endTime});

  factory UserAuthorityModel.fromJson(Map<String, dynamic> json) =>
      UserAuthorityModel(
        mail: json['mail'],
        password: json['password'],
        userId: json['userId'],
        startTime: json['startTime'],
        endTime: json['endTime'],
      );

  Map<String, dynamic> toJson() => {
        'mail': mail,
        'password': password,
        'userId': userId,
        'startTime': startTime,
        'endTime': endTime,
      };
}
