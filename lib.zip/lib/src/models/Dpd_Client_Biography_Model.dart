// To parse this JSON data, do
//
//     final dpdClientBiographyModel = dpdClientBiographyModelFromJson(jsonString);

import 'dart:convert';

DpdClientBiographyModel dpdClientBiographyModelFromJson(String str) => DpdClientBiographyModel.fromJson(json.decode(str));

String dpdClientBiographyModelToJson(DpdClientBiographyModel data) => json.encode(data.toJson());

class DpdClientBiographyModel {
  String? code;
  String? msg;
  List<Value>? value;

  DpdClientBiographyModel({
    this.code,
    this.msg,
    this.value,
  });

  factory DpdClientBiographyModel.fromJson(Map<String, dynamic> json) => DpdClientBiographyModel(
    code: json["CODE"],
    msg: json["MSG"],
    value: json["Value"] == null ? [] : List<Value>.from(json["Value"]!.map((x) => Value.fromJson(x))),
  );

  Map<String, dynamic> toJson() => {
    "CODE": code,
    "MSG": msg,
    "Value": value == null ? [] : List<dynamic>.from(value!.map((x) => x.toJson())),
  };
}

class Value {
  String? clientBiographyId;
  String? clientId;
  String? clientCode;
  String? orgCode;
  String? biographyDtl;

  Value({
    this.clientBiographyId,
    this.clientId,
    this.clientCode,
    this.orgCode,
    this.biographyDtl,
  });

  factory Value.fromJson(Map<String, dynamic> json) => Value(
    clientBiographyId: json["CLIENT_BIOGRAPHY_ID"],
    clientId: json["CLIENT_ID"],
    clientCode: json["CLIENT_CODE"],
    orgCode: json["ORG_CODE"],
    biographyDtl: json["BIOGRAPHY_DTL"],
  );

  Map<String, dynamic> toJson() => {
    "CLIENT_BIOGRAPHY_ID": clientBiographyId,
    "CLIENT_ID": clientId,
    "CLIENT_CODE": clientCode,
    "ORG_CODE": orgCode,
    "BIOGRAPHY_DTL": biographyDtl,
  };
}
