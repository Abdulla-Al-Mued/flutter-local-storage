// To parse this JSON data, do
//
//     final dpdCmsCarerListModel = dpdCmsCarerListModelFromJson(jsonString);

import 'dart:convert';

DpdCmsCarerListModel dpdCmsCarerListModelFromJson(String str) =>
    DpdCmsCarerListModel.fromJson(json.decode(str));

String dpdCmsCarerListModelToJson(DpdCmsCarerListModel data) =>
    json.encode(data.toJson());

class DpdCmsCarerListModel {
  String? code;
  String? msg;
  List<Value>? value;

  DpdCmsCarerListModel({
    this.code,
    this.msg,
    this.value,
  });

  factory DpdCmsCarerListModel.fromJson(Map<String, dynamic> json) =>
      DpdCmsCarerListModel(
        code: json["CODE"],
        msg: json["MSG"],
        value: json["Value"] == null
            ? []
            : List<Value>.from(json["Value"]!.map((x) => Value.fromJson(x))),
      );

  Map<String, dynamic> toJson() => {
        "CODE": code,
        "MSG": msg,
        "Value": value == null
            ? []
            : List<dynamic>.from(value!.map((x) => x.toJson())),
      };
}

class Value {
  String? carerId;
  String? carerCode;
  String? carerName;
  String? orgCode;
  String? orgName;

  Value({
    this.carerId,
    this.carerCode,
    this.carerName,
    this.orgCode,
    this.orgName,
  });

  factory Value.fromJson(Map<String, dynamic> json) => Value(
        carerId: json["CARER_ID"],
        carerCode: json["CARER_CODE"],
        carerName: json["CARER_NAME"],
        orgCode: json["ORG_CODE"],
        orgName: json["ORG_NAME"],
      );

  Map<String, dynamic> toJson() => {
        "CARER_ID": carerId,
        "CARER_CODE": carerCode,
        "CARER_NAME": carerName,
        "ORG_CODE": orgCode,
        "ORG_NAME": orgName,
      };
}
