import 'dart:convert';

DpdCarerChkInoutStatus dpdCarerChkInoutStatusFromJson(String str) => DpdCarerChkInoutStatus.fromJson(json.decode(str));

String dpdCarerChkInoutStatusToJson(DpdCarerChkInoutStatus data) => json.encode(data.toJson());

class DpdCarerChkInoutStatus {
  String? code;
  String? msg;
  List<Value>? value;

  DpdCarerChkInoutStatus({
    this.code,
    this.msg,
    this.value,
  });

  factory DpdCarerChkInoutStatus.fromJson(Map<String, dynamic> json) => DpdCarerChkInoutStatus(
    code: json["CODE"],
    msg: json["MSG"],
    value: json["Value"] == null ? [] : List<Value>.from(json["Value"]!.map((x) => Value.fromJson(x))),
  );

  Map<String, dynamic> toJson() => {
    "CODE": code,
    "MSG": msg,
    "Value": value == null ? [] : List<dynamic>.from(value!.map((x) => x.toJson())),
  };
}

class Value {
  String? status;

  Value({
    this.status,
  });

  factory Value.fromJson(Map<String, dynamic> json) => Value(
    status: json["STATUS"],
  );

  Map<String, dynamic> toJson() => {
    "STATUS": status,
  };
}
