
import 'dart:convert';

DpdCarerVisitGroceriDtl dpdCarerVisitGroceriDtlFromJson(String str) => DpdCarerVisitGroceriDtl.fromJson(json.decode(str));

String dpdCarerVisitGroceriDtlToJson(DpdCarerVisitGroceriDtl data) => json.encode(data.toJson());

class DpdCarerVisitGroceriDtl {
  String? code;
  String? msg;
  List<Value>? value;

  DpdCarerVisitGroceriDtl({
    this.code,
    this.msg,
    this.value,
  });

  factory DpdCarerVisitGroceriDtl.fromJson(Map<String, dynamic> json) => DpdCarerVisitGroceriDtl(
    code: json["CODE"],
    msg: json["MSG"],
    value: json["Value"] == null ? [] : List<Value>.from(json["Value"]!.map((x) => Value.fromJson(x))),
  );

  Map<String, dynamic> toJson() => {
    "CODE": code,
    "MSG": msg,
    "Value": value == null ? [] : List<dynamic>.from(value!.map((x) => x.toJson())),
  };
}

class Value {
  String? carerVisitMstId;
  String? orgCode;
  String? clientId;
  String? clientCode;
  String? taskCode;
  String? groceries;

  Value({
    this.carerVisitMstId,
    this.orgCode,
    this.clientId,
    this.clientCode,
    this.taskCode,
    this.groceries,
  });

  factory Value.fromJson(Map<String, dynamic> json) => Value(
    carerVisitMstId: json["CARER_VISIT_MST_ID"],
    orgCode: json["ORG_CODE"],
    clientId: json["CLIENT_ID"],
    clientCode: json["CLIENT_CODE"],
    taskCode: json["TASK_CODE"],
    groceries: json["GROCERIES"],
  );

  Map<String, dynamic> toJson() => {
    "CARER_VISIT_MST_ID": carerVisitMstId,
    "ORG_CODE": orgCode,
    "CLIENT_ID": clientId,
    "CLIENT_CODE": clientCode,
    "TASK_CODE": taskCode,
    "GROCERIES": groceries,
  };
}
