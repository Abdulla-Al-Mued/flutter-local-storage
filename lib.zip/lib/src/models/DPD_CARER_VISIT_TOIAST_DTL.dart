
import 'dart:convert';

DpdCarerVisitToiastDtl dpdCarerVisitToiastDtlFromJson(String str) => DpdCarerVisitToiastDtl.fromJson(json.decode(str));

String dpdCarerVisitToiastDtlToJson(DpdCarerVisitToiastDtl data) => json.encode(data.toJson());

class DpdCarerVisitToiastDtl {
  String? code;
  String? msg;
  List<Value>? value;

  DpdCarerVisitToiastDtl({
    this.code,
    this.msg,
    this.value,
  });

  factory DpdCarerVisitToiastDtl.fromJson(Map<String, dynamic> json) => DpdCarerVisitToiastDtl(
    code: json["CODE"],
    msg: json["MSG"],
    value: json["Value"] == null ? [] : List<Value>.from(json["Value"]!.map((x) => Value.fromJson(x))),
  );

  Map<String, dynamic> toJson() => {
    "CODE": code,
    "MSG": msg,
    "Value": value == null ? [] : List<dynamic>.from(value!.map((x) => x.toJson())),
  };
}

class Value {
  String? carerVisitMstId;
  String? orgCode;
  String? clientId;
  String? clientCode;
  String? taskCode;
  String? toiletAssistant;

  Value({
    this.carerVisitMstId,
    this.orgCode,
    this.clientId,
    this.clientCode,
    this.taskCode,
    this.toiletAssistant,
  });

  factory Value.fromJson(Map<String, dynamic> json) => Value(
    carerVisitMstId: json["CARER_VISIT_MST_ID"],
    orgCode: json["ORG_CODE"],
    clientId: json["CLIENT_ID"],
    clientCode: json["CLIENT_CODE"],
    taskCode: json["TASK_CODE"],
    toiletAssistant: json["TOILET_ASSISTANT"],
  );

  Map<String, dynamic> toJson() => {
    "CARER_VISIT_MST_ID": carerVisitMstId,
    "ORG_CODE": orgCode,
    "CLIENT_ID": clientId,
    "CLIENT_CODE": clientCode,
    "TASK_CODE": taskCode,
    "TOILET_ASSISTANT": toiletAssistant,
  };
}
