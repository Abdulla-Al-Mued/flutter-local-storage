class Response {


  String? statusCode;
  String? msg;
  String? values;
  int? data;

  Response({
    this.statusCode,
    this.msg,
    this.values,
    this.data,
  });
  Response.fromJson(Map<String, dynamic> json) {
    statusCode = json['status_code']?.toString();
    msg = json['msg']?.toString();
    values = json['values']?.toString();
    data = json['data'];
  }
  Map<String, dynamic> toJson() {
    final data = <String, dynamic>{};
    data['status_code'] = statusCode;
    data['msg'] = msg;
    data['values'] = values;
    data['data'] = this.data;
    return data;
  }
}