class DpdCmsUserLoginModel {
  String? code;
  String? msg;
  List<Value>? value;

  DpdCmsUserLoginModel({
    this.code,
    this.msg,
    this.value,
  });

  factory DpdCmsUserLoginModel.fromJson(Map<String, dynamic> json) =>
      DpdCmsUserLoginModel(
        code: json["CODE"],
        msg: json["MSG"],
        value: json["Value"] == null || json["Value"] == ""
            ? []
            : List<Value>.from(json["Value"]!.map((x) => Value.fromJson(x))),
      );

  Map<String, dynamic> toJson() => {
    "CODE": code,
    "MSG": msg,
    "Value": value == null || value!.isEmpty
        ? []
        : List<dynamic>.from(value!.map((x) => x.toJson())),
  };
}

class Value {
  String? status;
  String? userCode;
  String? firstName;
  String? lastName;
  String? orgCode;
  String? orgName;
  String? userTypeCode;
  String? userOrgCount;
  String? userId;
  String? careTypeCode;
  String? careTypeDesc;
  String? carerId;
  String? carerCode;
  String? userPassword;
  String? carerImagePath;
  String? carerPhone;
  String? userActiveStatus; // Added field

  Value({
    this.status,
    this.userCode,
    this.firstName,
    this.lastName,
    this.orgCode,
    this.orgName,
    this.userTypeCode,
    this.userOrgCount,
    this.userId,
    this.careTypeCode,
    this.careTypeDesc,
    this.carerId,
    this.carerCode,
    this.userPassword,
    this.carerImagePath,
    this.carerPhone,
    this.userActiveStatus, // Added parameter in the constructor
  });

  factory Value.fromJson(Map<String, dynamic> json) => Value(
    status: json["STATUS"],
    userCode: json["USER_CODE"],
    firstName: json["FIRST_NAME"],
    lastName: json["LAST_NAME"],
    orgCode: json["ORG_CODE"],
    orgName: json["ORG_NAME"],
    userTypeCode: json["USER_TYPE_CODE"],
    userOrgCount: json["USER_ORG_COUNT"],
    userId: json["USER_ID"],
    careTypeCode: json["CARE_TYPE_CODE"],
    careTypeDesc: json["CARE_TYPE_DESC"],
    carerId: json["CARER_ID"],
    carerCode: json["CARER_CODE"],
    userPassword: json["USER_PASSWORD"],
    carerImagePath: json["CARER_IMAGE_PATH"],
    carerPhone: json["CARER_PHONE"],
    userActiveStatus: json["USER_ACTIVE_STATUS"], // Parse USER_ACTIVE_STATUS
  );

  Map<String, dynamic> toJson() => {
    "STATUS": status,
    "USER_CODE": userCode,
    "FIRST_NAME": firstName,
    "LAST_NAME": lastName,
    "ORG_CODE": orgCode,
    "ORG_NAME": orgName,
    "USER_TYPE_CODE": userTypeCode,
    "USER_ORG_COUNT": userOrgCount,
    "USER_ID": userId,
    "CARE_TYPE_CODE": careTypeCode,
    "CARE_TYPE_DESC": careTypeDesc,
    "CARER_ID": carerId,
    "CARER_CODE": carerCode,
    "USER_PASSWORD": userPassword,
    "CARER_IMAGE_PATH": carerImagePath,
    "CARER_PHONE": carerPhone,
    "USER_ACTIVE_STATUS": userActiveStatus, // Include USER_ACTIVE_STATUS in JSON
  };
}

