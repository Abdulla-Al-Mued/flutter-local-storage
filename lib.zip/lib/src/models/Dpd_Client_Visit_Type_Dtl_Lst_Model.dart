// To parse this JSON data, do
//
//     final dpdClientVisitTypeDtlLstModel = dpdClientVisitTypeDtlLstModelFromJson(jsonString);

import 'dart:convert';

DpdClientVisitTypeDtlLstModel dpdClientVisitTypeDtlLstModelFromJson(
        String str) =>
    DpdClientVisitTypeDtlLstModel.fromJson(json.decode(str));

String dpdClientVisitTypeDtlLstModelToJson(
        DpdClientVisitTypeDtlLstModel data) =>
    json.encode(data.toJson());

class DpdClientVisitTypeDtlLstModel {
  String? code;
  String? msg;
  List<Value>? value;

  DpdClientVisitTypeDtlLstModel({
    this.code,
    this.msg,
    this.value,
  });

  factory DpdClientVisitTypeDtlLstModel.fromJson(Map<String, dynamic> json) =>
      DpdClientVisitTypeDtlLstModel(
        code: json["CODE"],
        msg: json["MSG"],
        value: json["Value"] == null
            ? []
            : List<Value>.from(json["Value"]!.map((x) => Value.fromJson(x))),
      );

  Map<String, dynamic> toJson() => {
        "CODE": code,
        "MSG": msg,
        "Value": value == null
            ? []
            : List<dynamic>.from(value!.map((x) => x.toJson())),
      };
}

class Value {
  String? clientVisitTypeMstId;
  String? clientVisitTypeDtlId;
  String? clientId;
  String? clientCode;
  String? orgCode;
  String? taskCode;
  String? taskDesc;
  String? iconImagePath;

  Value({
    this.clientVisitTypeMstId,
    this.clientVisitTypeDtlId,
    this.clientId,
    this.clientCode,
    this.orgCode,
    this.taskCode,
    this.taskDesc,
    this.iconImagePath,
  });

  factory Value.fromJson(Map<String, dynamic> json) => Value(
        clientVisitTypeMstId: json["CLIENT_VISIT_TYPE_MST_ID"],
        clientVisitTypeDtlId: json["CLIENT_VISIT_TYPE_DTL_ID"],
        clientId: json["CLIENT_ID"],
        clientCode: json["CLIENT_CODE"],
        orgCode: json["ORG_CODE"],
        taskCode: json["TASK_CODE"],
        taskDesc: json["TASK_DESC"],
        iconImagePath: json["ICON_IMAGE_PATH"],
      );

  Map<String, dynamic> toJson() => {
        "CLIENT_VISIT_TYPE_MST_ID": clientVisitTypeMstId,
        "CLIENT_VISIT_TYPE_DTL_ID": clientVisitTypeDtlId,
        "CLIENT_ID": clientId,
        "CLIENT_CODE": clientCode,
        "ORG_CODE": orgCode,
        "TASK_CODE": taskCode,
        "TASK_DESC": taskDesc,
        "ICON_IMAGE_PATH": iconImagePath,
      };
}
