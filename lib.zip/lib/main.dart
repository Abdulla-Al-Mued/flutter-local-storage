import 'dart:io';

import 'package:care4u/src/controls/utils/app_theme.dart';
import 'package:care4u/src/views/bodymaps/Controller/body_map_controller.dart';
import 'package:care4u/src/views/homePage/providers/home_page_provider.dart';
import 'package:care4u/src/views/report/controller/check_out_button_controller.dart';
import 'package:care4u/src/views/report/controller/expended_controller.dart';
import 'package:care4u/src/views/report/controller/report_visit_controller.dart';
import 'package:care4u/src/views/report/controller/task_controller.dart';
import 'package:care4u/src/views/report/tasks_screen/medication/medication_controller.dart';
import 'package:care4u/src/views/reportPage/report_provider.dart';
import 'package:care4u/src/views/schedulelist/ClientProvider/ClientProvider.dart';
import 'package:care4u/src/views/signinPage/providers/password_visibility.dart';
import 'package:care4u/src/views/signinPage/providers/sign_page_provider.dart';
import 'package:care4u/src/views/startPage/start_page_view.dart';
import 'package:flutter/material.dart';
import 'package:get_storage/get_storage.dart';
import 'package:provider/provider.dart';
import 'package:webview_flutter/webview_flutter.dart';

import 'src/controls/utils/global_internet_check.dart';
import 'src/views/report/controller/emoji_controller.dart';


void main() async {
  /*-----------------> Start flutter engine <----------------------*/
  WidgetsFlutterBinding.ensureInitialized();
  await GetStorage.init('dStorage');
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MultiProvider(
      providers: [
        ChangeNotifierProvider(create: (_) => InternetConnectionCheck()),
        ChangeNotifierProvider(create: (_) => SignInPageProvider()),
        ChangeNotifierProvider(create: (_) => HomePageProvider()),
        ChangeNotifierProvider(create: (_) => ClientProvider()),
        ChangeNotifierProvider(create: (_) => VisitTypeController()),
        ChangeNotifierProvider(create: (_) => TaskController()),
        ChangeNotifierProvider(create: (_) => EmojiState()),
        ChangeNotifierProvider(create: (_) => ExpandableRowModel()),
        ChangeNotifierProvider(create: (_) => BodyMapController()),
        ChangeNotifierProvider(create: (_) => MedicationController()),
        ChangeNotifierProvider(create: (_) => ReportController()),
        ChangeNotifierProvider(create: (_) => PasswordVisibilityProvider()),
        ChangeNotifierProvider(create: (_) => CheckOutButtonController()),
      ],
      child: MaterialApp(
        debugShowCheckedModeBanner: false,
        themeMode: ThemeMode.light,
        theme: themeData,
        // home: const SignInPage(),
        home: const StartPageView(),
      ),
    );
  }
}
