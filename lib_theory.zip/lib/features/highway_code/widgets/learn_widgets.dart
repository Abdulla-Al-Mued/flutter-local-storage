import 'package:flutter/material.dart';
import 'package:theory_test_ltd/common/base_widgets/screen_config.dart';

class LearnMenuItem extends StatelessWidget {
  final String text;
  final Color color;
  final ScreenConfig screenConfig;
  final VoidCallback onTap;

  const LearnMenuItem({
    super.key,
    required this.text,
    required this.color,
    required this.screenConfig,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.symmetric(vertical: 5.0),
      padding: const EdgeInsets.all(8),
      decoration: BoxDecoration(
        color: color.withValues(alpha: 0.1),
        borderRadius: BorderRadius.circular(5),
        border: Border.all(color: color),
      ),
      child: ListTile(
        title: Text(
          text,
          style: TextStyle(
            color: color,
            fontSize: screenConfig.menuFontSize,
            fontWeight: FontWeight.w700,
          ),
        ),
        onTap: onTap,
      ),
    );
  }
}
