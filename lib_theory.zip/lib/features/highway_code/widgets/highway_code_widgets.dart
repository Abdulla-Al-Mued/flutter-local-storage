import 'package:flutter/material.dart';
import 'package:theory_test_ltd/common/base_widgets/screen_config.dart';
import 'package:theory_test_ltd/utils/color_resources.dart';

class HighwayCodeMenuItem extends StatelessWidget {
  final IconData icon;
  final String text;
  final Color color;
  final Color iconBg;
  final ScreenConfig screenConfig;
  final VoidCallback onTap;

  const HighwayCodeMenuItem({
    super.key,
    required this.icon,
    required this.text,
    required this.color,
    required this.iconBg,
    required this.screenConfig,
    required this.onTap,

  });

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.symmetric(vertical: 8.0),
      padding: EdgeInsets.only(top: 8, bottom: 8),
      decoration: BoxDecoration(
        color: color.withValues(alpha: 0.1),
        borderRadius: BorderRadius.circular(5),
        border: Border.all(color: color),
      ),
      child: ListTile(
        leading: Container(
          padding: const EdgeInsets.all(10),
          decoration: BoxDecoration(
            color: iconBg,
            borderRadius: BorderRadius.circular(5),
          ),
          child: Icon(
            icon,
            color: AppColors.white,
            size: screenConfig.menuIconSize,
          ),
        ),
        title: Text(
          text,
          style: TextStyle(
            color: color,
            fontSize: screenConfig.menuFontSize,
            fontWeight: FontWeight.w400,
          ),
        ),
        onTap: onTap,
      ),
    );
  }
}
