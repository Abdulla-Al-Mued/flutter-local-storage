import 'package:flutter/material.dart';
import 'package:hive/hive.dart';
import 'package:theory_test_ltd/common/base_widgets/loading_animation.dart';
import 'package:theory_test_ltd/utils/color_resources.dart';
import 'package:webview_flutter/webview_flutter.dart';

class LearnWebViewScreen extends StatefulWidget {
  final String htmlAssetPath;
  final String title;

  const LearnWebViewScreen({super.key, required this.htmlAssetPath, required this.title});

  @override
  State<LearnWebViewScreen> createState() => _LearnWebViewScreenState();
}

class _LearnWebViewScreenState extends State<LearnWebViewScreen> {
  var isLoading = ValueNotifier<bool>(true);
  late WebViewController controller;
  late Box favoritesBox;
  bool isFavorite = false;

  @override
  void initState() {
    super.initState();
     controller = WebViewController()
       ..setJavaScriptMode(JavaScriptMode.unrestricted)
      ..loadFlutterAsset(widget.htmlAssetPath);
    controller.setNavigationDelegate(
      NavigationDelegate(onPageFinished: (String url) async {
        isLoading.value = false;
      }),
    );

    // Open Hive box for favorites
    favoritesBox = Hive.box('favorites');
    isFavorite = favoritesBox.containsKey(widget.htmlAssetPath);
  }

  void toggleFavorite() {
    setState(() {
      isFavorite = !isFavorite;
    });

    if (isFavorite) {
      favoritesBox.put(widget.htmlAssetPath, widget.title);
    } else {
      favoritesBox.delete(widget.htmlAssetPath);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(widget.title, style: TextStyle(
          color: Colors.white,
          fontSize: 20,
          fontWeight: FontWeight.bold,
        ),),
        iconTheme: const IconThemeData(
          color: Colors.white, // This sets the back button color to white
        ),

        actions: [
          IconButton(
            icon: Icon(
              isFavorite ? Icons.bookmark : Icons.bookmark_border,
              color: isFavorite ? AppColors.gold : Colors.white,
            ),
            onPressed: toggleFavorite,
          ),
        ],
        backgroundColor: AppColors.iceGreenLight,
      ),
      body: ValueListenableBuilder<bool>(
        valueListenable: isLoading,
        builder: (context, value, _) {
          return Stack(
            children: <Widget>[
              WebViewWidget(controller: controller),
              if (value)
                const Center(
                  child:  LoadingAnimation(),
                ),
            ],
          );
        },
      ),
    );
  }
}
