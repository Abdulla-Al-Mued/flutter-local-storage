import 'package:flutter/material.dart';
import 'package:theory_test_ltd/common/base_widgets/custom_app_bar.dart';
import 'package:theory_test_ltd/common/base_widgets/navigate_pages.dart';
import 'package:theory_test_ltd/data/local/static/highway_code_data.dart';
import 'package:theory_test_ltd/features/highway_code/screens/learn_webview_screen.dart';
import 'package:theory_test_ltd/features/highway_code/widgets/learn_widgets.dart';
import 'package:theory_test_ltd/utils/color_resources.dart';
import 'package:theory_test_ltd/common/base_widgets/screen_config.dart';

class LearnScreen extends StatefulWidget {
  const LearnScreen({super.key});

  @override
  State<LearnScreen> createState() => _LearnScreenState();
}

class _LearnScreenState extends State<LearnScreen> {
  List highwayCodeDataFiltered = highwayCodeData;
  TextEditingController searchController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: const CustomAppBar(
        title: 'Highway Code',
        gradientColors: [
          AppColors.iceGreen,
          AppColors.iceGreenLight,
        ],
      ),
      body: LayoutBuilder(
        builder: (context, constraints) {
          final screenConfig = getScreenConfig(constraints, context);
          return Padding(
            padding: const EdgeInsets.all(10.0),
            child: Column(
              children: [
                // Search Field at the top
                TextField(
                  controller: searchController,
                  onChanged: (value) {
                    setState(() {
                      highwayCodeDataFiltered = highwayCodeData
                          .where((item) => item.title
                              .toLowerCase()
                              .contains(value.toLowerCase()))
                          .toList();
                    });
                  },
                  decoration: InputDecoration(
                    hintText: 'Search...',
                    prefixIcon: const Icon(Icons.search),
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(10),
                    ),
                  ),
                ),
                const SizedBox(height: 10),
                // Expanded to hold the list
                Expanded(
                  child: ListView.builder(
                    itemCount: highwayCodeDataFiltered.length,
                    itemBuilder: (context, index) {
                      final item = highwayCodeDataFiltered[index];
                      return LearnMenuItem(
                        text: item.title,
                        color: AppColors.iceGreenLight,
                        screenConfig: screenConfig,
                        onTap: () {
                          navigateTo(
                            () => LearnWebViewScreen(
                              htmlAssetPath: item.assets,
                              title: item.title,
                            ),
                          );
                        },
                      );
                    },
                  ),
                ),
              ],
            ),
          );
        },
      ),
    );
  }

  @override
  void dispose() {
    searchController.dispose();
    super.dispose();
  }
}
