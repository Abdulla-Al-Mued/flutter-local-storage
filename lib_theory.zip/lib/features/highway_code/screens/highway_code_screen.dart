import 'package:flutter/material.dart';
import 'package:theory_test_ltd/common/base_widgets/custom_app_bar.dart';
import 'package:theory_test_ltd/common/base_widgets/navigate_pages.dart';
import 'package:theory_test_ltd/common/base_widgets/screen_config.dart';
import 'package:theory_test_ltd/features/highway_code/screens/bookmark_screen.dart';
import 'package:theory_test_ltd/features/highway_code/screens/get_stared_screen.dart';
import 'package:theory_test_ltd/features/highway_code/screens/learn_screen.dart';
import 'package:theory_test_ltd/features/highway_code/widgets/highway_code_widgets.dart';
import 'package:theory_test_ltd/utils/color_resources.dart';

class HighwayCodeScreen extends StatelessWidget {
  const HighwayCodeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.backgroundLight,
      appBar: CustomAppBar(
        title: 'Highway Code',
        gradientColors: [
          AppColors.iceGreen,
          AppColors.iceGreenLight,
        ],
      ),
      body: LayoutBuilder(
        builder: (context, constraints) {
          final screenConfig = getScreenConfig(constraints, context);

          return Padding(
            padding: const EdgeInsets.all(10.0),
            child: SingleChildScrollView(
              child: Column(
                children: [
                  HighwayCodeMenuItem(
                    iconBg: AppColors.primary,
                    icon: Icons.rocket_launch,
                    text: 'Get Started',
                    color: AppColors.iceGreenLightMenu,
                    screenConfig: screenConfig,
                    onTap: () {
                      navigateTo(() => GetStartedScreenHighwayCode());
                    },
                  ),
                  HighwayCodeMenuItem(
                    iconBg: AppColors.blue,
                    icon: Icons.menu_book_sharp,
                    text: 'Learn',
                    color: AppColors.iceGreenLightMenu,
                    screenConfig: screenConfig,
                    onTap: () {
                      navigateTo(() => LearnScreen());
                    },
                  ),

                  HighwayCodeMenuItem(
                    iconBg: AppColors.secondary,
                    icon: Icons.bookmark_border,
                    text: 'Bookmarks',
                    color: AppColors.iceGreenLightMenu,
                    screenConfig: screenConfig,
                    onTap: () {
                      navigateTo(() => BookmarkScreen());
                    },
                  ),
                  // HighwayCodeMenuItem(
                  //   iconBg: AppColors.steelBlue,
                  //   icon: Icons.question_mark,
                  //   text: 'Quiz',
                  //   color: AppColors.iceGreenLightMenu,
                  //   screenConfig: screenConfig,
                  //   onTap: () {},
                  // ),
                  // HighwayCodeMenuItem(
                  //   iconBg: AppColors.secondary,
                  //   icon: Icons.bar_chart,
                  //   text: 'Progress Monitor',
                  //   color: AppColors.iceGreenLightMenu,
                  //   screenConfig: screenConfig,
                  //   onTap: () {
                  //      navigateTo(() => ProgressMonitorScreen());
                  //   },
                  // ),
                ],
              ),
            ),
          );
        },
      ),
    );
  }
}
