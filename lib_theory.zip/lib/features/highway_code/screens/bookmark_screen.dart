import 'package:flutter/material.dart';
import 'package:theory_test_ltd/common/base_widgets/custom_app_bar.dart';
import 'package:theory_test_ltd/common/base_widgets/navigate_pages.dart';
import 'package:theory_test_ltd/common/base_widgets/screen_config.dart';
import 'package:theory_test_ltd/features/highway_code/screens/learn_webview_screen.dart';
import 'package:theory_test_ltd/features/highway_code/widgets/bookmark_code_widgets.dart';
import 'package:theory_test_ltd/utils/color_resources.dart';
import 'package:hive_flutter/hive_flutter.dart';

class BookmarkScreen extends StatefulWidget {
  const BookmarkScreen({super.key});

  @override
  State<BookmarkScreen> createState() => _BookmarkScreenState();
}

class _BookmarkScreenState extends State<BookmarkScreen> {
  late Box<dynamic> favoritesBox;

  @override
  void initState() {
    super.initState();
    favoritesBox =
        Hive.box('favorites');  
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: const CustomAppBar(
        title: 'Bookmarks',
        gradientColors: [
          AppColors.iceGreen,
          AppColors.iceGreenLight,
        ],
      ),
      body: LayoutBuilder(
        builder: (context, constraints) {
          final screenConfig = getScreenConfig(constraints, context);

          return Padding(
            padding: const EdgeInsets.all(10.0),
            child: ValueListenableBuilder(
              valueListenable: favoritesBox.listenable(),
              builder: (context, Box<dynamic> box, _) {
                final List<dynamic> bookmarks = box.values.toList();
                if (bookmarks.isEmpty) {
                  return const Center(
                    child: Text(
                      'No bookmarks available',
                      style: TextStyle(fontSize: 18, color: Colors.grey),
                    ),
                  );
                }
                return ListView.builder(
                  itemCount: bookmarks.length,
                  itemBuilder: (context, index) {
                    final htmlAssetPath = favoritesBox.keyAt(index);
                    final title = favoritesBox.get(htmlAssetPath);

                    return BookmarkMenuItem(
                      text: title,
                      color: AppColors.iceGreenLight,
                      screenConfig: screenConfig,
                      onTap: () {
                        navigateTo(
                          () => LearnWebViewScreen(
                            htmlAssetPath: htmlAssetPath,
                            title: title,
                          ),
                        );
                      },
                    );
                  },
                );
              },
            ),
          );
        },
      ),
    );
  }
}
