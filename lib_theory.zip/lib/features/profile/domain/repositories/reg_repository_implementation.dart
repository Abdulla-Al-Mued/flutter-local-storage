import 'package:theory_test_ltd/features/profile/domain/models/registration_model.dart';
import 'package:theory_test_ltd/features/profile/domain/repositories/registration_repository.dart';
import 'package:theory_test_ltd/features/profile/domain/services/registration_services.dart';

class RegistrationRepositoryImpl implements RegistrationRepository {

  @override
  Future<bool> registerUser(RegistrationModel registrationData) async {
    return await RegistrationService.registerUser(registrationData);
  }

  @override
  Future<bool> updateUser(RegistrationModel registrationData) {
    return RegistrationService.updateUser(registrationData);
  }



}