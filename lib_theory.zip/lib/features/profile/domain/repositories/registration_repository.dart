
import 'package:theory_test_ltd/features/profile/domain/models/registration_model.dart';

abstract class RegistrationRepository {
  Future<bool> registerUser(RegistrationModel registrationData);
  Future<bool> updateUser(RegistrationModel registrationData);
}


