import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart'; // Add this import
import 'package:theory_test_ltd/features/profile/domain/models/registration_model.dart';
import 'package:theory_test_ltd/utils/api_constant.dart';

class RegistrationService {
  static Future<bool> registerUser(RegistrationModel registrationData) async {
    final response = await http.post(
      Uri.parse('$baseUrl$registrationEndPoint'),
      body: jsonEncode(registrationData.toJson()),
      headers: {'Content-Type': 'application/json'}, // Ensure correct headers
    );

    if (response.statusCode == 200) {
      final responseBody = jsonDecode(response.body);

      if (responseBody["CODE"] == "200") {
        final dataList = responseBody["DATA"] as List;
        if (dataList.isNotEmpty) {
          final custId = dataList[0]["CUST_ID"];

          // Save CUST_ID to SharedPreferences
          SharedPreferences prefs = await SharedPreferences.getInstance();
          await prefs.setString('CUST_ID', custId);

          print('Saved CUST_ID: $custId');
        }
        return true;
      } else {
        throw Exception('Registration failed: ${responseBody["MSG"]}');
      }
    } else {
      throw Exception('Failed to register user');
    }
  }


  static Future<bool> updateUser(RegistrationModel registrationData) async {
    final response = await http.post(
      Uri.parse('$baseUrl$updateEndPoint'),
      headers: {'Content-Type': 'application/json'},
      body: jsonEncode(registrationData.toJson()),
    );

    if (response.statusCode == 200) {
      final responseData = jsonDecode(response.body);

      print(registrationData.name);
      print(registrationData.id);

      if (responseData['CODE'] == '200') {
        print('✅ Update Success');
        return true;
      } else {
        print('⚠️ Update Failed: ${responseData['MSG']}');
        return false;
      }
    } else {
      print('❌ Server Error: ${response.statusCode}');
      throw Exception('Failed to update user');
    }
  }

}
