class RegistrationModel {
  final String? id;
  final String name;
  final String email;
  final String dialCode;
  final String? number;
  final String? soundEnable;
  final String? payModeCode;
  final String userIp;
  final String user;
  final String dateOfExam;

  RegistrationModel({
     this.id,
    required this.name,

    required this.email,
    required this.dialCode,
    required this.number,
     this.soundEnable,
     this.payModeCode,
    required this.userIp,
    required this.user,
    required this.dateOfExam,
  });

  Map<String, dynamic> toJson() {
    return {
      'P_CUST_ID': id,
      'P_CUST_NAME': name,
      'P_EMAIL': email,
      'P_DIAL_CODE': dialCode,
      'P_PHONE': number ?? '',
      'P_SOUND_ENABLE': soundEnable,
      'P_PAY_MODE_CODE': payModeCode,
      'P_USER_IP': userIp,
      'P_USER': user,
      'P_THEORY_EXAM_DATE': dateOfExam,
    };
  }

  factory RegistrationModel.fromJson(Map<String, dynamic> json) {
    return RegistrationModel(
      id: json['P_CUST_ID'],
      name: json['P_CUST_NAME'],
      email: json['P_EMAIL'],
      dialCode: json['P_DIAL_CODE'],
      number: json['P_PHONE'],
      soundEnable: json['P_SOUND_ENABLE'],
      payModeCode: json['P_PAY_MODE_CODE'],
      userIp: json['P_USER_IP'],
      user: json['P_USER'],
      dateOfExam: json['P_THEORY_EXAM_DATE'],
    );
  }
}
