// Profile Provider for State Management
import 'dart:io';

import 'package:flutter/cupertino.dart';

class ProfileProvider extends ChangeNotifier {
  File? _profileImage;
  DateTime? _selectedExamDate;

  File? get profileImage => _profileImage;

  DateTime? get selectedExamDate => _selectedExamDate;

  void setProfileImage(File? image) {
    _profileImage = image;
    notifyListeners();
  }

  void setSelectedExamDate(DateTime? date) {
    _selectedExamDate = date;
    notifyListeners();
  }
}