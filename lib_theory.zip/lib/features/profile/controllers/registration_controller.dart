import 'package:flutter/material.dart';
import 'package:theory_test_ltd/features/profile/domain/models/registration_model.dart';
import 'package:theory_test_ltd/features/profile/domain/repositories/registration_repository.dart';

class RegistrationController with ChangeNotifier {
  final RegistrationRepository repository;

  bool _isLoading = false;
  String? _errorMessage;

  bool get isLoading => _isLoading;
  String? get errorMessage => _errorMessage;

  RegistrationController({required this.repository});

  Future<void> registerUser(RegistrationModel registrationData) async {
    _isLoading = true;
    _errorMessage = null;
    notifyListeners();

    try {
      await repository.registerUser(registrationData);
    } catch (error) {
      _errorMessage = error.toString();
    } finally {
      _isLoading = false;
      notifyListeners();
    }
  }


  Future<void>updateUser(RegistrationModel registrationData) async {
    _isLoading = true;
    _errorMessage = null;
    notifyListeners();
    try {
      await repository.updateUser(registrationData);
    } catch (error) {
      _errorMessage = error.toString();
    } finally {
      _isLoading = false;
      notifyListeners();
    }
  }
}
