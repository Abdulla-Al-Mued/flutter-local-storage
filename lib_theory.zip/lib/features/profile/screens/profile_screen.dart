import 'package:flutter/material.dart';
import 'package:theory_test_ltd/common/base_widgets/gradient_appbar.dart';
import 'package:theory_test_ltd/features/profile/widgets/profile_widgets.dart';
import 'package:theory_test_ltd/utils/dimensions.dart';

class ProfileScreen extends StatefulWidget {
  const ProfileScreen({super.key});

  @override
  State<ProfileScreen> createState() => _ProfileScreenState();
}

class _ProfileScreenState extends State<ProfileScreen> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: const GradientAppBar(title: 'Profile'),
      body: LayoutBuilder(
        builder: (context, constraints) {
          return Column(
            children: [

              Expanded(
                child: Padding(
                  padding: const EdgeInsets.symmetric(horizontal: Dimensions.paddingSizeDefault),
                  child: ProfileDetailsForm(),
                ),
              ),
            ],
          );
        },
      ),
    );
  }
}
