import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:get_it/get_it.dart';
import 'package:intl/intl.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:theory_test_ltd/common/base_widgets/gradient_appbar.dart';
import 'package:theory_test_ltd/common/base_widgets/loading_animation.dart';
import 'package:theory_test_ltd/features/categories/screens/categories_screen.dart';
import 'package:theory_test_ltd/features/profile/controllers/registration_controller.dart';
import 'package:theory_test_ltd/features/profile/domain/models/registration_model.dart';
import 'package:theory_test_ltd/features/profile/widgets/registration_widgets.dart';
import 'package:theory_test_ltd/utils/color_resources.dart';
import 'package:theory_test_ltd/utils/tools.dart';

class RegistrationScreen extends StatefulWidget {
  const RegistrationScreen({super.key});

  @override
  State<RegistrationScreen> createState() => _RegistrationScreenState();
}

class _RegistrationScreenState extends State<RegistrationScreen> {
  final TextEditingController nameController = TextEditingController();
  final TextEditingController emailController = TextEditingController();
  final TextEditingController numberController = TextEditingController();
  DateTime? selectedDate;
  String? _emailError;

  void _setOnboardCompleted() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    await prefs.setBool('onboardCompleted', false);
  }

  Future<void> _saveRegistrationData(RegistrationModel data) async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    String jsonData = json.encode(data.toJson());
    await prefs.setString('registrationData', jsonData);
  }

  Future<void> _selectDate(BuildContext context) async {
    final DateTime? picked = await showDatePicker(
      context: context,
      initialDate: DateTime.now(),
      firstDate: DateTime.now(),
      lastDate: DateTime(3000),
    );
    if (picked != null && picked != selectedDate) {
      setState(() {
        selectedDate = picked;
      });
    }
  }

  String formatDate(DateTime date) {
    final DateFormat formatter = DateFormat('dd/MM/yyyy');
    return formatter.format(date);
  }

  @override
  Widget build(BuildContext context) {
    final controller = GetIt.instance<RegistrationController>();

    return Scaffold(
      appBar: const GradientAppBar(title: 'Registration'),
      body: AnimatedBuilder(
        animation: controller,
        builder: (context, _) {
          return Stack(
            children: [
              Padding(
                padding: const EdgeInsets.all(16.0),
                child: SingleChildScrollView(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const SizedBox(height: 20),
                      CustomTextField(
                        controller: nameController,
                        labelText: 'Name *',
                        icon: Icons.person,
                        errorText: nameController.text.isEmpty
                            ? 'Name is required'
                            : null,
                      ),
                      const SizedBox(height: 16),
                      CustomTextField(
                        controller: emailController,
                        labelText: 'Email *',
                        icon: Icons.email,
                        keyboardType: TextInputType.emailAddress,
                        errorText: _emailError,
                      ),
                      const SizedBox(height: 16),
                      CustomTextField(
                        controller: numberController,
                        labelText: 'Number',
                        icon: Icons.phone,
                        keyboardType: TextInputType.number,
                      ),
                      const SizedBox(height: 16),
                      GestureDetector(
                        onTap: () => _selectDate(context),
                        child: AbsorbPointer(
                          child: TextFormField(
                            decoration: InputDecoration(
                              labelText: selectedDate == null
                                  ? 'Theory Exam date'
                                  : formatDate(selectedDate!),
                              prefixIcon: const Icon(
                                Icons.calendar_today,
                                color: AppColors.primary,
                              ),
                              border: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(12),
                              ),
                            ),
                          ),
                        ),
                      ),
                      const SizedBox(height: 30),
                      Center(
                        child: ElevatedButton(
                          onPressed: () async {
                            final email = emailController.text.trim();
                            final emailRegex =
                                RegExp(r'^[\w-\.]+@([\w-]+\.)+[\w-]{2,4}$');

                            _emailError = null; // Reset error first

                            // Validation
                            if (nameController.text.isEmpty) {
                              ScaffoldMessenger.of(context).showSnackBar(
                                const SnackBar(
                                    content: Text('Name is required')),
                              );
                              return;
                            }

                            if (email.isEmpty) {
                              setState(() {
                                _emailError = 'Email is required';
                              });
                              return;
                            } else if (!emailRegex.hasMatch(email)) {
                              setState(() {
                                _emailError = 'Please enter a valid email';
                              });
                              return;
                            }

                            // No error, continue
                            _setOnboardCompleted();

                            final registrationData = RegistrationModel(
                              name: nameController.text,
                              email: email,
                              dialCode: '+44',
                              number: numberController.text,
                              soundEnable: 'Y',
                              payModeCode: '01',
                              userIp: await getIp(),
                              user: email,
                              dateOfExam: selectedDate != null
                                  ? formatDate(selectedDate!)
                                  : '',
                            );

                            await controller.registerUser(registrationData);

                            if (controller.errorMessage != null) {
                              ScaffoldMessenger.of(context).showSnackBar(
                                const SnackBar(
                                    content: Text("Something went wrong")),
                              );
                            } else {
                              await _saveRegistrationData(registrationData);
                              Navigator.pushAndRemoveUntil(
                                context,
                                MaterialPageRoute(
                                    builder: (context) =>
                                        const CategoriesScreen()),
                                (Route<dynamic> route) => false,
                              );
                              ScaffoldMessenger.of(context).showSnackBar(
                                const SnackBar(
                                    content: Text('Registration successful')),
                              );
                            }
                          },
                          style: ElevatedButton.styleFrom(
                            backgroundColor: AppColors.primary,
                            padding: const EdgeInsets.symmetric(
                                horizontal: 50, vertical: 15),
                            textStyle: const TextStyle(fontSize: 18),
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(10),
                            ),
                          ),
                          child: Text(
                            'Register',
                            style: TextStyle(color: AppColors.white),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              if (controller.isLoading)
                Container(
                  color: Colors.black45,
                  child: const Center(
                    child: LoadingAnimation(),
                  ),
                ),
            ],
          );
        },
      ),
    );
  }
}
