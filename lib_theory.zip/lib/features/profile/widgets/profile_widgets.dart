import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'package:connectivity_plus/connectivity_plus.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:intl/intl.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:provider/provider.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:theory_test_ltd/common/base_widgets/common_button_widget.dart';
import 'package:theory_test_ltd/common/base_widgets/input_text_widget.dart';
import 'package:theory_test_ltd/common/base_widgets/loading_animation.dart';
import 'package:theory_test_ltd/common/base_widgets/navigate_pages.dart';
import 'package:theory_test_ltd/features/categories/screens/categories_screen.dart';
import 'package:theory_test_ltd/features/profile/controllers/profile_controller.dart';
import 'package:theory_test_ltd/features/profile/controllers/registration_controller.dart';
import 'package:theory_test_ltd/getit_dl.dart';
import 'package:theory_test_ltd/utils/color_resources.dart';
import 'package:theory_test_ltd/features/profile/domain/models/registration_model.dart';
import 'package:theory_test_ltd/utils/tools.dart';

class ProfileDetailsForm extends StatefulWidget {
  const ProfileDetailsForm({super.key});

  @override
  ProfileDetailsFormState createState() => ProfileDetailsFormState();
}

class ProfileDetailsFormState extends State<ProfileDetailsForm> {
  final TextEditingController _nameController = TextEditingController();
  final TextEditingController _emailController = TextEditingController();
  final TextEditingController _phoneController = TextEditingController();
  final TextEditingController _examDateController = TextEditingController();

  String? _nameError;
  String? _emailError;
  String? _phoneError;
  String? _examDateError;

  String? category;
  String? custId;
  bool _isLoading = false;

  final ImagePicker _picker = ImagePicker();
  final String _imageKey = 'profile_image';
  late Uint8List? imageB = Uint8List(1);
  final controller = getIt<RegistrationController>();
  bool hasInternet = true;
  StreamSubscription<List<ConnectivityResult>>? _connectivitySubscription;

  @override
  void initState() {
    super.initState();
    _initConnectivity();

    // Listen for ongoing connectivity changes
    _connectivitySubscription = Connectivity().onConnectivityChanged.listen((result) {
      updateInternetStatus(result);
    });
    loadCategory();
    _loadProfileData();
    _loadImage();
  }

  Future<void> _initConnectivity() async {
    final result = await Connectivity().checkConnectivity();
    updateInternetStatus(result);
  }



// Update your updateInternetStatus method
  void updateInternetStatus(List<ConnectivityResult> results) {
    final newStatus = !results.contains(ConnectivityResult.none);

    // Only update if the status has changed
    if (newStatus != hasInternet) {
      if (mounted) {
        setState(() {
          hasInternet = newStatus;
        });
      }
    }
  }
  loadCategory() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    setState(() {
      category = prefs.getString('selectedCategory') ?? "";
      custId = prefs.getString('CUST_ID');
    });

  }

  Future<void> _loadProfileData() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    String? registrationData = prefs.getString('registrationData');
    String? profileImagePath = prefs.getString('profileImagePath');

    if (registrationData != null) {
      Map<String, dynamic> jsonData = json.decode(registrationData);
      RegistrationModel registrationModel =
          RegistrationModel.fromJson(jsonData);

      _nameController.text = registrationModel.name;
      _emailController.text = registrationModel.email;
      _phoneController.text = registrationModel.number ?? '';
      _examDateController.text = registrationModel.dateOfExam;

      // Load profile image if exists
      if (profileImagePath != null) {
        context.read<ProfileProvider>().setProfileImage(File(profileImagePath));
      }

      // Load exam date
      if (registrationModel.dateOfExam.isNotEmpty) {
        DateTime parsedDate =
            DateFormat('dd/MM/yyyy').parse(registrationModel.dateOfExam);
        context.read<ProfileProvider>().setSelectedExamDate(parsedDate);
      }
    }
  }

  Future<void> _loadImage() async {
    try {
      SharedPreferences prefs = await SharedPreferences.getInstance();
      String? base64Image = prefs.getString(_imageKey);
      if (base64Image != null) {
        final bytes = base64Decode(base64Image);
        imageB = bytes;
        setState(() {});
        // final tempFile = File('${(await getTemporaryDirectory()).path}/temp_image.png');
        // tempFile.writeAsBytesSync(bytes);
        // setState(() {
        //   _image = tempFile;
        // });
      }
    } catch (e) {
      if (kDebugMode) {
        print("OP$e");
      }
    }
  }

  // Pick image from gallery and save as base64 in SharedPreferences
  Future<void> _pickImage() async {
    getStoragePermission();
    final pickedFile = await _picker.pickImage(source: ImageSource.gallery);
    if (pickedFile != null) {
      final bytes = await pickedFile.readAsBytes();
      setState(() {
        imageB = bytes;
      });
    }
  }

  // Save the image as a base64 string in SharedPreferences
  Future<void> _saveImageToLocal(Uint8List bytes) async {
    final base64Image = base64Encode(bytes);

    SharedPreferences prefs = await SharedPreferences.getInstance();
    await prefs.setString(_imageKey, base64Image);
  }

  getStoragePermission() async {
    final permission = await Permission.storage.status;
    if (permission.isDenied) {
      await Permission.storage.request();
    }
  }

  Future<void> _saveProfileData() async {

    final email = _emailController.text.trim();
    final emailRegex =
    RegExp(r'^[\w-\.]+@([\w-]+\.)+[\w-]{2,4}$');

    setState(() {
      _nameError = _nameController.text.isEmpty ? 'Name is required' : null;

      if (email.isEmpty) {
        _emailError = 'Email is required';
        return;
      } else if (!emailRegex.hasMatch(email)) {
        _emailError = 'Please enter a valid email';
        return;
      }

    });

    // Continue only if no error
    if (_emailError != null) {
      return;
    }


    // Check if there are any errors
    if (_nameError == null &&
        _emailError == null) {



      // Set loading to true before operations
      setState(() {
        _isLoading = true;
      });

      try {
        SharedPreferences prefs = await SharedPreferences.getInstance();

        RegistrationModel updatedData = RegistrationModel(
          id: custId,
          name: _nameController.text,
          email: _emailController.text,
          dialCode: '+44',
          number: _phoneController.text,
          userIp: await getIp(),
          user: _emailController.text,
          dateOfExam: _examDateController.text,
        );
        await controller.updateUser(updatedData);

        await _saveImageToLocal(imageB!);
        String jsonData = json.encode(updatedData.toJson());
        await prefs.setString('registrationData', jsonData);

        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Padding(
              padding: const EdgeInsets.all(8.0),
              child: Text(
                'Profile updated successfully',
                style: TextStyle(color: AppColors.black),
              ),
            ),
            padding: const EdgeInsets.all(8),
            duration: const Duration(seconds: 3),
            backgroundColor: AppColors.primary200,
            behavior: SnackBarBehavior.floating,
          ),
        );
      } catch (e) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Padding(
              padding: const EdgeInsets.all(8.0),
              child: Text(
                'Error updating profile: ${e.toString()}',
                style: TextStyle(color: AppColors.black),
              ),
            ),
            backgroundColor: Colors.red[200],
            behavior: SnackBarBehavior.floating,
          ),
        );
      } finally {
        // Set loading to false after operations
        if (mounted) {
          setState(() {
            _isLoading = false;
          });
        }
      }
    }
  }

  @override
  void dispose() {
    _nameController.dispose();
    _emailController.dispose();
    _phoneController.dispose();
    _examDateController.dispose();
    _connectivitySubscription?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return ChangeNotifierProvider(
      create: (context) => ProfileProvider(),
      child: Scaffold(
        body: _isLoading ? LoadingAnimation(): SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const SizedBox(height: 20),
              Center(
                child: Consumer<ProfileProvider>(
                  builder: (context, profileProvider, child) {
                    return Stack(
                      alignment: Alignment.center,
                      children: [
                        GestureDetector(
                          onTap: _pickImage,
                          child: ClipOval(
                            child: Image.memory(
                              imageB!,
                              fit: BoxFit.cover,
                              width: 100.0,
                              height: 100.0,
                              errorBuilder: (context, error, stackTrace) {
                                return CircleAvatar(
                                  radius: 50,
                                  backgroundColor: Colors.grey[400],
                                  child: const Icon(
                                    Icons.person,
                                    size: 100,
                                    color: Colors.white,
                                  ),
                                );
                              },
                            ),
                          ),
                        ),
                        Positioned(
                          bottom: 0,
                          right: 4,
                          child: InkWell(
                            onTap: _pickImage,
                            child: Container(
                              decoration: BoxDecoration(
                                shape: BoxShape.circle,
                                color: Colors.blueAccent,
                                border: Border.all(color: Colors.white, width: 2),
                              ),
                              padding: EdgeInsets.all(6),
                              child: Icon(
                                Icons.edit,
                                size: 18,
                                color: Colors.white,
                              ),
                            ),
                          ),
                        ),
                      ],
                    );

                  },
                ),
              ),
              const SizedBox(height: 20),

              InputTextWidget(
                controller: _nameController,
                labelText: 'Name',
                borderColor: Colors.blueAccent,
                errorText: _nameError,
              ),
              InputTextWidget(
                controller: _emailController,
                labelText: 'Email',
                borderColor: Colors.blueAccent,
                errorText: _emailError,
              ),
              InputTextWidget(
                controller: _phoneController,
                labelText: 'Phone',
                borderColor: Colors.blueAccent,
                errorText: _phoneError,
              ),

              // Theory Exam Date Picker
              DatePickerWidget(
                controller: _examDateController,
                labelText: 'Theory Exam Date',
                borderColor: Colors.blueAccent,
                initialDate: DateTime.now(),
                firstDate: DateTime.now(),
                // Only future dates
                lastDate: DateTime(2050),
                // Limit to 3 years in future
                onDateSelected: (selectedDate) {},
              ),

              const SizedBox(height: 20),
              hasInternet
                  ? CommonButtonWidget(
                onPressed: _saveProfileData,
                buttonText: 'Save',
              )   : Center(
                child: Text(
                  'No Internet Connection',
                  style: TextStyle(
                    fontSize: 20,
                    color: AppColors.primary,
                  ),
                ),
              ),
              const SizedBox(height: 40),
              Center(
                child: Container(
                  width: double.infinity,
                  padding: EdgeInsets.all(16),
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      colors: AppColors.flashDealGradientColorList,
                      begin: Alignment.bottomCenter,
                      end: Alignment.topCenter,
                    ),
                    borderRadius: BorderRadius.circular(5),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.black26,
                        blurRadius: 8,
                        offset: Offset(0, 4),
                      ),
                    ],
                  ),
                  child:Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Text(
                        'Current Category:',
                        style: TextStyle(
                          color: Colors.black45,
                          fontSize: 14,
                          fontWeight: FontWeight.w400,
                        ),
                      ),
                      SizedBox(height: 8),
                      Container(
                        width: double.infinity,
                        padding: EdgeInsets.symmetric(horizontal: 12, vertical: 10),
                        decoration: BoxDecoration(
                          color: Colors.black.withValues(alpha:0.4),
                          borderRadius: BorderRadius.circular(8),
                          border: Border.all(color: AppColors.gold.withValues(alpha:0.2), width: 1),
                        ),
                        child: Text(
                          '$category',
                          style: TextStyle(
                            color: Colors.white,
                            fontSize: 18,
                            fontWeight: FontWeight.bold,
                          ),
                          overflow: TextOverflow.ellipsis,
                          maxLines: 2,
                        ),
                      ),
                      SizedBox(height: 16),
                      Align(
                        alignment: Alignment.center,
                        child: InkWell(
                          onTap: () {
                            navigateTo(() => CategoriesScreen());
                          },
                          child: Container(
                            padding: EdgeInsets.symmetric(vertical: 10, horizontal: 20),
                            decoration: BoxDecoration(
                              color: AppColors.white.withValues(alpha:0.2),
                              borderRadius: BorderRadius.circular(10),
                              border: Border.all(color: AppColors.white, width: 1),
                            ),
                            child: Row(
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                Icon(
                                  Icons.edit,
                                  size: 16,
                                  color: AppColors.white,
                                ),
                                SizedBox(width: 8),
                                Text(
                                  'Change Category',
                                  style: TextStyle(
                                    color: AppColors.white,
                                    fontSize: 15,
                                    fontWeight: FontWeight.w600,
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      ),
                    ],
                  )
                ),
              )
            ],
          ),
        ),
      ),
    );
  }
}
