
import 'dart:ffi';

import 'package:flutter/cupertino.dart';
import 'package:theory_test_ltd/features/progress_status/local_database/overall_progress_data.dart';

class ProgressController extends ChangeNotifier{

  OverAllProgressData overAllProgressData = OverAllProgressData();

  // Separate values
  double totalTopics = 0.0;
  double viewedTopics = 0.0;
  double totalMocks = 0.0;
  double attemptedMocks = 0.0;
  int passedMockTest = 0;
  int takenTopicQues = 0;
  int inCorrectTopicQues = 0;


  // Percentage calculations
  double topicCompletionPercentage = 0.0;
  double mockCompletionPercentage = 0.0;
  double mockPassedPercentage = 0.0;
  double topicMistakePercentage = 0.0;

  Future<void> getTopicData() async {

    Map<String, double> topicData = await overAllProgressData.getItemCounts();
    Map<String, double> mockData = await overAllProgressData.getMockSetCounts();
    Map<String, int> topicMistake = await overAllProgressData.getTopicReadQuestionCounts();
    passedMockTest = await overAllProgressData.getPassedMockTestCount();

    // Assign values safely
    totalTopics = topicData['totalCount'] ?? 0.0;
    viewedTopics = topicData['yStatusCount'] ?? 0.0;
    totalMocks = mockData['totalCount'] ?? 0.0;
    attemptedMocks = mockData['attemptMockCount'] ?? 0.0;
    takenTopicQues = topicMistake['totalCount'] ?? 0;
    inCorrectTopicQues = topicMistake['incorrect'] ?? 0;

    // Calculate percentages
    topicCompletionPercentage = totalTopics > 0 ? (viewedTopics / totalTopics)  : 0.0;
    mockCompletionPercentage = totalMocks > 0 ? (attemptedMocks / totalMocks)  : 0.0;
    mockPassedPercentage = attemptedMocks > 0 ? (passedMockTest / attemptedMocks)  : 0.0;
    topicMistakePercentage = takenTopicQues > 0 ? (inCorrectTopicQues / takenTopicQues)  : 0.0;


    notifyListeners();

  }

}