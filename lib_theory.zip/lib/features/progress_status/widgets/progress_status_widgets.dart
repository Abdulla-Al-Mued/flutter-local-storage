import 'package:fl_chart/fl_chart.dart';
import 'package:flutter/material.dart';
import 'package:theory_test_ltd/common/base_widgets/screen_config.dart';
import 'package:theory_test_ltd/utils/color_resources.dart';

class BarChartWidget extends StatelessWidget {
  final List<int> data;
  final List<String> labels;
  final List<Color> colors;

  const BarChartWidget({
    super.key,
    required this.data,
    required this.labels,
    required this.colors,
  });

  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(
      builder: (BuildContext context, BoxConstraints constraints) {
        // Get screen configuration based on the available space
        final ScreenConfig config = getScreenConfig(constraints, context);

        return SizedBox(
          height: config.isTablet ? 350 : 250, // Dynamic height based on screen type
          child: BarChart(
            BarChartData(
              alignment: BarChartAlignment.spaceAround,
              barGroups: _buildBarGroups(),
              titlesData: FlTitlesData(
                bottomTitles: AxisTitles(
                  sideTitles: SideTitles(
                    showTitles: true,
                    getTitlesWidget: (double value, TitleMeta meta) {
                      final index = value.toInt();
                      return Padding(
                        padding: const EdgeInsets.only(top: 8.0),
                        child: Text(
                          labels[index],
                          style: TextStyle(
                            fontSize: config.menuFontSize, // Dynamic font size for labels
                          ),
                        ),
                      );
                    },
                  ),
                ),
                leftTitles: AxisTitles(
                  sideTitles: SideTitles(
                    showTitles: true,
                    reservedSize: 40,
                    interval: 20,
                    getTitlesWidget: (double value, TitleMeta meta) {
                      return Text('${value.toInt()}%');
                    },
                  ),
                ),
              ),
              gridData: FlGridData(show: false),
              borderData: FlBorderData(show: false),
              maxY: 100,
            ),
          ),
        );
      },
    );
  }

  List<BarChartGroupData> _buildBarGroups() {
    return List.generate(data.length, (index) {
      return BarChartGroupData(
        x: index,
        barRods: [
          BarChartRodData(
            toY: data[index].toDouble(),
            color: colors[index],
            width: 20,
            borderRadius: BorderRadius.circular(4),
          ),
        ],
      );
    });
  }
}
Widget buildStatItem(ScreenConfig config, {
  required String label,
  required int attempts,
  required int correct,
  required int accuracy,
}) {
  return Container(
    padding: EdgeInsets.all(8.0),
    decoration: BoxDecoration(
      borderRadius: BorderRadius.circular(8.0),
      border: Border.all(color: AppColors.grey),
    ),
    child: Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Text(
          label,
          style: TextStyle(
            fontSize: config.fontSizeSubtitle,
            fontWeight: FontWeight.w500,
            color: AppColors.black,
          ),
        ),
        Column(
          crossAxisAlignment: CrossAxisAlignment.end,
          children: [
            Text(
              'Attempts: $attempts',
              style: TextStyle(
                fontSize: config.menuFontSize,
                color: AppColors.black,
              ),
            ),
            Text(
              'Correct: $correct',
              style: TextStyle(
                fontSize: config.menuFontSize,
                color: AppColors.black,
              ),
            ),
            Text(
              'Accuracy: $accuracy%',
              style: TextStyle(
                fontSize: config.menuFontSize,
                fontWeight: FontWeight.bold,
                color: AppColors.black,
              ),
            ),
          ],
        ),
      ],
    ),
  );
}