import 'package:flutter/material.dart';
import '../../../utils/color_resources.dart';

class ProgressCard extends StatelessWidget {
  final double progress;
  final String title;
  final String currentValue;
  final String totalValue;
  final Color texColor;
  final Color progressColor;
  final Color countColor;
  final Color bgColor;

  const ProgressCard({
    super.key,
    required this.progress,
    required this.title,
    required this.currentValue,
    required this.totalValue,
    required this.texColor,
    required this.progressColor,
    required this.countColor, required this.bgColor,
  });

  @override
  Widget build(BuildContext context) {
    return Card(
      color: bgColor,
      elevation: 5,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(12), // Smooth rounded corners
      ),
      child: Padding(
        padding: const EdgeInsets.all(18), // Padding for better spacing
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            SizedBox(
              width: double.infinity, // Full width
              child: Row(
                children: [
                  SizedBox(
                    width: 60,
                    height: 60,
                    child: Stack(
                      fit: StackFit.expand,
                      children: [
                        CircularProgressIndicator(
                          value: progress, // Progress (0.65 or 13/20)
                          strokeWidth: 8,
                          backgroundColor: Colors.grey.shade300,
                          valueColor: AlwaysStoppedAnimation<Color>(progressColor),
                        ),
                        Center(
                          child: Text(
                            "${(progress * 100).toStringAsFixed(0)}%", // Show percentage inside
                            style: TextStyle(
                              fontSize: 15,
                              fontWeight: FontWeight.bold,
                              color: AppColors.gold,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(width: 16), // Space below the progress bar
                  Expanded(
                    child: Row(
                      children: [
                        Flexible(
                          child: Text(
                            title,
                            overflow: TextOverflow.ellipsis,
                            style: TextStyle(
                              fontSize: 15,
                              fontWeight: FontWeight.w500,
                              color: AppColors.gold,
                            ),
                          ),
                        ),
                        const SizedBox(width: 8), // Space between text and value
                        Text(
                          "$currentValue/$totalValue",
                          style: TextStyle(
                            fontSize: 16,
                            fontWeight: FontWeight.bold,
                            color: AppColors.gold,
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
