import 'package:fl_chart/fl_chart.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

import '../../../utils/color_resources.dart';
import 'Indicator_widget.dart';

class MistakesStatus extends StatefulWidget {
  const MistakesStatus({super.key});

  @override
  State<MistakesStatus> createState() => _MistakesStatusState();
}

class _MistakesStatusState extends State<MistakesStatus> {
  final double width = 16; // Increased column width

  late List<BarChartGroupData> barGroups;

  @override
  void initState() {
    super.initState();
    barGroups = [
      makeGroupData(0, 30, 20), // Topic
      makeGroupData(1, 25, 18), // Mock Test

    ];
  }

  @override
  Widget build(BuildContext context) {
    return AspectRatio(
      aspectRatio: 1.2,
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: <Widget>[

            const SizedBox(height: 10),

            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Indicator(color: Colors.green, text: 'Total Taken Exam'),
                const SizedBox(width: 16),
                Indicator(color: Colors.red, text: 'Total Mistakes'),
              ],
            ),
            const SizedBox(height: 24),
            Expanded(

              child: Padding(
                padding: const EdgeInsets.only(top: 10.0),
                child: BarChart(
                  BarChartData(
                    maxY: 40,
                    titlesData: FlTitlesData(
                      leftTitles: AxisTitles(
                        sideTitles: SideTitles(
                          showTitles: true,
                          reservedSize: 40,
                          interval: 10,
                          getTitlesWidget: leftTitles,
                        ),
                      ),
                      bottomTitles: AxisTitles(
                        sideTitles: SideTitles(
                          showTitles: true,
                          getTitlesWidget: bottomTitles,
                          reservedSize: 42,
                        ),
                      ),
                      rightTitles: const AxisTitles(sideTitles: SideTitles(showTitles: false)),
                      topTitles: const AxisTitles(sideTitles: SideTitles(showTitles: false)),
                    ),
                    borderData: FlBorderData(show: false),
                    gridData: const FlGridData(show: false),
                    barGroups: barGroups,
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget leftTitles(double value, TitleMeta meta) {
    return SideTitleWidget(
      space: 8,
      meta: meta,
      child: Text('${value.toInt()}', style: const TextStyle(fontWeight: FontWeight.bold,fontSize: 14, color: AppColors.secondary)),
    );
  }

  Widget bottomTitles(double value, TitleMeta meta) {
    const labels = ['Topic', 'Mock Test'];
    return SideTitleWidget(
      space: 10,
      meta: meta,
      child: Text(
        labels[value.toInt()],
        style: const TextStyle(fontSize: 14, fontWeight: FontWeight.bold, color: AppColors.secondary),
      ),
    );
  }

  BarChartGroupData makeGroupData(int x, double totalExam, double takenExam) {
    return BarChartGroupData(
      barsSpace: 8,
      x: x,
      barRods: [
        BarChartRodData(
          toY: totalExam,
          color: Colors.green,
          width: width,
          borderRadius: BorderRadius.circular(5),
        ),
        BarChartRodData(
          toY: takenExam,
          color: Colors.red,
          width: width,
          borderRadius: BorderRadius.circular(5),
        ),
      ],
    );
  }

}
