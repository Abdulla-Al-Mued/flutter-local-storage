import 'package:fl_chart/fl_chart.dart';
import 'package:flutter/material.dart';

import '../../../utils/color_resources.dart';
import 'Indicator_widget.dart';

class BarChartSample extends StatefulWidget {

  final double totalTopic;
  final double viewTopic;
  final double totalMock;
  final double viewMock;
  final double totalHazard;
  final double viewHazard;


  const BarChartSample({
    super.key,
    required this.totalTopic,
    required this.viewTopic,
    required this.totalMock,
    required this.viewMock,
    required this.totalHazard,
    required this.viewHazard,
  });

  @override
  State<StatefulWidget> createState() => _BarChartSampleState();
}

class _BarChartSampleState extends State<BarChartSample> {
  final double width = 16; // Increased column width

  //late List<BarChartGroupData> barGroups;

  List<BarChartGroupData> get barGroups {
    return [
      makeGroupData(0, widget.totalTopic, widget.viewTopic),
      makeGroupData(1, widget.totalMock, widget.viewMock),
      makeGroupData(2, widget.totalHazard, widget.viewHazard),
    ];
  }

  @override
  void initState() {
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return AspectRatio(
      aspectRatio: 1.2,
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: <Widget>[

            const SizedBox(height: 10),

            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Flexible(child: Indicator(color: Colors.blue, text: 'Total Exam')),
                const SizedBox(width: 16),
                Flexible(child: Indicator(color: Colors.green, text: 'Total Taken Exam')),
              ],
            ),
            const SizedBox(height: 24),
            Expanded(

              child: Padding(
                padding: const EdgeInsets.only(top: 10.0),
                child: BarChart(
                  BarChartData(
                    maxY: 40,
                    titlesData: FlTitlesData(
                      leftTitles: AxisTitles(
                        sideTitles: SideTitles(
                          showTitles: true,
                          reservedSize: 40,
                          interval: 10,
                          getTitlesWidget: leftTitles,
                        ),
                      ),
                      bottomTitles: AxisTitles(
                        sideTitles: SideTitles(
                          showTitles: true,
                          getTitlesWidget: bottomTitles,
                          reservedSize: 42,
                        ),
                      ),
                      rightTitles: const AxisTitles(sideTitles: SideTitles(showTitles: false)),
                      topTitles: const AxisTitles(sideTitles: SideTitles(showTitles: false)),
                    ),
                    borderData: FlBorderData(show: false),
                    gridData: const FlGridData(show: false),
                    barGroups: barGroups,
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget leftTitles(double value, TitleMeta meta) {
    return SideTitleWidget(
      space: 8,
      meta: meta,
      child: Text('${value.toInt()}', style: const TextStyle(fontWeight: FontWeight.bold,fontSize: 14, color: AppColors.secondary)),
    );
  }

  Widget bottomTitles(double value, TitleMeta meta) {
    const labels = ['Topic', 'Mock Test', 'Hazard'];
    return SideTitleWidget(
      space: 10,
      meta: meta,
      child: Text(
        labels[value.toInt()],
        style: const TextStyle(fontSize: 14, fontWeight: FontWeight.bold, color: AppColors.secondary),
      ),
    );
  }

  BarChartGroupData makeGroupData(int x, double totalExam, double takenExam) {
    return BarChartGroupData(
      barsSpace: 8,
      x: x,
      barRods: [
        BarChartRodData(
          toY: totalExam,
          color: Colors.blue,
          width: width,
          borderRadius: BorderRadius.circular(5),
        ),
        BarChartRodData(
          toY: takenExam,
          color: Colors.green,
          width: width,
          borderRadius: BorderRadius.circular(5),
        ),
      ],
    );
  }
}


