import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:theory_test_ltd/common/base_widgets/custom_app_bar.dart';
import 'package:theory_test_ltd/common/base_widgets/screen_config.dart';
import 'package:theory_test_ltd/features/hazard_perception/controllers/result_controller.dart';
import 'package:theory_test_ltd/features/progress_status/controller/progress_controller.dart';
import 'package:theory_test_ltd/features/progress_status/widgets/progress_status_widgets.dart';
import 'package:theory_test_ltd/utils/color_resources.dart';

import '../widgets/barchat_status_screen.dart';
import '../widgets/mistakes_status.dart';
import '../widgets/percentage_view.dart';

class ProgressStatusScreen extends StatefulWidget {
  const ProgressStatusScreen({super.key});

  @override
  State<ProgressStatusScreen> createState() => _ProgressStatusScreenState();
}

class _ProgressStatusScreenState extends State<ProgressStatusScreen> {

  late HazardResultsController hazardResultsController;
  late ProgressController progressController;


  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      hazardResultsController.loadHazardVideos();
      progressController.getTopicData();
    });
  }

  @override
  Widget build(BuildContext context) {



    hazardResultsController = Provider.of<HazardResultsController>(context, listen: false);
    progressController = Provider.of<ProgressController>(context, listen: false);


    return Scaffold(
      appBar: CustomAppBar(
        title: 'Practice Progress',
        gradientColors: [
          Colors.pink.shade400,
          Colors.pink.shade400,
        ],
      ),
      body: Container(
        height: MediaQuery.of(context).size.height,
        decoration: BoxDecoration(

          gradient: LinearGradient(
            colors: [
              Colors.pink.shade400,
              Colors.orange.shade200,
            ],
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
          ),
        ),
        child: LayoutBuilder(
          builder: (BuildContext context, BoxConstraints constraints) {

            final ScreenConfig config = getScreenConfig(constraints, context);

            return Padding(
              padding: EdgeInsets.all(16.0),
              child: SingleChildScrollView(
                child: Consumer2<ProgressController, HazardResultsController>(builder: (BuildContext context, ProgressController value, HazardResultsController value2, Widget? child) {


                  return Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'Progress Overview',
                        style: TextStyle(
                          fontSize: 22,
                          fontWeight: FontWeight.bold,
                          color: AppColors.white,
                        ),
                      ),
                      const SizedBox(height: 15),

                      Card(
                        color: AppColors.primary200,
                        elevation: 5,
                        child: BarChartSample(
                          totalTopic: value.totalTopics,
                          viewTopic: value.viewedTopics,
                          totalMock: value.totalMocks,
                          viewMock: value.attemptedMocks,
                          totalHazard: value2.totalVideos.toDouble(),
                          viewHazard: value2.watchedVideos.toDouble(),
                        ),
                      ),

                      const SizedBox(height: 20),

                      ProgressCard(
                        currentValue: value.viewedTopics.toInt().toString(),
                        progress: value.topicCompletionPercentage,
                        //progress: 0.67,
                        title: "Total Topic Read",
                        totalValue:  value.totalTopics.toInt().toString(),
                        texColor: AppColors.secondary,
                        progressColor: AppColors.plum,
                        countColor: AppColors.primary, bgColor: AppColors.slateGrey,
                      ),
                      const SizedBox(height: 10),
                      ProgressCard(
                        currentValue: value.attemptedMocks.toInt().toString(),
                        progress: value.mockCompletionPercentage,
                        //progress: 0.67,
                        title: "Mock Test Taken",
                        totalValue: value.totalMocks.toInt().toString(),
                        texColor: AppColors.secondary,
                        progressColor: AppColors.yellowLightMenuLight,
                        countColor: AppColors.primary,
                        bgColor: AppColors.primary,
                      ),
                      const SizedBox(height: 10),
                      ProgressCard(
                        currentValue: value2.watchedVideos.toString(),
                        progress: value2.progressPercentage/100,
                        //progress: 0.67,
                        title: "Hazard",
                        totalValue: value2.totalVideos.toString(),
                        texColor: AppColors.secondary,
                        progressColor: AppColors.coral,
                        countColor: AppColors.primary,
                        bgColor: AppColors.slateGrey,
                      ),
                      const SizedBox(height: 10),
                      ProgressCard(
                        currentValue: value.passedMockTest.toInt().toString(),
                        progress: value.mockPassedPercentage,
                        title: "Taken Mock Test Passed",
                        totalValue: value.attemptedMocks.toInt().toString(),
                        texColor: AppColors.secondary,
                        progressColor: AppColors.harlequin,
                        countColor: AppColors.primary,
                        bgColor: AppColors.primary,
                      ),
                      const SizedBox(height: 10),
                      ProgressCard(
                        currentValue: value.inCorrectTopicQues.toString(),
                        progress: value.topicMistakePercentage,
                        title: "Topic Mistakes",
                        totalValue: value.takenTopicQues.toString(),
                        texColor: AppColors.secondary,
                        progressColor: AppColors.pink,
                        countColor: AppColors.primary, bgColor: AppColors.slateGrey,
                      ),

                      const SizedBox(height: 20),

                    ],
                  );
                })
              ),
            );
          },
        ),
      ),
    );
  }

  Widget _buildDetailedStats(ScreenConfig config) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        buildStatItem(
          config,
          label: "Theory Test",
          attempts: 5,
          correct: 4,
          accuracy: 80,
        ),
        const SizedBox(height: 10),
        buildStatItem(
          config,
          label: "Hazard Perception",
          attempts: 4,
          correct: 2,
          accuracy: 50,
        ),
      ],
    );
  }
}
