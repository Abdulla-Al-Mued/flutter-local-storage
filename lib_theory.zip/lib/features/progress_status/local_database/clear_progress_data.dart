import 'package:flutter/material.dart';
import 'package:theory_test_ltd/Local_database/Local_database_handler.dart';

class ClearProgressData{

  LocalDatabaseHandler handler = LocalDatabaseHandler();

  Future<void> clearAllTables() async {
    final db = await handler.getDatabase;
    await db?.transaction((txn) async {
      await txn.execute("DELETE FROM THT_CUST_MISTAKE_QUES_ANS");
      await txn.execute("DELETE FROM THT_CUST_MOCK_TEST_LOG");
      await txn.execute("DELETE FROM THT_CUST_MOCK_TEST_QUES_ANS");
      await txn.execute("UPDATE THRY_TEST_MOCK_SETS_QUESTION_ANS SET ATTEMPT_MOCK = 'N'");
      await txn.execute("DELETE FROM THT_CUST_TOPIC_READ_QUES_ANS");
      await txn.execute("DELETE FROM THT_CUST_FAVORITE_QUES_ANS");
      await txn.execute("UPDATE HAZARD_VIDEO_MST SET LAST_SCORE = 0, IS_WATCHED = 'N'");
    });
  }

}

void showDeleteConfirmationDialog(BuildContext context) {

  showDialog(
    context: context,
    builder: (BuildContext context) {
      return AlertDialog(
        title: Text("Confirm Deletion"),
        content: Text("Are you sure you want to reset all progress? This action cannot be undone."),
        actions: [
          TextButton(
            onPressed: () {
              Navigator.of(context).pop(); // Close dialog
            },
            child: Text("Cancel"),
          ),
          TextButton(
            onPressed: () async {

            },
            child: Text("Delete", style: TextStyle(color: Colors.red)),
          ),
        ],
      );
    },
  );
}
