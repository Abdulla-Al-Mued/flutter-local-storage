import 'package:sqflite/sqflite.dart';
import 'package:theory_test_ltd/Local_database/Local_database_handler.dart';

class OverAllProgressData{

  LocalDatabaseHandler handler = LocalDatabaseHandler();

  Future<Map<String, double>> getItemCounts() async {
    final db = await handler.getDatabase;

    try{
      final totalCountResult = await db?.rawQuery('SELECT COUNT(*) FROM THRY_TEST_TYPE_DTL_CAT');
      final totalCount = Sqflite.firstIntValue(totalCountResult!) ?? 0;

      // Query to get count of items where STATUS is 'Y'
      final yStatusCountResult = await db?.rawQuery("SELECT COUNT(*) FROM THRY_TEST_TYPE_DTL_CAT WHERE STATUS = 'Y'");
      final yStatusCount = Sqflite.firstIntValue(yStatusCountResult!) ?? 0;

      return {
        'totalCount': totalCount.toDouble(),
        'yStatusCount': yStatusCount.toDouble(),
      };
    }catch(e){
      print(e.toString());
      return{};
    }



  }

  Future<Map<String, double>> getMockSetCounts() async {
    final db = await handler.getDatabase;

    // Query to get total item count from the table
    final totalCountResult = await db?.rawQuery('SELECT COUNT(*) FROM THRY_TEST_MOCK_SETS_QUESTION_ANS');
    final totalCount = Sqflite.firstIntValue(totalCountResult!) ?? 0;

    // Query to get count of items where ATTEMPT_MOCK is 'Y'
    final attemptMockCountResult = await db?.rawQuery("SELECT COUNT(*) FROM THRY_TEST_MOCK_SETS_QUESTION_ANS WHERE ATTEMPT_MOCK = 'Y'");
    final attemptMockCount = Sqflite.firstIntValue(attemptMockCountResult!) ?? 0;

    return {
      'totalCount': totalCount.toDouble(),
      'attemptMockCount': attemptMockCount.toDouble(),
    };
  }

  Future<int> getPassedMockTestCount() async {
    final db = await handler.getDatabase;

    final result = await db!.rawQuery(
        "SELECT COUNT(*) FROM THT_CUST_MOCK_TEST_LOG WHERE STATUS = 'P'");

    return Sqflite.firstIntValue(result) ?? 0;
  }

  Future<Map<String, int>> getTopicReadQuestionCounts() async {
    final db = await handler.getDatabase;

    final totalCountResult = await db!.rawQuery(
        "SELECT COUNT(*) FROM THT_CUST_TOPIC_READ_QUES_ANS");
    final totalCount = Sqflite.firstIntValue(totalCountResult) ?? 0;

    final incompleteCountResult = await db.rawQuery(
        "SELECT COUNT(*) FROM THT_CUST_TOPIC_READ_QUES_ANS WHERE STATUS = 'I'");
    final incorrect = Sqflite.firstIntValue(incompleteCountResult) ?? 0;

    return {
      'totalCount': totalCount,
      'incorrect': incorrect,
    };
  }



}