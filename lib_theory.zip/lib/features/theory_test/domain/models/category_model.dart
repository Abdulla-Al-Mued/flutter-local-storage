class Category {
  final int id;
  final String testTypeDtlCatId;
  final String testTypeDtlId;
  final String testTypeMstId;
  final String testDtlCatDesc;
  final String testTypeDtlCatImgPath;
  final String status;
  final String createDate;
  final String createUser;
  final String createIp;
  final String updateDate;
  final String updateUser;
  final String updateIp;

  Category({
    required this.id,
    required this.testTypeDtlCatId,
    required this.testTypeDtlId,
    required this.testTypeMstId,
    required this.testDtlCatDesc,
    required this.testTypeDtlCatImgPath,
    required this.status,
    required this.createDate,
    required this.createUser,
    required this.createIp,
    required this.updateDate,
    required this.updateUser,
    required this.updateIp,
  });

  factory Category.fromMap(Map<String, dynamic> map) {
    return Category(
      id: map['ID'],
      testTypeDtlCatId: map['TEST_TYPE_DTL_CAT_ID'] ?? '', // Handle null
      testTypeDtlId: map['TEST_TYPE_DTL_ID'] ?? '', // Handle null
      testTypeMstId: map['TEST_TYPE_MST_ID'] ?? '', // Handle null
      testDtlCatDesc: map['TEST_DTL_CAT_DESC'] ?? '', // Handle null
      testTypeDtlCatImgPath: map['TEST_TYPE_DTL_CAT_IMG_PATH'] ?? '', // Handle null
      status: map['STATUS'] ?? '', // Handle null
      createDate: map['CREATE_DATE'] ?? '', // Handle null
      createUser: map['CREATE_USER'] ?? '', // Handle null
      createIp: map['CREATE_IP'] ?? '', // Handle null
      updateDate: map['UPDATE_DATE'] ?? '', // Handle null
      updateUser: map['UPDATE_USER'] ?? '', // Handle null
      updateIp: map['UPDATE_IP'] ?? '', // Handle null
    );
  }
}
