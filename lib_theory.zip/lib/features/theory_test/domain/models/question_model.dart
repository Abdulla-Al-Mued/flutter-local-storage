class Question {
  final int id;
  final String serialNo;
  final String theoryTestQuestionId;
  final String testTypeMstId;
  final String testTypeDtlId;
  final String testTypeDtlCatId;
  final String testTypeDtlDtlId;
  final String questionDesc;
  final String questionImagePath;
  final String ans1Desc;
  final String ans1ImagePath;
  final String ans2Desc;
  final String ans2ImagePath;
  final String ans3Desc;
  final String ans3ImagePath;
  final String ans4Desc;
  final String ans4ImagePath;
  final String correctAnsNo;
  final String hintExplanation;
  final String hintCategory;
  final String hintReferences;
  final String questionSrlNo;
  final String htmlRules;
  final String status;
  final String createDate;
  final String createUser;
  final String createIp;
  final String updateDate;
  final String updateUser;
  final String updateIp;

  Question({
    required this.id,
    required this.serialNo,
    required this.theoryTestQuestionId,
    required this.testTypeMstId,
    required this.testTypeDtlId,
    required this.testTypeDtlCatId,
    required this.testTypeDtlDtlId,
    required this.questionDesc,
    required this.questionImagePath,
    required this.ans1Desc,
    required this.ans1ImagePath,
    required this.ans2Desc,
    required this.ans2ImagePath,
    required this.ans3Desc,
    required this.ans3ImagePath,
    required this.ans4Desc,
    required this.ans4ImagePath,
    required this.correctAnsNo,
    required this.hintExplanation,
    required this.hintCategory,
    required this.hintReferences,
    required this.questionSrlNo,
    required this.htmlRules,
    required this.status,
    required this.createDate,
    required this.createUser,
    required this.createIp,
    required this.updateDate,
    required this.updateUser,
    required this.updateIp,
  });

  // Function to map from database result (Map) with null checks
  factory Question.fromMap(Map<String, dynamic> map) {
    return Question(
      id: map['ID'] ?? 0,
      serialNo: map['QUESTION_SRL_NO'] ?? '',
      theoryTestQuestionId: map['THEORY_TEST_QUESTION_ID'] ?? '',
      testTypeMstId: map['TEST_TYPE_MST_ID'] ?? '',
      testTypeDtlId: map['TEST_TYPE_DTL_ID'] ?? '',
      testTypeDtlCatId: map['TEST_TYPE_DTL_CAT_ID'] ?? '',
      testTypeDtlDtlId: map['TEST_TYPE_DTL_DTL_ID'] ?? '',
      questionDesc: map['QUESTION_DESC'] ?? '',
      questionImagePath: map['QUESTION_IMAGE_PATH'] ?? '',
      ans1Desc: map['ANS1_DESC'] ?? '',
      ans1ImagePath: map['ANS1_IMAGE_PATH'] ?? '',
      ans2Desc: map['ANS2_DESC'] ?? '',
      ans2ImagePath: map['ANS2_IMAGE_PATH'] ?? '',
      ans3Desc: map['ANS3_DESC'] ?? '',
      ans3ImagePath: map['ANS3_IMAGE_PATH'] ?? '',
      ans4Desc: map['ANS4_DESC'] ?? '',
      ans4ImagePath: map['ANS4_IMAGE_PATH'] ?? '',
      correctAnsNo: map['CORRECT_ANS_NO'] ?? '',
      hintExplanation: map['HINT_EXPLANATION'] ?? '',
      hintCategory: map['HINT_CATEGORY'] ?? '',
      hintReferences: map['HINT_REFERENCES'] ?? '',
      questionSrlNo: map['QUESTION_SRL_NO'] ?? '',
      htmlRules: map['HTML_RULES'] ?? '',
      status: map['STATUS'] ?? '',
      createDate: map['CREATE_DATE'] ?? '',
      createUser: map['CREATE_USER'] ?? '',
      createIp: map['CREATE_IP'] ?? '',
      updateDate: map['UPDATE_DATE'] ?? '',
      updateUser: map['UPDATE_USER'] ?? '',
      updateIp: map['UPDATE_IP'] ?? '',
    );
  }
}
class MockSet {
  final int setNumber;
  final List<Question> questions;
  final String setRange;
  final String attemptMock;  // Add the attemptMock field

  MockSet({
    required this.setNumber,
    required this.questions,
    required this.setRange,
    required this.attemptMock,  // Initialize attemptMock
  });
}

