import 'dart:io';
import 'package:flutter/material.dart';
import 'package:theory_test_ltd/common/base_widgets/navigate_pages.dart';
import 'package:theory_test_ltd/features/theory_test/screens/learning_webview_screen.dart';
import 'package:theory_test_ltd/utils/color_resources.dart';
import 'package:flutter_tts/flutter_tts.dart';

class QuestionText extends StatelessWidget {
  final String questionText;

  const QuestionText({super.key, required this.questionText});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(5),
      child: Text(
        questionText,
        style:  TextStyle(
          fontSize: 20,
          fontFamily: 'Poppins',
          fontWeight: FontWeight.bold,
          color: AppColors.teal,
        ),
      ),
    );
  }
}

class QuestionOptions extends StatelessWidget {
  final List<String> options;
  final int? selectedOption;
  final ValueChanged<int> onOptionSelected;
  final int correctAnswerIndex;

  const QuestionOptions({
    super.key,
    required this.options,
    required this.selectedOption,
    required this.onOptionSelected,
    required this.correctAnswerIndex,
  });

  @override
  Widget build(BuildContext context) {
    FlutterTts flutterTts = FlutterTts();

    Future<void> speak(String text) async {
      await flutterTts.setLanguage('en-US');
      await flutterTts.setPitch(5.0);
      await flutterTts.speak(text);
    }

    return Column(
      children: List.generate(options.length, (index) {
        final isSelected = selectedOption == index;
        final isCorrectOption = index == correctAnswerIndex;
        Color optionColor;

        if (selectedOption != null) {
          if (isSelected && isCorrectOption) {
            optionColor = Colors.blue;
          } else if (isSelected && !isCorrectOption) {
            optionColor = Colors.red;
          } else if (isCorrectOption) {
            optionColor = Colors.green;
          } else {
            optionColor = Colors.grey;
          }
        } else {
          optionColor = Colors.grey;
        }

        return GestureDetector(
          onTap: () {
            if (selectedOption == null) {
              onOptionSelected(index);
            }
          },
          child: Container(
            margin: const EdgeInsets.symmetric(vertical: 8.0),
            padding: const EdgeInsets.all(12.0),
            decoration: BoxDecoration(
              border: Border.all(
                color: optionColor,
                width: 2.0,
              ),
              borderRadius: BorderRadius.circular(8.0),
              color: optionColor.withValues(alpha: 0.1),
            ),
            child: Row(
              children: [
                Expanded(
                  child: Text(
                    options[index],
                    style: TextStyle(
                      fontSize: 16,
                      fontWeight:
                          isSelected ? FontWeight.bold : FontWeight.normal,
                      color: optionColor,
                    ),
                  ),
                ),
                IconButton(
                  icon: Icon(Icons.volume_up, color: optionColor),
                  onPressed: () {
                    speak(options[index]);
                  },
                ),
              ],
            ),
          ),
        );
      }),
    );
  }
}

class ImageOptions extends StatelessWidget {
  final List<String> optionImages;
  final int? selectedOption;
  final ValueChanged<int> onOptionSelected;
  final int correctAnswerIndex;

  const ImageOptions({
    super.key,
    required this.optionImages,
    required this.selectedOption,
    required this.onOptionSelected,
    required this.correctAnswerIndex,
  });

  @override
  Widget build(BuildContext context) {
    return GridView.builder(
      shrinkWrap: true,
      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: 2,
      ),
      itemCount: optionImages.length,
      itemBuilder: (context, index) {
        final isSelected = selectedOption == index;
        final isCorrectOption = index == correctAnswerIndex;
        Color optionColor;

        if (selectedOption != null) {
          if (isSelected && isCorrectOption) {
            optionColor = Colors.blue;
          } else if (isSelected && !isCorrectOption) {
            optionColor = Colors.red;
          } else if (isCorrectOption) {
            optionColor = Colors.green;
          } else {
            optionColor = Colors.grey;
          }
        } else {
          optionColor = Colors.grey;
        }

        return GestureDetector(
          onTap: () {
            if (selectedOption == null) {
              onOptionSelected(index);
            }
          },
          child: Container(
            margin: const EdgeInsets.all(8.0),
            decoration: BoxDecoration(
              border: Border.all(
                color: optionColor,
                width: 2.0,
              ),
              borderRadius: BorderRadius.circular(8.0),
              color: optionColor.withValues(alpha: 0.1),
            ),
            child: Image.file(File(optionImages[index])),
          ),
        );
      },
    );
  }
}

class ExplanationSection extends StatelessWidget {
  final bool isCorrect;
  final String explanation;
  final String? rules;
  final String? reference;

   ExplanationSection({
    super.key,
    required this.isCorrect,
    required this.explanation,
    required this.rules,
    required this.reference,
  });

final  FlutterTts flutterTts = FlutterTts();

  Future<void> speak(String text) async {
    await flutterTts.setLanguage('en-US');
    await flutterTts.setPitch(5.0);
    await flutterTts.speak(text);
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(5.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(
                isCorrect ? Icons.check_circle : Icons.cancel,
                color: isCorrect ? Colors.green : Colors.red,
                size: 32,
              ),
              const SizedBox(width: 10),
              Text(
                isCorrect ? "Correct!" : "Incorrect!",
                style: TextStyle(
                  fontSize: 22,
                  fontWeight: FontWeight.bold,
                  color: isCorrect ? Colors.green : Colors.red,
                ),
              ),
            ],
          ),
          const SizedBox(height: 20),
          Container(
            width: double.infinity,
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: AppColors.blue.withValues(alpha:0.8), // Changed to withOpacity for clarity
              borderRadius: BorderRadius.circular(10),
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withValues(alpha:0.2), // Changed to withOpacity
                  blurRadius: 10,
                  spreadRadius: 2,
                  offset: const Offset(0, 3),
                ),
              ],
            ),
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Expanded(
                  child: RichText(
                    text: TextSpan(
                      text: 'Explanation: ',
                      style: TextStyle(
                        fontSize: 16,
                        fontWeight: FontWeight.bold,
                        color: AppColors.white,
                      ),
                      children: [
                        TextSpan(
                          text: explanation,
                          style: TextStyle(
                            fontWeight: FontWeight.w300,
                            fontSize: 16,
                            color: AppColors.white,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
                IconButton(
                  icon: Icon(Icons.volume_up),
                  color: AppColors.white, // Optional: Set icon color
                  onPressed: () => speak(explanation), // Call the _speak function when pressed
                ),
              ],
            ),
          ),
          const SizedBox(height: 20),
          if (reference != null && reference!.isNotEmpty) ...[
            Row(
              children:  [
                Expanded(
                  child: Text(
                    'Reference: :$reference ',
                    style: TextStyle(fontWeight: FontWeight.bold),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 4),

          ],
          const SizedBox(height: 10),
          if (rules != null && rules!.isNotEmpty) ...[
            Row(
              children: const [
                Icon(
                  Icons.info_outline,
                  color: Colors.blue,
                ),
                SizedBox(width: 6),
                Text(
                  "See rules here:",
                  style: TextStyle(fontWeight: FontWeight.bold),
                ),
              ],
            ),
            const SizedBox(height: 4),
            GestureDetector(
              onTap: () {
                navigateTo(()=>LearningWebViewScreen(htmlAssetPath: rules!));

              },
              child: Container(
                margin: EdgeInsets.all(5),
                padding: EdgeInsets.all(8),
                decoration: BoxDecoration(
                    color: AppColors.orange,
                    borderRadius: BorderRadius.circular(8)),
                child: Text(
                  'See Rules',
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 14,
                  ),
                ),
              ),
            ),
            const SizedBox(height: 20),
          ],

        ],
      ),
    );
  }
}

class NavigationButtons extends StatelessWidget {
  final VoidCallback? onPrevious;
  final VoidCallback? onNext;
  final VoidCallback? onFav;
  final VoidCallback? onReset;
  final bool isLastQuestion;
  final bool isFirstQuestion;
  final bool isFavorite;

  const NavigationButtons({
    super.key,
    required this.onPrevious,
    required this.onNext,
    required this.onFav,
    required this.onReset,
    required this.isLastQuestion,
    required this.isFirstQuestion,
    required this.isFavorite,
  });

  @override
  Widget build(BuildContext context) {
    return Align(
      alignment: Alignment.bottomCenter,
      child: Padding(
        padding: const EdgeInsets.all(8.0),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          // Space between buttons
          children: [
            // Previous Button
            if (!isFirstQuestion)
              _buildFloatingButton(
                  onPressed: onPrevious,
                  icon: Icons.navigate_before,
                  iconColor: Colors.black),

            // Favorite Button
            _buildFloatingButton(
              onPressed: onFav,
              icon: isFavorite ? Icons.bookmark : Icons.bookmark_border,
              iconColor: AppColors.red,
            ),

            // Reset Button
            _buildFloatingButton(
                onPressed: () {
                  _showResetConfirmationDialog(context);
                },
                icon: Icons.restart_alt,
                iconColor: Colors.black),

            // Next/Finish Button
            _buildFloatingButton(
                onPressed: onNext,
                icon: isLastQuestion ? Icons.check : Icons.navigate_next,
                iconColor: Colors.black),
          ],
        ),
      ),
    );
  }

  // Show reset confirmation dialog
  void _showResetConfirmationDialog(BuildContext context) {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return Dialog(
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(12), // Rounded corners
          ),
          backgroundColor: Colors.transparent, // Transparent background to use gradient
          child: Container(
            padding: EdgeInsets.all(20),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(12),
              gradient: LinearGradient(
                colors: [ AppColors.secondary,
                  AppColors.primary,], // Gradient background
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
            ),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Center(
                  child: Text(
                    'Confirm Reset',
                    style: TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.bold,
                      color: Colors.white,
                    ),
                  ),
                ),
                SizedBox(height: 10),
                Text(
                  'If you reset, all your progress will be lost. Do you want to continue?',
                  style: TextStyle(
                    fontSize: 16,
                    color: Colors.white70,

                  ),
                  textAlign: TextAlign.center,
                ),
                SizedBox(height: 20),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: [
                    // Cancel Button
                    _buildDialogButton(
                      context,
                      'Cancel',
                      onPressed: () {
                        Navigator.of(context).pop(); // Close the dialog
                      },
                      buttonColor: AppColors.harlequin,
                      textColor: AppColors.white,
                    ),
                    // Reset Button
                    _buildDialogButton(
                      context,
                      'Reset',
                      onPressed: () {
                        Navigator.of(context).pop(); // Close the dialog
                        onReset!(); // Call the onReset callback function
                      },
                      buttonColor: AppColors.red,
                      textColor: AppColors.white,
                    ),
                  ],
                ),
              ],
            ),
          ),
        );
      },
    );
  }

// Custom Button for Dialog Actions
  Widget _buildDialogButton(
      BuildContext context,
      String text, {
        required VoidCallback onPressed,
        required Color buttonColor,
        required Color textColor,
      }) {
    return ElevatedButton(
      onPressed: onPressed,
      style: ElevatedButton.styleFrom(
        backgroundColor: buttonColor, // Background color of the button
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(8), // Rounded corners
        ),
        padding: EdgeInsets.symmetric(horizontal: 20, vertical: 10), // Button padding
      ),
      child: Text(
        text,
        style: TextStyle(
          fontSize: 16,
          color: textColor,
        ),
      ),
    );
  }

  Widget _buildFloatingButton({
    required VoidCallback? onPressed,
    required IconData icon,
    required Color iconColor,
  }) {
    return SizedBox(
      child: GestureDetector(
        onTap: onPressed,
        child: Icon(
          icon,
          size: 30, // Adjust icon size for readability
          color: iconColor,
        ),
      ),
    );
  }
}
