import 'package:flutter/material.dart';
import 'package:theory_test_ltd/common/base_widgets/screen_config.dart';
import 'package:theory_test_ltd/utils/color_resources.dart';

class ResultsWidgets {
  static Widget resultCard({
    required String testName,
    required int totalQuestions,
    required int correctAnswers,
    required int wrongAnswers,
    required double percentage,
    required String takenTime,
    required String examTime,
    required String examDate,
    required BuildContext context,
  }) {
    final screenConfig = getScreenConfig(BoxConstraints(
      maxWidth: MediaQuery.of(context).size.width,
      maxHeight: MediaQuery.of(context).size.height,
    ), context);


    final Color correctColor = AppColors.primary;
    final Color wrongColor = AppColors.cris;
    final bool isPassed = percentage >= 60;

    return Container(
      margin: EdgeInsets.symmetric(
          horizontal: screenConfig.isTablet ? 16 : 12,
          vertical: screenConfig.isTablet ? 8 : 6
      ),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(16),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: 0.05),
            blurRadius: 10,
            offset: const Offset(0, 5),
          ),
        ],
      ),
      child: Card(
        elevation: 0,
        margin: EdgeInsets.zero,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        child: Container(
          padding: EdgeInsets.all(screenConfig.isTablet ? 16 : 12),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(16),
            gradient: LinearGradient(
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
              colors: [Colors.white, isPassed ? AppColors.primary.withValues(alpha: 0.06) : AppColors.cris.withValues(alpha: 0.05)],
            ),
          ),
          child: Row(
            children: [
              // Left side - Progress indicator
              Container(
                width: screenConfig.isTablet ? 80 : 60,
                height: screenConfig.isTablet ? 80 : 60,
                margin: EdgeInsets.only(right: screenConfig.isTablet ? 16 : 12),
                child: Stack(
                  children: [
                    SizedBox.expand(
                      child: CircularProgressIndicator(
                        value: percentage / 100,
                        strokeWidth: screenConfig.isTablet ? 8 : 6,
                        backgroundColor: Colors.grey.shade200,
                        valueColor: AlwaysStoppedAnimation<Color>(
                          isPassed ? correctColor : wrongColor,
                        ),
                      ),
                    ),
                    Center(
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Text(
                            '${percentage.toStringAsFixed(0)}%',
                            style: TextStyle(
                              fontSize: screenConfig.isTablet ? 20 : 16,
                              fontWeight: FontWeight.bold,
                              color: isPassed ? correctColor : wrongColor,
                            ),
                          ),
                          Text(
                            'Score',
                            style: TextStyle(
                              fontSize: screenConfig.isTablet ? 12 : 10,
                              color: Colors.grey.shade600,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),

              // Right side - Test info
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    // Test name and status
                    Row(
                      children: [
                        Expanded(
                          child: Text(
                            testName,
                            style: TextStyle(
                              fontSize: screenConfig.fontSizeSubtitle * 0.8,
                              fontWeight: FontWeight.bold,
                            ),
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                          ),
                        ),
                        Container(
                          padding: EdgeInsets.symmetric(
                              horizontal: 8,
                              vertical: 4
                          ),
                          decoration: BoxDecoration(
                            color: isPassed ? correctColor.withValues(alpha:0.1) : wrongColor.withValues(alpha:0.1),
                            borderRadius: BorderRadius.circular(20),
                          ),
                          child: Text(
                            isPassed ? 'PASS' : 'FAIL',
                            style: TextStyle(
                              color: isPassed ? correctColor : wrongColor,
                              fontWeight: FontWeight.bold,
                              fontSize: screenConfig.isTablet ? 14 : 10,
                            ),
                          ),
                        ),
                      ],
                    ),

                    SizedBox(height: screenConfig.isTablet ? 8 : 6),

                    // Stats in a grid
                    Row(
                      children: [
                        // Date & Time column
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              _buildCompactStat(
                                icon: Icons.calendar_month_rounded,
                                value: examDate,
                                color: Colors.black54,
                                screenConfig: screenConfig,
                              ),
                              SizedBox(height: screenConfig.isTablet ? 6 : 4),
                              _buildCompactStat(
                                icon: Icons.access_time_rounded,
                                value: "$takenTime / $examTime",
                                color: AppColors.chocolate,
                                screenConfig: screenConfig,
                              ),
                            ],
                          ),
                        ),

                        // Questions column
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              _buildCompactStat(
                                icon: Icons.check_circle_rounded,
                                value: "$correctAnswers / $totalQuestions",
                                color: correctColor,
                                screenConfig: screenConfig,
                              ),
                              SizedBox(height: screenConfig.isTablet ? 6 : 4),
                              _buildCompactStat(
                                icon: Icons.cancel_rounded,
                                value: "$wrongAnswers / $totalQuestions",
                                color: wrongColor,
                                screenConfig: screenConfig,
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  static Widget _buildCompactStat({
    required IconData icon,
    required String value,
    required Color color,
    required ScreenConfig screenConfig,
  }) {
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        Container(
          padding: EdgeInsets.all(screenConfig.isTablet ? 6 : 4),
          decoration: BoxDecoration(
            color: color.withValues(alpha:0.1),
            borderRadius: BorderRadius.circular(8),
          ),
          child: Icon(
            icon,
            color: color,
            size: screenConfig.isTablet ? 16 : 12,
          ),
        ),
        SizedBox(width: screenConfig.isTablet ? 8 : 4),
        Expanded(
          child: Text(
            value,
            style: TextStyle(
              fontSize: screenConfig.isTablet ? 14 : 12,
              fontWeight: FontWeight.w500,
            ),
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
          ),
        ),
      ],
    );
  }
}