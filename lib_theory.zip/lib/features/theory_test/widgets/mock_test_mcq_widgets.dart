import 'dart:io';
import 'package:flutter/material.dart';
import 'package:theory_test_ltd/utils/color_resources.dart';
import 'package:flutter_tts/flutter_tts.dart';

class MockTestQuestionText extends StatelessWidget {
  final String questionText;

  const MockTestQuestionText({super.key, required this.questionText});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(5),
      child: Text(
        questionText,
        style:  TextStyle(
          fontSize: 20,
          fontFamily: 'Poppins',
          fontWeight: FontWeight.bold,
          color: AppColors.teal,
        ),
      ),
    );
  }
}

class MockTestQuestionOptions extends StatelessWidget {
  final List<String> options;
  final int? selectedOption;
  final ValueChanged<int> onOptionSelected;
  final int correctAnswerIndex;

  const MockTestQuestionOptions({
    super.key,
    required this.options,
    required this.selectedOption,
    required this.onOptionSelected,
    required this.correctAnswerIndex,
  });

  @override
  Widget build(BuildContext context) {
    FlutterTts flutterTts = FlutterTts();

    Future<void> speak(String text) async {
      await flutterTts.setLanguage('en-US');
      await flutterTts.setPitch(5.0);
      await flutterTts.speak(text);
    }

    return Column(
      children: List.generate(options.length, (index) {
        final isSelected = selectedOption == index;

        return GestureDetector(
          onTap: () {

              onOptionSelected(index);

          },
          child: Container(
            margin: const EdgeInsets.symmetric(vertical: 8.0),
            padding: const EdgeInsets.all(12.0),
            decoration: BoxDecoration(
              border: Border.all(
                color: isSelected ? Colors.blue : Colors.grey,
                width: 2.0,
              ),
              borderRadius: BorderRadius.circular(8.0),
              color: Colors.white, // White background for all options
            ),
            child: Row(
              children: [
                Expanded(
                  child: Text(
                    options[index],
                    style: TextStyle(
                      fontSize: 16,
                      fontWeight: isSelected ? FontWeight.bold : FontWeight.normal,
                      color: isSelected ? Colors.blue : Colors.grey,
                    ),
                  ),
                ),
                IconButton(
                  icon: Icon(Icons.volume_up, color: isSelected ? Colors.blue : Colors.grey,), // Blue icon for selected
                  onPressed: () {
                    speak(options[index]);
                  },
                ),
              ],
            ),
          ),
        );
      }),
    );
  }
}

class MockTestImageOptions extends StatelessWidget {
  final List<String> optionImages;
  final int? selectedOption;
  final ValueChanged<int> onOptionSelected;
  final int correctAnswerIndex;

  const MockTestImageOptions({
    super.key,
    required this.optionImages,
    required this.selectedOption,
    required this.onOptionSelected,
    required this.correctAnswerIndex,
  });

  @override
  Widget build(BuildContext context) {
    return GridView.builder(
      shrinkWrap: true,
      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: 2,
      ),
      itemCount: optionImages.length,
      itemBuilder: (context, index) {
        final isSelected = selectedOption == index;

        return GestureDetector(
          onTap: () {

              onOptionSelected(index);

          },
          child: Container(
            margin: const EdgeInsets.all(8.0),
            decoration: BoxDecoration(
              border: Border.all(
                color: isSelected ? Colors.blue : Colors.grey, // Blue border for selected, grey for unselected
                width: 2.0,
              ),
              borderRadius: BorderRadius.circular(8.0),
              color: Colors.white, // Background color
            ),
            child: Image.file(File(optionImages[index])),
          ),
        );
      },
    );
  }
}

class NavigationButtons extends StatelessWidget {
  final VoidCallback? onPrevious;
  final VoidCallback? onNext;
  final VoidCallback? onFav;
  final bool isLastQuestion;
  final bool isFirstQuestion;
  final bool isFavorite;

  const NavigationButtons({
    super.key,
    required this.onPrevious,
    required this.onNext,
    required this.onFav,
    required this.isLastQuestion,
    required this.isFirstQuestion,
    required this.isFavorite,
  });

  @override
  Widget build(BuildContext context) {
    return Align(
      alignment: Alignment.bottomCenter,
      child: Padding(
        padding: const EdgeInsets.all(8.0),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          // Space between buttons
          children: [
            // Previous Button
            if (!isFirstQuestion)
              _buildFloatingButton(
                  onPressed: onPrevious,
                  icon: Icons.navigate_before,
                  iconColor: Colors.black),

            // Favorite Button
            _buildFloatingButton(
              onPressed: onFav,
              icon: isFavorite ? Icons.bookmark : Icons.bookmark_border,
              iconColor: AppColors.red,
            ),

            // Next/Finish Button
            _buildFloatingButton(
                onPressed: onNext,
                icon: isLastQuestion ? Icons.check : Icons.navigate_next,
                iconColor: Colors.black),
          ],
        ),
      ),
    );
  }


  Widget _buildFloatingButton({
    required VoidCallback? onPressed,
    required IconData icon,
    required Color iconColor,
  }) {
    return SizedBox(
      child: GestureDetector(
        onTap: onPressed,
        child: Icon(
          icon,
          size: 30,
          color: iconColor,
        ),
      ),
    );
  }
}
