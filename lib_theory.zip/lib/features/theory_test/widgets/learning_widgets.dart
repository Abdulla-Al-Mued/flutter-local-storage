import 'package:flutter/material.dart';
import 'package:theory_test_ltd/common/base_widgets/screen_config.dart';

class LearningMenuItem extends StatelessWidget {
  final String text;
  final Color color;
  final ScreenConfig screenConfig;
  final VoidCallback onTap;

   LearningMenuItem({
    super.key,
    required this.text,
    required this.color,
    required this.screenConfig,
    required this.onTap,
  });

  // Map for category names and their corresponding image paths
  final Map<String, String> topicImagePaths = {
    // Existing and Common Theory
    "Alertness": "assets/topic_image/alertness.png",
    "Attitude": "assets/topic_image/attitude.png",
    "Essential documents": "assets/topic_image/essential-documents.png",
    "Documents": "assets/topic_image/essential-documents.png",
    "Hazard awareness": "assets/topic_image/hazard-awareness.png",
    "Incidents, accidents and emergencies": "assets/topic_image/incidents-accidents-and-emergencies.png",
    "Motorway rules": "assets/topic_image/motorway-rules.png",
    "Other types of vehicle": "assets/topic_image/other-types-of-vehicle.png",
    "Other Road Users": "assets/topic_image/other-types-of-vehicle.png",
    "Road and traffic signs": "assets/topic_image/road-and-traffic-signs.png",
    "Rules of the road": "assets/topic_image/rules-of-the-road.png",
    "Safety and your vehicle": "assets/topic_image/safety-and-your-vehicle.png",
    "Safety margins": "assets/topic_image/safety-margins.png",
    "Vehicle handling": "assets/topic_image/vehicle-handling.png",
    "Vehicle loading": "assets/topic_image/vehicle-loading.png",
    "Vulnerable road users": "assets/topic_image/vulnerable-road-users.png",

    // Additional from ADI / PCV
    "Accidents": "assets/topic_image/accidents.png",
    "Braking systems": "assets/topic_image/braking-systems.png",
    "Carrying passengers": "assets/topic_image/accidents.png", // Assuming same as "Accidents"
    "Drivers' hours and rest periods": "assets/topic_image/drivers-hours-and-rest-periods.png",
    "Environmental issues": "assets/topic_image/environmental-issues.png",
    "Leaving the vehicle": "assets/topic_image/leaving-the-vehicle.png",
    "Restricted view": "assets/topic_image/restricted-view.png",
    "The driver": "assets/topic_image/the-driver.png",
    "The road": "assets/topic_image/the-road.png",
    "Vehicle condition": "assets/topic_image/vehicle-condition.png",
    "Vehicle weights and dimensions": "assets/topic_image/vehicle-weights-and-dimensions.png",

    // Band Categories (ADI)
    "Band 1 road procedure": "assets/topic_image/road-procedure.png",
    "Band 2 traffic signs and signals, car control, pedestrians, mechanical knowledge": "assets/topic_image/road-and-traffic-signs.png",
    "Band 3 driving test, disabilities, law": "assets/topic_image/driving-test.png",
    "Band 4 publications, instructional techniques": "assets/topic_image/publications.png",

    // Motorcycle specific (if needed)
    "Motorcycle loading": "assets/topic_image/vehicle-loading.png",
    "Motorcycle handling": "assets/topic_image/vehicle-handling.png",
    "Safety and your motorcycle": "assets/topic_image/safety-and-your-vehicle.png",

    // Catch-all for unknowns
    "Traffic Signs": "assets/topic_image/road-and-traffic-signs.png",
    "Band 2 traffic signs and signals": "assets/topic_image/road-and-traffic-signs.png",
    "Band 3 driving test": "assets/topic_image/driving-test.png",
    "Band 4 publications": "assets/topic_image/publications.png",
  };

  @override
  Widget build(BuildContext context) {
    // Get the image path for the text (category name)
    String? imagePath = topicImagePaths[text];

    return Container(
      margin: const EdgeInsets.symmetric(vertical: 5.0),
      padding: const EdgeInsets.all(8),
      decoration: BoxDecoration(
        color: color.withValues(alpha: 0.1),
        borderRadius: BorderRadius.circular(5),
        border: Border.all(color: color),
      ),
      child: ListTile(
        title: Row(
          mainAxisAlignment: MainAxisAlignment.start,
          children: [
            // Display the image if found, otherwise a placeholder image
            Padding(
              padding: const EdgeInsets.all(8.0),
              child: imagePath != null
                  ? Image.asset(imagePath, width: 50)  // Use the image from the map
                  : Image.asset("assets/topic_image/road-procedure.png", width: 50),  // Placeholder if no image is found
            ),
            Expanded(
              child: Text(
                text,
                style: TextStyle(
                  color: color,
                  fontSize: screenConfig.menuFontSize,
                  fontWeight: FontWeight.w700,
                ),
              ),
            ),
          ],
        ),
        onTap: onTap,
      ),
    );
  }
}
