import 'dart:async';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:theory_test_ltd/Local_database/Local_database_handler.dart';
import 'package:theory_test_ltd/features/theory_test/controllers/mock_test_controller.dart';
import 'package:theory_test_ltd/features/theory_test/domain/models/question_model.dart';
import 'package:theory_test_ltd/utils/color_resources.dart';

class MockTestQuestionProvider extends ChangeNotifier {
  final MockSet mockSet;
  final LocalDatabaseHandler databaseHandler;

  late Timer _timer;
  int _currentIndex = 0;
  bool _isLoading = false;
  Map<int, int> _userAnswers = {};
  int _totalRemainingTime; // Total time for all questions
  DateTime _startTime;
  String? _deviceId;
  bool autoNext = false;
  static const int _baseQuestionCount = 50;
  static const int _baseTimeInMinutes = 57;
  static const int _baseTimeInSeconds = _baseTimeInMinutes * 60; // 3420 seconds
  MockTestQuestionProvider(
      this.mockSet,
      this.databaseHandler,
      BuildContext context,
      ) : _totalRemainingTime = ((_baseTimeInSeconds / _baseQuestionCount) * mockSet.questions.length).round(),
        _startTime = DateTime.now() {
    _initialize(context);
  }

  bool get isLoading => _isLoading;

  Question get currentQuestion => mockSet.questions[_currentIndex];

  int get currentQuestionIndex => _currentIndex;

  bool get isLastQuestion => _currentIndex == mockSet.questions.length - 1;

  bool get isFirstQuestion => _currentIndex == 0;

  int? get selectedOption => _userAnswers[_currentIndex];

  double get progress => (_currentIndex + 1) / mockSet.questions.length;

  int get totalRemainingTime => _totalRemainingTime;

  Future<void> _initialize(BuildContext context)  async {
    _isLoading = true;
    notifyListeners();
    _startTimer(context);
    _isLoading = false;
    notifyListeners();
  }




   void _startTimer(BuildContext context) {
    _timer = Timer.periodic(const Duration(seconds: 1), (timer) {
      if (_totalRemainingTime > 0) {
        _totalRemainingTime--;
        notifyListeners();
      } else {
        _timer.cancel();
        finishTest(context: context);
      }
    });
  }

  void selectOption(BuildContext context, int optionIndex) {
    _userAnswers[_currentIndex] = optionIndex;
    notifyListeners();

  }

  void goToNextQuestion() {
    if (_currentIndex < mockSet.questions.length - 1) {
      _currentIndex++;
      notifyListeners();
    }
  }

  void goToPreviousQuestion() {
    if (_currentIndex > 0) {
      _currentIndex--;
      notifyListeners();
    }


  }

  Future<void> finishTest({BuildContext? context}) async {
    _timer.cancel();

    int correctAnswers = 0;
    int wrongAnswers = 0;

    // Calculate correct and wrong answers
    _userAnswers.forEach((questionIndex, userAnswer) {
      if (userAnswer ==
          int.parse(mockSet.questions[questionIndex].correctAnsNo) - 1) {
        correctAnswers++;
      } else {
        wrongAnswers++;
      }
    });

    // Save data to the local database
    await _saveMockTestLog(correctAnswers, wrongAnswers);
    await saveQuestionAnswers();

    await _updateAttemptStatus(mockSet.setNumber.toString(),);


      if (context != null) {
        final mockTestProvider = Provider.of<MockTestProvider>(context, listen: false);
        await mockTestProvider.fetchMockSets(); // Refresh mock sets
      }


    // If context is not null, show the result dialog
    if (context != null && context.mounted) {
      final now = DateTime.now();
      final duration = now.difference(_startTime);
      String formattedDuration = formatDuration(duration);

      showDialog(
        context: context,
        barrierDismissible: false,
        builder: (context) => AlertDialog(

          backgroundColor: Colors.white,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
          contentPadding: const EdgeInsets.all(24),
          content: Container(

            width: double.maxFinite,
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Row(
                  children: [
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            'Test Results',
                            style: TextStyle(
                              fontSize: 20,
                              fontWeight: FontWeight.bold,
                              color: Colors.black87,
                            ),
                          ),
                          const SizedBox(height: 24),
                          ResultItem(
                            label: 'Correct:',
                            value: '$correctAnswers',
                            color: Colors.green,
                          ),
                          const SizedBox(height: 12),
                          ResultItem(
                            label: 'Wrong:',
                            value: '$wrongAnswers',
                            color: Colors.redAccent,
                          ),
                          const SizedBox(height: 12),
                          ResultItem(
                            label: 'Total Q:',
                            value: '${mockSet.questions.length}',
                            color: Colors.blue,
                          ),
                          const SizedBox(height: 12),
                          ResultItem(
                            label: 'Time:',
                            value: formattedDuration,
                            color: Colors.orange,
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(width: 24),
                    SizedBox(
                      width: 120,
                      height: 120,
                      child: Stack(
                        children: [
                          SizedBox(
                            width: 120,
                            height: 120,
                            child: CircularProgressIndicator(
                              value: correctAnswers / mockSet.questions.length,
                              strokeWidth: 12,
                              backgroundColor: Colors.grey.shade200,
                              valueColor: AlwaysStoppedAnimation<Color>(
                                AppColors.primary,
                              ),
                            ),
                          ),
                          Center(
                            child: Column(
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                Text(
                                  '${(correctAnswers * 100 / mockSet.questions.length).toStringAsFixed(1)}%',
                                  style: TextStyle(
                                    fontSize: 24,
                                    fontWeight: FontWeight.bold,
                                    color:  AppColors.primary,
                                  ),
                                ),
                                Text(
                                  'Score',
                                  style: TextStyle(
                                    fontSize: 14,
                                    color: Colors.grey.shade600,
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 32),
                SizedBox(
                  width: double.infinity,
                  child: ElevatedButton(
                    onPressed: () {
                      Navigator.of(context).pop(true); // Close dialog
                      Navigator.of(context).pop(true); // Return to mock test list
                    },
                    style: ElevatedButton.styleFrom(
                      backgroundColor:  AppColors.primary,
                      padding: const EdgeInsets.symmetric(vertical: 16),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(12),
                      ),
                    ),
                    child: const Text(
                      'Finish',
                      style: TextStyle(
                        fontSize: 16,
                        fontWeight: FontWeight.w600,
                        color: Colors.white,
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      );

    }
  }




  Future<void> _saveMockTestLog(int totalCorrect, int totalWrong) async {

    _isLoading = true;

    final db = await databaseHandler.getDatabase;
    final now = DateTime.now();
    final duration = now.difference(_startTime);

    double result = mockSet.questions.isNotEmpty
        ? (totalCorrect / mockSet.questions.length) * 100
        : 0;

    await db?.insert('THT_CUST_MOCK_TEST_LOG', {
      'CUST_MOCK_TEST_LOG_ID': DateTime.now().millisecondsSinceEpoch.toString(),
      'TEST_TYPE_MST_ID': mockSet.questions.first.testTypeMstId,
      'TEST_TYPE_DTL_ID': mockSet.questions.first.testTypeDtlId,
      'DEVICE_ID': '',
      'CUST_ID': '',
      'CUST_CODE': '',
      'TOTAL_NO_OF_QUES': mockSet.questions.length.toString(),
      'TOTAL_ANSWERED_QUES': _userAnswers.length.toString(),
      'TOTAL_CORRECT_ANS': totalCorrect.toString(),
      'TOTAL_WRONG_ANS': totalWrong.toString(),
      'TOTAL_EXAM_TIME': ((_baseTimeInSeconds / _baseQuestionCount) * mockSet.questions.length).round().toString(),
      'TOTAL_TIME_TAKEN': duration.inSeconds.toString(),
      'EXAM_DATE': now.toIso8601String(),
      'STATUS': result >= 86 ? "P" : "F",
      'CREATE_DATE': now.toIso8601String(),
      'CREATE_IP': '',
    });
    _isLoading = false;

  }

  Future<void> _updateAttemptStatus(String mockTestId) async {
    final db = await databaseHandler.getDatabase;

    // Check if it's already set to 'Y'
    var result = await db?.query(
      'THRY_TEST_MOCK_SETS_QUESTION_ANS',
      where: 'MOCK_TEST_NO = ? AND ATTEMPT_MOCK = ?',
      whereArgs: [mockTestId, 'Y'],
    );

    // If it's not already set to 'Y', then update
    if (result == null || result.isEmpty) {
      await db?.update(
        'THRY_TEST_MOCK_SETS_QUESTION_ANS',
        {'ATTEMPT_MOCK': 'Y'},
        where: 'MOCK_TEST_NO = ?',
        whereArgs: [mockTestId],
      );
    }
  }



  Future<void> saveQuestionAnswers() async {
    _isLoading = true;


    final db = await databaseHandler.getDatabase;
    final now = DateTime.now();
    _timer.cancel();

    int correctAnswers = 0;
    int wrongAnswers = 0;

    // Calculate correct and wrong answers
    _userAnswers.forEach((questionIndex, userAnswer) {
      if (userAnswer ==
          int.parse(mockSet.questions[questionIndex].correctAnsNo) - 1) {
        correctAnswers++;
      } else {
        wrongAnswers++;
      }
    });


    for (var entry in _userAnswers.entries) {
      final question = mockSet.questions[entry.key];
      await db?.insert('THT_CUST_MOCK_TEST_QUES_ANS', {
        'CUST_TOPIC_MOCK_QUES_ID':
            DateTime.now().millisecondsSinceEpoch.toString(),
        'THEORY_TEST_QUESTION_ID': question.id,
        'TEST_TYPE_MST_ID': question.testTypeMstId,
        'TEST_TYPE_DTL_ID': question.testTypeDtlId,
        'TEST_TYPE_DTL_CAT_ID': question.testTypeDtlCatId,
        'TEST_TYPE_DTL_DTL_ID': question.testTypeDtlDtlId,
        'DEVICE_ID': _deviceId,
        'CUST_ID': '',
        'CUST_CODE': '',
        'CORRECT_ANS_NO': question.correctAnsNo,
        'ANSWERED_ANS_NO': (entry.value + 1).toString(),
        'STATUS': 'C',
        'CREATE_DATE': now.toIso8601String(),
        'CREATE_IP': '',
      });
      notifyListeners();
    }

    _isLoading = false;

    notifyListeners();
  }

  @override
  void dispose() {
    _timer.cancel();
    super.dispose();
  }
}

String formatDuration(Duration duration) {
  final minutes = duration.inMinutes;
  final seconds = duration.inSeconds % 60;
  return '$minutes m ${seconds.toString().padLeft(2, '0')} s';
}
class ResultItem extends StatelessWidget {
  final String label;
  final String value;
  final Color color;

  const ResultItem({
    required this.label,
    required this.value,
    required this.color,
    super.key,
  });

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Text(
          label,
          style: TextStyle(
            fontSize: 16,
            color: Colors.grey.shade600,
          ),
        ),
        Expanded(
          child: Text(
            value,
            style: TextStyle(
              fontSize: 16,
              fontWeight: FontWeight.w600,
              color: color,
            ),
          ),
        ),
      ],
    );
  }
}