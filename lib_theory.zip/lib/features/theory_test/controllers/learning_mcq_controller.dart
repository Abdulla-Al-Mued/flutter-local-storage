import 'package:flutter/material.dart';
import 'package:theory_test_ltd/Local_database/Local_database_handler.dart';
import 'package:theory_test_ltd/features/theory_test/domain/models/question_model.dart';

class QuestionProvider extends ChangeNotifier {
  final LocalDatabaseHandler _databaseHandler;
  final String categoryId;

  QuestionProvider(this._databaseHandler, this.categoryId) {
    _fetchQuestions();
  }

  List<Question> _questionList = [];
  int _currentQuestionIndex = 0;
  int? _selectedOption;
  bool _showExplanation = false;
  bool _isAnswerReadOnly = false;
  bool _isLoading = true;

  bool _isFavorite = false;

  bool get isFavorite => _isFavorite;
  bool get isLoading => _isLoading;

  List<Question> get questionList => _questionList;

  int get currentQuestionIndex => _currentQuestionIndex;

  bool get showExplanation => _showExplanation;

  int? get selectedOption => _selectedOption;

  bool get isAnswerReadOnly => _isAnswerReadOnly;

  Future<void> _fetchQuestions() async {
    try {
      _isLoading = true;
      notifyListeners();

      final db = await _databaseHandler.getDatabase;

      List<Map<String, dynamic>> questionMaps = await db!.query(
        'THRY_TEST_QUESTION_ANS',
        where: 'TEST_TYPE_DTL_CAT_ID = ?',
        whereArgs: [categoryId],
      );

      _questionList = questionMaps.map((map) => Question.fromMap(map)).toList();

      if (_questionList.isNotEmpty) {
        await checkPreviousAnswer();
      }
      _isLoading = false;
      notifyListeners();
    } catch (e) {
      _isLoading = false;
      notifyListeners();
      rethrow;
    }
  }

  Future<void> checkPreviousAnswer() async {
    final db = await _databaseHandler.getDatabase;

    final question = _questionList[_currentQuestionIndex];

    final result = await db!.query(
      'THT_CUST_TOPIC_READ_QUES_ANS',
      where: 'THEORY_TEST_QUESTION_ID = ?',
      whereArgs: [question.theoryTestQuestionId],
    );

    if (result.isNotEmpty) {
      final previousAnswer = result.first;

      final answeredAnsNo = previousAnswer['ANSWERED_ANS_NO'] as String? ?? '';

      if (answeredAnsNo.isNotEmpty) {
        _selectedOption = int.tryParse(answeredAnsNo) != null
            ? int.parse(answeredAnsNo) - 1
            : null;
        _isAnswerReadOnly = true;
        _showExplanation = true;
      } else {
        _selectedOption = null;
        _isAnswerReadOnly = false;
      }
    } else {
      _selectedOption = null;
      _isAnswerReadOnly = false;
      _showExplanation = false;
    }

    notifyListeners();
  }

  Future<void> insertAnswerData(BuildContext context, bool isCorrect) async {
    final db = await _databaseHandler.getDatabase;
    final question = _questionList[_currentQuestionIndex];

    final topicReadData = {
      'CUST_TOPIC_READ_QUES_ID': DateTime.now().millisecondsSinceEpoch.toString(),
      'THEORY_TEST_QUESTION_ID': question.theoryTestQuestionId,
      'TEST_TYPE_MST_ID': question.testTypeMstId,
      'TEST_TYPE_DTL_ID': question.testTypeDtlId,
      'TEST_TYPE_DTL_CAT_ID': question.testTypeDtlCatId,
      'TEST_TYPE_DTL_DTL_ID': question.testTypeDtlDtlId,
      'DEVICE_ID': '',
      'CUST_ID': '',
      'CUST_CODE': '',
      'CORRECT_ANS_NO': question.correctAnsNo,
      'ANSWERED_ANS_NO':
          (_selectedOption != null) ? (_selectedOption! + 1).toString() : '',
      'STATUS': isCorrect ? 'C' : 'I',
      'CREATE_DATE': DateTime.now().toString(),
      'CREATE_USER': '',
      'CREATE_IP': '',
      'UPDATE_DATE': DateTime.now().toString(),
      'UPDATE_USER': '',
      'UPDATE_IP': '1.1.1.1',
    };

    await db!.insert('THT_CUST_TOPIC_READ_QUES_ANS', topicReadData);

    if (!isCorrect) {
      final mistakeData = {
        'CUST_MISTAKE_QUES_ID':
            DateTime.now().millisecondsSinceEpoch.toString(),
        'THEORY_TEST_QUESTION_ID': question.theoryTestQuestionId,
        'TEST_TYPE_MST_ID': question.testTypeMstId,
        'TEST_TYPE_DTL_ID': question.testTypeDtlId,
        'TEST_TYPE_DTL_CAT_ID': question.testTypeDtlCatId,
        'TEST_TYPE_DTL_DTL_ID': question.testTypeDtlDtlId,
        'DEVICE_ID': '',
        'CUST_ID': '',
        'CUST_CODE': '',
        'MISTAKE_FROM': 'LEARNING',
        'STATUS': 'N',
        'CREATE_DATE': DateTime.now().toString(),
        'CREATE_USER': '',
        'CREATE_IP': '',
        'UPDATE_DATE': DateTime.now().toString(),
        'UPDATE_USER': '',
        'UPDATE_IP': '1.1.1.1',
      };

      await db.insert('THT_CUST_MISTAKE_QUES_ANS', mistakeData);
    }
  }

  Future<void> insertAnswerFav(BuildContext context, bool isFavorite) async {
    final db = await _databaseHandler.getDatabase;
    final question = _questionList[_currentQuestionIndex];

    if (isFavorite) {
      final favoriteData = {
        'CUST_FAVORITE_QUES_ID':
            DateTime.now().millisecondsSinceEpoch.toString(),
        'THEORY_TEST_QUESTION_ID': question.theoryTestQuestionId,
        'TEST_TYPE_MST_ID': question.testTypeMstId,
        'TEST_TYPE_DTL_ID': question.testTypeDtlId,
        'TEST_TYPE_DTL_CAT_ID': question.testTypeDtlCatId,
        'TEST_TYPE_DTL_DTL_ID': question.testTypeDtlDtlId,
        'DEVICE_ID': '',
        'CUST_ID': '',
        'CUST_CODE': '',
        'MISTAKE_FROM': 'LEARNING',
        'STATUS': 'N',
        'CREATE_DATE': DateTime.now().toString(),
        'CREATE_USER': '',
        'CREATE_IP': '',
        'UPDATE_DATE': DateTime.now().toString(),
        'UPDATE_USER': '',
        'UPDATE_IP': '1.1.1.1',
      };

      await db!.insert('THT_CUST_FAVORITE_QUES_ANS', favoriteData);
      _isFavorite = true; // Update favorite status
    } else {
      await db!.delete(
        'THT_CUST_FAVORITE_QUES_ANS',
        where: 'THEORY_TEST_QUESTION_ID = ?',
        whereArgs: [question.theoryTestQuestionId],
      );
      _isFavorite = false; // Update favorite status

    }

    notifyListeners(); // Notify listeners to update UI
  }

  void goToNextQuestion() {
    if (_currentQuestionIndex < _questionList.length - 1) {
      _currentQuestionIndex++;
      _showExplanation = false;
      _selectedOption = null;
      _isAnswerReadOnly = false;
      checkPreviousAnswer();
      checkFavoriteStatus();
      notifyListeners();
    }
  }

  void goToPreviousQuestion() {
    if (_currentQuestionIndex > 0) {
      _currentQuestionIndex--;
      _showExplanation = false;
      _selectedOption = null;
      _isAnswerReadOnly = false;
      checkPreviousAnswer();
      checkFavoriteStatus();
      notifyListeners();
    }
  }

  void selectOption(BuildContext context, int index) {
    if (_isAnswerReadOnly) return;

    _selectedOption = index;
    _showExplanation = true;

    final question = _questionList[_currentQuestionIndex];
    final correctAnswerIndex = int.tryParse(question.correctAnsNo) ?? 0;
    final isCorrect = _selectedOption == (correctAnswerIndex - 1);

    insertAnswerData(context, isCorrect);

    notifyListeners();
  }

  bool get isCorrectAnswer {
    final question = _questionList[_currentQuestionIndex];
    final correctAnswerIndex = int.tryParse(question.correctAnsNo);

    if (correctAnswerIndex != null && _selectedOption != null) {
      return _selectedOption == (correctAnswerIndex - 1);
    }

    return false;
  }

  void showAnswerExplanation() {
    _showExplanation = true;
    notifyListeners();
  }

  void hideAnswerExplanation() {
    _showExplanation = false;
    notifyListeners();
  }

  void finishTest(BuildContext context) {
    Navigator.pop(context);
  }

  Future<void> clearTopicReadData(BuildContext context) async {
    final db = await _databaseHandler.getDatabase;
    await db!.delete('THT_CUST_TOPIC_READ_QUES_ANS');
    Navigator.pop(context);
    notifyListeners();
  }

  Future<void> checkFavoriteStatus() async {
    final db = await _databaseHandler.getDatabase;
    final question = _questionList[_currentQuestionIndex];

    final result = await db!.query(
      'THT_CUST_FAVORITE_QUES_ANS',
      where: 'THEORY_TEST_QUESTION_ID = ?',
      whereArgs: [question.theoryTestQuestionId],
    );

    _isFavorite = result.isNotEmpty; // Set _isFavorite based on the result
    notifyListeners();
  }


  Future<void> fetchFavoriteQuestions() async {
    try {
      final db = await _databaseHandler.getDatabase;

      List<Map<String, dynamic>> favoriteQuestionMaps = await db!.query(
        'THT_CUST_FAVORITE_QUES_ANS',
      );

      List<String> favoriteQuestionIds = favoriteQuestionMaps
          .map((map) => map['THEORY_TEST_QUESTION_ID'].toString())
          .toList();

      if (favoriteQuestionIds.isNotEmpty) {
        List<Map<String, dynamic>> questionMaps = await db.query(
          'THRY_TEST_QUESTION_ANS',
          where: 'THEORY_TEST_QUESTION_ID IN (${favoriteQuestionIds.join(', ')})',
        );

        _questionList = questionMaps.map((map) => Question.fromMap(map)).toList();
      } else {
        _questionList = [];
      }

      notifyListeners();
    } catch (e) {
      rethrow;
    }
  }



}
