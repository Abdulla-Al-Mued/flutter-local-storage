import 'package:flutter/material.dart';
import 'package:sqflite/sqflite.dart';
import 'package:theory_test_ltd/Local_database/Local_database_handler.dart';
import 'package:theory_test_ltd/features/theory_test/domain/models/question_model.dart';

class MockTestProvider extends ChangeNotifier {
  final LocalDatabaseHandler databaseHandler;
  List<MockSet> _mockSets = [];
  bool _isLoading = true;
  static const int questionsPerSet = 50;

  MockTestProvider(this.databaseHandler) {
    //fetchMockSets();
  }

  List<MockSet> get mockSets => _mockSets;

  bool get isLoading => _isLoading;

  int get numberOfSets => _mockSets.length;

  Future<void> insertMockTestSetQuestionAns(String startQuestionId, String endQuestionId, String mockTestNo) async {
    final db = await databaseHandler.getDatabase;

    List<Map<String, dynamic>> existingRecords = [];

    try {
      // Ensure the where clause is properly formatted
      existingRecords = await db!.query(
        'THRY_TEST_MOCK_SETS_QUESTION_ANS',
        where: 'START_QUESTION_ID = ? AND END_QUESTION_ID = ? AND MOCK_TEST_NO = ?',
        whereArgs: [startQuestionId, endQuestionId, mockTestNo],
      );
    } catch (e) {
      print("Error executing query: ${e.toString()}");
    }

    if(existingRecords.isNotEmpty){
      return;
    }

    // Insert only if no duplicate exists
    if (existingRecords.isEmpty) {
      await db!.transaction((txn) async {
        await txn.insert(
          'THRY_TEST_MOCK_SETS_QUESTION_ANS',
          {
            'START_QUESTION_ID': startQuestionId,
            'END_QUESTION_ID': endQuestionId,
            'MOCK_TEST_NO': mockTestNo,
          },
          conflictAlgorithm: ConflictAlgorithm.ignore, // Ignore if already exists
        );
      });
    }
  }




  Future<bool> isMockTestAttempted(int setNumber) async {
    final db = await databaseHandler.getDatabase;
    List<Map<String, dynamic>> result = await db!.query(
      'THRY_TEST_MOCK_SETS_QUESTION_ANS',
      columns: ['ATTEMPT_MOCK'],
      where: 'MOCK_TEST_NO = ?',
      whereArgs: [setNumber.toString()],
    );

    if (result.isNotEmpty) {
      return result.first['ATTEMPT_MOCK'] == 'Y';  // Check if ATTEMPT_MOCK is 'Y'
    }
    return false;
  }

  // Fetch mock sets from the THRY_TEST_MOCK_SETS_QUESTION_ANS table
  Future<void> fetchMockSets() async {
    try {
      _isLoading = true;
      notifyListeners();

      final db = await databaseHandler.getDatabase;

      // Fetch all questions ordered by serial number
      List<Map<String, dynamic>> questionMaps = await db!.query(
        'THRY_TEST_QUESTION_ANS',
        columns: [
          'ID',
          'QUESTION_DESC',
          'QUESTION_IMAGE_PATH',
          'ANS1_DESC',
          'ANS1_IMAGE_PATH',
          'ANS2_DESC',
          'ANS2_IMAGE_PATH',
          'ANS3_DESC',
          'ANS3_IMAGE_PATH',
          'ANS4_DESC',
          'ANS4_IMAGE_PATH',
          'CORRECT_ANS_NO',
          'HINT_EXPLANATION',
          'QUESTION_SRL_NO'
        ],
        orderBy: 'CAST(QUESTION_SRL_NO AS INTEGER) ASC',
      );

      // Convert to Question objects
      List<Question> allQuestions = questionMaps
          .map((map) => Question.fromMap(map))
          .toList();

      // Split into sets of 50 (or remaining questions)
      _mockSets = [];
      for (var i = 0; i < allQuestions.length; i += questionsPerSet) {
        final end = (i + questionsPerSet < allQuestions.length)
            ? i + questionsPerSet
            : allQuestions.length;

        final setQuestions = allQuestions.sublist(i, end);
        final setNumber = (_mockSets.length + 1);
        final startSerial = setQuestions.first.questionSrlNo;
        final endSerial = setQuestions.last.serialNo;

        print("($startSerial - $endSerial) - $setNumber");

        _mockSets.add(MockSet(
          setNumber: setNumber,
          questions: setQuestions,
          setRange: '$startSerial-$endSerial',
          attemptMock: 'N',
        ));

        // await insertMockTestSetQuestionAns(startSerial, endSerial, setNumber.toString());
      }

      //bool isAvailable = await isMockTestSetTableEmpty();

      for (var mockSet in _mockSets) {

        // if(!isAvailable){
        //   break;
        // }

        final startSerial = mockSet.questions.first.questionSrlNo;
        final endSerial = mockSet.questions.last.serialNo;
        await insertMockTestSetQuestionAns(startSerial, endSerial, mockSet.setNumber.toString());
      }

      _isLoading = false;
      notifyListeners();
    } catch (e) {
      print(e.toString());
      _isLoading = false;
      notifyListeners();
      rethrow;
    }
  }

  MockSet getMockSet(int setIndex) {
    if (setIndex < 0 || setIndex >= _mockSets.length) {
      throw RangeError('Invalid mock set index');
    }
    return _mockSets[setIndex];
  }

  Future<bool> isMockTestSetTableEmpty() async {
    final db = await databaseHandler.getDatabase;

    try {
      List<Map<String, dynamic>> records = await db!.query(
        'THRY_TEST_MOCK_SETS_QUESTION_ANS',
        limit: 1, // Optimize by fetching only 1 record
      );

      return records.isEmpty; // Return true if empty, false otherwise
    } catch (e) {
      print("Error checking table: ${e.toString()}");
      return false; // Default to false in case of an error
    }
  }

}