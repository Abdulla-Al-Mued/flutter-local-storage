import 'package:flutter/cupertino.dart';
import 'package:theory_test_ltd/Local_database/Local_database_handler.dart';
import 'package:theory_test_ltd/features/theory_test/domain/models/category_model.dart';

class LearningProvider extends ChangeNotifier {
  final LocalDatabaseHandler _databaseHandler;

  LearningProvider(this._databaseHandler) {
    // Initially fetch data when the provider is created
    fetchCategories();
  }

  List<Category> _categoryList = [];
  List<Category> _filteredCategoryList = [];
  bool _isLoading = true;

  List<Category> get filteredCategoryList => _filteredCategoryList;
  bool get isLoading => _isLoading;

  // Method to fetch categories from the database and refresh the list
  Future<void> fetchCategories({bool forceRefresh = false}) async {
    try {
      _isLoading = true;
      notifyListeners();

      // If forceRefresh is true, clear the old category list
      if (forceRefresh) {
        _categoryList.clear();
        _filteredCategoryList.clear();
      }

      final db = await _databaseHandler.getDatabase;

      // Query the database
      List<Map<String, dynamic>> categoryMaps = await db!.query(
        'THRY_TEST_TYPE_DTL_CAT',
        columns: [
          'ID',
          'TEST_TYPE_DTL_CAT_ID',
          'TEST_TYPE_DTL_ID',
          'TEST_TYPE_MST_ID',
          'TEST_DTL_CAT_DESC',
          'TEST_TYPE_DTL_CAT_IMG_PATH',
          'STATUS',
          'CREATE_DATE',
          'CREATE_USER',
          'CREATE_IP',
          'UPDATE_DATE',
          'UPDATE_USER',
          'UPDATE_IP'
        ],
      );

      // Map the data from the database to the Category model
      _categoryList = categoryMaps.map((map) => Category.fromMap(map)).toList();
      _filteredCategoryList = _categoryList;

      _isLoading = false;
      notifyListeners();
    } catch (e) {
      _isLoading = false;
      notifyListeners();
      rethrow;
    }
  }

  // Method to search categories based on a query
  void searchCategories(String query) {
    _filteredCategoryList = _categoryList
        .where((category) => category.testDtlCatDesc
        .toLowerCase()
        .contains(query.toLowerCase()))
        .toList();
    notifyListeners();  // Ensure UI is updated after filtering
  }

  Future<void> refreshCategories() async {
    await fetchCategories();
  }

  Future<void> updateCategoryStatus(String categoryId) async {
    try {
      final db = await _databaseHandler.getDatabase;

      await db!.update(
        'THRY_TEST_TYPE_DTL_CAT',
        {'STATUS': 'Y'},
        where: 'TEST_TYPE_DTL_CAT_ID = ?',
        whereArgs: [categoryId],
      );


    } catch (e) {
      rethrow;
    }
  }
}
