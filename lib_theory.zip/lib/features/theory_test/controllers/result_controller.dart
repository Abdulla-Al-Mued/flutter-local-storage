import 'package:flutter/material.dart';
import 'package:theory_test_ltd/Local_database/Local_database_handler.dart';

class ResultsProvider with ChangeNotifier {
  List<Map<String, dynamic>> _results = [];
  bool _isLoading = false;

  List<Map<String, dynamic>> get results => _results;

  bool get isLoading => _isLoading;

  Future<void> fetchResults() async {
    try {
      _isLoading = true;
      notifyListeners();

      final dbHandler = LocalDatabaseHandler();
      _results = await dbHandler.getResultsFromMockTestLog();

      _isLoading = false;
      notifyListeners();
    } catch (e) {
      _isLoading = false;

      notifyListeners();
    }
  }
}
