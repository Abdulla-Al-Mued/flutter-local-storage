import 'package:flutter/cupertino.dart';
import 'package:theory_test_ltd/Local_database/Local_database_handler.dart';

class TheoryTestController extends ChangeNotifier {
  // The variable to store the total mistake count
  int _totalMistakes = 0;
  int get totalMistakes => _totalMistakes;

  // Create an instance of the LocalDatabaseHandler to access the database
  final LocalDatabaseHandler _databaseHandler = LocalDatabaseHandler();

  // Method to fetch the total mistake count from the database
  Future<void> fetchTotalMistakes() async {
    try {
      _totalMistakes = await _databaseHandler.getTotalMistakes(); // Fetch the total mistakes
      notifyListeners(); // Notify listeners to update the UI
    } catch (e) {
    }
  }
}
