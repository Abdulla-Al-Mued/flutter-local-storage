import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter_tts/flutter_tts.dart';
import 'package:path_provider/path_provider.dart';
import 'package:provider/provider.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:theory_test_ltd/Local_database/Local_database_handler.dart';
import 'package:theory_test_ltd/common/base_widgets/custom_app_bar.dart';
import 'package:theory_test_ltd/common/base_widgets/loading_animation.dart';
import 'package:theory_test_ltd/features/theory_test/controllers/learning_mcq_controller.dart';
import 'package:theory_test_ltd/features/theory_test/widgets/learning_mcq_widgets.dart';
import 'package:theory_test_ltd/utils/color_resources.dart';

class LearningMcqScreen extends StatefulWidget {
  final String categoryId;

  const LearningMcqScreen({super.key, required this.categoryId});

  @override
  State<LearningMcqScreen> createState() => _LearningMcqScreenState();
}

class _LearningMcqScreenState extends State<LearningMcqScreen> {
  late FlutterTts flutterTts;
  String? savedDirectoryPath;
  late Directory directory;

  @override
  void initState() {
    super.initState();
    flutterTts = FlutterTts();
    _getSavedDirectoryPath();
  }

  Future<void> _getSavedDirectoryPath() async {
    final prefs = await SharedPreferences.getInstance();
    setState(() {
      savedDirectoryPath = prefs.getString('selectedCategory');
    });
    directory = await getApplicationDocumentsDirectory();
  }

  Future<void> _speak(String text) async {
    await flutterTts.setLanguage('en-US');
    await flutterTts.setPitch(1.0);
    await flutterTts.speak(text);
  }

  @override
  Widget build(BuildContext context) {
    return ChangeNotifierProvider(
      create: (_) => QuestionProvider(
          Provider.of<LocalDatabaseHandler>(context), widget.categoryId),
      child: Consumer<QuestionProvider>(
        builder: (context, questionProvider, child) {
          if (questionProvider.isLoading) {
            return Center(child: LoadingAnimation());
          }

          if (questionProvider.questionList.isEmpty) {
            return Scaffold(    appBar: CustomAppBar(
              title: 'Learning',
              gradientColors: [
                AppColors.secondary,
                AppColors.primary,
              ],
            ),body: Center(child: Text("No questions available.")));
          }

          final question = questionProvider
              .questionList[questionProvider.currentQuestionIndex];
          final isLastQuestion = questionProvider.currentQuestionIndex ==
              questionProvider.questionList.length - 1;
          final isFirstQuestion = questionProvider.currentQuestionIndex == 0;

          return Scaffold(
            appBar: CustomAppBar(
              title: 'Learning',
              gradientColors: [
                AppColors.secondary,
                AppColors.primary,
              ],
            ),
            body: Padding(
              padding: EdgeInsets.all(16.0),
              child: SingleChildScrollView(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    LayoutBuilder(
                      builder: (context, constraints) {
                        return Row(
                          children: [
                            Expanded(
                              child: QuestionText(
                                questionText: question.questionDesc,
                              ),
                            ),
                            IconButton(
                              icon: Icon(Icons.volume_up),
                              onPressed: () => _speak(question.questionDesc),
                            ),
                          ],
                        );
                      },
                    ),
                    const SizedBox(height: 16),
                    if (question.questionImagePath.isNotEmpty &&
                        savedDirectoryPath != null)
                      Center(
                          child: Image.file(File(
                              '${directory.path}/${savedDirectoryPath?.toLowerCase()}/${question.questionImagePath.toLowerCase()}'))),
                    const SizedBox(height: 16),
                    if (question.ans1ImagePath.isNotEmpty ||
                        question.ans2ImagePath.isNotEmpty ||
                        question.ans3ImagePath.isNotEmpty ||
                        question.ans4ImagePath.isNotEmpty)
                      ImageOptions(
                        optionImages: [
                          '${directory.path}/${savedDirectoryPath?.toLowerCase()}/${question.ans1ImagePath.toLowerCase()}',
                          '${directory.path}/${savedDirectoryPath?.toLowerCase()}/${question.ans2ImagePath.toLowerCase()}',
                          '${directory.path}/${savedDirectoryPath?.toLowerCase()}/${question.ans3ImagePath.toLowerCase()}',
                          '${directory.path}/${savedDirectoryPath?.toLowerCase()}/${question.ans4ImagePath.toLowerCase()}',
                        ],
                        selectedOption: questionProvider.selectedOption,
                        onOptionSelected: (index) {
                          questionProvider.selectOption(context, index);
                        },
                        correctAnswerIndex: question.correctAnsNo == '1'
                            ? 0
                            : question.correctAnsNo == '2'
                                ? 1
                                : question.correctAnsNo == '3'
                                    ? 2
                                    : 3,
                      )
                    else if (question.ans1Desc.isNotEmpty ||
                        question.ans2Desc.isNotEmpty ||
                        question.ans3Desc.isNotEmpty ||
                        question.ans4Desc.isNotEmpty)
                      QuestionOptions(
                        options: [
                          question.ans1Desc,
                          question.ans2Desc,
                          question.ans3Desc,
                          question.ans4Desc
                        ],
                        selectedOption: questionProvider.selectedOption,
                        onOptionSelected: (index) {
                          questionProvider.selectOption(context, index);
                        },
                        correctAnswerIndex: question.correctAnsNo == '1'
                            ? 0
                            : question.correctAnsNo == '2'
                                ? 1
                                : question.correctAnsNo == '3'
                                    ? 2
                                    : 3,
                      ),
                    if (questionProvider.showExplanation)
                      ExplanationSection(
                        isCorrect: questionProvider.isCorrectAnswer,
                        explanation: question.hintExplanation,
                        rules: question.htmlRules,
                        reference: question.hintReferences,
                      ),
                  ],
                ),
              ),
            ),
            bottomNavigationBar: BottomAppBar(
              child: NavigationButtons(
                onNext: isLastQuestion
                    ? () => questionProvider.finishTest(context)
                    : questionProvider.goToNextQuestion,
                isLastQuestion: isLastQuestion,
                isFirstQuestion: isFirstQuestion,
                onPrevious: questionProvider.goToPreviousQuestion,
                onFav: () async {
                  await questionProvider.insertAnswerFav(
                      context, !questionProvider.isFavorite);
                },
                isFavorite: questionProvider.isFavorite,
                onReset: () async {
                  await questionProvider.clearTopicReadData(context);
                },
              ),
            ),
          );
        },
      ),
    );
  }
}
