import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:theory_test_ltd/common/base_widgets/custom_app_bar.dart';
import 'package:theory_test_ltd/common/base_widgets/navigate_pages.dart';
import 'package:theory_test_ltd/common/base_widgets/screen_config.dart';
import 'package:theory_test_ltd/features/theory_test/controllers/theory_test_controller.dart';
import 'package:theory_test_ltd/features/theory_test/screens/favorite_mcq_screen.dart';
import 'package:theory_test_ltd/features/theory_test/screens/learning_screen.dart';
import 'package:theory_test_ltd/features/theory_test/screens/mistake_screen.dart';
import 'package:theory_test_ltd/features/theory_test/screens/mock_test_screen.dart';
import 'package:theory_test_ltd/features/theory_test/screens/results_screen.dart';
import 'package:theory_test_ltd/features/theory_test/widgets/theory_test_widgets.dart';
import 'package:theory_test_ltd/utils/color_resources.dart';


class TheoryTestScreen extends StatelessWidget {
  const TheoryTestScreen({super.key});

  @override
  Widget build(BuildContext context) {


    return Scaffold(
      backgroundColor: AppColors.aliceBlue,
      appBar: CustomAppBar(
        title: 'Theory Test',
        gradientColors: [
          AppColors.secondary,
          AppColors.primary,
        ],
      ),
      body: LayoutBuilder(
        builder: (context, constraints) {
          final screenConfig = getScreenConfig(constraints, context);

          return Padding(
            padding: const EdgeInsets.all(10.0),
            child: SingleChildScrollView(
              child: Column(
                children: [
                  TheoryMenuItem(
                    iconBg: AppColors.harlequin,
                    icon: Icons.book,
                    text: 'Learning',
                    color: AppColors.primary,
                    screenConfig: screenConfig,
                    onTap: () {
                      navigateTo(()=> LearningScreen());
                    },
                  ),
                  TheoryMenuItem(
                    iconBg: AppColors.cris,
                    icon: Icons.edit,
                    text: 'Mock Test',
                    color: AppColors.primary,
                    screenConfig: screenConfig,
                    onTap: () {
                      navigateTo(()=> MockTestListScreen());
                    },
                  ),
                  TheoryMenuItem(
                    iconBg: AppColors.megenda,
                    icon: Icons.error,
                    text: 'Your Mistakes',
                    color: AppColors.primary,
                    screenConfig: screenConfig,
                    onTap: () async {
                      // Fetch total mistake count
                      await context.read<TheoryTestController>().fetchTotalMistakes();
                      int totalMistakes = context.read<TheoryTestController>().totalMistakes;

                      // Show custom dialog with mistake count
                      bool? exit = await showDialog<bool>(
                        context: context,
                        builder: (context) => Dialog(
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(12),
                          ),
                          backgroundColor: Colors.transparent,
                          child: Container(
                            padding: EdgeInsets.all(20),
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(12),
                              gradient: LinearGradient(
                                colors: [
                                  AppColors.secondary,
                                  AppColors.primary,
                                ],
                                begin: Alignment.topLeft,
                                end: Alignment.bottomRight,
                              ),
                            ),
                            child: Column(
                              mainAxisSize: MainAxisSize.min,
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Center(
                                  child: Text(
                                    'Your Mistakes',
                                    style: TextStyle(
                                      fontSize: 18,
                                      fontWeight: FontWeight.bold,
                                      color: Colors.white,
                                    ),
                                  ),
                                ),
                                SizedBox(height: 10),
                                Text(
                                  totalMistakes == 0
                                      ? 'You don\'t have any mistakes. Great job!'
                                      : 'You have a total of $totalMistakes mistakes. Do you want to view them?',
                                  style: TextStyle(
                                    fontSize: 16,
                                    color: Colors.white70,
                                  ),
                                  textAlign: TextAlign.center,
                                ),
                                SizedBox(height: 20),
                                Row(
                                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                                  children: [
                                    _buildDialogButton(
                                      context,
                                      'Cancel',
                                      onPressed: () {
                                        Navigator.of(context).pop(false); // Close dialog
                                      },
                                      buttonColor: AppColors.harlequin,
                                      textColor: AppColors.white,
                                    ),
                                    _buildDialogButton(
                                      context,
                                      totalMistakes == 0 ? 'OK' : 'Continue',
                                      onPressed: () {
                                        Navigator.of(context).pop(true); // Close dialog
                                        if (totalMistakes > 0) {
                                          navigateTo(() => MistakeMcqScreen()); // Navigate to the Mistake screen
                                        }
                                      },
                                      buttonColor: AppColors.red,
                                      textColor: AppColors.white,
                                    ),
                                  ],
                                ),
                              ],
                            ),
                          ),
                        ),
                      );
                      if ((exit ?? false) && totalMistakes > 0) {
                        navigateTo(() => MistakeMcqScreen());
                      }
                    },
                  ),
                  TheoryMenuItem(
                    iconBg: AppColors.teal,
                    icon: Icons.bookmark_border,
                    text: 'Bookmark Questions',
                    color: AppColors.primary,
                    screenConfig: screenConfig,
                    onTap: () {
                      navigateTo(()=> FavoriteMcqScreen());
                    },
                  ),
                  TheoryMenuItem(
                    iconBg: AppColors.orange,
                    icon: Icons.bookmark_added_outlined,
                    text: 'Result',
                    color: AppColors.primary,
                    screenConfig: screenConfig,
                    onTap: () {
                      navigateTo(()=>ResultsScreen());
                    },
                  ),
                ],
              ),
            ),
          );
        },
      ),
    );
  }
}
Widget _buildDialogButton(
    BuildContext context,
    String text, {
      required VoidCallback onPressed,
      required Color buttonColor,
      required Color textColor,
    }) {
  return ElevatedButton(
    onPressed: onPressed,
    style: ElevatedButton.styleFrom(
      backgroundColor: buttonColor,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(8),
      ),
      padding: EdgeInsets.symmetric(horizontal: 20, vertical: 10),
    ),
    child: Text(
      text,
      style: TextStyle(
        fontSize: 16,
        color: textColor,
      ),
    ),
  );
}