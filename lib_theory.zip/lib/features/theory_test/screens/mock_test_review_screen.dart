import 'package:flutter/material.dart';
import 'package:theory_test_ltd/features/theory_test/domain/models/question_model.dart';
import 'package:theory_test_ltd/Local_database/Local_database_handler.dart';

class ReviewScreen extends StatelessWidget {
  final MockSet mockSet;

   ReviewScreen({
    super.key,
    required this.mockSet,
  });

  // Cache to store answers for each question to avoid redundant DB queries
  Future<Map<int, List<Map<String, dynamic>>>>? _answersCache;

  // Function to fetch answers from the database for all questions at once
  Future<Map<int, List<Map<String, dynamic>>>> _fetchAnswers() async {
    final db = await LocalDatabaseHandler().getDatabase;
    final result = await db?.query('THT_CUST_MOCK_TEST_QUES_ANS');

    Map<int, List<Map<String, dynamic>>> answers = {};

    result?.forEach((answer) {
      final questionId = answer['THEORY_TEST_QUESTION_ID'] as int?;  // Ensure it's an int
      if (questionId != null) {
        if (!answers.containsKey(questionId)) {
          answers[questionId] = [];
        }
        answers[questionId]?.add(answer);
      }
    });

    return answers;
  }

  // Function to get the correct answer index from the correct answer number
  int _getCorrectAnswerIndex(String correctAnsNo) {
    switch (correctAnsNo) {
      case '1':
        return 0;
      case '2':
        return 1;
      case '3':
        return 2;
      case '4':
        return 3;
      default:
        return -1;  // In case of invalid answer number
    }
  }

  // Widget to build each option text with color based on correctness
  Widget _buildOptionText(
      String optionNumber,
      String optionText,
      int correctAnswerIndex,
      int answeredIndex,
      ) {
    final int optionIndex = int.parse(optionNumber) - 1;
    final bool isCorrectAnswer = correctAnswerIndex == optionIndex;
    final bool isSelectedAnswer = answeredIndex == optionIndex;

    Color optionColor = Colors.black;
    if (isCorrectAnswer) {
      optionColor = Colors.green;
    } else if (isSelectedAnswer) {
      optionColor = Colors.red;
    }

    return Row(
      children: [
        Expanded(
          child: Text(
            '$optionNumber: $optionText',
            style: TextStyle(
              color: optionColor,
              fontWeight: isCorrectAnswer || isSelectedAnswer
                  ? FontWeight.bold
                  : FontWeight.normal,
            ),
          ),
        ),
        if (isCorrectAnswer)
          Icon(Icons.check, color: Colors.green),
        if (isSelectedAnswer && !isCorrectAnswer)
          Icon(Icons.close, color: Colors.red),
      ],
    );
  }

  // Function to fetch answers for a specific question from the cache or DB
  Future<Map<int, List<Map<String, dynamic>>>> _getAnswers() async {
    if (_answersCache == null) {
      _answersCache = _fetchAnswers();
    }
    return _answersCache!;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Review Test'),
      ),
      body: FutureBuilder<Map<int, List<Map<String, dynamic>>>>(
        future: _getAnswers(),
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return Center(child: CircularProgressIndicator());
          }

          if (snapshot.hasError) {
            return Center(child: Text('Error loading data'));
          }

          final answersData = snapshot.data ?? {};
          return ListView.builder(
            itemCount: mockSet.questions.length,
            itemBuilder: (context, index) {
              final question = mockSet.questions[index];
              final correctAnswerIndex = _getCorrectAnswerIndex(question.correctAnsNo);

              final userAnswerData = answersData[question.id]?.firstWhere(
                    (answer) => answer['THEORY_TEST_QUESTION_ID'] == question.id,
                orElse: () => {'ANSWERED_ANS_NO': ''},
              ) ?? {'ANSWERED_ANS_NO': ''};

              final answeredAnsNo = userAnswerData['ANSWERED_ANS_NO']?.toString() ?? '';
              final answeredIndex = int.tryParse(answeredAnsNo) ?? -1;

              return Card(
                margin: const EdgeInsets.all(8.0),
                child: Padding(
                  padding: const EdgeInsets.all(12.0),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'Q${index + 1}: ${question.questionDesc}',
                        style: TextStyle(fontWeight: FontWeight.bold),
                      ),
                      const SizedBox(height: 8),
                      _buildOptionText('1', question.ans1Desc, correctAnswerIndex, answeredIndex),
                      _buildOptionText('2', question.ans2Desc, correctAnswerIndex, answeredIndex),
                      _buildOptionText('3', question.ans3Desc, correctAnswerIndex, answeredIndex),
                      _buildOptionText('4', question.ans4Desc, correctAnswerIndex, answeredIndex),
                    ],
                  ),
                ),
              );
            },
          );
        },
      ),
    );
  }
}
