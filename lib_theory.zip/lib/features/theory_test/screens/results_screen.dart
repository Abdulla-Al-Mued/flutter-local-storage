import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:theory_test_ltd/common/base_widgets/custom_app_bar.dart';
import 'package:theory_test_ltd/common/base_widgets/loading_animation.dart';
import 'package:theory_test_ltd/features/theory_test/controllers/result_controller.dart';
import 'package:theory_test_ltd/features/theory_test/widgets/results_widgets.dart';
import 'package:theory_test_ltd/utils/color_resources.dart';

class ResultsScreen extends StatefulWidget {
  const ResultsScreen({super.key});

  @override
  ResultsScreenState createState() => ResultsScreenState();
}

class ResultsScreenState extends State<ResultsScreen> {
  @override
  void initState() {
    super.initState();
    // Fetch results when the screen loads
    WidgetsBinding.instance.addPostFrameCallback((_) {
      Provider.of<ResultsProvider>(context, listen: false).fetchResults();
    });
  }

  // Helper function to convert seconds to "min sec" format
  String formatTime(int seconds) {
    int minutes = seconds ~/ 60; // Integer division to get the minutes
    int remainingSeconds = seconds % 60; // Get the remaining seconds
    return '$minutes m ${remainingSeconds}s'; // Format as "X min Y sec"
  }

  String formatDate(String dateTimeString) {
    // Parse the date-time string to a DateTime object
    DateTime dateTime = DateTime.parse(dateTimeString);
    // Format and return only the date part
    return "${dateTime.year}-${dateTime.month.toString().padLeft(2, '0')}-${dateTime.day.toString().padLeft(2, '0')}";
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: CustomAppBar(
        title: 'Result',
        gradientColors: [
          AppColors.secondary,
          AppColors.primary,
        ],
      ),
      body: Consumer<ResultsProvider>(
        builder: (context, provider, child) {
          final results = provider.results;

          if (provider.isLoading) {
            // If results are still loading, show the loading animation
            return Center(child: LoadingAnimation());
          }

          if (results.isEmpty) {
            // If results are empty, show "No results found"
            return Center(
              child: Text(
                'No results found',
                style: TextStyle(
                  fontSize: 18,
                  color: AppColors.primary,
                  fontWeight: FontWeight.bold,
                ),
              ),
            );
          }

          return ListView.builder(
            padding: const EdgeInsets.symmetric(vertical: 12),
            itemCount: results.length,
            itemBuilder: (context, index) {
              final result = results[index];

              // Get the time and convert to "min sec" format
              String formattedTakenTime = formatTime(int.parse(result['TOTAL_TIME_TAKEN']));
              String formattedExamTime = formatTime(int.parse(result['TOTAL_EXAM_TIME']));
              String formattedExamDate = formatDate(result['EXAM_DATE']);

              // Calculate the percentage
              double percentage = (int.parse(result['TOTAL_CORRECT_ANS']) /
                  int.parse(result['TOTAL_NO_OF_QUES'])) *
                  100;

              // Get a more user-friendly test name if possible
              String testName = result['TEST_TYPE_DTL_ID'];
              // You could potentially transform the test ID into a more readable name here
              // For example: testName = getReadableTestName(result['TEST_TYPE_DTL_ID']);

              return ResultsWidgets.resultCard(
                testName: testName,
                totalQuestions: int.parse(result['TOTAL_NO_OF_QUES']),
                correctAnswers: int.parse(result['TOTAL_CORRECT_ANS']),
                wrongAnswers: int.parse(result['TOTAL_WRONG_ANS']),
                percentage: percentage,
                takenTime: formattedTakenTime,
                examTime: formattedExamTime,
                examDate: formattedExamDate,
                context: context, // Add the required context parameter here
              );
            },
          );
        },
      ),
    );
  }
}
