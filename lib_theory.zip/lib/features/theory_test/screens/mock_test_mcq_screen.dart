import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter_tts/flutter_tts.dart';
import 'package:path_provider/path_provider.dart';
import 'package:provider/provider.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:theory_test_ltd/Local_database/Local_database_handler.dart';
import 'package:theory_test_ltd/common/base_widgets/custom_app_bar.dart';
import 'package:theory_test_ltd/common/base_widgets/loading_animation.dart';
import 'package:theory_test_ltd/features/theory_test/controllers/mock_test_mcq_controller.dart';
import 'package:theory_test_ltd/features/theory_test/domain/models/question_model.dart';
import 'package:theory_test_ltd/features/theory_test/widgets/mock_test_mcq_widgets.dart';
import 'package:theory_test_ltd/utils/color_resources.dart';

class MockTestMcqScreen extends StatefulWidget {
  final MockSet mockSet;

  const MockTestMcqScreen({
    super.key,
    required this.mockSet,
  });

  @override
  State<MockTestMcqScreen> createState() => _MockTestMcqScreenState();
}

class _MockTestMcqScreenState extends State<MockTestMcqScreen> {
  late FlutterTts flutterTts;
  String? savedDirectoryPath;
  late Directory directory;
  bool autoNext = false;

  @override
  void initState() {
    super.initState();
    flutterTts = FlutterTts();
    _getSavedDirectoryPath();
    _getAutoNextPreference();
  }

  Future<void> _speak(String text) async {
    await flutterTts.setLanguage('en-US');
    await flutterTts.setPitch(1.0);
    await flutterTts.speak(text);
  }

  Future<void> _getSavedDirectoryPath() async {
    final prefs = await SharedPreferences.getInstance();
    setState(() {
      savedDirectoryPath = prefs.getString('selectedCategory');
    });
    directory = await getApplicationDocumentsDirectory();
  }

  Future<void> _getAutoNextPreference() async {
    final prefs = await SharedPreferences.getInstance();
    setState(() {
      autoNext = prefs.getBool('autonext') ?? false;

    });
  }

  @override
  Widget build(BuildContext context) {

    return ChangeNotifierProvider(
      create: (_) => MockTestQuestionProvider(
        widget.mockSet,
        Provider.of<LocalDatabaseHandler>(context, listen: false),
        context,
      ),
      child: Consumer<MockTestQuestionProvider>(
        builder: (context, provider, child) {
          if (provider.isLoading) {
            return const Scaffold(
              body: Center(child: LoadingAnimation()),
            );
          }


          final question = provider.currentQuestion;

          return WillPopScope(
            onWillPop: () async {
              bool? exit = await showDialog<bool>(
                context: context,
                builder: (context) => Dialog(
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(12),  
                      ),
                      backgroundColor: Colors.transparent,  
                      child: Container(
                        padding: EdgeInsets.all(20),
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(12),
                          gradient: LinearGradient(
                            colors: [ AppColors.secondary,
                              AppColors.primary,],  
                            begin: Alignment.topLeft,
                            end: Alignment.bottomRight,
                          ),
                        ),
                        child: Column(
                          mainAxisSize: MainAxisSize.min,
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Center(
                              child: Text(
                                'Finish Test ?',
                                style: TextStyle(
                                  fontSize: 18,
                                  fontWeight: FontWeight.bold,
                                  color: Colors.white,
                                ),
                              ),
                            ),
                            SizedBox(height: 10),
                            Text(
                              'Finishing now will save all your progress up to this point. Are you sure you want to continue?',
                              style: TextStyle(
                                fontSize: 16,
                                color: Colors.white70,

                              ),
                              textAlign: TextAlign.center,
                            ),
                            SizedBox(height: 20),
                            Row(
                              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                              children: [
                                 
                                _buildDialogButton(
                                  context,
                                  'Cancel',
                                  onPressed: () {
                                    Navigator.of(context).pop(false);
                                  },
                                  buttonColor: AppColors.harlequin,
                                  textColor: AppColors.white,
                                ),
                                 
                                _buildDialogButton(
                                  context,
                                  'Finish',
                                  onPressed: () {

                                    provider.finishTest(context: context);

                                  },
                                  buttonColor: AppColors.red,
                                  textColor: AppColors.white,
                                ),
                              ],
                            ),
                          ],
                        ),
                      ),
                    )
              );
              return exit ?? false;
            },


            child: Scaffold(
              appBar: CustomAppBar(
                title: 'Mock Test ${widget.mockSet.setNumber}',
                gradientColors: [AppColors.secondary, AppColors.primary],
              ),


              body: Padding(
                padding: const EdgeInsets.all(16.0),
                child: Column(
                  children: [
                     
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                         
                        Text(
                          'Question ${provider.currentQuestionIndex + 1}/${widget.mockSet.questions.length}',
                          style: TextStyle(
                            color: AppColors.primary,
                            fontWeight: FontWeight.w600,
                            fontSize:
                                18,  
                          ),
                        ),

                         
                        Row(
                          children: [
                            Icon(
                              Icons.timer,  
                              color: provider.totalRemainingTime <= 15
                                  ? AppColors.red
                                  : AppColors.primary,
                              size: 20,  
                            ),
                            SizedBox(width: 8),
                             
                            TimerWidget(
                              seconds: provider.totalRemainingTime,
                              isWarning: provider.totalRemainingTime <= 15,
                            ),
                          ],
                        ),
                      ],
                    ),
                    const SizedBox(height: 8),
                    LinearProgressIndicator(
                      value: provider.progress,
                      backgroundColor: Colors.grey[200],
                      valueColor:
                          AlwaysStoppedAnimation<Color>(AppColors.primary),
                    ),
                    const SizedBox(height: 16),
                    Expanded(
                      child: SingleChildScrollView(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            LayoutBuilder(
                              builder: (context, constraints) {
                                return Row(
                                  children: [
                                    Expanded(
                                      child: MockTestQuestionText(
                                        questionText: question.questionDesc,
                                      ),
                                    ),
                                    IconButton(
                                      icon: Icon(
                                        Icons.volume_up,
                                        color: AppColors.primary,
                                      ),
                                      onPressed: () =>
                                          _speak(question.questionDesc),
                                    ),
                                  ],
                                );
                              },
                            ),
                            const SizedBox(height: 16),
                            if (question.questionImagePath.isNotEmpty &&
                                savedDirectoryPath != null)
                              Center(
                                  child: Image.file(File(
                                      '${directory.path}/${savedDirectoryPath?.toLowerCase()}/${question.questionImagePath.toLowerCase()}'))),
                            const SizedBox(height: 16),
                            if (question.ans1ImagePath.isNotEmpty ||
                                question.ans2ImagePath.isNotEmpty ||
                                question.ans3ImagePath.isNotEmpty ||
                                question.ans4ImagePath.isNotEmpty)
                              MockTestImageOptions(
                                optionImages: [
                                  '${directory.path}/${savedDirectoryPath?.toLowerCase()}/${question.ans1ImagePath.toLowerCase()}',
                                  '${directory.path}/${savedDirectoryPath?.toLowerCase()}/${question.ans2ImagePath.toLowerCase()}',
                                  '${directory.path}/${savedDirectoryPath?.toLowerCase()}/${question.ans3ImagePath.toLowerCase()}',
                                  '${directory.path}/${savedDirectoryPath?.toLowerCase()}/${question.ans4ImagePath.toLowerCase()}',
                                ],
                                selectedOption: provider.selectedOption,
                                onOptionSelected: (index) {
                                  provider.selectOption(context, index);
                                  if(autoNext == true){
                                    provider.goToNextQuestion();
                                  }

                                },
                                correctAnswerIndex: question.correctAnsNo == '1'
                                    ? 0
                                    : question.correctAnsNo == '2'
                                        ? 1
                                        : question.correctAnsNo == '3'
                                            ? 2
                                            : 3,
                              )
                            else if (question.ans1Desc.isNotEmpty ||
                                question.ans2Desc.isNotEmpty ||
                                question.ans3Desc.isNotEmpty ||
                                question.ans4Desc.isNotEmpty)
                              MockTestQuestionOptions(
                                options: [
                                  question.ans1Desc,
                                  question.ans2Desc,
                                  question.ans3Desc,
                                  question.ans4Desc
                                ],
                                selectedOption: provider.selectedOption,
                                onOptionSelected: (index) {
                                  provider.selectOption(context, index);
                                  if(autoNext == true){
                                    provider.goToNextQuestion();
                                  }

                                },
                                correctAnswerIndex: question.correctAnsNo == '1'
                                    ? 0
                                    : question.correctAnsNo == '2'
                                        ? 1
                                        : question.correctAnsNo == '3'
                                            ? 2
                                            : 3,
                              ),
                          ],
                        ),
                      ),
                    ),
                  ],
                ),
              ),
              bottomNavigationBar: BottomAppBar(
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: [
                    // Show "Previous" button if user is not on the first question
                    if (!provider.isFirstQuestion)
                      ElevatedButton(
                        style: ElevatedButton.styleFrom(
                          backgroundColor: AppColors.red,
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(12),
                          ),
                          padding: EdgeInsets.symmetric(vertical: 16, horizontal: 32),
                          elevation: 8,
                        ),
                        onPressed: provider.goToPreviousQuestion,
                        child: const Text('Previous', style: TextStyle(color: AppColors.white)),
                      ),

                    // If autoNext is false, always show "Next" button (unless it's the last question)
                    if (!autoNext && !provider.isLastQuestion)
                      ElevatedButton(
                        style: ElevatedButton.styleFrom(
                          backgroundColor: AppColors.harlequin,
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(12),
                          ),
                          padding: EdgeInsets.symmetric(vertical: 16, horizontal: 32),
                          elevation: 8,
                        ),
                        onPressed: provider.goToNextQuestion,
                        child: const Text('Next', style: TextStyle(color: AppColors.white)),
                      ),

                    // If autoNext is true, show "Next" only when option is selected and it's not the last question
                    if (autoNext && provider.selectedOption != null && !provider.isLastQuestion)
                      ElevatedButton(
                        style: ElevatedButton.styleFrom(
                          backgroundColor: AppColors.harlequin,
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(12),
                          ),
                          padding: EdgeInsets.symmetric(vertical: 16, horizontal: 32),
                          elevation: 8,
                        ),
                        onPressed: provider.goToNextQuestion,
                        child: const Text('Next', style: TextStyle(color: AppColors.white)),
                      ),

                    // Show "Finish" button if on the last question and an option is selected
                    if (provider.isLastQuestion && provider.selectedOption != null)
                      ElevatedButton(
                        style: ElevatedButton.styleFrom(
                          backgroundColor: AppColors.primary,
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(12),
                          ),
                          padding: EdgeInsets.symmetric(vertical: 16, horizontal: 32),
                          elevation: 8,
                        ),
                        onPressed: () => provider.finishTest(context: context),
                        child: const Text('Finish', style: TextStyle(color: AppColors.white)),
                      ),
                  ],
                ),
              ),


            ),
          );
        },
      ),
    );
  }
}

class TimerWidget extends StatelessWidget {
  final int seconds;
  final bool isWarning;

  const TimerWidget({
    super.key,
    required this.seconds,
    required this.isWarning,
  });

  @override
  Widget build(BuildContext context) {
    final minutes = seconds ~/ 60;
    final remainingSeconds = seconds % 60;

    return Text(
      '$minutes:${remainingSeconds.toString().padLeft(2, '0')}',
      style: TextStyle(
        color: isWarning ? Colors.red : AppColors.primary,
        fontWeight: FontWeight.bold,
        fontSize: 18,
      ),
    );
  }
}
Widget _buildDialogButton(
    BuildContext context,
    String text, {
      required VoidCallback onPressed,
      required Color buttonColor,
      required Color textColor,
    }) {
  return ElevatedButton(
    onPressed: onPressed,
    style: ElevatedButton.styleFrom(
      backgroundColor: buttonColor,  
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(8),  
      ),
      padding: EdgeInsets.symmetric(horizontal: 20, vertical: 10),  
    ),
    child: Text(
      text,
      style: TextStyle(
        fontSize: 16,
        color: textColor,
      ),
    ),
  );
}
