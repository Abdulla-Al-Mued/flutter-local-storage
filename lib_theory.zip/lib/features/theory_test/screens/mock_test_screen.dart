import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:theory_test_ltd/common/base_widgets/custom_app_bar.dart';
import 'package:theory_test_ltd/common/base_widgets/loading_animation.dart';
import 'package:theory_test_ltd/features/theory_test/controllers/mock_test_controller.dart';
import 'package:theory_test_ltd/features/theory_test/domain/models/question_model.dart';
import 'package:theory_test_ltd/features/theory_test/screens/mock_test_mcq_screen.dart';
import 'package:theory_test_ltd/utils/color_resources.dart';

class MockTestListScreen extends StatefulWidget {
  const MockTestListScreen({super.key});

  @override
  State<MockTestListScreen> createState() => _MockTestListScreenState();
}

class _MockTestListScreenState extends State<MockTestListScreen> {
  bool autoNext = false; // Default value

  @override
  void initState() {
    super.initState();
    // Call fetchCategories() to ensure data is refreshed when the screen is opened
    Future.delayed(Duration.zero, () {
      Provider.of<MockTestProvider>(context, listen: false).fetchMockSets();
    });
    _getAutoNextPreference();

  }

  Future<void> _getAutoNextPreference() async {
    final prefs = await SharedPreferences.getInstance();
    setState(() {
      autoNext = prefs.getBool('autonext') ?? false;

      print(autoNext);

    });
  }

  void startDialog(BuildContext context, {required MockSet mockSet}) {

    const int _baseQuestionCount = 50;
    const int _baseTimeInSeconds = 57 * 60; // 57 minutes in seconds

    // Calculate total time based on question count
    int totalSeconds = ((_baseTimeInSeconds / _baseQuestionCount) * mockSet.questions.length).round();

    // Convert to minutes:seconds format
    String formatTime(int seconds) {
      final minutes = (seconds / 60).floor();
      final remainingSeconds = seconds % 60;
      return '$minutes:${remainingSeconds.toString().padLeft(2, '0')}';
    }

    String timeDisplay = formatTime(totalSeconds);
    String perQuestionTime = formatTime((_baseTimeInSeconds / _baseQuestionCount).round());


    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (BuildContext context) {
        return StatefulBuilder(
          builder: (BuildContext context, StateSetter setState) {
            return Dialog(
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(24),
              ),
              elevation: 10,
              backgroundColor: Colors.transparent,
              child: Stack(
                children: [
                  BackdropFilter(
                    filter: ImageFilter.blur(sigmaX: 10, sigmaY: 10),
                    child: Container(
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(24),
                        color:AppColors.primary.withAlpha(50),
                        boxShadow: [
                          BoxShadow(
                            color: Colors.black.withAlpha(100),
                            blurRadius: 15,
                            offset: Offset(0, 10),
                          ),
                        ],
                        border: Border.all(
                          color: Colors.white.withAlpha(100),
                          width: 1.5,
                        ),
                      ),
                      child: Padding(
                        padding: const EdgeInsets.all(24),
                        child: Column(
                          mainAxisSize: MainAxisSize.min,
                          crossAxisAlignment: CrossAxisAlignment.center,
                          children: [
                            Text(
                              'Start the Test!',
                              style: TextStyle(
                                color: Colors.white,
                                fontWeight: FontWeight.bold,
                                fontSize: 26,
                              ),
                            ),
                            SizedBox(height: 16),
                            Text(
                              '''You are about to begin a limited-time mock test. 
You can change your answers during the test, but once you finish, your results will be displayed. 
If you exit the test in the middle, your progress will not be saved.\n
You have ${mockSet.questions.length} Questions and $timeDisplay minute time''',
                              textAlign: TextAlign.center,
                              style: TextStyle(
                                color: AppColors.primary200,
                                fontSize: 18,
                              ),
                            ),
                            SizedBox(height: 30),

                            // Auto-Next Toggle
                            Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                Text(
                                  'Auto-Next Question',
                                  style: TextStyle(
                                    color: Colors.yellow,
                                    fontWeight: FontWeight.bold,
                                    fontSize: 16,
                                  ),
                                ),
                                SizedBox(width: 8),
                                Switch(
                                  value: autoNext,
                                  onChanged: (value) async {
                                    setState(() {
                                      autoNext = value; // Update the local variable
                                    });
                                    SharedPreferences prefs = await SharedPreferences.getInstance();
                                    await prefs.setBool('autonext', autoNext); // Save the state in SharedPreferences
                                  },
                                  activeColor: Colors.yellow,
                                ),
                              ],
                            ),
                            SizedBox(height: 40),

                            // Start Test Button
                            ElevatedButton(
                              onPressed: () async {
                                Navigator.pop(context);
                                Navigator.push(
                                  context,
                                  MaterialPageRoute(
                                    builder: (context) => MockTestMcqScreen(
                                      mockSet: mockSet,
                                    ),
                                  ),
                                );
                              },
                              style: ElevatedButton.styleFrom(
                                foregroundColor: Colors.white,
                                backgroundColor:AppColors.primary,
                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(12),
                                ),
                                padding: EdgeInsets.symmetric(vertical: 12, horizontal: 40),
                                elevation: 8,
                              ),
                              child: Text(
                                "Let's Start",
                                style: TextStyle(
                                  fontSize: 18,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            );
          },
        );
      },
    );
  }



  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: CustomAppBar(
        title: 'Mock Tests',
        gradientColors: [
          AppColors.secondary,
          AppColors.primary,
        ],
      ),
      body: Consumer<MockTestProvider>(
        builder: (context, provider, child) {
          if (provider.isLoading) {
            return const Center(child: LoadingAnimation());
          }

          if (provider.mockSets.isEmpty) {
            return const Center(
              child: Text('No mock tests available. \nPlease download data from manage',textAlign: TextAlign.center,    style: TextStyle(
                fontSize: 18,
                color: AppColors.primary,
                fontWeight: FontWeight.bold,
              ),),
            );
          }

          return Padding(
            padding: const EdgeInsets.all(16.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Available Mock Tests',
                  style: Theme.of(context).textTheme.headlineSmall?.copyWith(
                    color: AppColors.primary,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                const SizedBox(height: 16),
                Expanded(
                  child: GridView.builder(
                    gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                      crossAxisCount: 2,
                      crossAxisSpacing: 16,
                      mainAxisSpacing: 16,
                      childAspectRatio: 1.5,
                    ),
                    itemCount: provider.numberOfSets,
                    itemBuilder: (context, index) {
                      final mockSet = provider.mockSets[index];
                    //  bool isAttempted = mockSet.attemptMock == 'Y';
                      return FutureBuilder<bool>(
                        future: provider.isMockTestAttempted(mockSet.setNumber),
                        builder: (context, snapshot) {
                          final isAttempted = snapshot.data ?? false;

                          return InkWell(
                            onTap: () {
                              startDialog(context , mockSet: mockSet);
                            },
                            child: Container(
                              decoration: BoxDecoration(
                                gradient: LinearGradient(
                                  colors: isAttempted
                                      ? [
                                    AppColors.pink,  // Color if ATTEMPT_MOCK == 'N'
                                    AppColors.red,
                                  ] : [
                                    AppColors.primary.withAlpha(200),  // Color if ATTEMPT_MOCK == 'Y'
                                    AppColors.secondary.withAlpha(230),
                                  ],
                                ),
                                borderRadius: BorderRadius.circular(12),
                                boxShadow: [
                                  BoxShadow(
                                    color: AppColors.primary.withAlpha(100),
                                    blurRadius: 8,
                                    offset: const Offset(0, 4),
                                  ),
                                ],
                              ),
                              child: Column(
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  Text(
                                    'Mock Test ${mockSet.setNumber}',
                                    style: TextStyle(
                                      color: isAttempted
                                          ?AppColors.white : AppColors.yellow ,
                                      fontSize: 20,
                                      fontWeight: FontWeight.bold,
                                    ),
                                  ),
                                  Text(
                                    '(${mockSet.questions.length} questions)',
                                    style: const TextStyle(
                                      color: AppColors.gainsBg,
                                      fontSize: 14,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          );
                        },
                      );
                    },
                  ),
                ),
              ],
            ),
          );
        },
      ),
    );
  }
}