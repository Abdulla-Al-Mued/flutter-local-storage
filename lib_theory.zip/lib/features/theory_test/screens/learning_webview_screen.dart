import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:webview_flutter/webview_flutter.dart';
import 'package:theory_test_ltd/common/base_widgets/custom_app_bar.dart';
import 'package:theory_test_ltd/common/base_widgets/loading_animation.dart';
import 'package:theory_test_ltd/utils/color_resources.dart';

class LearningWebViewScreen extends StatefulWidget {
  final String htmlAssetPath;

  const LearningWebViewScreen({super.key, required this.htmlAssetPath});

  @override
  State<LearningWebViewScreen> createState() => _LearningWebViewScreenState();
}

class _LearningWebViewScreenState extends State<LearningWebViewScreen> {
  var isLoading = ValueNotifier<bool>(true);
  late WebViewController controller;

  @override
  void initState() {
    super.initState();
    _loadWebView();
  }

  Future<bool> doesAssetExist(String assetPath) async {
    try {
      await rootBundle.load(assetPath);
      return true;
    } catch (e) {
      return false;
    }
  }

  void _loadWebView() async {
    String assetPath = 'assets/html/${widget.htmlAssetPath.toLowerCase()}.html';
    bool exists = await doesAssetExist(assetPath);

    if (exists) {
      controller = WebViewController()
        ..setJavaScriptMode(JavaScriptMode.unrestricted)
        ..loadFlutterAsset(assetPath);

      controller.setNavigationDelegate(
        NavigationDelegate(onPageFinished: (String url) async {
          isLoading.value = false;
        }),
      );
    } else {
      print("Error: Asset $assetPath not found!");
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: CustomAppBar(
        title: 'Rules',
        gradientColors: [
          AppColors.secondary,
          AppColors.primary,
        ],
      ),
      body: ValueListenableBuilder<bool>(
        valueListenable: isLoading,
        builder: (context, value, _) {
          return Stack(
            children: <Widget>[
              if (!value) WebViewWidget(controller: controller),
              if (value) const Center(child: LoadingAnimation()),
            ],
          );
        },
      ),
    );
  }
}
