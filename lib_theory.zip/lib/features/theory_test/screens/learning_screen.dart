import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:theory_test_ltd/common/base_widgets/custom_app_bar.dart';
import 'package:theory_test_ltd/common/base_widgets/navigate_pages.dart';
import 'package:theory_test_ltd/common/base_widgets/screen_config.dart';
import 'package:theory_test_ltd/features/theory_test/controllers/learning_controller.dart';
import 'package:theory_test_ltd/features/theory_test/screens/learning_mcq_screen.dart';
import 'package:theory_test_ltd/features/theory_test/widgets/learning_widgets.dart';
import 'package:theory_test_ltd/utils/color_resources.dart';

class LearningScreen extends StatefulWidget {

  LearningScreen({super.key});

  @override
  State<LearningScreen> createState() => _LearningScreenState();
}

class _LearningScreenState extends State<LearningScreen> {
  final TextEditingController searchController = TextEditingController();

  @override
  void initState() {
    super.initState();
    // Call fetchCategories() to ensure data is refreshed when the screen is opened
    Future.delayed(Duration.zero, () {
      Provider.of<LearningProvider>(context, listen: false).fetchCategories();
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: CustomAppBar(
        title: 'Learning',
        gradientColors: [
          AppColors.secondary,
          AppColors.primary,
        ],
      ),
      body: LayoutBuilder(
        builder: (context, constraints) {
          final screenConfig = getScreenConfig(constraints, context);
          return Padding(
            padding: const EdgeInsets.all(10.0),
            child: Column(
              children: [
                // Search Bar
                TextField(
                  controller: searchController,
                  onChanged: (value) {
                    Provider.of<LearningProvider>(context, listen: false)
                        .searchCategories(value);
                  },
                  decoration: InputDecoration(
                    hintText: 'Search...',
                    prefixIcon:
                        const Icon(Icons.search, color: AppColors.primary),
                    hintStyle: TextStyle(color: AppColors.primary),
                    // Hint text color

                    enabledBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(10),
                      borderSide: BorderSide(color: AppColors.primary),
                    ),

                    focusedBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(10),
                      borderSide:
                          BorderSide(color: AppColors.primary, width: 2.0),
                    ),

                    // Set other customization if needed
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(10),
                    ),
                  ),
                ),
                const SizedBox(height: 10),

                // Categories List
                Consumer<LearningProvider>(
                  builder: (context, provider, child) {
                    if (provider.isLoading) {
                      return const Center(child: CircularProgressIndicator());
                    } else if (provider.filteredCategoryList.isEmpty) {
                      return const Center(child: Text('No categories found. \nPlease download data from manage',textAlign: TextAlign.center,    style: TextStyle(
                        fontSize: 18,
                        color: AppColors.primary,
                        fontWeight: FontWeight.bold,
                      ),));
                    } else {
                      return Expanded(
                        child: ListView.builder(
                          itemCount: provider.filteredCategoryList.length,
                          itemBuilder: (context, index) {
                            final category =
                                provider.filteredCategoryList[index];
                            return LearningMenuItem(
                              text: category.testDtlCatDesc,
                              color: AppColors.primary,
                              screenConfig: screenConfig,
                              onTap: () {
                                String categoryId = category.testTypeDtlCatId;
                                provider.updateCategoryStatus(categoryId);

                                navigateTo(()=> LearningMcqScreen( categoryId: categoryId,));
                              },
                            );
                          },
                        ),
                      );
                    }
                  },
                ),
              ],
            ),
          );
        },
      ),
    );
  }
}
