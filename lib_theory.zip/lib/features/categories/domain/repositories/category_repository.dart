import 'package:theory_test_ltd/features/categories/domain/models/category_model.dart';
import 'package:theory_test_ltd/features/categories/domain/services/category_services.dart';

class CategoryRepository {
  final CategoryService categoryService;

  CategoryRepository(this.categoryService);

  Future<List<CategoryModel>> getCategories() async {
    return await categoryService.fetchCategories();
  }
}
