import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:theory_test_ltd/features/categories/domain/models/category_model.dart';
import 'package:theory_test_ltd/utils/api_constant.dart';

class CategoryService {
  final String apiUrl = "$baseUrlImage/theory_exam/theory_test_type_dtl_reg.php";

  Future<List<CategoryModel>> fetchCategories() async {
    try {
      final response = await http.get(Uri.parse(apiUrl));

      if (response.statusCode == 200) {
        List<dynamic> data = json.decode(response.body);

        // Parse the JSON data and map it to CategoryModel
        List<CategoryModel> categories = data
            .map((json) => CategoryModel.fromJson(json))
            .toList();
        return categories;
      } else {
        throw Exception('Failed to load categories');
      }
    } catch (e) {
      throw Exception('Error: $e');
    }
  }
}
