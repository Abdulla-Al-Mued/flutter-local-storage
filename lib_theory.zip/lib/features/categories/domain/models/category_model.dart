class CategoryModel {
  final String id;
  final String description;
  final String imagePath;
  final String imgLocName;

  CategoryModel({
    required this.id,
    required this.description,
    required this.imagePath,
    required this.imgLocName,
  });

  factory CategoryModel.fromJson(Map<String, dynamic> json) {
    return CategoryModel(
      id: json['TEST_TYPE_DTL_ID'] ?? '',
      description: json['TEST_DTL_DESC'] ?? '',
      imagePath: json['IMG_PATH_NAME'] ?? '', // Image Path from API
      imgLocName: json['IMG_LOC_NAME'] ?? '',          // Local image code
    );
  }
}
