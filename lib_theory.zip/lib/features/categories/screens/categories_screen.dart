import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:theory_test_ltd/common/base_widgets/custom_app_bar.dart';
import 'package:theory_test_ltd/common/base_widgets/screen_config.dart';
import 'package:theory_test_ltd/data/network/download_data/controller/download_controller.dart';
import 'package:theory_test_ltd/features/categories/domain/models/category_model.dart';
import 'package:theory_test_ltd/features/categories/domain/repositories/category_repository.dart';
import 'package:theory_test_ltd/features/categories/domain/services/category_services.dart';
import 'package:theory_test_ltd/features/categories/widgets/categories_widgets.dart';
import 'package:theory_test_ltd/features/dashboard/screens/dashboard_screen.dart';
import 'package:theory_test_ltd/utils/api_constant.dart';
import 'package:theory_test_ltd/utils/color_resources.dart';

import '../../../Local_database/data_fetching_and_setup.dart';
import '../../../common/base_widgets/downloading_ui.dart';
import '../widgets/data_clear_alert.dart';


class CategoriesScreen extends StatefulWidget {
  const CategoriesScreen({super.key});

  @override
  State<CategoriesScreen> createState() => _CategoriesScreenState();
}

class _CategoriesScreenState extends State<CategoriesScreen> {
  String? selectedCategory;
  String? previousCategory;
  String? categoryCode;
  var downloadController;
  late CategoryRepository categoryRepository;
  Future<List<CategoryModel>>? _categoriesFuture;



  @override
  void initState() {
    super.initState();
    categoryRepository = CategoryRepository(CategoryService());
    generateTable();
    initController();
    _categoriesFuture = CategoryService().fetchCategories();
    loadPreviousCategory();
  }

  Future<void> loadPreviousCategory() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    String? previousCategory1 = prefs.getString('selectedCategory');

    if (previousCategory1 != null && previousCategory1.isNotEmpty) {
      setState(() {
        previousCategory = previousCategory1;
      });
    }
  }

  Future<void> generateTable() async {
    await tableGenerator();
  }

  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(
      builder: (context, constraints) {
        final screenConfig = getScreenConfig(constraints, context);

        return Scaffold(
          extendBody: true,
          backgroundColor: AppColors.cate,
          appBar: CustomAppBar(
            title: 'Category',
            gradientColors: [
              AppColors.iceGreen,
              AppColors.iceGreenLight,
            ],
          ),
          body: Stack(
            children: [
              // Background image
              Positioned.fill(
                child: Image.asset(
                  'assets/images/ic_category_img.jpg',
                  fit: BoxFit.cover,
                ),
              ),

              // Gradient overlay
              Positioned.fill(
                child: Container(
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      colors: AppColors.cole,
                      begin: Alignment.topCenter,
                      end: Alignment.bottomCenter,
                    ),
                  ),
                ),
              ),

              // Foreground content wrapped with SizedBox.expand
              SizedBox.expand(
                child: Consumer<DownloadController>(
                  builder: (BuildContext context, DownloadController value, Widget? child) {
                    return value.isLoading
                        ? LoadingAnimationDownload()
                        : FutureBuilder<List<CategoryModel>>(
                      future: _categoriesFuture,
                      builder: (context, snapshot) {
                        if (snapshot.connectionState == ConnectionState.waiting) {
                          return Center(child: CircularProgressIndicator());
                        } else if (snapshot.hasError) {
                          return Center(child: Text('Error: ${snapshot.error}'));
                        } else if (snapshot.hasData) {
                          final categories = snapshot.data!;
                          return SingleChildScrollView(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                const SizedBox(height: 20),
                                Center(
                                  child: CategorySelectionMessage(
                                    selectedCategory: selectedCategory,
                                    categories: categories,
                                  ),
                                ),
                                Container(
                                  alignment: Alignment.center,
                                  margin: const EdgeInsets.only(top: 30),
                                  padding: const EdgeInsets.all(10.0),
                                  child: GridView.builder(
                                    shrinkWrap: true,

                                    physics: const NeverScrollableScrollPhysics(),
                                    gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                                      crossAxisCount: screenConfig.gridCrossAxisCount,
                                      childAspectRatio: 1.20,
                                      crossAxisSpacing: 5,
                                      mainAxisSpacing: 5,
                                    ),
                                    itemCount: categories.length,
                                    itemBuilder: (context, index) {
                                      final category = categories[index];

                                      return CategoryCard(
                                        category: category.imgLocName,
                                        image: '$baseUrlImage/${category.imagePath}',
                                        isSelected: selectedCategory == category.imgLocName,
                                        previousCategory: previousCategory == category.imgLocName,
                                        onTap: () {
                                          setState(() {
                                            selectedCategory = category.imgLocName;
                                          });
                                        },
                                        screenConfig: screenConfig,
                                      );
                                    },
                                  ),
                                ),
                              ],
                            ),
                          );
                        } else {
                          return const Center(child: Text("No categories available"));
                        }
                      },
                    );
                  },
                ),
              ),
            ],
          ),


          bottomNavigationBar: selectedCategory != null
              ? Consumer<DownloadController>(
                builder: (BuildContext context, DownloadController value, Widget? child) {
                  return !value.isLoading?Container(
                    color: Colors.transparent, // You can adjust the background color
                    margin: EdgeInsets.only(bottom: 60, left: 20, right: 20),
                    child: ElevatedButton(
                      onPressed: () async {
                        if (_categoriesFuture == null) return; // Safety check

                        List<CategoryModel>? categories = await _categoriesFuture;
                        if (categories == null || categories.isEmpty) return; // If no data, exit

                        final selectedCategoryModel = categories.firstWhere(
                              (category) => category.imgLocName == selectedCategory,
                          //orElse: () => CategoryModel(id: '', imgLocName: '', imagePath: ''), // Provide a default
                        );

                        if (selectedCategoryModel.id.isEmpty) {
                          print("Selected category not found!");
                          return;
                        }

                        SharedPreferences prefs = await SharedPreferences.getInstance();
                        String previousCategory = prefs.getString('selectedCategory') ?? "";

                        print('Previous Category: $previousCategory');
                        print("Selected Category ID: ${selectedCategoryModel.id}");
                        print("Selected Category Name: $selectedCategory");

                        await prefs.setString('selectedCategory', selectedCategory!);

                        if(previousCategory.isNotEmpty){
                          String result = await showDeleteDialog(
                              context,
                              'Downloading new data will erase all existing progress and data. Are you sure you want to continue?',
                              'Confirm Download'
                          );
                          if (result == 'n') {
                            return;
                          }
                        }


                        bool success = await downloadController.downloadData(
                          selectedCategoryModel.id,
                          selectedCategory?.toLowerCase(),
                          previousCategory.toLowerCase(),
                        );

                        if (success) {


                          Navigator.pushAndRemoveUntil(
                            context,
                            MaterialPageRoute(builder: (context) => DashboardScreen()),
                                (Route<dynamic> route) => false,  // This removes all previous routes
                          );
                        } else {
                          print("Download failed!");
                        }
                      },
                      style: ElevatedButton.styleFrom(
                        backgroundColor: AppColors.coral,
                        padding: const EdgeInsets.symmetric(
                          horizontal: 50,
                          vertical: 15,
                        ),
                        textStyle: const TextStyle(fontSize: 18),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(10),
                        ),
                      ),
                      child: Text(
                        'Start Download',
                        style: TextStyle(color: AppColors.white, fontWeight: FontWeight.w600),
                      ),
                    ),
                  ):Container();
                },
              )
              : null, // If no category is selected, don't show anything

          // bottomNavigationBar: selectedCategory != null?:Container(),
        );
      },
    );
  }

  void initController() {
    downloadController = Provider.of<DownloadController>(context, listen: false);
  }
}
