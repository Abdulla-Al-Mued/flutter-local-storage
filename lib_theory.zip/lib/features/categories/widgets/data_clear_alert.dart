import 'package:flutter/material.dart';
import '../../../utils/color_resources.dart';

Future<String> showDeleteDialog(BuildContext context , String content, String heading) async {
  bool? result = await showDialog<bool>(
    context: context,
    builder: (context) => Dialog(
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(12),
      ),
      backgroundColor: Colors.transparent,
      child: Container(
        padding: EdgeInsets.all(20),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(12),
          gradient: LinearGradient(
            colors: [AppColors.secondary, AppColors.primary],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Center(
              child: Text(
                heading,
                style: TextStyle(
                  fontSize: 18,
                  fontWeight: FontWeight.bold,
                  color: Colors.white,
                ),
              ),
            ),
            SizedBox(height: 10),
            Text(
              content,
              style: TextStyle(
                fontSize: 16,
                color: Colors.white70,
              ),
              textAlign: TextAlign.center,
            ),
            SizedBox(height: 20),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                _buildDialogButton(
                  context,
                  'Cancel',
                  onPressed: () {
                    Navigator.of(context).pop(false); // Return false
                  },
                  buttonColor: AppColors.harlequin,
                  textColor: AppColors.white,
                ),
                _buildDialogButton(
                  context,
                  'Proceed',
                  onPressed: () {
                    Navigator.of(context).pop(true); // Return true
                  },
                  buttonColor: AppColors.red,
                  textColor: AppColors.white,
                ),
              ],
            ),
          ],
        ),
      ),
    ),
  );

  return result == true ? 'y' : 'n'; // Return 'y' for Proceed, 'n' for Cancel
}

Widget _buildDialogButton(
    BuildContext context,
    String text, {
      required VoidCallback onPressed,
      required Color buttonColor,
      required Color textColor,
    }) {
  return ElevatedButton(
    onPressed: onPressed,
    style: ElevatedButton.styleFrom(
      backgroundColor: buttonColor,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(8),
      ),
      padding: EdgeInsets.symmetric(horizontal: 20, vertical: 10),
    ),
    child: Text(
      text,
      style: TextStyle(
        fontSize: 16,
        color: textColor,
      ),
    ),
  );
}
