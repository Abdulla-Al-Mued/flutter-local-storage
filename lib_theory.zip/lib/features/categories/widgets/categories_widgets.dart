import 'dart:ui';

import 'package:flutter/material.dart';
import 'package:theory_test_ltd/common/base_widgets/screen_config.dart';
import 'package:theory_test_ltd/features/categories/domain/models/category_model.dart';

import '../../../utils/color_resources.dart';

class CategoryCard extends StatelessWidget {
  final String category;
  final String image;
  final bool isSelected;
  final VoidCallback onTap;
  final ScreenConfig screenConfig;
  final bool previousCategory;

  const CategoryCard({
    super.key,
    required this.category,
    required this.image,
    required this.isSelected,
    required this.onTap,
    required this.screenConfig,
    required this.previousCategory,
  });

  @override
  Widget build(BuildContext context) {
    print("hjhkjh$previousCategory");
    return GestureDetector(
      onTap: onTap,
      child: Card(
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(10),
          side: BorderSide(
            color: previousCategory ? AppColors.white : (isSelected ? Colors.white : Colors.white),
            width: 1,
          ),
        ),
        elevation: 5,
        color: previousCategory
            ? AppColors.iceGreenLight200.withAlpha(90) // Green background if previousCategory is not null
            : (isSelected
            ? AppColors.red.withAlpha(90)
            : AppColors.white.withAlpha(90)),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
            width: screenConfig.categoryIconSize, height: screenConfig.categoryIconSize,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.all(Radius.circular(5)),
                image: DecorationImage(
                    image: NetworkImage(image),
                    fit: BoxFit.fill,
                ),
              ),
            //   child: Image.network(
            //       image,
            //
            // ),
            ),
            const SizedBox(height: 5),
            Text(
              category.toUpperCase(),
              style: TextStyle(
                fontSize: screenConfig.fontSizeCategory,
                fontWeight: FontWeight.bold,
                color:previousCategory || isSelected ?Colors.white: Colors.black.withValues(alpha: 0.7),
              ),
            ),
          ],
        ),
      ),
    );
  }
}


class CategorySelectionMessage extends StatelessWidget {
  final String? selectedCategory;
  final List<CategoryModel> categories;

  const CategorySelectionMessage({
    super.key,
    required this.selectedCategory,
    required this.categories,
  });

  @override
  Widget build(BuildContext context) {
    if (selectedCategory == null) {
      return Container(
        margin: EdgeInsets.only(top: 20, bottom: 40),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(12),
          border: Border.all(
            color: Colors.blue.withValues(alpha:0.3),
            width: 2,
          ),
          color: Colors.blue.withValues(alpha:0.1),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withValues(alpha:0.13),
              blurRadius: 10,
              spreadRadius: 2,
              offset: Offset(0, 4),
            ),
          ],
        ),
        child: ClipRRect(
          borderRadius: BorderRadius.circular(12),
          child: BackdropFilter(
            filter: ImageFilter.blur(sigmaX: 10, sigmaY: 10),
            child: Padding(
              padding: const EdgeInsets.all(12.0),
              child: Column(
                children: [
                  Text(
                    'CHOSE A CATEGORY',
                    style: TextStyle(
                      fontSize: 18, // Use appropriate font size
                      fontWeight: FontWeight.bold,
                      color: Colors.white,
                    ),
                    textAlign: TextAlign.center,
                  ),
                  //const SizedBox(height: 8),
                  // Text(
                  //   'Please be patient,\n download the necessary \n data for  offline use.\n This may take a few moments',
                  //   style: TextStyle(
                  //     fontSize: 16, // Adjust the font size
                  //     color: Colors.black.withValues(alpha:0.8),
                  //   ),
                  //   textAlign: TextAlign.center,
                  // ),
                ],
              ),
            ),
          ),
        ),
      );
    }

    return Padding(
      padding: const EdgeInsets.only(bottom: 16),
      child: Container(

        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(12),
          border: Border.all(
            color: Colors.blue.withValues(alpha:0.3),
            width: 2,
          ),
          color: Colors.blue.withValues(alpha:0.1),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withValues(alpha:0.13),
              blurRadius: 10,
              spreadRadius: 2,
              offset: Offset(0, 4),
            ),
          ],
        ),
        child: ClipRRect(
          borderRadius: BorderRadius.circular(12),
          child: BackdropFilter(
            filter: ImageFilter.blur(sigmaX: 10, sigmaY: 10),
            child: Padding(
              padding: const EdgeInsets.all(12.0),
              child: Column(
                children: [
                  Text(
                    'YOU SELECTED: $selectedCategory',
                    style: TextStyle(
                      fontSize: 18, // Use appropriate font size
                      fontWeight: FontWeight.bold,
                      color: Colors.blue,
                    ),
                    textAlign: TextAlign.center,
                  ),
                  const SizedBox(height: 8),
                  Text(
                    'Please be patient,\n download the necessary \n data for  offline use.\n This may take a few moments',
                    style: TextStyle(
                      fontSize: 16, // Adjust the font size
                      color: Colors.white.withValues(alpha:0.9),
                      fontWeight: FontWeight.w500
                    ),
                    textAlign: TextAlign.center,
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
