// 1. MODEL CLASS
class HazardVideo {
  final int id;
  final String hazardVideoMstId;
  final String hazardVideoName;
  final String videoThumbImageName;
  final String lastScore;
  final bool isWatched;

  HazardVideo({
    required this.id,
    required this.hazardVideoMstId,
    required this.hazardVideoName,
    required this.videoThumbImageName,
    this.lastScore = '',
    this.isWatched = false,
  });

  factory HazardVideo.fromMap(Map<String, dynamic> map) {
    return HazardVideo(
      id: map['ID'],
      hazardVideoMstId: map['HAZARD_VIDEO_MST_ID'] ?? '',
      hazardVideoName: map['HAZARD_VIDEO_NAME'] ?? '',
      videoThumbImageName: map['VIDEO_THUMB_IMAGE_NAME'] ?? '',
      lastScore: map['LAST_SCORE'] ?? '',
      isWatched: map['IS_WATCHED'] == 'Y',
    );
  }
}
