import 'dart:io';
import 'package:http/http.dart' as http;
import 'package:path_provider/path_provider.dart';
import 'package:sqflite/sqflite.dart';
import 'package:theory_test_ltd/Local_database/Local_database_handler.dart';
import 'package:theory_test_ltd/utils/api_constant.dart';

class Video {
  final String id;
  final String title;
  final String imageUrl;
  final String videoUrl;
  final List<Hazard> hazards;

  Video({
    required this.id,
    required this.title,
    required this.imageUrl,
    required this.videoUrl,
    required this.hazards,
  });
}

class Hazard {
  final Duration time;
  final int points;

  Hazard({required this.time, required this.points});
}

class VideoService {
  // Define the list of videos
  final LocalDatabaseHandler dbHandler = LocalDatabaseHandler();

  Future<List<Video>> getVideos() async {
    List<Video> videos = [];
    List<Map<String, dynamic>> hazardVideoData =
        await dbHandler.getHazardVideos();

    for (var videoData in hazardVideoData) {
      List<Hazard> hazards = [];
      // Create Hazard objects for each hazard start time
      for (int i = 1; i <= 10; i++) {
        String timeField = 'HAZARD_START_TIME_$i';
        if (videoData[timeField] != null) {
          hazards.add(Hazard(
            time: Duration(seconds: int.parse(videoData[timeField])),
            points: 5, // You can customize points based on logic
          ));
        }
      }

      videos.add(Video(
        id: videoData['HAZARD_VIDEO_MST_ID'].toString(),
        title: videoData['HAZARD_VIDEO_NAME'],
        imageUrl:
            'assets/hazerd_thumbnails/${videoData['VIDEO_THUMB_IMAGE_NAME']}',
        // Assuming the thumbnail is stored like Hazard_1.jpg
        videoUrl:
            '$hazardBaseUrl${videoData['HAZARD_VIDEO_NAME']}',

        hazards: hazards,
      ));
    }

    return videos;
  }

  static Future<File?> downloadAndSaveVideo(
      String videoUrl, void Function(bool isLoading) setLoading) async {
    try {
      setLoading(true);

      final dir = await getApplicationDocumentsDirectory();
      final filePath = '${dir.path}/${videoUrl.split('/').last}';

      // Check if file already exists
      if (await File(filePath).exists()) {
        setLoading(false);
        return File(filePath);
      } else {
        final response = await http.get(Uri.parse(videoUrl));

        if (response.statusCode == 200) {
          final file = File(filePath);
          await file.writeAsBytes(response.bodyBytes);
          setLoading(false);
          print('Video downloaded to: $filePath');
          return file;
        } else {
          setLoading(false);
          print(
              'Failed to download video. Status code: ${response.statusCode}');
          throw Exception('Failed to download video');
        }
      }
    } catch (e) {
      setLoading(false);
      print('Error downloading video: $e');
      return null;
    }
  }

  static Future<bool> deleteVideo(String videoUrl) async {
    try {
      final videoFilePath = await VideoService.getDownloadedVideoPath(videoUrl);
      final videoFile = File(videoFilePath);
      if (await videoFile.exists()) {
        await videoFile.delete();
      }
      return true;
    } catch (e) {
      return false;
    }
  }

  // Check if the video is downloaded
  Future<bool> isVideoDownloaded(String videoUrl) async {
    final videoFilePath = await VideoService.getDownloadedVideoPath(videoUrl);
    return File(videoFilePath).existsSync();
  }

  // Get the path where the video is downloaded
  static Future<String> getDownloadedVideoPath(String videoUrl) async {
    final fileName = videoUrl.split('/').last;
    final dir = await getApplicationDocumentsDirectory();
    return '${dir.path}/$fileName';
  }

  // Fetch hazard videos
  Future<List<Map<String, dynamic>>> getHazardVideos() async {
    Database? db = await dbHandler.getDatabase;
    try {
      return await db!.query('HAZARD_VIDEO_MST');
    } catch (e) {
      rethrow;
    }
  }

  // Update last score for a specific hazard
  Future<void> updateLastScore(String hazardId, String score) async {
    final db = await dbHandler.getDatabase;

    await db?.rawUpdate(
      '''
     UPDATE HAZARD_VIDEO_MST 
     SET LAST_SCORE = ?, IS_WATCHED = ? 
     WHERE HAZARD_VIDEO_MST_ID = ?
      ''',
      [score, 'Y', hazardId],
    );
  }

  // Fetch last score for a specific hazard
  Future<String?> fetchLastScore(String hazardId) async {
    final db = await dbHandler.getDatabase;

    var result = await db?.query(
      'HAZARD_VIDEO_MST',
      columns: ['LAST_SCORE'],
      where: 'HAZARD_VIDEO_MST_ID = ?',
      whereArgs: [hazardId],
    );

    if (result != null && result.isNotEmpty) {
      return result.first['LAST_SCORE'].toString();
    }
    return null;
  }
}
