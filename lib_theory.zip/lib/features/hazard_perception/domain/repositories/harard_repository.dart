import 'dart:io';
import 'package:theory_test_ltd/features/hazard_perception/domain/services/hazard_services.dart';

abstract class HazardRepository {

  Future<List<Video>> fetchVideos();


  Future<File?> downloadVideo(String videoUrl, void Function(bool isLoading) setLoading);

  Future<bool> deleteVideo(String videoUrl);

  Future<bool> isVideoDownloaded(String videoUrl);

  Future<String?> fetchLastScore(String hazardId);

  Future<void> updateLastScore(String hazardId, String score);



}

class HazardRepositoryImpl implements HazardRepository {

  final VideoService videoService = VideoService();
  @override
  Future<List<Video>> fetchVideos() async {
    return await VideoService().getVideos();
  }

  @override
  Future<File?> downloadVideo(
      String videoUrl, void Function(bool isLoading) setLoading) async {
    return await VideoService.downloadAndSaveVideo(videoUrl, setLoading);
  }

  @override
  Future<bool> deleteVideo(String videoUrl) async {
    return await VideoService.deleteVideo(videoUrl);
  }

  @override
  Future<bool> isVideoDownloaded(String videoUrl) async {
    final videoFilePath = await VideoService.getDownloadedVideoPath(videoUrl);
    return File(videoFilePath).existsSync();
  }


  @override
  Future<String?> fetchLastScore(String hazardId) async {
    return await videoService.fetchLastScore(hazardId); // Call instance method
  }

  // Update last score
  @override
  Future<void> updateLastScore(String hazardId, String score) async {
    await videoService.updateLastScore(hazardId, score); // Call instance method
  }
}
