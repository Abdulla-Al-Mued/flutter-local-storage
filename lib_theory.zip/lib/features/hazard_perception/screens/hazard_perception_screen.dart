import 'package:flutter/material.dart';
import 'package:theory_test_ltd/common/base_widgets/custom_app_bar.dart';
import 'package:theory_test_ltd/common/base_widgets/navigate_pages.dart';
import 'package:theory_test_ltd/common/base_widgets/screen_config.dart';
import 'package:theory_test_ltd/features/hazard_perception/screens/hazard_introduction.dart';
import 'package:theory_test_ltd/features/hazard_perception/screens/hazard_practice_video_screen.dart';
import 'package:theory_test_ltd/features/hazard_perception/screens/results_screen.dart';
import 'package:theory_test_ltd/features/hazard_perception/widgets/hazard_perception_widgets.dart';
import 'package:theory_test_ltd/utils/color_resources.dart';

class HazardPerceptionScreen extends StatelessWidget {
  const HazardPerceptionScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.backgroundLight,
      appBar: CustomAppBar(
        title: 'Hazard Perception',
        gradientColors: [
          AppColors.blue,
          AppColors.steelBlue,
        ],
      ),
      body: LayoutBuilder(
        builder: (context, constraints) {
          final screenConfig = getScreenConfig(constraints, context);

          return Padding(
            padding: const EdgeInsets.all(10.0),
            child: SingleChildScrollView(
              child: Column(
                children: [
                  HazardPerceptionMenuItem(
                    iconBg: AppColors.blue,
                    icon: Icons.video_camera_back_outlined,
                    text: 'Introduction',
                    color: AppColors.blue,
                    screenConfig: screenConfig,
                    onTap: () {
                      navigateTo(()=>HazardIntroduction());
                    },
                  ),
                  HazardPerceptionMenuItem(
                    iconBg: AppColors.indigo,
                    icon: Icons.ads_click,
                    text: 'Practice Hazard Clips',
                    color: AppColors.blue,
                    screenConfig: screenConfig,
                    onTap: () {
                      navigateTo(() => HazardPracticeVideoScreen());
                    },
                  ),
                  // HazardPerceptionMenuItem(
                  //   iconBg: AppColors.steelBlue,
                  //   icon: Icons.edit,
                  //   text: 'Mock Test',
                  //   color: AppColors.blue,
                  //   screenConfig: screenConfig,
                  //   onTap: () {},
                  // ),
                  HazardPerceptionMenuItem(
                    iconBg: AppColors.secondary,
                    icon: Icons.bar_chart,
                    text: 'Progress Monitor',
                    color: AppColors.blue,
                    screenConfig: screenConfig,
                    onTap: () {
                      navigateTo(()=> HazardResultsScreen());
                    },
                  ),
                  // HazardPerceptionMenuItem(
                  //   iconBg: AppColors.midnightBlue,
                  //   icon: Icons.info,
                  //   text: 'Advice & Information',
                  //   color: AppColors.blue,
                  //   screenConfig: screenConfig,
                  //   onTap: () {},
                  // ),
                ],
              ),
            ),
          );
        },
      ),
    );
  }
}
