import 'dart:io';
import 'package:flutter/material.dart';
import 'package:theory_test_ltd/common/base_widgets/loading_animation.dart';
import 'package:theory_test_ltd/features/hazard_perception/domain/repositories/harard_repository.dart';
import 'package:theory_test_ltd/features/hazard_perception/domain/services/hazard_services.dart';
import 'package:theory_test_ltd/features/hazard_perception/widgets/hazard_complate_dialog.dart';
import 'package:theory_test_ltd/utils/color_resources.dart';
import 'package:video_player/video_player.dart';
import 'package:flutter/services.dart';

class VideoPlayerScreen extends StatefulWidget {
  final File videoFile;
  final Video video;

  const VideoPlayerScreen(
      {required this.videoFile, required this.video, super.key});

  @override
  State<VideoPlayerScreen> createState() => _VideoPlayerScreenState();
}

class _VideoPlayerScreenState extends State<VideoPlayerScreen> {
  late VideoPlayerController _controller;
  List<Duration> flags = [];
  int score = 0;
  Map<Duration, int> hazardScores = {};
  int totalPoints = 0;
  bool _isDialogVisible = false;

  // false: exam mode; true: review mode
  bool _isReviewMode = false;
  bool _isDoubleTap = false;
  DateTime _lastTapTime = DateTime.now();
  bool _isReviewFinished = false;

  // Five-color gradient for hazard markers.
  final List<Color> hazardColors = [
    Colors.blue,
    Colors.green,
    Colors.yellow,
    Colors.orange,
    Colors.red,




  ];

  @override
  void initState() {
    super.initState();

    // 🔹 Force landscape orientation during playback.
    SystemChrome.setPreferredOrientations([
      DeviceOrientation.landscapeRight,
      DeviceOrientation.landscapeLeft,
    ]);

    // 🔹 Initialize video player
    _controller = VideoPlayerController.file(widget.videoFile)
      ..initialize().then((_) {
        setState(() {}); // Refresh UI after initialization.

        // 🔹 Ensure video starts after a short delay (for iOS playback issues)
        Future.delayed(Duration(milliseconds: 300), () {
          if (mounted) {
            _controller.play().catchError((error) {
            });
          }
        });
      }).catchError((error) {
      });

    // 🔹 Add a listener that updates UI in exam and review modes.
    _controller.addListener(() {
      if (!_controller.value.isInitialized) return;

      final currentPosition = _controller.value.position;
      final duration = _controller.value.duration;


      // 🔹 Exam Mode: Detect when video ends.
      if (!_isReviewMode && currentPosition >= (duration - Duration(milliseconds: 500))) {
        _onExamVideoEnd();
      }

      // 🔹 Review Mode: Detect when video ends.
      if (_isReviewMode && currentPosition >= (duration - Duration(milliseconds: 500))) {
        if (!_isReviewFinished) {
          setState(() {
            _isReviewFinished = true;
          });
        }
      } else if (_isReviewFinished && currentPosition < duration) {
        // Reset finished state if user rewinds video
        setState(() {
          _isReviewFinished = false;
        });
      }

      // 🔹 Ensure progress updates in review mode.
      if (_isReviewMode) {
        setState(() {});
      }
    });

    // 🔹 Calculate total possible points.
    totalPoints = widget.video.hazards.fold(0, (sum, hazard) => sum + hazard.points);
  }

  @override
  void dispose() {
    SystemChrome.setPreferredOrientations([
      DeviceOrientation.portraitUp,
      DeviceOrientation.portraitDown,
    ]);
    _controller.dispose();
    super.dispose();
  }

  // In exam mode, record the user tap (flag) and update the score.
  void _addFlag() {
    if (_isReviewMode) return; // Do nothing in review mode

    final currentPosition = _controller.value.position;
    final now = DateTime.now();

    // Basic double-tap detection.
    if (now.difference(_lastTapTime) < const Duration(milliseconds: 500)) {
      setState(() {
        _isDoubleTap = true;
      });
      _togglePlay();
      _showDoubleTapDialog();
    } else {
      _isDoubleTap = false;
    }
    _lastTapTime = now;

    if (!_isDoubleTap) {
      setState(() {
        flags.add(currentPosition);
        // For each hazard, update score if the tap timing is near the hazard.
        for (var hazard in widget.video.hazards) {
          final hazardTime = hazard.time;
          if (currentPosition.inSeconds == hazardTime.inSeconds) {
            if (!hazardScores.containsKey(hazardTime) ||
                hazardScores[hazardTime]! < hazard.points) {
              hazardScores[hazardTime] = hazard.points;
              score += hazard.points;
            }
          } else if (currentPosition.inSeconds > hazardTime.inSeconds) {
            final decrement = currentPosition.inSeconds - hazardTime.inSeconds;
            final potentialScore =
                (hazard.points - decrement).clamp(0, hazard.points);
            if (!hazardScores.containsKey(hazardTime) ||
                hazardScores[hazardTime]! < potentialScore) {
              hazardScores[hazardTime] = potentialScore;
              score += potentialScore;
            }
          }
        }
      });
    }
  }

  // Restart the exam video (and clear flags/score in exam mode).
  void _restartExamVideo() {
    _controller.seekTo(Duration.zero);
    _controller.play();
    setState(() {
      if (!_isReviewMode) {
        flags.clear();
        score = 0;
      }
      _isReviewFinished = false;
    });

  }

  // When the exam video ends, show a score dialog with the "Review" option.
  void _onExamVideoEnd() {

    if (_isDialogVisible) return; // Prevent reopening the dialog
    _isDialogVisible = true;

    _saveScoreToDatabase(widget.video.id, score);
    showDialog(
      context: context,
      builder: (context) {
        return ExamCompletionDialog(
          score: score,
          totalPoints: totalPoints,
          onReview: () {
            Navigator.of(context).pop(); // Close the dialog
            _enterReviewMode(); // Enter review mode
            setState(() {
              // Update state only if necessary
            });
          },
          onClose: () {
            Navigator.of(context).pop(); // Close the dialog
            _exitReviewMode(); // Exit the review mode and close the screen
            setState(() {
              // Update state if needed
            });
          },
        );
      },
    ).then((_) {
      // Ensure the UI is updated and closed properly after the dialog is dismissed
      if (_isReviewMode) {
        setState(() {
          _isDialogVisible = false;

        });
      }
    });
  }


  Future<void> _saveScoreToDatabase( String hazardId, int score) async {

    HazardRepository hazardRepository = HazardRepositoryImpl();
    // Call the repository's updateLastScore method
    await hazardRepository.updateLastScore(hazardId, score.toString());
  }


  // Switch to review mode and restart the video.
  void _enterReviewMode() {
    setState(() {
      _isReviewMode = true;
      _isReviewFinished = false;
      _restartExamVideo();
    });
  }

  void _exitReviewMode() {
    Navigator.of(context).pop(true);
  }

  // Format a Duration (mm:ss).
  String _formatDuration(Duration d) {
    String twoDigits(int n) => n.toString().padLeft(2, '0');
    final minutes = d.inMinutes.remainder(60);
    final seconds = d.inSeconds.remainder(60);
    return '${twoDigits(minutes)}:${twoDigits(seconds)}';
  }

  // --- Video Control Methods (active only in review mode) ---
  void _rewind5() {
    final currentPos = _controller.value.position;
    final newPos = currentPos - const Duration(seconds: 5);
    _controller.seekTo(newPos > Duration.zero ? newPos : Duration.zero);
  }

  void _forward5() {
    final currentPos = _controller.value.position;
    final maxDuration = _controller.value.duration;
    final newPos = currentPos + const Duration(seconds: 5);
    _controller.seekTo(newPos < maxDuration ? newPos : maxDuration);
  }

  void _togglePlay() {
    setState(() {
      if (_controller.value.isPlaying) {
        _controller.pause();
      } else {
        _controller.play();
      }
    });
  }

  // Build the review controls overlay (only visible in review mode).
  Widget _buildReviewControls() {
    return Positioned(
      bottom: 60, // Positioned above the timeline
      left: 0,
      right: 0,
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          // Interactive progress slider.

          // Playback control buttons.
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            children: [
              IconButton(
                icon: const Icon(Icons.replay_5, color: Colors.white),
                onPressed: _rewind5,
              ),
              IconButton(
                icon: Icon(
                  _controller.value.isPlaying ? Icons.pause : Icons.play_arrow,
                  color: Colors.white,
                ),
                onPressed: _togglePlay,
              ),
              IconButton(
                icon: const Icon(Icons.forward_5, color: Colors.white),
                onPressed: _forward5,
              ), if (_isReviewFinished)
                ElevatedButton(
                  onPressed: _exitReviewMode,
                  style: ElevatedButton.styleFrom(
                    backgroundColor: AppColors.iceGreenLight,
                    padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 12),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(8),
                    ),
                  ),
                  child: const Text('OK',
                      style: TextStyle(
                          fontSize: 16,
                          color: Colors.white,
                          fontWeight: FontWeight.bold
                      )
                  ),
                ),
            ],
          ),
        ],
      ),
    );
  }
  void _showDoubleTapDialog() {
    showDialog(
      barrierDismissible: false, // Prevent closing the dialog when clicking outside
      context: context,
      builder: (context) {
        return Dialog(
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(12.0),
          ),
          elevation: 16,
          child: Container(
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: [   AppColors.blue,
                  AppColors.steelBlue,],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
              borderRadius: BorderRadius.circular(12.0),
            ),
            padding: EdgeInsets.all(16),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Icon(
                  Icons.warning_amber_rounded,
                  color: AppColors.gold,
                  size: 80,
                ),
                SizedBox(height: 20),
                Text(
                  'Double Tap Detected',
                  style: TextStyle(
                    fontSize: 22,
                    fontWeight: FontWeight.bold,
                    color: Colors.white,
                  ),
                ),
                SizedBox(height: 10),
                Text(
                  'Double tap is unacceptable. Would you like to reattempt the test?',
                  style: TextStyle(
                    fontSize: 16,
                    color: Colors.white70,
                  ),
                  textAlign: TextAlign.center,
                ),
                SizedBox(height: 20),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: [
                    ElevatedButton(
                      onPressed: () {
                        Navigator.of(context).pop(); // Close the dialog
                        _restartExamVideo(); // Restart the video
                      },
                      style: ElevatedButton.styleFrom(
                        backgroundColor: AppColors.orange, // Green color for the button
                        padding: EdgeInsets.symmetric(horizontal: 24, vertical: 12),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(8),
                        ),
                      ),
                      child: Text('Reattempt Test', style: TextStyle(fontSize: 16 , color: Colors.white)),
                    ),
                  ],
                ),
              ],
            ),
          ),
        );
      },
    );
  }


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      // In review mode, show custom video controls as an overlay.
      body: Padding(
        padding: const EdgeInsets.all(5.0),
        child: GestureDetector(
          onTap: () {
            if (!_isReviewMode) {
              _addFlag();
            }
          },
          child: Center(
            child: _controller.value.isInitialized
                ? Stack(
                    children: [
                      Column(
                        children: [
                          Expanded(
                            child: AspectRatio(
                              aspectRatio: _controller.value.aspectRatio,
                              child: VideoPlayer(_controller),
                            ),
                          ),
                          _buildTimeline(),
                        ],
                      ),
                      if (_isReviewMode) _buildReviewControls(),
                    ],
                  )
                : const LoadingAnimation(),
          ),
        ),
      ),
    );
  }

  // Build the timeline widget.
  // In review mode, the timeline shows a blue progress fill,
  // hazard gradient markers, and user flag markers.
  Widget _buildTimeline() {
    return Container(
      height: 50,
      color: Colors.black.withOpacity(0.6),
      child: LayoutBuilder(
        builder: (context, constraints) {
          final containerWidth = constraints.maxWidth;
          final double oneSecondWidth = containerWidth / _controller.value.duration.inSeconds;

          // Create list of all widgets for the Stack
          List<Widget> stackChildren = [];

          // Add progress bar fill if in review mode
          if (_isReviewMode) {
            stackChildren.add(
              Positioned.fill(
                child: Align(
                  alignment: Alignment.centerLeft,
                  child: FractionallySizedBox(
                    widthFactor: _controller.value.duration.inMilliseconds > 0
                        ? _controller.value.position.inMilliseconds /
                        _controller.value.duration.inMilliseconds
                        : 0.0,
                    child: Container(color: Colors.blue.withOpacity(0.5)),
                  ),
                ),
              ),
            );
          }

          // Add hazard markers if in review mode
          if (_isReviewMode) {
            for (var hazard in widget.video.hazards) {
              for (int i = 0; i < hazardColors.length; i++) {
                final startTimeMs = hazard.time.inMilliseconds + (i * 1000);
                final endTimeMs = startTimeMs + 1000; // End is 1 second after start

                if (startTimeMs <= _controller.value.duration.inMilliseconds) {
                  final startPosition = (startTimeMs / _controller.value.duration.inMilliseconds) * containerWidth;

                  // Calculate exact end position, capped at video duration
                  final endTimeToUse = endTimeMs <= _controller.value.duration.inMilliseconds
                      ? endTimeMs
                      : _controller.value.duration.inMilliseconds;
                  final endPosition = (endTimeToUse / _controller.value.duration.inMilliseconds) * containerWidth;

                  // Width is exactly the span of 1 second on the timeline
                  final width = endPosition - startPosition;

                  stackChildren.add(
                    Positioned(
                      left: startPosition,
                      bottom: 0,
                      child: Container(
                        width: width,
                        height: 25,
                        color: hazardColors[i],
                      ),
                    ),
                  );
                }
              }
            }
          }

          // Add flag markers
          for (var flag in flags) {
            stackChildren.add(
              Positioned(
                left: ((flag.inMilliseconds / _controller.value.duration.inMilliseconds) * containerWidth),
                bottom: 0,
                child: Icon(
                  Icons.flag,
                  color: AppColors.red,
                  size: 35,
                ),
              ),
            );
          }

          // Add time display if in review mode
          if (_isReviewMode) {
            stackChildren.add(
              Positioned(
                right: 10,
                top: 10,
                child: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                  color: Colors.black54,
                  child: Text(
                    '${_formatDuration(_controller.value.position)} / ${_formatDuration(_controller.value.duration)}',
                    style: const TextStyle(color: Colors.white, fontSize: 12),
                  ),
                ),
              ),
            );
          }

          return Stack(children: stackChildren);
        },
      ),
    );
  }
}
