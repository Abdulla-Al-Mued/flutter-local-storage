import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:theory_test_ltd/Local_database/Local_database_handler.dart';
import 'package:theory_test_ltd/common/base_widgets/screen_config.dart';
import 'package:theory_test_ltd/features/hazard_perception/controllers/result_controller.dart';
import 'package:theory_test_ltd/features/hazard_perception/widgets/results_widgets.dart';

class HazardResultsScreen extends StatelessWidget {
  const HazardResultsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return ChangeNotifierProvider(
      create: (context) => HazardResultsController(LocalDatabaseHandler()),
      child: Scaffold(
        body: LayoutBuilder(
          builder: (context, constraints) {
            final screenConfig = getScreenConfig(constraints, context);
            return ModernHazardResultsView(screenConfig: screenConfig);
          },
        ),
      ),
    );
  }
}

