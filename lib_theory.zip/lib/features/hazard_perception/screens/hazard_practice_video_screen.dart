import 'dart:io';
import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:theory_test_ltd/common/base_widgets/custom_app_bar.dart';
import 'package:theory_test_ltd/common/base_widgets/loading_animation.dart';
import 'package:theory_test_ltd/common/base_widgets/screen_config.dart';
import 'package:theory_test_ltd/features/hazard_perception/controllers/hazard_video_provider.dart';
import 'package:theory_test_ltd/features/hazard_perception/domain/services/hazard_services.dart';
import 'package:theory_test_ltd/features/hazard_perception/screens/video_player_screen.dart';
import 'package:theory_test_ltd/features/hazard_perception/widgets/hazard_perception_widgets.dart';
import 'package:theory_test_ltd/utils/color_resources.dart';


class HazardPracticeVideoScreen extends StatefulWidget {
  const HazardPracticeVideoScreen({super.key});

  @override
  State<HazardPracticeVideoScreen> createState() =>
      _HazardPracticeVideoScreenState();
}

class _HazardPracticeVideoScreenState extends State<HazardPracticeVideoScreen>   {

  @override
  void initState() {
    super.initState();

    // Delay the loadVideos() call until after the build phase completes
    WidgetsBinding.instance.addPostFrameCallback((_) {
      Provider.of<HazardVideoProvider>(context, listen: false).loadVideos();
    });
    WidgetsBinding.instance.addPostFrameCallback((_) {
      Provider.of<HazardVideoProvider>(context, listen: false).loadHazardVideos();
    });

  }


  _reloadData(){
    // Delay the loadVideos() call until after the build phase completes
    WidgetsBinding.instance.addPostFrameCallback((_) {
      Provider.of<HazardVideoProvider>(context, listen: false).loadVideos();
    });
    WidgetsBinding.instance.addPostFrameCallback((_) {
      Provider.of<HazardVideoProvider>(context, listen: false).loadHazardVideos();
    });

  }



  void playVideo(BuildContext context, File videoFile, Video video) {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (BuildContext context) {
        return Dialog(
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(24),
          ),
          elevation: 10,
          backgroundColor: Colors.transparent,
          child: Stack(
            children: [

              BackdropFilter(
                filter: ImageFilter.blur(sigmaX: 10, sigmaY: 10),
                child: Container(
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(24),
                    color: Colors.blue.withValues(alpha:0.2),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.black.withValues(alpha:0.1),
                        blurRadius: 15,
                        offset: Offset(0, 10),
                      ),
                    ],
                    border: Border.all(
                      color: Colors.white.withValues(alpha:0.3),
                      width: 1.5,
                    ),
                  ),
                  child: Padding(
                    padding: const EdgeInsets.all(24),
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Text(
                          'Start the Test!',
                          style: TextStyle(
                            color: Colors.white,
                            fontWeight: FontWeight.bold,
                            fontSize: 26,
                          ),
                        ),
                        SizedBox(height: 16),
                        Text(
                          'Click on the video when you see a hazard developing. Be careful not to click in rapid succession or in a pattern, as this will result in a score of 0.',
                          textAlign: TextAlign.center,
                          style: TextStyle(
                            color: AppColors.primary200,
                            fontSize: 18,
                          ),
                        ),
                        SizedBox(height: 40),
                        ElevatedButton(
                          onPressed: () async {
                            Navigator.pop(context);
                            Navigator.push(
                              context,
                              MaterialPageRoute(
                                builder: (context) => VideoPlayerScreen(
                                  videoFile: videoFile,
                                  video: video,
                                ),
                              ),
                            ).then((shouldReload) {
                              if (shouldReload == true) {
                                _reloadData(); // Reload data when coming back from VideoPlayerScreen
                              }
                            });
                          },
                          style: ElevatedButton.styleFrom(
                            foregroundColor: Colors.white,
                            backgroundColor: Colors.blueAccent,
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(12),
                            ),
                            padding: EdgeInsets.symmetric(vertical: 12, horizontal: 40),
                            elevation: 8,
                          ),
                          child: Text(
                            "Let's Start",
                            style: TextStyle(
                              fontSize: 18,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ],
          ),
        );
      },
    );
  }



  @override
  Widget build(BuildContext context) {
    final videoProvider = Provider.of<HazardVideoProvider>(context);

    return Scaffold(
      backgroundColor: AppColors.backgroundLight,
      appBar: CustomAppBar(
        title: 'Hazard Practice Videos',
        gradientColors: [
          AppColors.blue,
          AppColors.blue,
        ],
      ),
      body: videoProvider.isLoading
          ? const Center(child: LoadingAnimation()) // Show loading animation only for initial data load
          : FutureBuilder<List<Video>>(
        future: videoProvider.hazardRepository.fetchVideos(),
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting && !snapshot.hasData) {
            // Show loading only during initial load, not after data is fetched
            return const Center(child: LoadingAnimation());
          }

          // Handle errors
          if (snapshot.hasError) {
            return Center(child: Text('Error: ${snapshot.error}'));
          }

          // Check for empty data after loading completes
          if (!snapshot.hasData || snapshot.data!.isEmpty) {
            return const Center(child: Text('No videos found \n Please Download from Manage', textAlign: TextAlign.center,    style: TextStyle(
              fontSize: 18,
              color: AppColors.steelBlue,
              fontWeight: FontWeight.bold,
            ),));
          }

          final videos = snapshot.data!;

          return LayoutBuilder(
            builder: (context, constraints) {
              ScreenConfig config = getScreenConfig(constraints, context);

              return Stack(
                children: [
                  Column(
                    children: [
                      // Progress Section
                      Container(
                        decoration: BoxDecoration(
                          gradient: LinearGradient(
                            begin: Alignment.topCenter,
                            end: Alignment.bottomCenter,
                            colors: [
                              AppColors.blue,
                              AppColors.steelBlue,
                            ],
                          ),
                        ),
                        child: ModernProgressSection(
                          screenConfig: config,
                          controller: videoProvider,
                        ),
                      ),

                      Expanded(
                        child: GridView.builder(
                          padding: const EdgeInsets.all(10),
                          itemCount: videos.length,
                          gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                            crossAxisCount: config.gridCrossAxisCount,
                            crossAxisSpacing: 10,
                            mainAxisSpacing: 10,
                          ),
                          itemBuilder: (context, index) {
                            final video = videos[index];

                            return FutureBuilder<bool>(
                              future: videoProvider.isVideoDownloaded(video.videoUrl),
                              builder: (context, snapshot) {
                                bool isDownloaded = snapshot.data ?? false;

                                return GestureDetector(
                                  onTap: () async {
                                    if (!isDownloaded) {
                                      final videoFile = await videoProvider.downloadVideo(video.videoUrl, context);

                                      if (videoFile != null) {
                                        playVideo(context, videoFile, video);
                                      }
                                    } else {
                                      final videoFilePath = await VideoService.getDownloadedVideoPath(video.videoUrl);
                                      final videoFile = File(videoFilePath);

                                      if (videoFile.existsSync()) {
                                        playVideo(context, videoFile, video);
                                      } else {
                                        ScaffoldMessenger.of(context).showSnackBar(
                                          const SnackBar(content: Text('Video file is missing or corrupted.')),
                                        );
                                      }
                                    }
                                  },
                                  child: Card(
                                    elevation: 8,
                                    shape: RoundedRectangleBorder(
                                      borderRadius: BorderRadius.circular(5),
                                    ),
                                    child: Column(
                                      crossAxisAlignment: CrossAxisAlignment.start,
                                      children: [
                                        Expanded(
                                          child: Stack(
                                            alignment: Alignment.center,
                                            children: [
                                              ClipRRect(
                                                borderRadius: const BorderRadius.only(
                                                  topLeft: Radius.circular(5),
                                                  topRight: Radius.circular(5),
                                                ),
                                                child: Image.asset(
                                                  video.imageUrl,
                                                  fit: BoxFit.cover,
                                                  height: double.infinity,
                                                  width: double.infinity,
                                                ),
                                              ),
                                              Positioned(
                                                child: CircleAvatar(
                                                  backgroundColor: Colors.black.withAlpha(100),
                                                  radius: 30,
                                                  child: const Icon(
                                                    Icons.play_arrow,
                                                    color: Colors.white,
                                                    size: 40,
                                                  ),
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                        Padding(
                                          padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 8),
                                          child: Row(
                                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                            children: [
                                              Expanded(
                                                child: Text(
                                                  video.title,
                                                  style: TextStyle(
                                                    fontWeight: FontWeight.bold,
                                                    fontSize: config.isTablet ? 16 : 12,
                                                    color: Colors.black,
                                                  ),
                                                  maxLines: 2,
                                                  overflow: TextOverflow.ellipsis,
                                                ),
                                              ),
                                              IconButton(
                                                icon: Icon(
                                                  isDownloaded
                                                      ? Icons.delete
                                                      : Icons.download,
                                                  color: isDownloaded ? Colors.red : Colors.green,
                                                ),
                                                onPressed: () async {
                                                  if (isDownloaded) {
                                                    bool success = await videoProvider.deleteVideo(video.videoUrl);
                                                    if (success) {
                                                      ScaffoldMessenger.of(context).showSnackBar(
                                                        const SnackBar(
                                                          content: Text('Video deleted successfully'),
                                                        ),
                                                      );
                                                    } else {
                                                      ScaffoldMessenger.of(context).showSnackBar(
                                                        const SnackBar(
                                                          content: Text('Failed to delete video'),
                                                        ),
                                                      );
                                                    }
                                                  } else {
                                                    await videoProvider.downloadVideo(video.videoUrl, context);
                                                  }
                                                },
                                              ),
                                            ],
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                );
                              },
                            );
                          },
                        ),
                      ),
                    ],
                  ),
                  // Overlay download indicator
                  if (videoProvider.isDownloading)
                    Container(
                      color: AppColors.backgroundLight.withAlpha(200),
                      width: double.infinity,
                      height: double.infinity,
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: const [
                          Text('Downloading video...', style: TextStyle(fontSize: 20)),
                          SizedBox(height: 20),
                          LoadingAnimation(),
                        ],
                      ),
                    ),
                ],
              );
            },
          );
        },
      ),
    );
  }

}
