import 'dart:io';
import 'package:connectivity_plus/connectivity_plus.dart';
import 'package:flutter/material.dart';
import 'package:theory_test_ltd/Local_database/Local_database_handler.dart';
import 'package:theory_test_ltd/features/hazard_perception/domain/models/hazard_model.dart';
import 'package:theory_test_ltd/features/hazard_perception/domain/repositories/harard_repository.dart';

class HazardVideoProvider extends ChangeNotifier {
  final LocalDatabaseHandler _dbHandler;
  final HazardRepository hazardRepository;

  // State variables
  bool _isLoading = true;
  bool _isDownloading = false;
  bool _isDeleting = false;
  String _errorMessage = '';
  double _progressPercentage = 0.0;
  int _watchedVideos = 0;
  int _totalVideos = 0;
  double _averageScore = 0.0;
  List<HazardVideo> _hazardVideos = [];

  // Getters
  bool get isLoading => _isLoading;
  bool get isDownloading => _isDownloading;
  bool get isDeleting => _isDeleting;
  double get progressPercentage => _progressPercentage;
  int get watchedVideos => _watchedVideos;
  int get totalVideos => _totalVideos;
  String get errorMessage => _errorMessage;
  double get averageScore => _averageScore;
  List<HazardVideo> get hazardVideos => _hazardVideos;

  HazardVideoProvider(this._dbHandler, {required this.hazardRepository});

  Future<void> loadVideos() async {
    if (_isLoading) {
      await Future.delayed(const Duration(milliseconds: 500));
      _isLoading = false;
      notifyListeners();
    }
  }

  Future<bool> hasInternetConnection() async {
    final results = await Connectivity().checkConnectivity();
    return !results.contains(ConnectivityResult.none) && results.isNotEmpty;
  }

  Future<File?> downloadVideo(String videoUrl, BuildContext context) async {
    if (_isDownloading) return null;

    final isConnected = await hasInternetConnection();
    if (!isConnected) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('No internet connection. Please try again later.')),
      );
      return null;
    }

    _setIsDownloading(true);
    final videoFile = await hazardRepository.downloadVideo(videoUrl, _setIsDownloading);
    _setIsDownloading(false);

    return videoFile;
  }

  Future<bool> deleteVideo(String videoUrl) async {
    if (_isDeleting) return false;

    _setIsDeleting(true);
    final success = await hazardRepository.deleteVideo(videoUrl);
    _setIsDeleting(false);

    return success;
  }

  Future<bool> isVideoDownloaded(String videoUrl) async {
    return hazardRepository.isVideoDownloaded(videoUrl);
  }

  void _setIsDownloading(bool value) {
    if (_isDownloading != value) {
      _isDownloading = value;
      notifyListeners();
    }
  }

  void _setIsDeleting(bool value) {
    if (_isDeleting != value) {
      _isDeleting = value;
      notifyListeners();
    }
  }

  Future<void> loadHazardVideos() async {
    try {
      _isLoading = true;
      _errorMessage = '';
      notifyListeners();

      // Check if table exists
      final tableExists = await _dbHandler.doesTableExist(tableName: 'HAZARD_VIDEO_MST');
      if (!tableExists) {
        _errorMessage = 'Hazard videos table does not exist';
        _isLoading = false;
        notifyListeners();
        return;
      }

      // Get hazard videos
      final hazardVideosData = await _dbHandler.getHazardVideos();
      _hazardVideos = hazardVideosData.map((data) => HazardVideo.fromMap(data)).toList();

      // Calculate progress
      _calculateProgress();

      _isLoading = false;
      notifyListeners();
    } catch (e) {
      _errorMessage = 'Error loading hazard videos: ${e.toString()}';
      _isLoading = false;
      notifyListeners();
    }
  }

  void _calculateProgress() {
    _totalVideos = _hazardVideos.length;
    _watchedVideos = _hazardVideos.where((video) => video.isWatched).length;

    // Calculate progress percentage
    _progressPercentage = _totalVideos > 0
        ? (_watchedVideos / _totalVideos) * 100
        : 0.0;

    // Calculate average score for watched videos with scores
    final scoredVideos = _hazardVideos.where(
            (video) => video.lastScore.isNotEmpty && video.isWatched
    ).toList();

    if (scoredVideos.isNotEmpty) {
      final totalScore = scoredVideos.fold(
          0.0,
              (sum, video) => sum + (double.tryParse(video.lastScore) ?? 0.0)
      );
      _averageScore = totalScore / scoredVideos.length;
    } else {
      _averageScore = 0.0;
    }
  }
}