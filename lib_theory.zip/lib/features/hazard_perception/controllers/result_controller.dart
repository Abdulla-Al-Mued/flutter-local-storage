// 2. CONTROLLER CLASS (PROVIDER)
import 'package:flutter/material.dart';
import 'package:theory_test_ltd/Local_database/Local_database_handler.dart';
import 'package:theory_test_ltd/features/hazard_perception/domain/models/hazard_model.dart';

class HazardResultsController extends ChangeNotifier {
  final LocalDatabaseHandler _dbHandler;
  List<HazardVideo> _hazardVideos = [];
  bool _isLoading = true;
  String _errorMessage = '';
  double _progressPercentage = 0.0;
  int _watchedVideos = 0;
  int _totalVideos = 0;
  double _averageScore = 0.0;

  HazardResultsController(this._dbHandler) {
    loadHazardVideos();
  }

  // Getters
  List<HazardVideo> get hazardVideos => _hazardVideos;
  bool get isLoading => _isLoading;
  String get errorMessage => _errorMessage;
  double get progressPercentage => _progressPercentage;
  int get watchedVideos => _watchedVideos;
  int get totalVideos => _totalVideos;
  double get averageScore => _averageScore;

  Future<void> loadHazardVideos() async {
    try {
      _isLoading = true;
      notifyListeners();

      // Check if table exists
      bool tableExists = await _dbHandler.doesTableExist(tableName: 'HAZARD_VIDEO_MST');
      if (!tableExists) {
        _errorMessage = 'Hazard videos table does not exist';
        _isLoading = false;
        notifyListeners();
        return;
      }

      // Get hazard videos
      final hazardVideosData = await _dbHandler.getHazardVideos();
      _hazardVideos = hazardVideosData.map((data) => HazardVideo.fromMap(data)).toList();

      // Calculate progress
      _calculateProgress();

      _isLoading = false;
      notifyListeners();
    } catch (e) {
      _errorMessage = 'Error loading hazard videos: ${e.toString()}';
      _isLoading = false;
      notifyListeners();
    }
  }

  void _calculateProgress() {
    _totalVideos = _hazardVideos.length;
    _watchedVideos = _hazardVideos.where((video) => video.isWatched).length;

    if (_totalVideos > 0) {
      _progressPercentage = (_watchedVideos / _totalVideos) * 100;
    } else {
      _progressPercentage = 0.0;
    }

    // Calculate average score for watched videos with scores
    List<HazardVideo> scoredVideos = _hazardVideos.where(
            (video) => video.lastScore.isNotEmpty && video.isWatched
    ).toList();

    if (scoredVideos.isNotEmpty) {
      double totalScore = scoredVideos.fold(
          0.0,
              (sum, video) => sum + (double.tryParse(video.lastScore) ?? 0.0)
      );
      _averageScore = totalScore / scoredVideos.length;
    } else {
      _averageScore = 0.0;
    }

    notifyListeners();
  }

  void refresh() {
    loadHazardVideos();
  }
}
