import 'package:flutter/material.dart';
import 'package:theory_test_ltd/common/base_widgets/screen_config.dart';
import 'package:theory_test_ltd/features/hazard_perception/controllers/hazard_video_provider.dart';
import 'package:theory_test_ltd/utils/color_resources.dart';

class HazardPerceptionMenuItem extends StatelessWidget {
  final IconData icon;
  final String text;
  final Color color;
  final Color iconBg;
  final ScreenConfig screenConfig;
  final VoidCallback onTap;

  const HazardPerceptionMenuItem({
    super.key,
    required this.icon,
    required this.text,
    required this.color,
    required this.iconBg,
    required this.screenConfig,
    required this.onTap,

  });

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.symmetric(vertical: 8.0),
      padding: EdgeInsets.only(top: 8, bottom: 8),
      decoration: BoxDecoration(
        color: color.withValues(alpha: 0.1),
        borderRadius: BorderRadius.circular(5),
        border: Border.all(color: color),
      ),
      child: ListTile(
        leading: Container(
          padding: const EdgeInsets.all(10),
          decoration: BoxDecoration(
            color: iconBg,
            borderRadius: BorderRadius.circular(5),
          ),
          child: Icon(
            icon,
            color: AppColors.white,
            size: screenConfig.menuIconSize,
          ),
        ),
        title: Text(
          text,
          style: TextStyle(
            color: color,
            fontSize: screenConfig.menuFontSize,
            fontWeight: FontWeight.w400,
          ),
        ),
        onTap: onTap,
      ),
    );
  }
}

class ModernProgressSection extends StatelessWidget {
  final ScreenConfig screenConfig;
  final HazardVideoProvider controller;

  const ModernProgressSection({
    super.key,
    required this.screenConfig,
    required this.controller,
  });

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(20, 16, 20, 16),
      child: Column(
        children: [
          // Stats Cards
          Row(
            children: [
              // Progress Card
              Expanded(
                flex: 2,
                child: _buildStatCard(
                  context: context,
                  title: 'Progress',
                  content: SizedBox(
                    height: screenConfig.isTablet ? 150 : 110,
                    width: screenConfig.isTablet ? 150 : 110,
                    child: Stack(
                      alignment: Alignment.center,
                      children: [
                        SizedBox(
                          height: screenConfig.isTablet ? 130 : 100,
                          width: screenConfig.isTablet ? 130 : 100,
                          child: CircularProgressIndicator(
                            value: controller.progressPercentage / 100,
                            strokeWidth: screenConfig.isTablet ? 12 : 8,
                            backgroundColor: Colors.white.withValues(alpha: 0.2),
                            valueColor: const AlwaysStoppedAnimation<Color>(Color(0xFF64FFDA)),
                          ),
                        ),
                        Column(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Text(
                              '${controller.progressPercentage.toStringAsFixed(0)}%',
                              style: TextStyle(
                                color: Colors.white,
                                fontSize: screenConfig.isTablet ? 36 : 28,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                            Text(
                              'Complete',
                              style: TextStyle(
                                color: Colors.white.withValues(alpha: 0.7),
                                fontSize: screenConfig.isTablet ? 16 : 12,
                              ),
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                ),
              ),

              const SizedBox(width: 16),

              // Stats Vertical Cards
              Expanded(
                flex: 3,
                child: Column(
                  children: [
                    // Watched Videos Card
                    _buildInfoCard(
                      title: 'Videos Watched',
                      icon: Icons.play_circle_filled,
                      iconColor: Color(0xFF64FFDA),
                      value: '${controller.watchedVideos}/${controller.totalVideos}',
                    ),

                    const SizedBox(height: 12),

                    // Average Score Card
                    _buildInfoCard(
                      title: 'Average Score',
                      icon: Icons.emoji_events,
                      iconColor: Color(0xFFFFC107),
                      value: controller.averageScore > 0
                          ? controller.averageScore.toStringAsFixed(1)
                          : 'N/A',
                    ),
                  ],
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildStatCard({
    required BuildContext context,
    required String title,
    required Widget content,
  }) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white.withValues(alpha:0.1),
        borderRadius: BorderRadius.circular(20),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          Text(
            title,
            style: TextStyle(
              color: Colors.white.withValues(alpha:0.7),
              fontSize: screenConfig.isTablet ? 18 : 14,
              fontWeight: FontWeight.w500,
            ),
          ),
          const SizedBox(height: 8),
          content,
        ],
      ),
    );
  }

  Widget _buildInfoCard({
    required String title,
    required IconData icon,
    required Color iconColor,
    required String value,
  }) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white.withValues(alpha:0.1),
        borderRadius: BorderRadius.circular(20),
      ),
      child: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(8),
            decoration: BoxDecoration(
              color: iconColor.withValues(alpha:0.2),
              borderRadius: BorderRadius.circular(12),
            ),
            child: Icon(
              icon,
              color: iconColor,
              size: screenConfig.isTablet ? 28 : 24,
            ),
          ),
          const SizedBox(width: 16),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  overflow: TextOverflow.ellipsis,
                  title,
                  style: TextStyle(
                    color: Colors.white.withValues(alpha:0.7),
                    fontSize: screenConfig.isTablet ? 14 : 12,
                  ),
                ),
                Text(
                  value,
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: screenConfig.isTablet ? 24 : 20,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
