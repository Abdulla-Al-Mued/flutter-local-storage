import 'package:flutter/material.dart';
import 'package:theory_test_ltd/utils/color_resources.dart';

class ExamCompletionDialog extends StatelessWidget {
  final int score;
  final int totalPoints;
  final VoidCallback onReview;
  final VoidCallback onClose;

  const ExamCompletionDialog({
    super.key,
    required this.score,
    required this.totalPoints,
    required this.onReview,
    required this.onClose,
  });

  @override
  Widget build(BuildContext context) {
    return Dialog(
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(25.0), // Softer rounded corners
      ),
      elevation: 10.0,
      backgroundColor: Colors.white,
      child: Container(
        width: 380, // Slightly narrower for a sleeker look
        padding: const EdgeInsets.all(24.0), // More padding for space
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(25.0),
          gradient: LinearGradient(
            colors: [      AppColors.blue,
              AppColors.steelBlue,],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.05),
              blurRadius: 12,
              offset: Offset(0, 5), // Soft shadow for depth
            ),
          ],
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            // Title
            Text(
              'Test Completed',
              style: Theme.of(context).textTheme.headlineMedium?.copyWith(
                color: AppColors.white,
                fontWeight: FontWeight.bold,
                letterSpacing: 1.2, // Slight letter spacing for style
              ),
            ),
            const SizedBox(height: 20),

            // Score
            Text(
              'Your score:',
              style: Theme.of(context).textTheme.titleMedium?.copyWith(
                color: Colors.white60,
                fontWeight: FontWeight.w600,
              ),
            ),
            Text(
              '$score / $totalPoints',
              style: Theme.of(context).textTheme.displaySmall?.copyWith(
                color: AppColors.yellow,
                fontWeight: FontWeight.bold,
                fontSize: 36, // Larger font for impact
              ),
            ),
            const SizedBox(height: 30),

            // Buttons
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              children: [
                // Review Button
                ElevatedButton(
                  onPressed: onReview,
                  style: ElevatedButton.styleFrom(
                    backgroundColor: AppColors.primary,
                    padding: const EdgeInsets.symmetric(
                      vertical: 14.0,
                      horizontal: 32.0,
                    ), // Larger touch target
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(12.0),
                    ),
                  ),
                  child: Text(
                    'Review',
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 16,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                ),
                // OK Button
                ElevatedButton(
                  onPressed: onClose,
                  style: ElevatedButton.styleFrom(
                    backgroundColor: AppColors.orange,
                    padding: const EdgeInsets.symmetric(
                      vertical: 14.0,
                      horizontal: 32.0,
                    ),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(12.0),
                    ),
                  ),
                  child: Text(
                    'OK',
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 16,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
