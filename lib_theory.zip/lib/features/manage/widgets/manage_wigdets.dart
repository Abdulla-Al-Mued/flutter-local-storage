import 'package:flutter/material.dart';
import 'package:theory_test_ltd/common/base_widgets/screen_config.dart';

class MenuItem extends StatelessWidget {
  final IconData icon;
  final String text;
  final LinearGradient gradient;
  final ScreenConfig screenConfig;
  final VoidCallback onTap;

  const MenuItem({
    super.key,
    required this.icon,
    required this.text,
    required this.gradient,
    required this.screenConfig,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        margin: const EdgeInsets.symmetric(vertical: 8.0),
        padding: const EdgeInsets.all(12.0),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(5),
          gradient: gradient,  // Gradient background for the entire menu item
          boxShadow: [
            BoxShadow(
              color: Colors.black.withValues(alpha: 0.1),
              blurRadius: 8,
              offset: Offset(2, 4),
            ),
          ],
        ),
        child: Row(
          children: [
            // Icon container with gradient background
            Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: Colors.white.withValues(alpha: 0.3), // Semi-transparent white background
              ),
              child: Icon(
                icon,
                size: screenConfig.menuIconSize,
                color: Colors.white,
              ),
            ),
            const SizedBox(width: 20),
            // Text
            Expanded(
              child: Text(
                text,
                style: TextStyle(
                  color: Colors.white,
                  fontSize: screenConfig.menuFontSize,
                  fontWeight: FontWeight.w600,
                ),
              ),
            ),
            // Arrow indicator
            Icon(
              Icons.arrow_forward_ios,
              color: Colors.white,
              size: screenConfig.menuIconSize * 0.8,
            ),
          ],
        ),
      ),
    );
  }
}
