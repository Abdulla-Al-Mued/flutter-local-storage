import 'package:flutter/material.dart';
import 'package:theory_test_ltd/common/base_widgets/screen_config.dart';

class TheorySettingsMenuItem extends StatelessWidget {
  final IconData icon;
  final String text;
  final LinearGradient gradient;
  final ScreenConfig screenConfig;
  final VoidCallback onTap;

  const TheorySettingsMenuItem({
    super.key,
    required this.icon,
    required this.text,
    required this.gradient,
    required this.screenConfig,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        margin: const EdgeInsets.symmetric(vertical: 8.0),
        padding: const EdgeInsets.all(12.0),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(5),
          gradient: gradient,
          boxShadow: [
            BoxShadow(
              color: Colors.black.withValues(alpha:0.1),
              blurRadius: 8,
              offset: Offset(2, 4),
            ),
          ],
        ),
        child: Row(
          children: [
              
            Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: Colors.white.withValues(alpha:0.3),
              ),
              child: Icon(
                icon,
                size: screenConfig.menuIconSize,
                color: Colors.white,
              ),
            ),
            const SizedBox(width: 20),
              
            Expanded(
              child: Text(
                text,
                style: TextStyle(
                  color: Colors.white,
                  fontSize: screenConfig.menuFontSize,
                  fontWeight: FontWeight.w600,
                ),
              ),
            ),
              
     
          ],
        ),
      ),
    );
  }
}
