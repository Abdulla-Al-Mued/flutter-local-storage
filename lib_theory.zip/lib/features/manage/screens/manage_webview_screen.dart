import 'dart:async';
import 'package:flutter/material.dart';
import 'package:hive/hive.dart';
import 'package:theory_test_ltd/common/base_widgets/custom_app_bar.dart';
import 'package:theory_test_ltd/common/base_widgets/loading_animation.dart';
import 'package:theory_test_ltd/utils/color_resources.dart';
import 'package:webview_flutter/webview_flutter.dart';
import 'package:connectivity_plus/connectivity_plus.dart';

class ManageWebViewScreen extends StatefulWidget {
  final String htmlAssetPath;

  const ManageWebViewScreen({super.key, required this.htmlAssetPath});

  @override
  State<ManageWebViewScreen> createState() => _ManageWebViewScreenState();
}

class _ManageWebViewScreenState extends State<ManageWebViewScreen> {
  var isLoading = ValueNotifier<bool>(true);
  late WebViewController controller;
  late Box favoritesBox;
  bool isFavorite = false;
  bool hasInternet = true;
  late List<ConnectivityResult> _connectivityResult;
  late StreamSubscription<List<ConnectivityResult>> _connectivitySubscription;

  @override
  void initState() {
    super.initState();
    checkInternetConnection();
    _connectivitySubscription = Connectivity().onConnectivityChanged.listen((List<ConnectivityResult> results) {
      updateInternetStatus(results);
    });

    controller = WebViewController()
      ..setJavaScriptMode(JavaScriptMode.unrestricted)
      ..loadRequest(Uri.parse(widget.htmlAssetPath));

    controller.setNavigationDelegate(
      NavigationDelegate(onPageFinished: (String url) async {
        isLoading.value = false;
      }),
    );
  }

  Future<void> checkInternetConnection() async {
    _connectivityResult = await Connectivity().checkConnectivity();
    updateInternetStatus(_connectivityResult);
  }

  void updateInternetStatus(List<ConnectivityResult> results) {
    if (results.contains(ConnectivityResult.none)) {
      setState(() {
        hasInternet = false;
      });
    } else {
      setState(() {
        hasInternet = true;
      });
    }
  }

  @override
  void dispose() {
    _connectivitySubscription.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: CustomAppBar(
        title: '',
        gradientColors: [
          AppColors.midnightBlue,
          AppColors.blue,
        ],
      ),
      body: hasInternet
          ? ValueListenableBuilder<bool>(
        valueListenable: isLoading,
        builder: (context, value, _) {
          return Stack(
            children: <Widget>[
              WebViewWidget(controller: controller),
              if (value)
                const Center(
                  child: LoadingAnimation(),
                ),
            ],
          );
        },
      )
          : Center(
        child: Text(
          'No Internet Connection',
          style: TextStyle(
            fontSize: 20,
            color: AppColors.primary,
          ),
        ),
      ),
    );
  }
}