import 'dart:io';

import 'package:flutter/material.dart';
import 'package:share_plus/share_plus.dart';
import 'package:theory_test_ltd/common/base_widgets/custom_app_bar.dart';
import 'package:theory_test_ltd/common/base_widgets/navigate_pages.dart';
import 'package:theory_test_ltd/common/base_widgets/screen_config.dart';
import 'package:theory_test_ltd/features/categories/screens/categories_screen.dart';
import 'package:theory_test_ltd/features/manage/screens/manage_webview_screen.dart';
import 'package:theory_test_ltd/features/manage/widgets/manage_wigdets.dart';
import 'package:theory_test_ltd/features/progress_status/local_database/clear_progress_data.dart';
import 'package:theory_test_ltd/utils/color_resources.dart';

import '../../categories/widgets/data_clear_alert.dart';

class ManageScreen extends StatelessWidget {
  const ManageScreen({super.key});

  final String websiteLink = "https://theoryexam.co.uk/";  // Your website link
  final String playStoreLink = "https://play.google.com/store/apps/details?id=com.example.yourapp";
  // Your app's Play Store link
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.aliceBlue,
      appBar: CustomAppBar(
        title: 'Manage',
        gradientColors: [
          AppColors.midnightBlue,
          AppColors.blue,
        ],
      ),
      body: LayoutBuilder(
        builder: (context, constraints) {
          final screenConfig = getScreenConfig(constraints, context);

          return Padding(
            padding: const EdgeInsets.all(10.0),
            child: SingleChildScrollView(
              child: Column(
                children: [
                  // MenuItem(
                  //   icon: Icons.settings,
                  //   text: 'Theory Settings',
                  //   gradient: LinearGradient(
                  //     colors: [AppColors.midnightBlue, Colors.lightBlueAccent],
                  //     begin: Alignment.topLeft,
                  //     end: Alignment.bottomRight,
                  //   ),
                  //   screenConfig: screenConfig,
                  //   onTap: () {
                  //     navigateTo(() => const TheorySettingsScreen());
                  //   },
                  // ),
                  MenuItem(
                    icon: Icons.download_rounded,
                    text: 'Download',
                    gradient: LinearGradient(
                      colors: [Colors.teal, Colors.greenAccent],
                      begin: Alignment.topLeft,
                      end: Alignment.bottomRight,
                    ),
                    screenConfig: screenConfig,
                    onTap: () {
                      navigateTo(()=> CategoriesScreen());
                    },
                  ),
                  MenuItem(
                    icon: Icons.lock_reset,
                    text: 'Reset Progress',
                    gradient: LinearGradient(
                      colors: [Colors.orange, Colors.deepOrange],
                      begin: Alignment.topLeft,
                      end: Alignment.bottomRight,
                    ),
                    screenConfig: screenConfig,
                    onTap: () async {
                      //showDeleteConfirmationDialog(context);
                      String result = await showDeleteDialog(
                          context,
                          "Are you sure you want to reset all progress? This action cannot be undone.",
                          'Confirm Deletion'
                      );
                      if (result == 'n') {
                        return;
                      }
                      ClearProgressData clearData = ClearProgressData();
                      await clearData.clearAllTables();
                      Navigator.of(context).pop(); // Close dialog
                      ScaffoldMessenger.of(context).showSnackBar(
                        SnackBar(content: Text("All data deleted successfully")),
                      );
                    },
                  ),
                  MenuItem(
                    icon: Icons.share_rounded,
                    text: 'Share Us',
                    gradient: LinearGradient(
                      colors: [Colors.pinkAccent, Colors.deepPurple],
                      begin: Alignment.topLeft,
                      end: Alignment.bottomRight,
                    ),
                    screenConfig: screenConfig,
                    onTap: () {
                      if (Platform.isIOS) {
                        // iOS-specific sharing
                        Share.share(
                          'Check out our website: $websiteLink\n\nDownload our app here: $playStoreLink',
                          subject: 'Share Our App',
                        );
                      } else {
                        // Android and other platforms
                        Share.share(
                          'Check out our website: $websiteLink\n\nDownload our app here: $playStoreLink',
                        );
                      }
                    },
                  ),
                  MenuItem(
                    icon: Icons.contact_page_rounded,
                    text: 'Contact Us',
                    gradient: LinearGradient(
                      colors: [Colors.indigoAccent, Colors.lightBlue],
                      begin: Alignment.topLeft,
                      end: Alignment.bottomRight,
                    ),
                    screenConfig: screenConfig,
                    onTap: () {
                      navigateTo(()=>ManageWebViewScreen(htmlAssetPath: 'https://drivingtheoryexam.com/contact/'));
                    },
                  ),
                  MenuItem(
                    icon: Icons.delete_rounded,
                    text: 'Delete Account',
                    gradient: LinearGradient(
                      colors: [Colors.red, Colors.redAccent],
                      begin: Alignment.topLeft,
                      end: Alignment.bottomRight,
                    ),
                    screenConfig: screenConfig,
                    onTap: () {
                      navigateTo(()=>ManageWebViewScreen(htmlAssetPath: 'https://drivingtheoryexam.com/delete-my-data/'));
                    },
                  ),
                  MenuItem(
                    icon: Icons.privacy_tip_outlined,
                    text: 'Privacy Policy',
                    gradient: LinearGradient(
                      colors: [AppColors.midnightBlue, Colors.lightBlueAccent],
                      begin: Alignment.topLeft,
                      end: Alignment.bottomRight,
                    ),
                    screenConfig: screenConfig,
                    onTap: () {
                      navigateTo(()=>ManageWebViewScreen(htmlAssetPath: 'https://drivingtheoryexam.com/privacy-policy'));
                    },
                  ),
                  MenuItem(
                    icon: Icons.description ,
                    text: 'Term & Conditions',
                    gradient: LinearGradient(
                      colors: [AppColors.teal, AppColors.steelBlue],
                      begin: Alignment.topLeft,
                      end: Alignment.bottomRight,
                    ),
                    screenConfig: screenConfig,
                    onTap: () {
                      navigateTo(()=>ManageWebViewScreen(htmlAssetPath: 'https://drivingtheoryexam.com/terms-and-conditions/'));
                    },
                  ),
                  MenuItem(
                    icon: Icons.info_rounded,
                    text: 'About Us',
                    gradient: LinearGradient(
                      colors: [Colors.cyan, Colors.deepPurpleAccent],
                      begin: Alignment.topLeft,
                      end: Alignment.bottomRight,
                    ),
                    screenConfig: screenConfig,
                    onTap: () {
                      navigateTo(()=>ManageWebViewScreen(htmlAssetPath: 'https://drivingtheoryexam.com/about-us'));
                    },
                  ),
                ],
              ),
            ),
          );
        },
      ),
    );
  }
}
