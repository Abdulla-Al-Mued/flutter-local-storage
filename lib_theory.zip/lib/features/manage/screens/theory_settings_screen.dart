import 'package:flutter/material.dart';
import 'package:theory_test_ltd/common/base_widgets/custom_app_bar.dart';
import 'package:theory_test_ltd/common/base_widgets/screen_config.dart';
import 'package:theory_test_ltd/features/manage/widgets/theory_test_widgets.dart';
import 'package:theory_test_ltd/utils/color_resources.dart';

class TheorySettingsScreen extends StatelessWidget {
  const TheorySettingsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.aliceBlue,
      appBar: CustomAppBar(
        title: 'Theory Settings',
        gradientColors: [
          AppColors.midnightBlue,
          AppColors.blue,
        ],
      ),
      body: LayoutBuilder(
        builder: (context, constraints) {
          final screenConfig = getScreenConfig(constraints, context);

          return Padding(
            padding: const EdgeInsets.all(10.0),
            child: SingleChildScrollView(
              child: Column(
                children: [
                     
                  TheorySettingsMenuItem(
                    icon: Icons.record_voice_over,
                    text: 'Text to Speech',
                    gradient: LinearGradient(
                      colors: [Colors.purple, Colors.blue],
                      begin: Alignment.topLeft,
                      end: Alignment.bottomRight,
                    ),
                    screenConfig: screenConfig,
                    onTap: () {
                         
                    },
                  ),
                     
                  TheorySettingsMenuItem(
                    icon: Icons.play_circle,
                    text: 'Auto Next Question',
                    gradient: LinearGradient(
                      colors: [Colors.orange, Colors.red],
                      begin: Alignment.topLeft,
                      end: Alignment.bottomRight,
                    ),
                    screenConfig: screenConfig,
                    onTap: () {
                         
                    },
                  ),
                     
                ],
              ),
            ),
          );
        },
      ),
    );
  }
}
