import 'dart:convert';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:theory_test_ltd/common/base_widgets/loading_animation.dart';
import 'package:theory_test_ltd/common/base_widgets/navigate_pages.dart';
import 'package:theory_test_ltd/common/base_widgets/screen_config.dart';
import 'package:theory_test_ltd/features/hazard_perception/screens/hazard_perception_screen.dart';
import 'package:theory_test_ltd/features/highway_code/screens/highway_code_screen.dart';
import 'package:theory_test_ltd/features/manage/screens/manage_screen.dart';
import 'package:theory_test_ltd/features/profile/domain/models/registration_model.dart';
import 'package:theory_test_ltd/features/profile/screens/profile_screen.dart';
import 'package:theory_test_ltd/features/progress_status/screens/progress_status_screen.dart';
import 'package:theory_test_ltd/features/road_sign/screens/road_sign_screen.dart';
import 'package:theory_test_ltd/features/theory_test/screens/theory_test_screen.dart';
import 'package:theory_test_ltd/utils/color_resources.dart';
import 'package:theory_test_ltd/utils/images.dart';
import '../widgets/dashboard_widgets.dart';

class DashboardScreen extends StatefulWidget {
  const DashboardScreen({super.key});

  @override
  State<DashboardScreen> createState() => _DashboardScreenState();
}

class _DashboardScreenState extends State<DashboardScreen> {
  bool isLoading = true;
  String userName = '';
  String theoryexam = '';
  bool examDate = false;
  String? userImage;
  final String _imageKey = 'profile_image';
  late Uint8List? imageB = Uint8List(1);

  @override
  void initState() {
    super.initState();
    _loadImage();
    _loadProfileData();
    Future.delayed(const Duration(seconds: 1), () {
      setState(() {
        isLoading = false;
      });
    });
  }

  Future<void> _loadProfileData() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    String? storedData = prefs.getString('registrationData');

    if (storedData != null) {
      Map<String, dynamic> jsonData = json.decode(storedData);
      RegistrationModel savedData = RegistrationModel.fromJson(jsonData);

      setState(() {
        userName = savedData.name;
        theoryexam = savedData.dateOfExam;

        if (theoryexam == "") {
          examDate = true;
          print(theoryexam);
        } else {
          examDate = false;
        }
      });
    }
  }

  Future<void> _loadImage() async {
    try {
      SharedPreferences prefs = await SharedPreferences.getInstance();
      String? base64Image = prefs.getString(_imageKey);
      if (base64Image != null) {
        final bytes = base64Decode(base64Image);
        imageB = bytes;
        setState(() {});
      }
    } catch (e) {
      print(e);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.backgroundLight,
      body: isLoading
          ? Center(child: LoadingAnimation())
          : LayoutBuilder(
              builder: (context, constraints) {
                ScreenConfig config = getScreenConfig(constraints, context);
                double topPadding = constraints.maxHeight * 0.07;

                return SingleChildScrollView(
                  child: Column(
                    children: [
                      Stack(
                        children: [
                          Image.asset(
                            Images.homeBg,
                            fit: BoxFit.cover,
                            width: double.infinity,
                            height: MediaQuery.of(context).orientation ==
                                    Orientation.portrait
                                ? config.topCurveHeight
                                : 250, // landscape height
                          ),
                          Positioned(
                            top: topPadding,
                            left: 20,
                            child: Row(
                              children: [
                                Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text(
                                      "Welcome Back",
                                      style: TextStyle(
                                        fontSize: config.fontSizeTitle,
                                        color: Colors.white,
                                        fontWeight: FontWeight.bold,
                                      ),
                                    ),
                                    SizedBox(height: 18),
                                    Text(
                                      userName,
                                      style: TextStyle(
                                        fontSize: config.fontSizeSubtitle,
                                        color: Colors.white,
                                      ),
                                    ),
                                  ],
                                ),
                              ],
                            ),
                          ),
                          Positioned(
                            top: topPadding + 40,
                            right: 20,
                            child: GestureDetector(
                              onTap: () async {
                                setState(() => isLoading = true);
                                await Navigator.push(
                                  context,
                                  MaterialPageRoute(
                                      builder: (_) => ProfileScreen()),
                                );
                                await _loadProfileData();
                                await _loadImage();
                                setState(() => isLoading = false);
                              },
                              child: Container(
                                padding: const EdgeInsets.all(5),
                                decoration: BoxDecoration(
                                  shape: BoxShape.circle,
                                  border:
                                      Border.all(color: Colors.white, width: 2),
                                  boxShadow: [
                                    BoxShadow(
                                      color:
                                          Colors.black.withValues(alpha: 0.2),
                                      blurRadius: 8,
                                      spreadRadius: 1,
                                    ),
                                  ],
                                ),
                                child: ClipRRect(
                                  borderRadius: BorderRadius.circular(25.0),
                                  child: imageB != null
                                      ? Image.memory(
                                          imageB!,
                                          height: config.homeAvatar,
                                          width: config.homeAvatar,
                                          fit: BoxFit.cover,
                                          errorBuilder: (_, __, ___) => Icon(
                                              Icons.person,
                                              size: config.homeAvatar),
                                        )
                                      : Icon(Icons.person,
                                          size: config.homeAvatar,
                                          color: Colors.white70),
                                ),
                              ),
                            ),
                          ),
                        ],
                      ),

                      // Inside your widget tree
                      if (MediaQuery.of(context).orientation ==
                              Orientation.portrait &&
                          !config.isTablet)
                        Image.asset(
                          Images.carDashboard,
                          fit: BoxFit.cover,
                          width: double.infinity,
                          height: 140,
                        ),

                      /// Grid section
                      Container(
                        width: double.infinity,
                        color: AppColors.custom,
                        padding: const EdgeInsets.only(
                            left: 20, right: 20, bottom: 30),
                        child: Column(
                          children: [
                            if(examDate == true)Padding(
                              padding: EdgeInsets.all(8),
                              child: Container(
                                padding: EdgeInsets.all(8),
                                decoration: BoxDecoration(
                                    borderRadius: BorderRadius.circular(5),
                                    color: AppColors.red
                                ),
                                child: Text("Please update your Theory exam date from profile",style: TextStyle(
                                  color: Colors.white,
                                  fontSize: config.fontSizeDashboard
                                ),
                                textAlign: TextAlign.center,),
                              ),
                            ),
                            GridView.count(
                              crossAxisCount: config.gridCrossAxisCount,
                              crossAxisSpacing: 10,
                              mainAxisSpacing: 10,
                              childAspectRatio: 1.30,
                              physics: const NeverScrollableScrollPhysics(),
                              shrinkWrap: true,
                              children: [
                                MenuCard(
                                  icon: AssetImage(Images.examIcon),
                                  iconSize: config.isTablet ? 90 : 70,
                                  label: "Theory",
                                  onTap: () =>
                                      navigateTo(() => TheoryTestScreen()),
                                ),
                                MenuCard(
                                  icon: AssetImage(Images.hazardIcon),
                                  iconSize: config.isTablet ? 90 : 70,
                                  label: "Hazard",
                                  onTap: () => navigateTo(
                                      () => HazardPerceptionScreen()),
                                  // onTap: (){}
                                ),
                                MenuCard(
                                  icon: AssetImage(Images.roadSignsIcon),
                                  iconSize: config.isTablet ? 90 : 70,
                                  label: "Road Sign",
                                  onTap: () =>
                                      navigateTo(() => RoadSignScreen()),
                                ),
                                MenuCard(
                                  icon: AssetImage(Images.highwayCodeIcon),
                                  iconSize: config.isTablet ? 90 : 70,
                                  label: "Highway Code",
                                  onTap: () =>
                                      navigateTo(() => HighwayCodeScreen()),
                                ),
                                MenuCard(
                                  icon: AssetImage(Images.progressIcon),
                                  iconSize: config.isTablet ? 90 : 70,
                                  label: "Progress",
                                  onTap: () =>
                                      navigateTo(() => ProgressStatusScreen()),
                                ),
                                MenuCard(
                                  icon: AssetImage(Images.manageIcon),
                                  iconSize: config.isTablet ? 90 : 70,
                                  label: "Manage",
                                  onTap: () => navigateTo(() => ManageScreen()),
                                ),
                              ],
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                );
              },
            ),
    );
  }
}
