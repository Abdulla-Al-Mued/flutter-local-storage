import 'package:flutter/material.dart';
import 'package:smooth_page_indicator/smooth_page_indicator.dart';
import 'package:theory_test_ltd/common/base_widgets/screen_config.dart';
import 'package:theory_test_ltd/features/dashboard/widgets/onboard_widgets.dart';
import 'package:theory_test_ltd/features/profile/screens/registration_screen.dart';
import 'package:theory_test_ltd/utils/color_resources.dart';
import 'package:theory_test_ltd/utils/images.dart';

class OnboardScreen extends StatefulWidget {
  final ScreenConfig screenConfig;

  const OnboardScreen({super.key, required this.screenConfig});

  @override
  OnboardScreenState createState() => OnboardScreenState();
}

class OnboardScreenState extends State<OnboardScreen> {
  final PageController _pageController = PageController();
  int _currentPage = 0;


  @override
  Widget build(BuildContext context) {
    double screenHeight = MediaQuery.of(context).size.height;

    return Scaffold(
      backgroundColor: AppColors.primary200,
      body: Stack(
        children: [
          Column(
            children: [
              Expanded(
                child: PageView(
                  controller: _pageController,
                  onPageChanged: (index) {
                    setState(() {
                      _currentPage = index;
                    });
                  },
                  children: [
                    OnboardWidgets(
                      gradientColors: [Colors.blue, Colors.blueAccent],
                      title: "Welcome To\nDriving Theory Exam Test",
                      subtitle: "Let’s continue your journey!",
                      image: Images.logo,
                      screenConfig: widget.screenConfig,
                    ),
                    OnboardWidgets(
                      gradientColors: [
                        AppColors.secondary,
                        AppColors.primary,
                      ],
                      title: "Theory Test",
                      subtitle: "Easily prepare for your driving theory exam with our app. Access mock tests,Stay confident, track your progress, and pass your test with ease!",
                      image: Images.examIcon,
                      screenConfig: widget.screenConfig,
                    ),
                    OnboardWidgets(
                      gradientColors: [
                        AppColors.blue,
                        AppColors.steelBlue,
                      ],
                      title: "Practice Hazard",
                      subtitle: "Enhance your hazard perception skills with our app. Practice using realistic hazard perception videos, track your progress, and improve your reaction times. Stay sharp and ready for your driving test!",
                      image: Images.hazardIcon,
                      screenConfig: widget.screenConfig,
                    ),
                    OnboardWidgets(
                      gradientColors: [
                        AppColors.yellowLightMenu,
                        AppColors.yellowLightMenuLight,
                      ],
                      title: "Learn Road Signs",
                      subtitle: "Master all road signs for your driving test with our app. Access a complete guide to road signs, practice identifying them, and test your knowledge to ensure you're fully prepared for the exam!",
                      image: Images.roadSignsIcon,
                      screenConfig: widget.screenConfig,
                      isLastScreen: true,
                    ),
                    OnboardWidgets(
                      gradientColors: [
                        AppColors.iceGreen,
                        AppColors.iceGreenLight,
                      ],
                      title: "Learn Highway Code",
                      subtitle: "Master the Highway Code for your driving test with our app. Learn the essential rules, practice key topics, and test your knowledge to ensure you're fully prepared to ace the exam!",
                      image: Images.highwayCodeIcon,
                      screenConfig: widget.screenConfig,
                      isLastScreen: true,
                    ),
                  ],
                ),
              ),
            ],
          ),
          Positioned(
            top: screenHeight * 0.86,
            left: 16,
            right: 16,
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.center,
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                if (_currentPage != 4)
                  TextButton(
                    onPressed: () {
                      _pageController.animateToPage(4,
                          duration: const Duration(milliseconds: 300),
                          curve: Curves.easeInOut);
                    },
                    style: TextButton.styleFrom(
                      foregroundColor: Colors.orange.shade200,
                      padding: const EdgeInsets.symmetric(
                          horizontal: 20, vertical: 10),
                      side: BorderSide(
                        color: AppColors.grey,
                        width: 2,
                      ),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(8),
                      ),
                    ),
                    child: const Text(
                      "Skip",
                      style: TextStyle(color: Colors.white),
                    ),
                  ),
                const SizedBox(height: 10),
                if (_currentPage == 4)
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      ElevatedButton(
                        onPressed: () {

                          Navigator.pushAndRemoveUntil(
                            context,
                            MaterialPageRoute(builder: (context) => RegistrationScreen()),
                                (Route<dynamic> route) => false,  // This removes all previous routes
                          );

                        },
                        style: ElevatedButton.styleFrom(
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(8),
                          ),
                          padding: const EdgeInsets.symmetric(
                              horizontal: 30, vertical: 12),
                          backgroundColor: AppColors.orange,
                        ),
                        child: const Text("Let's Start",
                            style: TextStyle(color: AppColors.white)),
                      ),
                    ],
                  )
                else
                  ElevatedButton(
                    onPressed: () {
                      _pageController.nextPage(
                          duration: const Duration(milliseconds: 300),
                          curve: Curves.easeInOut);
                    },
                    style: ElevatedButton.styleFrom(
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(8),
                      ),
                      padding: const EdgeInsets.symmetric(
                          horizontal: 30, vertical: 12),
                      backgroundColor: AppColors.primary200,
                    ),
                    child: const Text("Next",
                        style: TextStyle(color: AppColors.black)),
                  ),
              ],
            ),
          ),
          Positioned(
            bottom: screenHeight * 0.05,
            left: 0,
            right: 0,
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                SmoothPageIndicator(
                  controller: _pageController,
                  count: 5,
                  effect: ExpandingDotsEffect(
                    dotHeight: 10,
                    dotWidth: 10,
                    activeDotColor: Colors.pink.shade400,
                    dotColor: Colors.white,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
