import 'package:flutter/material.dart';
import 'package:theory_test_ltd/utils/color_resources.dart';

// Modern redesigned MenuCard widget with overflow fixes
class MenuCard extends StatelessWidget {
  final ImageProvider icon;
  final String label;
  final double iconSize;
  final VoidCallback onTap;

  const MenuCard({
    super.key,
    required this.icon,
    required this.iconSize,
    required this.label,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    // Get available width to calculate responsive sizes
    final screenWidth = MediaQuery.of(context).size.width;
    final isSmallScreen = screenWidth < 360;

    // Adjust padding based on screen size
    final padding = isSmallScreen ? 8.0 : 16.0;

    // Calculate responsive icon size
    final responsiveIconSize = screenWidth * 0.18  > iconSize ? iconSize : screenWidth * 0.2;

    return GestureDetector(
      onTap: onTap,
      child: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [
              Colors.white,
              Colors.grey.shade50,
            ],
          ),
          borderRadius: BorderRadius.circular(10),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withValues(alpha: 0.08),
              spreadRadius: 0,
              blurRadius: 10,
              offset: const Offset(0, 4),
            ),
          ],
        ),
        child: ClipRRect(
          borderRadius: BorderRadius.circular(20),
          child: Stack(
            children: [
              // Main content with responsive padding
              Padding(
                padding: EdgeInsets.all(padding),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    // Category label with responsive sizing
                    FittedBox(
                      fit: BoxFit.scaleDown,
                      child: Container(
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(4),
                          color: getColorForLabel(label).withValues(alpha: 0.2),
                        ),
                        padding: EdgeInsets.symmetric(
                            horizontal: isSmallScreen ? 8 : 12,
                            vertical: isSmallScreen ? 4 : 6),
                        child: Text(
                          label,
                          style: TextStyle(
                            fontSize: screenWidth > 600
                                ? 18
                                : (isSmallScreen ? 10 : 12),
                            color: getColorForLabel(label),
                            fontWeight: FontWeight.w600,
                          ),
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                        ),
                      ),
                    ),

                    // Icon with responsive sizing
                    Align(
                      alignment: Alignment.bottomRight,
                      child: Image(
                        image: icon,
                        height: responsiveIconSize,
                        fit: BoxFit.contain,
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  // Function to get color based on category
  Color getColorForLabel(String label) {
    switch (label) {
      case "Theory":
        return AppColors.primary;
      case "Hazard":
        return AppColors.blue;
      case "Road Sign":
        return AppColors.yellowLightMenu;
      case "Highway Code":
        return AppColors.iceGreenLight;
      case "Progress":
        return AppColors.pink;
      case "Manage":
        return AppColors.orange;
      default:
        return const Color(0xFF2196F3);
    }
  }
}
