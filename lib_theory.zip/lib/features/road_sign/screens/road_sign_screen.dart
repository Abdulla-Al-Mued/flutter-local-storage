import 'package:flutter/material.dart';
import 'package:theory_test_ltd/common/base_widgets/custom_app_bar.dart';
import 'package:theory_test_ltd/common/base_widgets/navigate_pages.dart';
import 'package:theory_test_ltd/common/base_widgets/screen_config.dart';
import 'package:theory_test_ltd/features/road_sign/screens/bookmark_screen.dart';
import 'package:theory_test_ltd/features/road_sign/screens/get_started_screen.dart';
import 'package:theory_test_ltd/features/road_sign/screens/traffic_sign_category_screen.dart';
import 'package:theory_test_ltd/features/road_sign/screens/traffic_sign_screen.dart';
import 'package:theory_test_ltd/features/road_sign/widgets/road_sign_widgets.dart';
import 'package:theory_test_ltd/utils/color_resources.dart';


class RoadSignScreen extends StatelessWidget {
  const RoadSignScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.backgroundLight,
      appBar: CustomAppBar(
        title: 'Road Signs',
        gradientColors: [
          AppColors.yellowLightMenu,
          AppColors.yellowLightMenuLight,
        ],
      ),
      body: LayoutBuilder(
        builder: (context, constraints) {
          final screenConfig = getScreenConfig(constraints, context);

          return Padding(
            padding: const EdgeInsets.all(10.0),
            child: SingleChildScrollView(
              child: Column(
                children: [
                  RoadSignMenuItem(
                    iconBg: AppColors.darkSlateGray,
                    icon: Icons.rocket_launch,
                    text: 'Get Started',
                    color: AppColors.yellowLightMenu,
                    screenConfig: screenConfig,
                    onTap: () {
                      navigateTo(()=> GetStartedScreen());
                    },
                  ),
                  RoadSignMenuItem(
                    iconBg: AppColors.darkOliveGreen,
                    icon: Icons.add_road,
                    text: 'learn Road Signs',
                    color: AppColors.yellowLightMenu,
                    screenConfig: screenConfig,
                    onTap: () {
                      navigateTo(()=> TrafficSignScreen());
                    },
                  ),
                  RoadSignMenuItem(
                    iconBg: AppColors.indigo,
                    icon: Icons.category,
                    text: 'Categories',
                    color: AppColors.yellowLightMenu,
                    screenConfig: screenConfig,
                    onTap: () {
                      navigateTo(()=> TrafficSignCategoryScreen());
                    },
                  ),

                  RoadSignMenuItem(
                    iconBg: AppColors.secondary,
                    icon: Icons.bookmark_border,
                    text: 'Bookmarks Signs',
                    color: AppColors.yellowLightMenu,
                    screenConfig: screenConfig,
                    onTap: () {
                      navigateTo(()=> BookmarkScreen());
                    },
                  ),


                ],
              ),
            ),
          );
        },
      ),
    );
  }
}
