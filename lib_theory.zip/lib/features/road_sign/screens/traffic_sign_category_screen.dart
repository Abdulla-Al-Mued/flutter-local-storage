import 'package:flutter/material.dart';
import 'package:theory_test_ltd/common/base_widgets/custom_app_bar.dart';
import 'package:theory_test_ltd/common/base_widgets/navigate_pages.dart';
import 'package:theory_test_ltd/data/local/static/traffic_sign_data.dart';
import 'package:theory_test_ltd/features/road_sign/screens/traffic_sign_webview_screen.dart';
import 'package:theory_test_ltd/features/road_sign/widgets/traffic_sign_widgets.dart';
import 'package:theory_test_ltd/utils/color_resources.dart';
import 'package:theory_test_ltd/common/base_widgets/screen_config.dart';

class TrafficSignCategoryScreen extends StatefulWidget {
  const TrafficSignCategoryScreen({super.key});

  @override
  State<TrafficSignCategoryScreen> createState() => _TrafficSignCategoryScreenState();
}

class _TrafficSignCategoryScreenState extends State<TrafficSignCategoryScreen> {
   
  Map<String, List<TrafficSignData>> categorizedSigns = {};

  @override
  void initState() {
    super.initState();
     
    for (var sign in trafficSignData) {
      if (categorizedSigns[sign.category] == null) {
        categorizedSigns[sign.category] = [];
      }
      categorizedSigns[sign.category]?.add(sign);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: CustomAppBar(
        title: 'Road Signs by Category',
        gradientColors: [
          AppColors.yellowLightMenu,
          AppColors.yellowLightMenuLight,
        ],
      ),
      body: LayoutBuilder(
        builder: (context, constraints) {
          return ListView.builder(
            itemCount: categorizedSigns.keys.length,
            itemBuilder: (context, index) {
              final category = categorizedSigns.keys.elementAt(index);
              final signs = categorizedSigns[category]!;

              return Container(
                margin: const EdgeInsets.symmetric(vertical: 5.0, horizontal: 10.0),
                padding: const EdgeInsets.all(8),
                decoration: BoxDecoration(
                  color: AppColors.yellowLightMenu.withValues(alpha: 0.1),
                  borderRadius: BorderRadius.circular(10),
                  border: Border.all(color: AppColors.yellowLightMenu),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      category,
                      style: const TextStyle(
                        fontWeight: FontWeight.bold,
                        fontSize: 18,
                        color: AppColors.megenda,
                      ),
                    ),
                    const SizedBox(height: 10),
                    Column(
                      children: signs.map((sign) {
                        return TrafficSignMenuItem(
                          text: sign.title,
                          color: AppColors.yellowLightMenu,
                          screenConfig: getScreenConfig(constraints, context),  
                          onTap: () {
                            navigateTo(() => TrafficSignWebViewScreen(
                              htmlAssetPath: sign.assets,
                              title: sign.title,
                            ));
                          },
                        );
                      }).toList(),
                    ),
                  ],
                ),
              );
            },
          );
        },
      ),
    );
  }
}
