import 'package:flutter/material.dart';
import 'package:theory_test_ltd/common/base_widgets/custom_app_bar.dart';
import 'package:theory_test_ltd/common/base_widgets/navigate_pages.dart';
import 'package:theory_test_ltd/data/local/static/traffic_sign_data.dart';
import 'package:theory_test_ltd/features/road_sign/screens/traffic_sign_webview_screen.dart';
import 'package:theory_test_ltd/features/road_sign/widgets/traffic_sign_widgets.dart';
import 'package:theory_test_ltd/utils/color_resources.dart';
import 'package:theory_test_ltd/common/base_widgets/screen_config.dart';

class TrafficSignScreen extends StatefulWidget {
  const TrafficSignScreen({super.key});

  @override
  State<TrafficSignScreen> createState() => _TrafficSignScreenState();
}

class _TrafficSignScreenState extends State<TrafficSignScreen> {
  List highwayCodeDataFiltered = trafficSignData;
  TextEditingController searchController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: CustomAppBar(
        title: 'Road Signs',
        gradientColors: [
          AppColors.yellowLightMenu,
          AppColors.yellowLightMenuLight,
        ],
      ),
      body: LayoutBuilder(
        builder: (context, constraints) {
          final screenConfig = getScreenConfig(constraints, context);
          return Padding(
            padding: const EdgeInsets.all(10.0),
            child: Column(
              children: [
                    
                TextField(
                  controller: searchController,
                  onChanged: (value) {
                    setState(() {
                      highwayCodeDataFiltered = trafficSignData
                          .where((item) => item.title
                              .toLowerCase()
                              .contains(value.toLowerCase()))
                          .toList();
                    });
                  },
                  decoration: InputDecoration(
                    hintText: 'Search...',
                    prefixIcon: const Icon(Icons.search),
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(10),
                    ),
                  ),
                ),
                const SizedBox(height: 10),
                    
                Expanded(
                  child: ListView.builder(
                    itemCount: highwayCodeDataFiltered.length,
                    itemBuilder: (context, index) {
                      final item = highwayCodeDataFiltered[index];
                      return TrafficSignMenuItem(
                        text: item.title,
                        color: AppColors.yellowLightMenu,
                        screenConfig: screenConfig,
                        onTap: () {
                          navigateTo(
                            () => TrafficSignWebViewScreen(
                              htmlAssetPath: item.assets,
                              title: item.title,
                            ),
                          );
                        },
                      );
                    },
                  ),
                ),
              ],
            ),
          );
        },
      ),
    );
  }

  @override
  void dispose() {
    searchController.dispose();
    super.dispose();
  }
}
