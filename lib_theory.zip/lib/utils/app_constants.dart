class AppConstants{

  static const String appName = 'Theory Test Exam';
  static const String slogan = '';
  static const String appVersion = '1.0';

}