
  // base url for php live server
  const String baseUrl = 'http://app.drivingtheoryexam.com/theory_exam/';
  // base url for php live server
  const String baseUrlImage = 'http://app.drivingtheoryexam.com/';

  // base url for Hazard
  const String hazardBaseUrl = 'http://app.drivingtheoryexam.com/theory_exam/hazard/';


  // Category Menu endpoint
   const String categoryMenuEndPoint = 'theory_test_type_dtl_reg.php';

   // image download url
   const String imageDownloadUrl = 'http://app.drivingtheoryexam.com/theory_exam/image/';

  // image end point lists
  const String imageEndPointListUrl = 'http://app.drivingtheoryexam.com/theory_exam/thry_img_download.php';



  // All End point endpoint
  const String registrationEndPoint = 'customer_entry.php';
  const String updateEndPoint = 'customer_update.php';
