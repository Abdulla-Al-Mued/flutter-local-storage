class Images {
  static const String splashLogo = 'assets/images/logo_splash.png';


  //menu icons
  static const String examIcon = 'assets/images/11.png';
  static const String roadSignsIcon = 'assets/images/2.png';
  static const String hazardIcon = 'assets/images/33.png';
  static const String progressIcon = 'assets/images/rb_32285.png';
  static const String manageIcon = 'assets/images/5.png';
  static const String highwayCodeIcon = 'assets/images/6.png';
  static const String homeBg = 'assets/images/final_header.png';
  static const String logo = 'assets/icon/logo_final.png';
  static const String carDashboard = 'assets/images/car_dashboard.png';

  //category Images
  static const String adi = 'assets/images/adi.png';
  static const String car = 'assets/images/car.png';
  static const String lgv = 'assets/images/lgv.png';
  static const String motorcycle = 'assets/images/motorcycle.png';
  static const String pvc = 'assets/images/pcv.png';


}

class Animations {

  static const String loadingAnimation = 'assets/animation/loading.json';


}
