import 'package:flutter/material.dart';

class AppColors {
  // Primary Colors
  static const Color primary = Color(0xFF1B96B7);
  static const Color primary200 = Color(0xFFE8D5C4);

  // Secondary Colors
  static const Color secondary = Color(0xFF3A6D8C);
  static const Color lightPrimary = Color(0xFF6A9AB0);
  static const Color lightSecondary = Color(0xFFF6F6F1);

  // Background Colors
  static const Color background = Color(0xFFEAD8B1);
  static const Color backgroundLight = Color(0xFFD8E6EC);

  // Other Colors
  static const Color black = Color(0xff000000);
  static const Color white = Color(0xFFE9EEF4);
  static const Color lightSkyBlue = Color(0xff8DBFF6);
  static const Color harlequin = Color(0xff3FCC01);
  static const Color cris = Color(0xffE2206B);
  static const Color grey = Color(0xffF1F1F1);
  static const Color red = Color(0xFFD32F2F);
  static const Color pink = Color(0xFFFF0082);
  static const Color hintTextColor = Color(0xff9E9E9E);
  static const Color gainsBg = Color(0xffE6E6E6);
  static const Color yellow = Color(0xffFFE31A);
  static const Color deepYellow = Color(0xffF9E400);
  static const Color megenda = Color(0xff7C00FE);
  static const Color cayen = Color(0xff48CFCB);
  static const Color orange = Color(0xffFF6600);

  static const Color custom = Color(0xfff8e0d9);

  static const Color blue = Color(0xff074799);
  static const Color textBg = Color(0xffF3F9FF);
  static const Color teal = Color(0xff008080);
  static const Color coral = Color(0xffFF7F50);
  static const Color lavender = Color(0xffE6E6FA);
  static const Color mintGreen = Color(0xff98FF98);
  static const Color plum = Color(0xff8E4585);
  static const Color gold = Color(0xffFFD700);
  static const Color slateGrey = Color(0xff708090);
  static const Color indigo = Color(0xff4B0082);
  static const Color peach = Color(0xffFFDAB9);
  static const Color chartreuse = Color(0xff7FFF00);
  static const Color rubyRed = Color(0xff9B111E);
  static const Color ivory = Color(0xffFFFFF0);
  static const Color steelBlue = Color(0xff4682B4);
  static const Color rosyBrown = Color(0xffBC8F8F);
  static const Color chocolate = Color(0xffD2691E);
  static const Color iceGreen = Color(0xff1B4242);
  static const Color iceGreenLight = Color(0xff265d5d);
  static const Color iceGreenLight200 = Color(0xff46b4b4);
  static const Color iceGreenLightMenu = Color(0xff092635);
  static const Color yellowLightMenu = Color(0xff342883);
  static const Color yellowLightMenuLight = Color(0xff6b58f6);

// Dark Shades
  static const Color darkSlateGray = Color(0xff2F4F4F);
  static const Color midnightBlue = Color(0xff191970);
  static const Color charcoal = Color(0xff36454F);
  static const Color darkOliveGreen = Color(0xff556B2F);
  static const Color maroon = Color(0xff800000);

// Light Shades
  static const Color honeydew = Color(0xffF0FFF0);
  static const Color lavenderBlush = Color(0xffFFF0F5);
  static const Color mintCream = Color(0xffF5FFFA);
  static const Color peachPuff = Color(0xffFFDAB9);
  static const Color aliceBlue = Color(0xffF0F8FF);
  static const Color cate = Color(0xffFFFFFF);

  // Primary Color Map for MaterialColor
  static const Map<int, Color> primaryColorMap = {
    50: Color(0xFF4C6680),
    100: Color(0xFF3C4F6D),
    200: Color(0xFF2E3B5C),
    300: Color(0xFF1F284A),
    400: Color(0xFF17233F),
    500: Color(0xFF001F3F),
    600: Color(0xFF001A38),
    700: Color(0xFF001432),
    800: Color(0xFF000F2C),
    900: Color(0xFF000C26),
  };


  // Primary Swatch
  static const MaterialColor primarySwatch = MaterialColor(0xFF003C43, primaryColorMap);

  // Gradient Color List
  static  List<Color> flashDealGradientColorList = [
    Colors.pink.shade400,
    Colors.orange.shade200

  ];
  static  List<Color> cole = [
    iceGreenLight.withAlpha(50),
    cate.withAlpha(95)

  ];
}
