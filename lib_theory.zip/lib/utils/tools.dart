import 'package:get_ip_address/get_ip_address.dart';

Future<String> getIp() async {

  try{
    var ipAddress = IpAddress(type: RequestType.json);

    dynamic data = await ipAddress.getIpAddress();

    return data.toString();

  } on IpAddressException catch (e){

    return '0.0.0.0';

  }

}