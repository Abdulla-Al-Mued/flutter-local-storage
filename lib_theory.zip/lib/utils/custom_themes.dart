import 'package:flutter/material.dart';


const titilliumRegular = TextStyle(
  fontSize: 12,
);


const titilliumSemiBold = TextStyle(
  fontSize: 12,
  fontWeight: FontWeight.w600,
);


const titilliumBold = TextStyle(
  fontSize: 14,
  fontWeight: FontWeight.w700,
);

// Italic text style
const titilliumItalic = TextStyle(
  fontSize: 14,
  fontStyle: FontStyle.italic,
);

// Title regular
TextStyle titleRegular({Color color = Colors.white}) {
  return TextStyle(
    fontWeight: FontWeight.w500,
    fontSize: 18,
    color: color, // Accepts color as a parameter
  );
}

// Title header
const titleHeaderAppBar = TextStyle(
  fontWeight: FontWeight.w600,
  fontSize: 20,
  color: Colors.white
);
const titleHeader = TextStyle(
    fontWeight: FontWeight.w600,
    fontSize: 25,
    color: Colors.white
);
// Generic text styles
const textRegular = TextStyle(
  fontWeight: FontWeight.w300,
  fontSize: 14,
);

// Medium weight text
const textMedium = TextStyle(
  fontSize: 14,
  fontWeight: FontWeight.w500,
);

// Bold text
const textBold = TextStyle(
  fontSize: 14,
  fontWeight: FontWeight.w600,
);


