import 'package:sqflite/sqflite.dart';

class DataDownloadIntoSql {
  Future<void> downloadData({
    required Map<String, dynamic> data,
    required String tableName,
    required Transaction txn, // Ensure you're using the transaction
  }) async {
    try {
      // Use the provided txn (transaction) for the insert
      await txn.insert(
        tableName,
        data,
        conflictAlgorithm: ConflictAlgorithm.replace,
      );
    } catch (e) {
      // Handle errors properly (optional logging)
      print("Error during data insertion: $e");
      rethrow;  // rethrow the error to handle it at a higher level if needed
    }
  }
}
