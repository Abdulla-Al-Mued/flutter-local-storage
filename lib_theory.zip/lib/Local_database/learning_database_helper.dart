// import 'package:sqflite/sqflite.dart';
// import 'package:theory_test_ltd/features/theory_test/domain/models/category_model.dart';
// import 'package:theory_test_ltd/features/theory_test/domain/models/question_model.dart';
//
// class DatabaseHelper {
//   static Database? _database;
//
//   // Lazy initialization of the database
//   static Future<Database> get database async {
//     if (_database != null) return _database!;
//     // Path to the database
//     var databasesPath = await getDatabasesPath();
//     String path = databasesPath + 'theory_test.db';
//
//     // Open the database
//     _database = await openDatabase(path, version: 1);
//     return _database!;
//   }
//
//   // Fetch Categories
//   static Future<List<Category>> fetchCategories() async {
//     final db = await database;
//
//     // SQL query to fetch categories
//     final List<Map<String, dynamic>> maps = await db.query('THRY_TEST_TYPE_DTL_CAT');
//
//     return List.generate(maps.length, (i) {
//       return Category(
//         id: maps[i]['id'],
//         name: maps[i]['name'],
//         // Add other necessary fields as required
//       );
//     });
//   }
//
//   // Fetch Questions for a specific Category
//   static Future<List<Question>> fetchQuestionsForCategory(String categoryId) async {
//     final db = await database;
//
//     // SQL query to fetch questions for a specific category
//     final List<Map<String, dynamic>> maps = await db.query(
//         'THRY_TEST_QUESTION_ANS',
//         where: 'category_id = ?',
//         whereArgs: [categoryId]
//     );
//
//     return List.generate(maps.length, (i) {
//       return Question(
//         id: maps[i]['id'],
//         questionText: maps[i]['question_text'],
//         correctAnswer: maps[i]['correct_answer'],
//         // Add other necessary fields as required
//       );
//     });
//   }
// }
