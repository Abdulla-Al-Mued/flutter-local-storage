
import 'package:sqflite/sqflite.dart';

class LocalDatabaseHandler{

/*===================>
  Variables Declaring
  <===================*/
  final String dbName = 'THEORY_TEST.db';
  final int dbVersion = 1;
  Database? _database;
  String dbPath = '';

  /*===================>
  Checking Database Available or Not
  <===================*/
  Future<Database?> get getDatabase async {
    if (_database != null) return _database;
    _database = await initDatabase();
    return _database;
  }

  /*===================>
  Initializing Database and Opening Database
  <===================*/
  Future<Database> initDatabase() async {
    //Directory? documentsDirectory = await getExternalStorageDirectory();
    try {
      //  dbPath = join(documentsDirectory!.path, dbName);
      var database = await openDatabase(dbName, version: dbVersion, onUpgrade: _onUpgrade);
      // print("check path");
      // print(database.path);
      return database;
    } catch (e) {
      rethrow;
    }
  }

  Future<void> _onUpgrade(Database db, int oldVersion, int newVersion) async {
    if (oldVersion < 2) {
      // Perform schema updates when upgrading to version 2
      //await db.execute('ALTER TABLE users ADD COLUMN age INTEGER');
      print("old version $oldVersion");
    }

    // Future versions can be handled similarly:
    // if (oldVersion < 3) {
    //   // Perform updates for version 3
    // }
  }

  /*===================>
  Checking Database is Exist or Not
  <===================*/
  Future<bool> doesTableExist({required String tableName}) async {
    try {
      Database? db = await getDatabase;
      List<Map<String, Object?>> tables =
      await db!.query('sqlite_master', columns: ['name']);
      final data = tables
          .any((Map<String, dynamic> table) => table['name'] == tableName);
      return data;
    } catch (e) {
      rethrow;
    }
  }

  /*===================>
    Creating Database Table
    <===================*/
  Future<void> createTable({required String sqlInject}) async {
    Database? db = await getDatabase;
    try {
      await db!.execute(sqlInject);
    } catch (e) {
      rethrow;
    }
  }


  Future<List<Map<String, dynamic>>> getHazardVideos() async {
    Database? db = await getDatabase;
    try {
      return await db!.query('HAZARD_VIDEO_MST');
    } catch (e) {
      rethrow;
    }
  }

  Future<List<Map<String, dynamic>>> getResultsFromMockTestLog() async {
    final db = await getDatabase;
    return await db!.query(
      'THT_CUST_MOCK_TEST_LOG',
      orderBy: 'EXAM_DATE DESC', // Sorts the results by exam date in descending order
    );
  }

  Future<int> getTotalMistakes() async {
    Database? db = await getDatabase;
    try {
      final result = await db!.rawQuery(
          'SELECT COUNT(*) as count FROM THT_CUST_MISTAKE_QUES_ANS'
      );
      return Sqflite.firstIntValue(result) ?? 0; // Return the count value
    } catch (e) {
      rethrow;
    }
  }



}