class TrafficSignData {
  int id;
  String assets;
  String title;
  String category;

  TrafficSignData({
    required this.id,
    required this.assets,
    required this.title,
    required this.category,
  });

  factory TrafficSignData.fromJson(Map<String, dynamic> json) {
    return TrafficSignData(
      id: json['id'],
      assets: json['assets'],
      title: json['title'],
      category: json['category'],
    );
  }


  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'assets': assets,
      'title': title,
      'category': category,
    };
  }
}


List<TrafficSignData> trafficSignData = [
  TrafficSignData(id: 1, assets: "assets/html/road_sign/the_signing_system.html", title: "The signing system", category: "Introduction"),
  TrafficSignData(id: 2, assets: "assets/html/road_sign/warning_signs.html", title: "Warning signs", category: "Warning"),
  TrafficSignData(id: 3, assets: "assets/html/road_sign/regulatory_signs.html", title: "Regulatory signs", category: "Regulatory"),
  TrafficSignData(id: 4, assets: "assets/html/road_sign/speed_limit_signs.html", title: "Speed limit signs", category: "Speed"),
  TrafficSignData(id: 5, assets: "assets/html/road_sign/low_bridge_signs.html", title: "Low bridge signs", category: "Bridge"),
  TrafficSignData(id: 6, assets: "assets/html/road_sign/level_crossing_signs_and_signals.html", title: "Level crossing signs and signals", category: "Crossing"),
  TrafficSignData(id: 7, assets: "assets/html/road_sign/tram_signs_signals_and_road_markings.html", title: "Tram signs, signals, and road markings", category: "Tram"),
  TrafficSignData(id: 8, assets: "assets/html/road_sign/bus_and_cycle_signs_and_road_markings.html", title: "Bus and cycle signs and road markings", category: "Bus & Cycle"),
  TrafficSignData(id: 9, assets: "assets/html/road_sign/pedestrian_zone_signs.html", title: "Pedestrian zone signs", category: "Pedestrian"),
  TrafficSignData(id: 10, assets: "assets/html/road_sign/on_street_parking_control_signs_and_road_markings.html", title: "On street parking control signs and road markings", category: "Parking"),
  TrafficSignData(id: 11, assets: "assets/html/road_sign/road_markings.html", title: "Road markings", category: "Markings"),
  TrafficSignData(id: 12, assets: "assets/html/road_sign/traffic_calming.html", title: "Traffic calming", category: "Calming"),
  TrafficSignData(id: 13, assets: "assets/html/road_sign/motorway_signs_signals_and_road_markings.html", title: "Motorway signs, signals, and road markings", category: "Motorway"),
  TrafficSignData(id: 14, assets: "assets/html/road_sign/direction_signs_on_all_purpose_roads.html", title: "Direction signs on all-purpose roads", category: "Direction"),
  TrafficSignData(id: 15, assets: "assets/html/road_sign/direction_signs_for_cyclists_and_pedestrians.html", title: "Direction signs for cyclists and pedestrians", category: "Cyclists & Pedestrians"),
  TrafficSignData(id: 16, assets: "assets/html/road_sign/information_signs.html", title: "Information signs", category: "Information"),
  TrafficSignData(id: 17, assets: "assets/html/road_sign/traffic_signals.html", title: "Traffic signals", category: "Signals"),
  TrafficSignData(id: 18, assets: "assets/html/road_sign/tidal_flow_lane_control_signs_and_signals.html", title: "Tidal flow lane control signs and signals", category: "Lane Control"),
  TrafficSignData(id: 19, assets: "assets/html/road_sign/pedestrian_cycle_and_equestrian_crossings.html", title: "Pedestrian, cycle, and equestrian crossings", category: "Crossings"),
  TrafficSignData(id: 20, assets: "assets/html/road_sign/signs_for_road_works_and_temporary_situations.html", title: "Signs for road works and temporary situations", category: "Road Works"),
  TrafficSignData(id: 21, assets: "assets/html/road_sign/miscellaneous_signs.html", title: "Miscellaneous signs", category: "Miscellaneous"),
];
