// import 'package:theory_test_ltd/features/theory_test/domain/models/question_model.dart';
//
// List<Question> mockQuestions = [
//   Question(
//     questionText: "What does this sign indicate?",
//     questionImage: "assets/images/adi.png",
//     options: ["Stop", "Yield", "No Entry", "Parking Allowed"],
//     answerIndex: 2,
//     explanation: "This sign indicates no entry for vehiclesThe first image represents a 'Pedestrian Crossing' signThe first image represents a 'Pedestrian Crossing' signThe first image represents a 'Pedestrian Crossing' sign.",
//     referencePath: "assets/html/road_sign/warning_signs.html",
//   ),
//   Question(
//     questionText: "Which of the following images represents a 'Stop' sign?",
//     optionImages: [
//       "assets/html/across-carriageway-give-way-traffic-from-right-miniroundabout.jpg",
//       "assets/html/across-carriageway-stop-line-at-stop-sign.jpg",
//       "assets/html/along-carriageway-diagonal-line.jpg",
//       "assets/html/along-carriageway-double-white-broken-line.jpg",
//     ],
//     answerIndex: 0,
//     explanation: "This sign indicates no entry for vehiclesThe first image represents a 'Pedestrian Crossing' signThe first image represents a 'Pedestrian Crossing' signThe first image represents a 'Pedestrian Crossing' sign.",
//     referencePath: "assets/html/road_sign/warning_signs.html",
//   ),
//   Question(
//     questionText: "What does this road sign mean?",
//     questionImage: "assets/html/car-arm-signal-turn-left2.jpg",
//     options: ["No Overtaking", "Pedestrian Crossing", "Road Narrows", "Give Way"],
//     answerIndex: 1,
//     explanation: "This sign indicates no entry for vehiclesThe first image represents a 'Pedestrian Crossing' signThe first image represents a 'Pedestrian Crossing' signThe first image represents a 'Pedestrian Crossing' sign.",
//     referencePath: "assets/html/road_sign/information_signs.html",
//   ),
//   Question(
//     questionText: "Which of the following images represents a 'Yield' sign?",
//     optionImages: [
//       "assets/html/car-arm-signals-turn-right.jpg",
//       "assets/html/car-arm-signal-slow-stop.jpg",
//       "assets/html/car-arm-signal-turn-left2.jpg",
//       "assets/html/car-arm-signal-turn-right.jpg",
//     ],
//     answerIndex: 2,
//     explanation: "The second image represents a 'Yield' sign.",
//     referencePath: "assets/html/road_sign/warning_signs.html",
//   ),
//   Question(
//     questionText: "What does this traffic sign indicate?",
//     questionImage: "assets/html/car-arm-signal-turn-left2.jpg",
//     options: ["No Parking", "No Entry", "Pedestrian Only", "Bicycles Only"],
//     answerIndex: 1,
//     explanation: "This sign indicates no entry for vehicles.",
//     referencePath: "assets/html/road_sign/warning_signs.html",
//   ),
//   Question(
//     questionText: "Which of the following images represents a 'No Parking' sign?",
//     optionImages: [
//       "assets/html/car-arm-signals-turn-right.jpg",
//       "assets/html/car-arm-signal-slow-stop.jpg",
//       "assets/html/car-arm-signal-turn-left2.jpg",
//       "assets/html/car-arm-signal-turn-right.jpg",
//     ],
//     answerIndex: 3,
//     explanation: "The first image represents a 'No Parking' sign.",
//     referencePath: "assets/html/road_sign/regulatory_signs.html",
//   ),
//   Question(
//     questionText: "What does this sign indicate?",
//     questionImage: "assets/html/Rule_124b.jpg",
//     options: ["Speed Limit", "Stop", "Yield", "No Overtaking"],
//     answerIndex: 1,
//     explanation: "This sign indicates the speed limit for vehicles.",
//     referencePath: "assets/html/road_sign/regulatory_signs.html",
//   ),
//   Question(
//     questionText: "Which of the following images represents a 'Pedestrian Crossing' sign?",
//     optionImages: [
//       "assets/html/car-arm-signal-turn-left2.jpg",
//       "assets/html/car-arm-signal-turn-right.jpg",
//       "assets/html/car-arm-signal-turn-left2.jpg",
//       "assets/html/car-arm-signal-turn-right.jpg",
//     ],
//     answerIndex: 0,
//     explanation: "This sign indicates no entry for vehiclesThe first image represents a 'Pedestrian Crossing' signThe first image represents a 'Pedestrian Crossing' signThe first image represents a 'Pedestrian Crossing' sign.",
//
//   ),
//   Question(
//     questionText: "What does this road sign indicate?",
//     questionImage: "assets/html/hazard-warning-oxidising-plate.jpg",
//     options: ["One Way", "No Entry", "Roundabout", "No Stopping"],
//     answerIndex: 2,
//     explanation: "This sign indicates a one-way road.",
//     referencePath: "assets/html/road_sign/regulatory_signs.html",
//   ),
//   Question(
//     questionText: "Which of the following images represents a 'Roundabout' sign?",
//     optionImages: [
//       "assets/html/car-arm-signal-turn-right.jpg",
//       "assets/html/car-arm-signal-turn-left2.jpg",
//       "assets/html/car-arm-signal-slow-stop.jpg",
//       "assets/html/car-arm-signal-turn-left2.jpg",
//     ],
//     answerIndex: 3,
//     explanation: "The first image represents a 'Roundabout' sign.",
//     referencePath: "assets/html/road_sign/warning_signs.html",
//   ),
// ];
