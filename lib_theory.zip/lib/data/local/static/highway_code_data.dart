class HighwayCodeDte {
  int id;
  String assets;
  String title;

  HighwayCodeDte({required this.id, required this.assets, required this.title});


  factory HighwayCodeDte.fromJson(Map<String, dynamic> json) {
    return HighwayCodeDte(
      id: json['id'],
      assets: json['assets'],
      title: json['title'],
    );
  }


  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'assets': assets,
      'title': title,
    };
  }
}


List<HighwayCodeDte> highwayCodeData = [
  HighwayCodeDte(id: 1, assets: "assets/html/introduction.html", title: "Introduction"),
  HighwayCodeDte(id: 2, assets: "assets/html/rules_for_pedestrians.html", title: "Rules for pedestrians (1 to 35)"),
  HighwayCodeDte(id: 3, assets: "assets/html/rules_for_users_of_powered_wheelchairs_and_mobility_scooters_36_46.html", title: "Rules for users of powered wheelchairs and mobility scooters (36 to 46)"),
  HighwayCodeDte(id: 4, assets: "assets/html/rules_about_animals_47_58.html", title: "Rules about animals (47 to 58)"),
  HighwayCodeDte(id: 5, assets: "assets/html/rules_for_cyclists_59_82.html", title: "Rules for cyclists (59 to 82)"),
  HighwayCodeDte(id: 6, assets: "assets/html/rules_for_motorcyclists_83_88.html", title: "Rules for motorcyclists (83 to 88)"),
  HighwayCodeDte(id: 7, assets: "assets/html/rules_for_drivers_and_motorcyclists_89_102.html", title: "Rules for drivers and motorcyclists (89 to 102)"),
  HighwayCodeDte(id: 8, assets: "assets/html/general_rules_techniques_and_advice_for_all_drivers_and_riders_103_158.html", title: "General rules, techniques and advice for all drivers and riders (103 to 158)"),
  HighwayCodeDte(id: 9, assets: "assets/html/using_the_road_159_203.html", title: "Using the road (159 to 203)"),
  HighwayCodeDte(id: 10, assets: "assets/html/road_users_requiring_extra_care_204_225.html", title: "Road users requiring extra care (204 to 225)"),
  HighwayCodeDte(id: 11, assets: "assets/html/driving_in_adverse_weather_conditions_226_237.html", title: "Driving in adverse weather conditions (226 to 237)"),
  HighwayCodeDte(id: 12, assets: "assets/html/waiting_and_parking_238_252.html", title: "Waiting and parking (238 to 252)"),
  HighwayCodeDte(id: 13, assets: "assets/html/motorways_253_274.html", title: "Motorways (253 to 274)"),
  HighwayCodeDte(id: 14, assets: "assets/html/breakdowns_and_incidents_275_287.html", title: "Breakdowns and incidents (275 to 287)"),
  HighwayCodeDte(id: 15, assets: "assets/html/road_works_level_crossings_and_tramways_288_307.html", title: "Road works, level crossings and tramways (288 to 307)"),
  HighwayCodeDte(id: 16, assets: "assets/html/light_signals_controlling_traffic.html", title: "Light signals controlling traffic"),
  HighwayCodeDte(id: 17, assets: "assets/html/signals_to_other_road_users.html", title: "Signals to other road users"),
  HighwayCodeDte(id: 18, assets: "assets/html/signals_by_authorised_persons.html", title: "Signals by authorised persons"),
  HighwayCodeDte(id: 19, assets: "assets/html/traffic_signs.html", title: "Traffic signs"),
  HighwayCodeDte(id: 20, assets: "assets/html/road_markings.html", title: "Road markings"),
  HighwayCodeDte(id: 21, assets: "assets/html/vehicle_markings.html", title: "Vehicle markings"),
  HighwayCodeDte(id: 22, assets: "assets/html/annex_1.html", title: "Annex 1. You and your bicycle"),
  HighwayCodeDte(id: 23, assets: "assets/html/annex_2.html", title: "Annex 2. Motorcycle licence requirements"),
  HighwayCodeDte(id: 24, assets: "assets/html/annex_3.html", title: "Annex 3. Motor vehicle documentation and learner driver requirements"),
  HighwayCodeDte(id: 25, assets: "assets/html/annex_4.html", title: "Annex 4. The road user and the law"),
  HighwayCodeDte(id: 26, assets: "assets/html/annex_5.html", title: "Annex 5. Penalties"),
  HighwayCodeDte(id: 27, assets: "assets/html/annex_6.html", title: "Annex 6. Vehicle maintenance, safety and security"),
  HighwayCodeDte(id: 28, assets: "assets/html/annex_7.html", title: "Annex 7. First aid on the road"),
  HighwayCodeDte(id: 29, assets: "assets/html/annex_8.html", title: "Annex 8. Safety code for new drivers"),
  HighwayCodeDte(id: 30, assets: "assets/html/updates.html", title: "Updates: The Highway Code"),
  HighwayCodeDte(id: 31, assets: "assets/html/other_information.html", title: "Other information"),
  // HighwayCodeDte(id: 32, assets: "assets/html/index.html", title: "A-Z Index")
];

