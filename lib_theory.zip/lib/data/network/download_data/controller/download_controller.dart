import 'package:flutter/material.dart';
import 'package:theory_test_ltd/Local_database/Local_database_handler.dart';
import 'package:theory_test_ltd/Local_database/data_download_into_sql.dart';
import 'package:theory_test_ltd/data/network/download_data/domain/repository/download_repository.dart';
import 'package:theory_test_ltd/data/network/download_data/domain/repository/download_repository_imp.dart';

class DownloadController extends ChangeNotifier {
  DownloadRepository downloadRepository = DownloadRepositoryImp();

  bool _isLoading = false;
  bool _isDeleting = false;
  String? _errorMessage;
  List<dynamic> _downloadedData = [];


  bool get isLoading => _isLoading;
  List<dynamic> get downloadedData => _downloadedData;

  double downloadProgress = 0.0;
  //double get downloadProgress => _downloadProgress;


  bool get isDownloading => _isDeleting;
  String? get errorMessage => _errorMessage;

  void calculateProgress(double progress){
    downloadProgress = progress;
    // print("PROGRESS: $_downloadProgress");
    if(progress == 1.0){
      downloadProgress = 0.0;
    }
    notifyListeners();
  }

  Future<bool> downloadData(
      String id, String vehicle, String previousVehicle) async {
    _isLoading = true;
    _errorMessage = null;

    if (previousVehicle.isNotEmpty) {

      _isDeleting = true;
      notifyListeners();

      try {

        downloadRepository.deleteImageData(previousVehicle);

      } catch (e) {

        _errorMessage = e.toString();
        print("controller1$e");
        _isDeleting = false;
        notifyListeners();
        return false;

      }

      _isDeleting = false;
      notifyListeners();

    }else{
      _isDeleting = false;
    }

    notifyListeners();

    try {
      var totalData = await downloadRepository.getData("thry_download_data.php", {"P_TEST_TYPE_DTL_ID": id});

      await downloadSingleTable(totalData["test_type_mst"], "TEST_TYPE_MST");
      await downloadSingleTable(totalData["theory_test_type_dtl"], "THEORY_TEST_TYPE_DTL");
      await downloadSingleTable(totalData["thry_test_type_dtl_dtl"], "THRY_TEST_TYPE_DTL_DTL");
      await downloadSingleTable(totalData["thry_test_type_dtl_cat"], "THRY_TEST_TYPE_DTL_CAT");
      await downloadSingleTable(totalData["thry_test_question_ans"], "THRY_TEST_QUESTION_ANS");
      await downloadSingleTable(totalData["hazard_video_mst"], "HAZARD_VIDEO_MST");

      // Fetch the latest data and notify listeners after download
      await _fetchDownloadedData();
      notifyListeners();

      downloadSingleTable(totalData["test_type_mst"], "TEST_TYPE_MST");
      downloadSingleTable(totalData["theory_test_type_dtl"], "THEORY_TEST_TYPE_DTL");
      downloadSingleTable(totalData["thry_test_type_dtl_dtl"], "THRY_TEST_TYPE_DTL_DTL");
      downloadSingleTable(totalData["thry_test_type_dtl_cat"], "THRY_TEST_TYPE_DTL_CAT");
      downloadSingleTable(totalData["thry_test_question_ans"], "THRY_TEST_QUESTION_ANS");
      downloadSingleTable(totalData["hazard_video_mst"], "HAZARD_VIDEO_MST");
      downloadSingleTable([], "THT_CUST_MISTAKE_QUES_ANS");
      downloadSingleTable([], "THT_CUST_MOCK_TEST_LOG");
      downloadSingleTable([], "THT_CUST_MOCK_TEST_QUES_ANS");
      downloadSingleTable([], "THT_CUST_TOPIC_READ_QUES_ANS");
      downloadSingleTable([], "THRY_TEST_MOCK_SETS_QUESTION_ANS");
      downloadSingleTable([], "THT_CUST_FAVORITE_QUES_ANS");


    } catch (error) {

      _errorMessage = error.toString();
      print("controller1" + error.toString());
      return false;

    }

    try {
      await downloadRepository.getImageData(vehicle, this);
    } catch (e) {
      _errorMessage = e.toString();
      print("controller12" + e.toString());
      return false;
    } finally {
      _isLoading = false;
      notifyListeners();
      return true;
    }
  }

  Future<void> _fetchDownloadedData() async {
    final _database = await LocalDatabaseHandler().getDatabase;
    List<Map<String, dynamic>> data = await _database!.query("TEST_TYPE_MST");

    _downloadedData = data; // Update the downloaded data
    notifyListeners(); // Notify the UI about the updated data
  }

  Future<void> downloadSingleTable(List totalData, String tableName) async {
    final _database = await LocalDatabaseHandler().getDatabase;

    // Start the transaction
    await _database?.transaction((txn) async {
      int dataLength = totalData.length;

      final countResult = await txn.rawQuery('SELECT COUNT(*) FROM $tableName');
      final count = countResult?.first.values.first as int? ?? 0;

      if (count > 0) {
        print("DELETE $tableName");
        await txn.rawQuery('DELETE FROM $tableName');
      } else {
        print("Empty Database: $tableName");
      }

      if (dataLength > 0) {
        for (int i = 0; i < dataLength; i++) {
          await DataDownloadIntoSql().downloadData(
            data: totalData[i],
            tableName: tableName,
            txn: txn, // Pass the transaction here
          );
        }
      }
    });
  }

}
