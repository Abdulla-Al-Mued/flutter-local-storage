import 'dart:io';
import 'package:flutter/material.dart';
import 'package:path_provider/path_provider.dart';
import 'package:http/http.dart' as http;
import '../../../../../utils/api_constant.dart';

/// Downloads an image from a given URL and saves it locally
Future<void> downloadImage(String fileName, String vehicleType) async {

  try {
    // Step 1: Get local storage directory
    Directory directory = await getApplicationDocumentsDirectory();
    String folderPath = '${directory.path}/$vehicleType'; // Ensure subdirectory
    String filePath = '$folderPath/$fileName';

    // Step 2: Ensure the directory exists
    Directory folder = Directory(folderPath);
    if (!await folder.exists()) {
      await folder.create(recursive: true);


      // Save folderPath in SharedPreferences

    }

    File file = File(filePath);

    // Step 3: Check if the file already exists
    if (await file.exists()) {
      return; // Skip downloading
    }

    // Step 4: Construct full image URL
    String fullImageUrl = "$imageDownloadUrl$vehicleType/$fileName";
    // Debugging

    // Step 5: Download the image
    var response = await http.post(Uri.parse(fullImageUrl));

    if (response.statusCode == 200) {

      await file.writeAsBytes(response.bodyBytes);

    } else {

    }

    // Step 6: Verify if the file was saved successfully
    if (await file.exists()) {
    } else {
    }
  } catch (e) {
  }

}


// sample retrieving from local storage image
Future<void> showImageDialog(BuildContext context, String fileName, String vehicleType) async {
  try {
    // Step 1: Get local storage directory
    Directory directory = await getApplicationDocumentsDirectory();
    String filePath = '${directory.path}/$vehicleType/$fileName';
    //String filePath = '/data/user/0/com.example.theory_test_ltd/app_flutter/motorcycle/ab2246_008.gif';
    File imageFile = File(filePath);

    // Step 2: Check if file exists
    if (await imageFile.exists()) {
      // Step 3: Show the dialog with image
      showDialog(
        context: context,
        builder: (context) {
          return AlertDialog(
            title: Text("Vehicle Image"),
            content: Image.file(imageFile, fit: BoxFit.cover), // Load the image
            actions: [
              TextButton(
                onPressed: () => Navigator.pop(context),
                child: Text("Close"),
              ),
            ],
          );
        },
      );
    } else {
      // Step 4: Show error if image does not exist
      showDialog(
        context: context,
        builder: (context) {
          return AlertDialog(
            title: Text("Error"),
            content: Text("Image not found!"),
            actions: [
              TextButton(
                onPressed: () => Navigator.pop(context),
                child: Text("OK"),
              ),
            ],
          );
        },
      );
    }
  } catch (e) {

  }
}
