import 'dart:io';
import 'package:path_provider/path_provider.dart';

Future<void> deleteVehicleImages(String vehicleType) async {
  try {
    // Step 1: Get local storage directory
    Directory directory = await getApplicationDocumentsDirectory();
    String folderPath = '${directory.path}/$vehicleType';
    Directory folder = Directory(folderPath);


    // if (await folder.exists()) {
    //   // Step 3: Delete the folder and all of its contents recursively
    //   await folder.delete(recursive: true);
    //   print("Deleted folder and its contents: $folderPath");
    // } else {
    //   print("Folder does not exist: $folderPath");
    // }

    //Step 2: Check if folder exists
    if (await folder.exists()) {
      // Step 3: Delete all files inside the folder
      List<FileSystemEntity> files = folder.listSync();
      for (FileSystemEntity file in files) {
        if (file is File) {
          await file.delete();
        }
      }

      // Step 4: Delete the folder itself
      await folder.delete();
    } else {
    }
  } catch (e) {
  }
}