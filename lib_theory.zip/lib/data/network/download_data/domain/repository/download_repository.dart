import 'package:theory_test_ltd/data/network/download_data/controller/download_controller.dart';

abstract class DownloadRepository{

  Future<dynamic> getData(String endPoint, Object data);

  Future<dynamic> getImageData(String vehicleType, DownloadController downloadController);

  void deleteImageData(String vehicleType);

}