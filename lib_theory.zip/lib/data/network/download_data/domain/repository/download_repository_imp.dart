import 'package:theory_test_ltd/api/api_call.dart';
import 'package:theory_test_ltd/api/api_interface.dart';
import 'package:theory_test_ltd/data/network/download_data/domain/repository/download_repository.dart';
import 'package:theory_test_ltd/data/network/download_data/domain/service/RemoveImageService.dart';

import '../../controller/download_controller.dart';

class DownloadRepositoryImp extends DownloadRepository{


  final ApiInterface apiInterface = ApiHandler();

  @override
  Future getData(String endPoint, Object data) {

    return apiInterface.getData(endPoint, data);
  }

  @override
  Future getImageData(String vehicleType,DownloadController downloadController) {

    return apiInterface.getImageData(vehicleType, downloadController);
  }

  @override
  void deleteImageData(String vehicleType) {

    deleteVehicleImages(vehicleType);

  }




}