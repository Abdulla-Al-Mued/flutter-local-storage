
import 'package:flutter/material.dart';
import 'package:get/get.dart';

void navigateTo(Widget Function() screen) {
  Get.to(
    screen(),
    transition: Transition.rightToLeft,
    duration: const Duration(milliseconds: 300),
  );
}
