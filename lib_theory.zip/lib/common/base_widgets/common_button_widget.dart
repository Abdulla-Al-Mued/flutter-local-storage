import 'package:flutter/material.dart';
import 'package:theory_test_ltd/common/base_widgets/screen_config.dart';
import 'package:theory_test_ltd/utils/color_resources.dart';

class CommonButtonWidget extends StatelessWidget {
  final VoidCallback onPressed;
  final String buttonText;
  final double borderRadius;
  final Color borderColor;
  final EdgeInsetsGeometry padding;
  final Color buttonColor;

  const CommonButtonWidget({
    super.key,
    required this.onPressed,
    required this.buttonText,
    this.borderRadius = 8.0,
    this.borderColor = AppColors.white,
    this.padding = const EdgeInsets.symmetric(vertical: 8.0),
    this.buttonColor = AppColors.primary,
  });

  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(
      builder: (context, constraints) {
        // Get screen config with BoxConstraints
        ScreenConfig config = getScreenConfig(constraints, context);

        return Padding(
          padding: padding,
          child: ElevatedButton(
            onPressed: onPressed,
            style: ElevatedButton.styleFrom(
              minimumSize: const Size(double.infinity, 50),
              backgroundColor: buttonColor, // Set button background color
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(borderRadius),
                side: BorderSide(color: borderColor), // Use separate border color
              ),
            ),
            child: Text(
              buttonText,
              style: TextStyle(
                color: AppColors.white,
                fontSize: config.fontSizeSubtitle,
              ),
            ),
          ),
        );
      },
    );
  }
}
