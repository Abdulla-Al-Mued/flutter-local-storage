
import 'package:flutter/material.dart';

class ScreenConfig {
  final bool isTablet;
  final double topCurveHeight;
  final int gridCrossAxisCount;
  final double fontSizeTitle;
  final double fontSizeSubtitle;
  final double menuFontSize;
  final double iconSize;
  final double homeAvatar;
  final double menuIconSize;
  final double categoryIconSize;
  final double fontSizeCategory;
  final double fontSizeDashboard;

  ScreenConfig({
    required this.isTablet,
    required this.topCurveHeight,
    required this.gridCrossAxisCount,
    required this.fontSizeTitle,
    required this.menuFontSize,
    required this.fontSizeSubtitle,
    required this.iconSize,
    required this.homeAvatar,
    required this.menuIconSize,
    required this.categoryIconSize,
    required this.fontSizeCategory,
    required this.fontSizeDashboard,
  });
}

ScreenConfig getScreenConfig(BoxConstraints constraints, BuildContext context) {
  bool isTablet = constraints.maxWidth >= 600;
  double topCurveHeight = isTablet ? MediaQuery.of(context).size.height * 0.40 : MediaQuery.of(context).size.height * 0.27;

  int gridCrossAxisCount = isTablet ? 3 : 2;
  double fontSizeTitle = isTablet ? 50 : 30;
  double fontSizeDashboard = isTablet ? 20 : 12;
  double fontSizeSubtitle = isTablet ? 30 : 18;
  double fontSizeCategory = isTablet ? 20 : 14;
  double menuFontSize = isTablet ? 25 : 15;
  double iconSize = isTablet ? 80 : 60;
  double categoryIconSize = isTablet ? 90 : 85;
  double homeAvatar = isTablet ? 80 : 40;
  double menuIconSize = isTablet ? 40 : 30;

  return ScreenConfig(
    isTablet: isTablet,
    topCurveHeight: topCurveHeight,
    gridCrossAxisCount: gridCrossAxisCount,
    fontSizeTitle: fontSizeTitle,
    fontSizeSubtitle: fontSizeSubtitle,
    menuFontSize: menuFontSize,
    homeAvatar: homeAvatar,
    iconSize: iconSize,
    menuIconSize: menuIconSize,
    categoryIconSize: categoryIconSize,
    fontSizeCategory: fontSizeCategory,
    fontSizeDashboard: fontSizeDashboard,
  );
}
