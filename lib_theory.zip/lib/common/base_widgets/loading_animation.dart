import 'package:flutter/material.dart';
import 'package:lottie/lottie.dart';
import 'package:theory_test_ltd/utils/images.dart';


class LoadingAnimation extends StatefulWidget {
  const LoadingAnimation({super.key});

  @override
  LoadingAnimationState createState() => LoadingAnimationState();
}

class LoadingAnimationState extends State<LoadingAnimation> with SingleTickerProviderStateMixin {
  late AnimationController _controller;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(vsync: this);
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Lottie.asset(
      Animations.loadingAnimation,
      controller: _controller,
      fit: BoxFit.fill,
      onLoaded: (composition) {

        _controller
          ..duration = composition.duration
          ..repeat();
      },
    );
  }
}
