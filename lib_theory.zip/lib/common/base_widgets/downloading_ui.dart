import 'package:flutter/material.dart';
import 'package:lottie/lottie.dart';
import 'package:provider/provider.dart';
import 'package:theory_test_ltd/utils/images.dart';

import '../../data/network/download_data/controller/download_controller.dart';

class LoadingAnimationDownload extends StatefulWidget {
  const LoadingAnimationDownload({super.key});

  @override
  LoadingAnimationState createState() => LoadingAnimationState();
}

class LoadingAnimationState extends State<LoadingAnimationDownload> with SingleTickerProviderStateMixin {
  late AnimationController _controller;
  double _progress = 0.0;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(vsync: this);
    //_simulateDownload();
  }

  void _simulateDownload() {
    Future.delayed(Duration(milliseconds: 500), () {
      if (mounted && _progress < 1.0) {
        setState(() {
          _progress += 0.1;
        });
        _simulateDownload();
      }
    });
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {

    final downloadController = Provider.of<DownloadController>(context, listen: false);

    return Consumer<DownloadController>(builder: (BuildContext context, DownloadController value, Widget? child) {

      return Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Lottie.asset(
            Animations.loadingAnimation,
            controller: _controller,
            fit: BoxFit.fill,
            onLoaded: (composition) {
              _controller
                ..duration = composition.duration
                ..repeat();
            },
          ),
          SizedBox(height: 20),
          Text(
            "Downloading: ${(value.downloadProgress *100).toInt()}%",
            style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Colors.white),
          ),
          SizedBox(height: 10),
          Container(
            padding: EdgeInsets.only(left: 20, right: 20),
            child: SizedBox(
              height: 10, // Adjust the height as needed
              child: LinearProgressIndicator(
                value: value.downloadProgress,
                borderRadius: BorderRadius.circular(5), // Optional: Add rounded corners
                backgroundColor: Colors.orange.shade200, // Background color
                valueColor: AlwaysStoppedAnimation<Color>(Colors.pink.shade400),
              ),
            ),
          ),
        ],
      );
    },);
  }
}
