import 'package:flutter/material.dart';
import 'package:intl/intl.dart';

class InputTextWidget extends StatelessWidget {
  final TextEditingController controller;
  final String labelText;
  final double borderRadius;
  final Color borderColor;
  final EdgeInsetsGeometry padding;
  final String? errorText;

  const InputTextWidget({
    super.key,
    required this.controller,
    required this.labelText,
    this.borderRadius = 8.0,
    this.borderColor = Colors.blue,
    this.padding = const EdgeInsets.symmetric(vertical: 10.0),
    this.errorText,
  });

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: padding,
      child: TextField(
        controller: controller,
        decoration: InputDecoration(
          labelText: labelText,
          errorText: errorText, // Display error text if provided
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(borderRadius),
            borderSide: BorderSide(color: borderColor),
          ),
        ),
      ),
    );
  }
}

class DatePickerWidget extends StatefulWidget {
  final TextEditingController controller;
  final String labelText;
  final double borderRadius;
  final Color borderColor;
  final EdgeInsetsGeometry padding;
  final String? errorText;
  final DateTime? initialDate;
  final DateTime? firstDate;
  final DateTime? lastDate;
  final bool allowPastDates;
  final ValueChanged<DateTime>? onDateSelected;

  const DatePickerWidget({
    super.key,
    required this.controller,
    required this.labelText,
    this.borderRadius = 8.0,
    this.borderColor = Colors.blue,
    this.padding = const EdgeInsets.symmetric(vertical: 10.0),
    this.errorText,
    this.initialDate,
    this.firstDate,
    this.lastDate,
    this.allowPastDates = false,
    this.onDateSelected,
  });

  @override
  _DatePickerWidgetState createState() => _DatePickerWidgetState();
}

class _DatePickerWidgetState extends State<DatePickerWidget> {
  late DateTime _selectedDate;
  late DateTime _firstDate;
  late DateTime _lastDate;

  @override
  void initState() {
    super.initState();

    // Set initial date
    _selectedDate = widget.initialDate ?? DateTime.now();

    // Set first date
    _firstDate = widget.firstDate ?? (widget.allowPastDates
        ? DateTime(1900)
        : DateTime.now());

    // Set last date
    _lastDate = widget.lastDate ?? DateTime(2101);

    // If controller has a date, parse it
    if (widget.controller.text.isNotEmpty) {
      try {
        _selectedDate = DateFormat('dd/MM/yyyy').parse(widget.controller.text);
      } catch (e) {
        // If parsing fails, use current date
        _selectedDate = DateTime.now();
      }
    }
  }

  Future<void> _selectDate(BuildContext context) async {
    final ThemeData theme = Theme.of(context);
    final DatePickerThemeData datePickerTheme = DatePickerThemeData(
      headerBackgroundColor: widget.borderColor,
      headerForegroundColor: Colors.white,
      confirmButtonStyle: TextButton.styleFrom(
        foregroundColor: widget.borderColor,
      ),
      cancelButtonStyle: TextButton.styleFrom(
        foregroundColor: Colors.red,
      ),
    );

    final DateTime? pickedDate = await showDatePicker(
      context: context,
      initialDate: _selectedDate,
      firstDate: _firstDate,
      lastDate: _lastDate,
      helpText: 'Select ${widget.labelText}',
      cancelText: 'Cancel',
      confirmText: 'Select',
      builder: (BuildContext context, Widget? child) {
        return Theme(
          data: theme.copyWith(
            datePickerTheme: datePickerTheme,
          ),
          child: child!,
        );
      },
    );

    if (pickedDate != null && pickedDate != _selectedDate) {
      setState(() {
        _selectedDate = pickedDate;
        widget.controller.text = DateFormat('dd/MM/yyyy').format(_selectedDate);
      });

      // Call onDateSelected callback if provided
      if (widget.onDateSelected != null) {
        widget.onDateSelected!(_selectedDate);
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: widget.padding,
      child: TextField(
        controller: widget.controller,
        readOnly: true,
        decoration: InputDecoration(
          labelText: widget.labelText,
          errorText: widget.errorText,
          suffixIcon: IconButton(
            icon: Icon(
              Icons.calendar_today,
              color: widget.borderColor,
            ),
            onPressed: () => _selectDate(context),
          ),
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(widget.borderRadius),
            borderSide: BorderSide(color: widget.borderColor),
          ),
        ),
        onTap: () => _selectDate(context),
      ),
    );
  }
}

