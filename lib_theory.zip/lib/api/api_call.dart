import 'dart:convert';
import 'package:theory_test_ltd/api/api_interface.dart';
import 'package:theory_test_ltd/data/network/download_data/controller/download_controller.dart';
import 'package:theory_test_ltd/data/network/download_data/domain/service/ImageDownloadService.dart';
import '../utils/api_constant.dart';
import 'package:http/http.dart' as http;

class ApiHandler extends ApiInterface{

  var client = http.Client();

  @override
  Future getData(String endPoint, Object data) async {

      final response = await client.post(
        Uri.parse('$baseUrl$endPoint'),
        body: jsonEncode(data),
      );

      var responseData = jsonDecode(response.body);

      if (response.statusCode == 200) {
        return responseData;
      } else {
        throw Exception('Request failed with status: ${response.statusCode}');
      }
  }

  @override
  Future getImageData(String vehicleType,DownloadController downloadController) async {

    final response = await client.post(
      Uri.parse(imageEndPointListUrl),
      body: jsonEncode({"vehicle_type": vehicleType}),
    );

    print(imageEndPointListUrl);

    var responseData = jsonDecode(response.body);


    print("IML: "+vehicleType);

    if (response.statusCode == 200) {

      // List<String> imageEndpoints = responseData;
      //print("IML: "+imageEndpoints.toString());

      // Step 2: Download each image using the full URL (baseUrl + endpoint)
      int totalImages = responseData.length;
      if (totalImages == 0) return true;

      for (int i = 0; i < totalImages; i++) {
        await downloadImage(responseData[i], vehicleType);

        // Correct progress calculation
        double progress = (i + 1) / totalImages;
        downloadController.calculateProgress(progress);
      }

      return true;
    } else {
      throw Exception('Request failed with status: ${response.statusCode}');
    }
  }

  // static Future<dynamic> downloadData(String endPoint, Object data) async {
  //   final response = await http.post(
  //     Uri.parse('$baseUrl$endPoint'),
  //     body: jsonEncode(data),
  //   );
  //
  //   var responseData = jsonDecode(response.body);
  //
  //   if (response.statusCode == 200) {
  //     return responseData;
  //   } else {
  //     throw Exception('Request failed with status: ${response.statusCode}');
  //   }
  //
  // }

}