import 'package:get_it/get_it.dart';
import 'package:theory_test_ltd/Local_database/Local_database_handler.dart';
import 'package:theory_test_ltd/features/profile/domain/repositories/reg_repository_implementation.dart';
import 'package:theory_test_ltd/features/profile/domain/repositories/registration_repository.dart';
import 'package:theory_test_ltd/features/profile/domain/services/registration_services.dart';
import 'package:theory_test_ltd/features/profile/controllers/registration_controller.dart';
import 'package:theory_test_ltd/features/theory_test/controllers/learning_controller.dart';


final GetIt getIt = GetIt.instance;

void setup() {
  // Register services
  getIt.registerLazySingleton<RegistrationService>(() => RegistrationService());

  // Register repositories
  getIt.registerLazySingleton<RegistrationRepository>(
        () => RegistrationRepositoryImpl(),
  );

  // Register controllers
  getIt.registerFactory<RegistrationController>(
        () => RegistrationController(repository: getIt<RegistrationRepository>()),
  );


  getIt.registerLazySingleton<LocalDatabaseHandler>(() => LocalDatabaseHandler());

  // Register LearningProvider as a singleton or factory depending on your needs
  getIt.registerFactory<LearningProvider>(() => LearningProvider(getIt<LocalDatabaseHandler>()));

}
