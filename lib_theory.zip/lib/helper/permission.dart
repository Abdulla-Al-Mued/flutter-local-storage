import 'package:flutter/material.dart';
import 'package:permission_handler/permission_handler.dart';

class PermissionHandler {
  final BuildContext context;

  PermissionHandler(this.context);

  // Request specific permission
  Future<PermissionStatus> requestPermission(Permission permission, {String? message}) async {
    // Check if permission is already granted
    if (await permission.isGranted) {
      return PermissionStatus.granted;
    }

    // Request permission
    PermissionStatus status = await permission.request();

    // Handle permission status
    switch (status) {
      case PermissionStatus.granted:
        return PermissionStatus.granted;

      case PermissionStatus.denied:
        _showSnackBar(message ?? 'Permission is required to proceed');
        return PermissionStatus.denied;

      case PermissionStatus.permanentlyDenied:
        _showPermanentDeniedSnackBar();
        return PermissionStatus.permanentlyDenied;

      default:
        return PermissionStatus.denied;
    }
  }

  // Show message when permission is denied
  void _showSnackBar(String message) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(message)),
    );
  }

  // Show message when permission is permanently denied
  void _showPermanentDeniedSnackBar() {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text('Please enable the required permission from settings.'),
        action: SnackBarAction(
          label: 'Open Settings',
          onPressed: () {
            openAppSettings();
          },
        ),
      ),
    );
  }
}
