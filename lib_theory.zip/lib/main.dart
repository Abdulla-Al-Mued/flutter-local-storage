import 'package:flutter/material.dart';
import 'package:get/get_navigation/src/root/get_material_app.dart';
import 'package:hive_flutter/hive_flutter.dart';
import 'package:provider/provider.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:theory_test_ltd/Local_database/Local_database_handler.dart';
import 'package:theory_test_ltd/common/base_widgets/loading_animation.dart';
import 'package:theory_test_ltd/common/base_widgets/screen_config.dart';
import 'package:theory_test_ltd/data/network/download_data/controller/download_controller.dart';
import 'package:theory_test_ltd/features/dashboard/screens/dashboard_screen.dart';
import 'package:theory_test_ltd/features/dashboard/screens/onboard_screen.dart';
import 'package:theory_test_ltd/features/hazard_perception/controllers/hazard_video_provider.dart';
import 'package:theory_test_ltd/features/hazard_perception/controllers/result_controller.dart';
import 'package:theory_test_ltd/features/hazard_perception/domain/repositories/harard_repository.dart';
import 'package:theory_test_ltd/features/profile/controllers/profile_controller.dart';
import 'package:theory_test_ltd/features/theory_test/controllers/learning_controller.dart';
import 'package:theory_test_ltd/features/theory_test/controllers/mistake_controller.dart';
import 'package:theory_test_ltd/features/theory_test/controllers/mock_test_controller.dart';
import 'package:theory_test_ltd/features/theory_test/controllers/result_controller.dart';
import 'package:theory_test_ltd/features/theory_test/controllers/theory_test_controller.dart';
import 'package:theory_test_ltd/getit_dl.dart';
import 'package:theory_test_ltd/utils/color_resources.dart';
import 'features/progress_status/controller/progress_controller.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  setup();
  await Hive.initFlutter();
  await Hive.openBox('favorites');
  await Hive.openBox('favorites_signs');

  runApp(
    MultiProvider(
      providers: [
        ChangeNotifierProvider(create: (_) => HazardVideoProvider(hazardRepository: HazardRepositoryImpl(),LocalDatabaseHandler()),),
        ChangeNotifierProvider(create: (_) => DownloadController()),
        ChangeNotifierProvider(create: (_) => ProfileProvider()),
        ChangeNotifierProvider(create: (_) => TheoryTestController()),
        ChangeNotifierProvider(create: (_) => ResultsProvider()),
        ChangeNotifierProvider(create: (_) => ProgressController()),
        ChangeNotifierProvider(create: (_) => LearningProvider(LocalDatabaseHandler())),
        ChangeNotifierProvider(create: (_) => HazardResultsController(LocalDatabaseHandler())),
        ChangeNotifierProvider(create: (_) => MistakeProvider(LocalDatabaseHandler())),
        ChangeNotifierProvider(create: (_) => MockTestProvider(LocalDatabaseHandler())),
        ChangeNotifierProvider(create: (_) => getIt<LearningProvider>()),
        Provider<LocalDatabaseHandler>(create: (context) => LocalDatabaseHandler(),),


      ],
      child: const MyApp(),
    ),
  );
}

class MyApp extends StatelessWidget {
   const MyApp({super.key});

  Future<bool> _isFirstTime() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    return prefs.getBool('onboardCompleted') ?? true;
  }

  // @override
  // Widget build(BuildContext context) {
  //
  //   return GetMaterialApp(
  //     debugShowCheckedModeBanner: false,
  //
  //     home: DashboardScreen(),
  //   );
  // }


  @override
  Widget build(BuildContext context) {
    return FutureBuilder<bool>(
      future: _isFirstTime(),
      builder: (context, snapshot) {
        if (snapshot.connectionState == ConnectionState.waiting) {
          return const Center(child: LoadingAnimation());
        }
        bool isFirstTime = snapshot.data ?? true;

        // Pass BoxConstraints instead of Size
        final screenConfig = getScreenConfig(
          BoxConstraints(maxWidth: MediaQuery.of(context).size.width, maxHeight: MediaQuery.of(context).size.height),
          context,
        );

        return GetMaterialApp(
          debugShowCheckedModeBanner: false,
          title: 'Theory Exam',
          theme: ThemeData(
            colorScheme: ColorScheme.fromSeed(
              seedColor: AppColors.primary,
              primary: AppColors.primary,
            ),
            useMaterial3: true,
          ),
          home: isFirstTime
              ? OnboardScreen(screenConfig: screenConfig)
              : const DashboardScreen(),

         // home: DashboardScreen(),

        );
      },
    );
  }
}